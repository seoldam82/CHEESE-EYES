// ── CHEESE EYES 여러 창: 창 간 실시간 동기화(BroadcastChannel) ──────────────
// 같은 프로필의 모든 대시보드 창이 함께 쓰는 채널 — 합방 판정 중계·표시 음량처럼
// 초당 여러 번 오가는 값 전용(docs/multi-window-design.md §3.8). 설정성 데이터는
// chrome.storage onChanged로 전파한다.
(function () {
  const channel = new BroadcastChannel('cheese-eyes-profile');
  const listeners = new Map(); // type -> Set<fn>

  channel.onmessage = (e) => {
    const msg = e.data;
    const set = msg && msg.type && listeners.get(msg.type);
    if (!set) return;
    set.forEach((fn) => {
      try { fn(msg.payload); } catch (err) {
        console.error('[CHEESE EYES] 창 간 동기화 리스너 오류:', err);
      }
    });
  };

  window.CheeseProfileSync = {
    send(type, payload) { channel.postMessage({ type, payload }); },
    on(type, fn) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type).add(fn);
      return () => { listeners.get(type)?.delete(fn); };
    }
  };
})();
