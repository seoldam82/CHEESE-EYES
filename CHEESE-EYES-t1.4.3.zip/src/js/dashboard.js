let presets = [];
let mainChannel = null;
let activeChatChannel = null;
// 채팅 2분할의 두 번째 칸 채널. activeChatChannel과 같을 수 없다(같은 hash iframe이 둘이면 프레임 조회가 꼬임).
let secondaryChatChannel = null;
let currentLayout = 'grid';
let chatVisible = false;
let queueSidebarVisible = false;
// 대기열(전역 단일). { videoId, title, channelName, targetHash } — targetHash=null이면 빈 슬롯 순서대로, 아니면 그 채널 전용.
let videoQueue = [];
// true면 슬롯이 자동으로 비어도 새 영상을 채우지 않는다(직접 삭제한 자리는 항상 빔).
let queuePaused = false;
let searchDebounceTimer = null;
let currentSearchKeyword = '';
let fetchedTagChannels = [];
let selectedTagChannels = [];
let channels = [];

const DEFAULT_MAIN_VOLUME = 100;
const DEFAULT_CHANNEL_VOLUME = 100;
const DEFAULT_SUB_VOLUME = 25;

// 그리드 채널 수 상한. 합방 파형 비교 비용 때문(docs/collab-auto-grouping-design.md §3). 줄여도 기존 채널은 유지.
const DEFAULT_MAX_CHANNELS = 12;
const MAX_CHANNELS_INPUT_MIN = 1;
const MAX_CHANNELS_INPUT_MAX = 50;

// collabGroups: [{ id, memberHashes, mode: 'live'|'vod-sync', vodOffsetSecByHash }] — 저장되는 건 VOD 싱크 그룹뿐(라이브는 자동 편성).
// 대표 채널 = mainChannel(§getCollabLeaderHash). vodStartTimeMsByHash: VOD 실제 방송 시작 시각 캐시(채널 속성이라 최상위에 둠).
// collabGroupNames: {정렬된 멤버 hash '|' 결합: 이름} — 같은 조합이 다시 묶이면 재사용.
let audioState = { mainVolumeByChannel: {}, channelVolumeOverrides: {}, collabGroups: [], collabGroupNames: {}, collabGroupColors: {}, vodStartTimeMsByHash: {} };

// 채널별 평균 dBFS(content.js 보고). 미측정 채널은 키가 없다 — 무음과 구분해야 함.
let channelAudioLevels = {};

// 합방 유사도용 채널별 dB 이력(ring buffer {t, db}, 약 12초).
let channelAudioLevelHistory = {};

// 합방 겹침으로 강제 음소거 중인 hash. recomputeCollabMuting이 매 주기 다시 채운다.
let collabMutedHashes = new Set();

// 채널별 레이턴시(라이브 엣지까지 초, 3표본 이동평균). 대표 없는 클러스터의 타이브레이커로만 쓴다.
let channelLatencySecByHash = {};
let collabLatencySmoothBuffer = {};
const COLLAB_LATENCY_SMOOTH_SAMPLES = 3;
function smoothChannelLatency(hash, rawSec) {
  const buf = collabLatencySmoothBuffer[hash] || (collabLatencySmoothBuffer[hash] = []);
  buf.push(rawSec);
  if (buf.length > COLLAB_LATENCY_SMOOTH_SAMPLES) buf.shift();
  return buf.reduce((sum, v) => sum + v, 0) / buf.length;
}

const IFRAME_ALLOW = "autoplay *; fullscreen *; encrypted-media *; picture-in-picture *; local-network-access *; loopback-network *";

// ── 유튜브 중계(relay.html) ── chrome-extension:// 출처에선 임베드 오류153·live_chat embed_domain 차단이 나서
// 실제 도메인(GitHub Pages)의 중계 페이지로 감싼다.
const YT_RELAY_ORIGIN = 'https://seoldam82.github.io/CHEESE-EYES';
let displayChannels = [];
let isFirstZeroRemoved = false;
let channelAddOrder = [];

// 이 창에 그릴 채널만 고른다(원본 channels는 그대로). 평소엔 소유 창 기준(docs/multi-window-design.md §3.2).
let extendedMainSubActive = false;
let representativeExtendedActive = false; // 대표 창이 알린 확장 여부(storage.session extended_main_sub_active)
let sharedMainChannel = null; // storage main_channel — 대표 창이 남긴 메인 채널
// 타일 드래그 데이터 { hash, sec } — 다른 창으로 끌어도 재생 위치를 이어받게.
const CHANNEL_DRAG_MIME = 'application/x-cheese-channel';

function isChannelShownInThisWindow(hash) {
  if (extendedMainSubActive) return (hash === mainChannel) === isRepresentativeWindow();
  return isChannelOwnedByThisWindow(hash);
}

function getChannelsShownInThisWindow(list) {
  return list.filter((c) => isChannelShownInThisWindow(c.hash));
}

// VOD를 다른 창으로 옮길 때 현재 위치를 startSec에 싣는다. 실었으면 true.
function carryPlaybackPositionForWindowMove(hash, sec) {
  const ch = channels.find((c) => c.hash === hash);
  if (!ch || !(ch.isVod || (ch.platform === 'youtube' && ch.videoId))) return false;
  if (typeof sec !== 'number' || !isFinite(sec) || sec <= 1) return false;
  const rounded = Math.floor(sec);
  ch.startSec = rounded;
  const dc = displayChannels.find((c) => c.hash === hash);
  if (dc) dc.startSec = rounded;
  return true;
}

// ── 창 사이 합방 판정 ── 각 창은 자기 iframe 소리만 받으므로 대표 창만 판정하고(§3.8),
// 나머지 창은 dB·레이턴시를 넘기고 캡처 요청 중계·음소거 결과 적용만 한다(§syncChannel.js).
function isCollabRelayWorkerWindow() {
  return hasMultipleDashboardWindows() && !!windowSlotId && windowSlotId !== representativeSlotId;
}

function isCrossWindowCollabRelayActive() {
  return !!window.CheeseProfileSync && hasMultipleDashboardWindows();
}

function hasLocalChannelIframe(hash) {
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  return !!(iframe && iframe.contentWindow);
}

// 캡처 기록을 비워 다음 판정 때 다시 켜게 한다 — iframe이 새로 만들어지면 워클릿 캡처가 사라지므로.
function forgetCollabCaptureState() {
  collabCaptureHashes.clear();
  Object.keys(collabCaptureWindowSecByHash).forEach((h) => { delete collabCaptureWindowSecByHash[h]; });
}

// ── 창 사이 이동 중 합방 일시정지 ── 이동 중 판정이 겹치면 창이 멈췄다. 옮긴 채널이 재생되면
// (또는 COLLAB_MOVE_PAUSE_MAX_MS 뒤) 재개. 멈춤 상태는 storage.session으로 공유.
const COLLAB_MOVE_PAUSE_SESSION_KEY = 'collab_move_pause';
const COLLAB_MOVE_PAUSE_MAX_MS = 15000;
let collabMovePause = null; // { hashes: [옮기는 중인 채널], startedAt, until }
let collabMovePauseTimer = null;

function isCollabMovePaused() {
  return !!collabMovePause && Date.now() < collabMovePause.until;
}

function beginCollabMovePause(hashes) {
  if (!isCollabSettingEnabled() || !isWindowRegistered() || !hashes || hashes.length === 0) return;
  const now = Date.now();
  const prev = isCollabMovePaused() ? collabMovePause : null;
  const next = {
    hashes: [...new Set([...(prev ? prev.hashes : []), ...hashes])],
    startedAt: prev ? prev.startedAt : now,
    until: now + COLLAB_MOVE_PAUSE_MAX_MS
  };
  applyCollabMovePause(next);
  chrome.storage.session.set({ [COLLAB_MOVE_PAUSE_SESSION_KEY]: next }).catch(() => {});
}

// 옮긴 채널이 COLLAB_MOVE_PLAYING_MS 이상 재생됐는지. 라이브는 따라잡느라 빨리 흐를 수 있어 덜 흐른 경우만 본다.
const COLLAB_MOVE_PLAYING_MS = 2000;
function hasMovedChannelStartedPlaying(hash) {
  const trail = liveSyncPlaybackTrail[hash];
  if (!trail || trail.length < 2) return false;
  const last = trail[trail.length - 1];
  if (Date.now() - last.at > 2000) return false;
  const first = [...trail].reverse().find((p) => last.at - p.at >= COLLAB_MOVE_PLAYING_MS);
  if (!first) return false;
  return last.sec - first.sec >= ((last.at - first.at) / 1000) * 0.9;
}

function finishCollabMovePauseFor(hash) {
  if (!isCollabMovePaused() || !collabMovePause.hashes.includes(hash)) return;
  const hashes = collabMovePause.hashes.filter((h) => h !== hash);
  const next = hashes.length ? { ...collabMovePause, hashes } : null;
  applyCollabMovePause(next);
  chrome.storage.session.set({ [COLLAB_MOVE_PAUSE_SESSION_KEY]: next }).catch(() => {});
}

function applyCollabMovePause(value) {
  const wasPaused = isCollabMovePaused();
  const prevHashes = wasPaused ? collabMovePause.hashes : [];
  const pausedSince = wasPaused ? collabMovePause.startedAt : null;
  collabMovePause = value && value.until > Date.now() ? value : null;
  clearTimeout(collabMovePauseTimer);
  collabMovePauseTimer = collabMovePause
    ? setTimeout(() => applyCollabMovePause(null), collabMovePause.until - Date.now() + 50)
    : null;
  if (collabMovePause) {
    // 이전 창의 재생 기록으로 오판하지 않게 비운다.
    collabMovePause.hashes.forEach((h) => { if (!prevHashes.includes(h)) delete liveSyncPlaybackTrail[h]; });
    if (!wasPaused) recomputeCollabMuting(); // 캡처만 끈다 — 음소거 상태는 그대로(§recomputeCollabMuting)
  } else if (wasPaused) {
    shiftCollabTimersBy(Date.now() - pausedSince);
    forgetCollabCaptureState();
    collabMutingLastTickAt = null; // 멈춘 시간만큼 unmute 게이지가 한 번에 차지 않게
    if (isCollabSettingEnabled()) recomputeCollabMuting();
    applyVolumeToAllChannels(true);
  }
}

// 멈춘 동안 판정 시계도 멈춘다 — 재개 직후 "확인 오래됨"으로 음소거가 풀리지 않게.
function shiftCollabTimersBy(ms) {
  if (!(ms > 0)) return;
  Object.values(collabWaveformScoreByPair).forEach((w) => { if (w && typeof w.at === 'number') w.at += ms; });
  [collabPairLastConfirmedAt, collabPairCandidateLastSeenAt].forEach((map) => {
    Object.keys(map).forEach((k) => { if (typeof map[k] === 'number') map[k] += ms; });
  });
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'session' || !changes[COLLAB_MOVE_PAUSE_SESSION_KEY]) return;
    applyCollabMovePause(changes[COLLAB_MOVE_PAUSE_SESSION_KEY].newValue || null);
  });
}

function updateLayoutModeButtons(layout) {
  document.getElementById('mode-grid')?.classList.toggle('active', layout === 'grid');
  document.getElementById('mode-main_sub')?.classList.toggle('active', layout === 'main_sub');
}

function readChannelDragData(dataTransfer) {
  if (!dataTransfer) return null;
  try {
    const raw = dataTransfer.getData(CHANNEL_DRAG_MIME);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed.hash === 'string') return parsed;
    }
  } catch (err) { /* 무시 — 아래 text/plain으로 폴백 */ }
  const hash = dataTransfer.getData('text/plain');
  return hash ? { hash, sec: null } : null;
}

// 같은 창 채널끼리만 자리를 바꾼다(다른 창에서 끌어온 건 무시).
function handleChannelTileDrop(drag, targetHash) {
  const draggedHash = drag && drag.hash;
  if (!draggedHash || !targetHash || draggedHash === targetHash) return;
  if (!channels.some((c) => c.hash === draggedHash)) return;
  if (isWindowRegistered() && (!isChannelOwnedByThisWindow(draggedHash) || !isChannelOwnedByThisWindow(targetHash))) return;
  swapChannels(draggedHash, targetHash);
}

function getFirstChzzkHash() {
  for (const h of channelAddOrder) {
    const c = channels.find(ch => ch.hash === h);
    if (c && c.platform === 'chzzk') return h;
  }
  return null;
}

const chatReinitOverlays = new Map();
const reinitPendingHashes = new Set();
function getChatReinitOverlay(hash) {
  if (!chatContainer) return null;
  let el = chatReinitOverlays.get(hash);
  if (el && el.isConnected) return el;
  el = document.createElement('div');
  el.className = 'chat-reinit-overlay';
  el.setAttribute('data-hash', hash);
  el.innerHTML = `<div class="chat-reinit-spinner"></div><div class="chat-reinit-text" data-i18n="app.chatReconnecting">${t('app.chatReconnecting', '채팅 재연결 중...')}</div>`;
  el.style.display = 'none';
  chatContainer.appendChild(el);
  chatReinitOverlays.set(hash, el);
  return el;
}
function updateChatReinitOverlayVisibility(hash) {
  const el = chatReinitOverlays.get(hash);
  if (!el) return;
  // 2분할이면 두 번째 칸 채널도 떠 있으므로 그 칸만 덮는다.
  const secondHash = getEffectiveSecondaryChatChannel();
  const pane = hash === activeChatChannel ? 1 : (secondHash && hash === secondHash ? 2 : 0);
  el.classList.toggle('chat-pane-1', pane === 1);
  el.classList.toggle('chat-pane-2', pane === 2);
  el.style.display = (reinitPendingHashes.has(hash) && pane > 0) ? 'flex' : 'none';
}
function showChatReinitOverlay(hash) {
  if (!hash) return;
  reinitPendingHashes.add(hash);
  getChatReinitOverlay(hash);
  updateChatReinitOverlayVisibility(hash);
}
function hideChatReinitOverlay(hash) {
  if (!hash) return;
  reinitPendingHashes.delete(hash);
  updateChatReinitOverlayVisibility(hash);
}

const soopVideoReadyMap = new Map();
function getSoopVideoReadyEntry(hash) {
  if (!soopVideoReadyMap.has(hash)) {
    let resolveFn;
    const promise = new Promise((res) => { resolveFn = res; });
    soopVideoReadyMap.set(hash, { promise, resolve: resolveFn, done: false });
  }
  return soopVideoReadyMap.get(hash);
}
function markSoopVideoReady(hash) {
  const entry = soopVideoReadyMap.get(hash);
  if (entry && !entry.done) {
    entry.done = true;
    entry.resolve();
  }
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'SOOP_VIDEO_LOGIN_READY') return;
  if (event.data.channelId) markSoopVideoReady(event.data.channelId);
});

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'SOOP_CHAT_NEEDS_REINIT') return;
  const hash = event.data.channelId;
  if (!hash || !chatContainer) return;
  const iframe = chatContainer.querySelector(`iframe[data-hash="${hash}"]`);
  if (!iframe) return;
  console.warn(`[CHEESE EYES] SOOP 채팅 재초기화 요청 수신 (hash=${hash}), referrer를 살려 다시 로드합니다.`);
  soopVideoReadyMap.delete(hash);
  const wasVisible = chatVisible && hash === activeChatChannel;
  if (wasVisible) showChatReinitOverlay(hash);
  loadChatIframe(iframe, hash, 'soop').finally(() => { if (wasVisible) hideChatReinitOverlay(hash); });
});

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHEESE_FORWARD_SHORTCUT') return;
  const key = event.data.key;
  if (!key) return;
  document.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true }));
});

let autocompleteRenderToken = 0;

function apiFetch(url, init = {}) {
  return new Promise((resolve, reject) => {
    try {
      const { requiresAuth, ...fetchInit } = init;
      chrome.runtime.sendMessage({ type: 'PROXY_FETCH', url, init: fetchInit, requiresAuth }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response) {
          reject(new Error('background 프록시 응답이 없습니다.'));
          return;
        }
        resolve({
          ok: response.ok,
          status: response.status,
          statusText: response.statusText,
          json: async () => JSON.parse(response.body || 'null'),
          text: async () => response.body || ''
        });
      });
    } catch (err) {
      reject(err);
    }
  });
}

// ---- 같은 프로필 다중 창(docs/multi-window-design.md §3.1~§3.5) ---- 채널 목록은 공용, 그릴 창만 channel_owner로 나눈다.
// 등록 실패 시 창마다 독립 동작.
const WINDOW_SLOT_SESSION_KEY = 'cheeseEyesWindowSlotId';
const MULTI_WINDOW_SESSION_KEYS = ['cheese_windows', 'representative_slot', 'channel_owner', 'extended_main_sub_active'];
const MULTI_WINDOW_MESSAGE_TIMEOUT_MS = 3000;
let windowSlotId = null;
let multiWindowRegistryActive = false;
let windowRegistry = {}; // slotId -> { tabId, windowId, openedAt }
let representativeSlotId = null;
let channelOwnerMap = {}; // hash -> slotId

function withMultiWindowTimeout(promise) {
  return Promise.race([promise, new Promise((resolve) => setTimeout(() => resolve(null), MULTI_WINDOW_MESSAGE_TIMEOUT_MS))]);
}

// values에 있는 키만 반영(storage.get 결과 또는 onChanged newValue).
function applyMultiWindowSessionState(values) {
  if ('cheese_windows' in values) windowRegistry = values.cheese_windows || {};
  if ('representative_slot' in values) representativeSlotId = values.representative_slot || null;
  if ('channel_owner' in values) channelOwnerMap = values.channel_owner || {};
  if ('extended_main_sub_active' in values) representativeExtendedActive = !!values.extended_main_sub_active;
}

async function registerThisWindow() {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.storage || !chrome.storage.session) return;
  try {
    let savedSlotId = null;
    try { savedSlotId = sessionStorage.getItem(WINDOW_SLOT_SESSION_KEY); } catch (err) { /* 무시 */ }
    const res = await withMultiWindowTimeout(chrome.runtime.sendMessage({ type: 'DASHBOARD_WINDOW_REGISTER', slotId: savedSlotId }));
    if (!res || !res.ok || !res.slotId) return;
    windowSlotId = res.slotId;
    try { sessionStorage.setItem(WINDOW_SLOT_SESSION_KEY, windowSlotId); } catch (err) { /* 무시 */ }
    const state = await chrome.storage.session.get(MULTI_WINDOW_SESSION_KEYS);
    applyMultiWindowSessionState(Object.fromEntries(MULTI_WINDOW_SESSION_KEYS.map((k) => [k, state[k]])));
    multiWindowRegistryActive = true;
    updateWindowRoleTitle();
  } catch (err) {
    console.warn('[CHEESE EYES] 창 등록 실패 — 예전처럼 창마다 동작합니다:', err);
  }
}

const windowRegistrationReady = registerThisWindow();

function isWindowRegistered() {
  return multiWindowRegistryActive && !!windowSlotId;
}

// 대표 창인가 — 사이드바 "보내기"·영구 값 저장을 맡는다(등록부를 못 쓰면 모든 창).
function isRepresentativeWindow() {
  return !isWindowRegistered() || windowSlotId === representativeSlotId;
}

function resolveChannelOwnerSlot(hash) {
  const owner = channelOwnerMap[hash];
  return owner && windowRegistry[owner] ? owner : representativeSlotId;
}

function isChannelOwnedByThisWindow(hash) {
  if (!isWindowRegistered()) return true;
  const owner = resolveChannelOwnerSlot(hash);
  return !owner || owner === windowSlotId; // owner 없음: 대표 창이 아직 정해지지 않음
}

// 소유 창 변경 — 이 창엔 즉시 반영, 등록부 기록은 background가 한다.
function claimChannelOwnership(hashes, slotId = windowSlotId) {
  if (!isWindowRegistered() || !slotId || !hashes || hashes.length === 0) return Promise.resolve();
  const next = { ...channelOwnerMap };
  hashes.forEach((hash) => { next[hash] = slotId; });
  channelOwnerMap = next;
  return withMultiWindowTimeout(chrome.runtime.sendMessage({ type: 'CHANNEL_CLAIM_OWNER', slotId, hashes })).catch(() => {});
}

// 소유 창을 먼저 기록하고 목록을 저장한다(반대면 대표 창이 잠깐 그 채널을 띄움).
function saveChannelsAfterClaim(hashes, slotId = windowSlotId) {
  if (!isWindowRegistered() || !hashes || hashes.length === 0) {
    saveChannelsToStorage();
    return;
  }
  claimChannelOwnership(hashes, slotId).then(() => saveChannelsToStorage());
}

function notifyChannelMovedHere(channel) {
  showPlatformNotice(t(
    'instanceLock.channelMovedHere',
    '다른 창에 있던 {name} 채널을 이 창으로 옮겼습니다.',
    { name: (channel && (channel.name || channel.hash)) || '' }
  ));
}

const BASE_DOCUMENT_TITLE = document.title || 'CHEESE EYES';

function getSortedWindowSlots() {
  return Object.keys(windowRegistry).sort((a, b) => (windowRegistry[a].openedAt || 0) - (windowRegistry[b].openedAt || 0));
}

// 탭 제목에 창 번호와 대표 표시(★)를 붙인다(설정의 대표 창 목록과 같은 번호).
function updateWindowRoleTitle() {
  if (!isWindowRegistered()) return;
  const slots = getSortedWindowSlots();
  if (slots.length <= 1) {
    document.title = BASE_DOCUMENT_TITLE;
    return;
  }
  const label = t('settings.windowLabel', '창 {n}', { n: slots.indexOf(windowSlotId) + 1 });
  document.title = `${windowSlotId === representativeSlotId ? '★ ' : ''}${BASE_DOCUMENT_TITLE} · ${label}`;
}

function renderRepresentativeWindowList() {
  const list = document.getElementById('representative-window-list');
  if (!list) return;
  list.innerHTML = '';
  if (!isWindowRegistered()) {
    const hint = document.createElement('div');
    hint.className = 'yt-settings-hint';
    hint.textContent = t('settings.representativeWindowUnavailable', '이 창에서는 대표 창을 바꿀 수 없습니다.');
    list.appendChild(hint);
    return;
  }
  getSortedWindowSlots().forEach((slotId, index) => {
    const isRepresentative = slotId === representativeSlotId;
    const owned = channels.filter((c) => resolveChannelOwnerSlot(c.hash) === slotId);
    const makeButton = (action, text) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'yt-settings-select';
      btn.dataset.slotAction = action;
      btn.dataset.slotId = slotId;
      btn.textContent = text;
      return btn;
    };

    const row = document.createElement('div');
    row.className = 'yt-settings-row representative-window-row';
    const label = document.createElement('span');
    label.className = 'yt-settings-label';
    let windowText = `${isRepresentative ? '★ ' : ''}${t('settings.windowLabel', '창 {n}', { n: index + 1 })}`;
    if (slotId === windowSlotId) windowText += ` ${t('settings.thisWindowSuffix', '(이 창)')}`;
    const names = owned.slice(0, 2).map((c) => c.name || c.hash).join(', ');
    const summary = t('settings.windowChannelSummary', '채널 {count}개', { count: owned.length })
      + (names ? `: ${names}${owned.length > 2 ? '…' : ''}` : '');
    label.textContent = `${windowText} · ${summary}`;
    label.title = label.textContent;

    const actions = document.createElement('div');
    actions.className = 'representative-window-actions';
    if (slotId !== windowSlotId) actions.appendChild(makeButton('focus', t('settings.focusWindowButton', '보기')));
    const representativeBtn = makeButton(
      'representative',
      isRepresentative ? t('settings.representativeBadge', '대표') : t('settings.makeRepresentativeButton', '대표로 지정')
    );
    representativeBtn.disabled = isRepresentative;
    actions.appendChild(representativeBtn);

    row.append(label, actions);
    list.appendChild(row);
  });
}

function refreshRepresentativeWindowListIfOpen() {
  const modal = document.getElementById('setting-modal');
  if (modal && modal.classList.contains('active')) renderRepresentativeWindowList();
}

function hasMultipleDashboardWindows() {
  return multiWindowRegistryActive && Object.keys(windowRegistry).length > 1;
}

function isRepresentativeWindow() {
  return isWindowRegistered() && windowSlotId === representativeSlotId;
}

// 메인-서브 확장은 제거됨 — 항상 꺼짐. 예전 켜짐 값도 끄도록 알린다.
function computeExtendedMainSubActive() {
  return false;
}

// 메인-서브 확장 조건이 바뀔 수 있는 곳마다 부른다. 바뀌면 다시 그리고 음량 역할도 맞춘다.
function refreshExtendedMainSubState() {
  const next = computeExtendedMainSubActive();
  // 대표 창은 결과를 다른 창에 알린다.
  if (isRepresentativeWindow() && next !== representativeExtendedActive) {
    representativeExtendedActive = next;
    chrome.storage.session.set({ extended_main_sub_active: next }).catch(() => {});
  }
  if (next !== extendedMainSubActive) {
    extendedMainSubActive = next;
    lastBroadcastChannelVolumesKey = null; // 켜지면 두 창이 곧바로 서로의 표시 음량을 받게 한다

    if (next) {
      document.documentElement.dataset.extendedMainSub = '1';
      // 대표 창은 자기 메인을 공용으로 남기고, 다른 창은 따른다.
      if (isRepresentativeWindow()) {
        sharedMainChannel = mainChannel;
        chrome.storage.local.set({ main_channel: mainChannel });
      } else if (sharedMainChannel && channels.some((c) => c.hash === sharedMainChannel)) {
        mainChannel = sharedMainChannel;
      }
    } else {
      delete document.documentElement.dataset.extendedMainSub;
      ensureMainChannelOwnedByThisWindow();
    }
    forgetCollabCaptureState();
    suppressVolumeEchoReports(2000);
    renderAll();
    applyVolumeToAllChannels(true);
  }
}

// ---- 창별 상태(§3.7) ---- 레이아웃·메인·채팅 표시는 window_state_<slotId>에 창마다 저장. 영구 값은 대표 창만 쓴다.
function getWindowStateSessionKey() {
  return isWindowRegistered() ? `window_state_${windowSlotId}` : null;
}

function saveWindowState() {
  const key = getWindowStateSessionKey();
  if (!key) return;
  chrome.storage.session.set({ [key]: { layout: currentLayout, mainChannel, chatVisible, activeChatChannel, secondaryChatChannel } }).catch(() => {});
}

async function loadWindowState() {
  const key = getWindowStateSessionKey();
  if (!key) return null;
  try {
    const stored = await chrome.storage.session.get(key);
    return stored[key] || null;
  } catch (err) {
    return null;
  }
}

// 메인 채널이 이 창 채널이 아니면 이 창 첫 채널로 바꾼다(화면과 음량 역할 어긋남 방지). 바꿨으면 true.
function ensureMainChannelOwnedByThisWindow() {
  if (!multiWindowRegistryActive || extendedMainSubActive) return false;
  if (mainChannel && isChannelOwnedByThisWindow(mainChannel) && displayChannels.some((c) => c.hash === mainChannel)) return false;
  const firstOwned = displayChannels.find((c) => isChannelOwnedByThisWindow(c.hash));
  const nextMain = firstOwned ? firstOwned.hash : null;
  if (nextMain === mainChannel) return false;
  mainChannel = nextMain;
  saveWindowState();
  return true;
}

function onRepresentativeRoleChanged(isOwner) {
  if (!isOwner) return;
  processPendingMultiviewAdd();
  // 대표가 됐으니 다음 시작 때 복원할 값을 이 창 값으로 남긴다.
  chrome.storage.local.set({ my_layout: currentLayout, my_chat_visible: chatVisible, main_channel: mainChannel });
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'session' || !multiWindowRegistryActive) return;
    const changedKeys = MULTI_WINDOW_SESSION_KEYS.filter((k) => changes[k]);
    if (changedKeys.length === 0) return;

    const wasRepresentative = isRepresentativeWindow();
    const wasCollabWorker = isCollabRelayWorkerWindow();
    const ownedBefore = new Set(displayChannels.filter((c) => isChannelShownInThisWindow(c.hash)).map((c) => c.hash));
    applyMultiWindowSessionState(Object.fromEntries(changedKeys.map((k) => [k, changes[k].newValue])));

    // 등록부에서 빠졌으면 같은 ID로 다시 올린다.
    if (windowSlotId && !windowRegistry[windowSlotId]) {
      registerThisWindow().then(() => {
        renderAll();
        applyVolumeToAllChannels(true);
      });
      return;
    }

    const ownedAfter = displayChannels.filter((c) => isChannelShownInThisWindow(c.hash)).map((c) => c.hash);
    const ownershipChanged = ownedAfter.length !== ownedBefore.size || ownedAfter.some((h) => !ownedBefore.has(h));
    if (ownershipChanged) {
      // 다른 창으로 넘어간 VOD는 재생 위치를 실어 보낸다.
      let carried = false;
      ownedBefore.forEach((hash) => {
        if (!ownedAfter.includes(hash) && carryPlaybackPositionForWindowMove(hash, lastKnownPlaybackTimeSec[hash])) carried = true;
      });
      if (carried) saveChannelsToStorage();
      ensureMainChannelOwnedByThisWindow();
      renderAll();
      applyVolumeToAllChannels(true);
    }

    const isRepresentativeNow = isRepresentativeWindow();
    if (isRepresentativeNow !== wasRepresentative) onRepresentativeRoleChanged(isRepresentativeNow);

    // 판정 역할이 바뀌면 캡처 기록을 비우고, 새로 맡았으면 바로 한 번 판정한다.
    if (isCollabRelayWorkerWindow() !== wasCollabWorker) {
      forgetCollabCaptureState();
      if (!isCollabRelayWorkerWindow() && isCollabSettingEnabled()) {
        ensureVadWorker();
        recomputeCollabMuting();
      }
    }

    refreshExtendedMainSubState();
    updateWindowRoleTitle();
    refreshRepresentativeWindowListIfOpen();
  });
}

let cachedAccountKeys = null;
let cachedAccountInfo = null; // [{platform, id, label}] — 화면 표시용(닉네임 등)

// 치지직 로그인 조회. userIdHash = 네이버 계정 식별값.
async function getChzzkAccountKey() {
  try {
    const res = await apiFetch('https://comm-api.game.naver.com/nng_main/v1/user/getUserStatus', { credentials: 'include' });
    if (!res.ok) {
      console.warn(`[CHEESE EYES][계정확인][치지직] 요청 실패: status=${res.status}`);
      return null;
    }
    const data = await res.json();
    const userIdHash = data?.content?.userIdHash;
    if (!userIdHash) {
      window.__cheeseDebugChzzkStatus = data;
      console.warn('[CHEESE EYES][계정확인][치지직] userIdHash를 찾지 못함. 콘솔에 copy(JSON.stringify(window.__cheeseDebugChzzkStatus)) 입력해서 확인:', data);
      return null;
    }
    const label = data?.content?.nickname || userIdHash;
    return { platform: 'chzzk', id: userIdHash, label };
  } catch (err) {
    console.warn('[CHEESE EYES] 치지직 계정 확인 실패(로그인 안 됨으로 간주):', err);
    return null;
  }
}

// 숲: afevent2.sooplive.com get_private_info.php의 CHANNEL.LOGIN_ID가 계정 아이디.
async function getSoopAccountKey() {
  try {
    const res = await apiFetch('https://afevent2.sooplive.com/api/get_private_info.php', { credentials: 'include' });
    if (!res.ok) {
      console.warn(`[CHEESE EYES][계정확인][숲] 요청 실패: status=${res.status}`);
      return null;
    }
    const data = await res.json();
    if (!data || !data.CHANNEL || Number(data.CHANNEL.IS_LOGIN) !== 1) return null;
    const userId = data.CHANNEL.LOGIN_ID;
    if (!userId) {
      window.__cheeseDebugSoopLogin = data;
      console.warn('[CHEESE EYES][계정확인][숲] 로그인은 확인됐지만 LOGIN_ID가 비어있음. 콘솔에 copy(JSON.stringify(window.__cheeseDebugSoopLogin)) 입력해서 확인:', data);
      return null;
    }
    const label = data.CHANNEL.LOGIN_NICK || userId;
    return { platform: 'soop', id: userId, label };
  } catch (err) {
    console.warn('[CHEESE EYES] 숲 계정 확인 실패(로그인 안 됨으로 간주):', err);
    return null;
  }
}

// 유튜브: InnerTube 계정 메뉴의 manageAccountTitle 링크 browseId가 채널ID(UC...).
async function getYoutubeAccountKey() {
  try {
    const adapter = PlatformAdapters?.youtube;
    if (!adapter) return null;
    const context = await adapter._context();
    const data = await adapter._innerTubePost('account/account_menu', { context }, true);
    const header = data?.actions?.[0]?.openPopupAction?.popup?.multiPageMenuRenderer?.header?.activeAccountHeaderRenderer;
    const channelId = header?.manageAccountTitle?.runs?.[0]?.navigationEndpoint?.browseEndpoint?.browseId
      || header?.channelHandle?.simpleText
      || header?.accountName?.simpleText;
    if (!channelId) {
      window.__cheeseDebugYoutubeAccountMenu = data;
      console.warn('[CHEESE EYES][계정확인][유튜브] 채널ID를 찾지 못함. 콘솔에 copy(JSON.stringify(window.__cheeseDebugYoutubeAccountMenu)) 입력해서 확인:', data);
      return null;
    }
    const label = header?.accountName?.simpleText || header?.channelHandle?.simpleText || channelId;
    return { platform: 'youtube', id: channelId, label };
  } catch (err) {
    console.warn('[CHEESE EYES] 유튜브 계정 확인 실패(로그인 안 됨으로 간주):', err);
    return null;
  }
}

async function getPlatformAccountKeys() {
  if (cachedAccountKeys !== null) return cachedAccountKeys;
  const results = await Promise.allSettled([getChzzkAccountKey(), getSoopAccountKey(), getYoutubeAccountKey()]);
  cachedAccountInfo = results
    .filter((r) => r.status === 'fulfilled' && r.value)
    .map((r) => r.value);
  cachedAccountKeys = cachedAccountInfo.map((info) => `${info.platform}:${info.id}`);
  return cachedAccountKeys;
}

// ---- 알림(토스트) ---- 우측 상단에 잠깐 뜨고 다른 기능은 막지 않는다.
function showPlatformNotice(message) {
  let container = document.getElementById('cheese-eyes-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'cheese-eyes-toast-container';
    container.style.cssText = [
      'position: fixed', 'top: 16px', 'right: 16px', 'z-index: 2147483647',
      'display: flex', 'flex-direction: column', 'gap: 8px',
      'pointer-events: none', 'max-width: 340px'
    ].join(';');
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.style.cssText = [
    'background: rgba(20,20,20,0.95)', 'color: #fff', 'border: 1px solid #ffc800',
    'border-radius: 8px', 'padding: 10px 14px', 'font-size: 13px', 'line-height: 1.5',
    "font-family: -apple-system, 'Malgun Gothic', sans-serif",
    'box-shadow: 0 4px 12px rgba(0,0,0,0.4)', 'pointer-events: auto', 'opacity: 0',
    'transition: opacity 0.2s'
  ].join(';');
  toast.textContent = message;
  container.appendChild(toast);
  requestAnimationFrame(() => { toast.style.opacity = '1'; });
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 250);
  }, 6000);
}

// 로그인 상태 예열(유튜브 댓글 작성자 표시 등). PlatformAdapters가 아래에서 선언되므로 마이크로태스크로 미룬다.
Promise.resolve().then(() => getPlatformAccountKeys().catch(() => {}));

function frameApiFetch(hash, url, init = {}, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const wrapper = typeof videoWrapperMap !== 'undefined' ? videoWrapperMap.get(hash) : null;
    const iframe = wrapper && wrapper.querySelector('iframe');
    if (!iframe || !iframe.contentWindow) {
      reject(new Error('frame_not_ready'));
      return;
    }

    const requestId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
    let settled = false;

    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      window.removeEventListener('message', onMessage);
      reject(new Error('frame_proxy_timeout'));
    }, timeoutMs);

    function onMessage(event) {
      if (!event.data || event.data.type !== 'CHEESE_API_PROXY_RESULT' || event.data.requestId !== requestId) return;
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      window.removeEventListener('message', onMessage);
      resolve({
        ok: event.data.ok,
        status: event.data.status,
        statusText: '',
        json: async () => JSON.parse(event.data.body || 'null'),
        text: async () => event.data.body || ''
      });
    }

    window.addEventListener('message', onMessage);
    iframe.contentWindow.postMessage({ type: 'CHEESE_API_PROXY', requestId, url, init }, '*');
  });
}

function checkLoginCookie(url, names) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'CHECK_LOGIN_COOKIE', url, names }, (response) => {
        if (chrome.runtime.lastError || !response) { resolve(false); return; }
        resolve(!!response.loggedIn);
      });
    } catch (e) { resolve(false); }
  });
}

function getSoopSessionKey() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'GET_SOOP_SESSION_KEY' }, (res) => {
        if (chrome.runtime.lastError || !res) { resolve(''); return; }
        resolve(res.ok ? res.value : '');
      });
    } catch (e) { resolve(''); }
  });
}

window.cheeseDebugSoopCookies = function () {
  chrome.runtime.sendMessage({ type: 'DEBUG_SOOP_COOKIES' }, (res) => {
    if (chrome.runtime.lastError || !res || !res.ok) {
      console.error('[CHEESE EYES] 쿠키 디버그 실패:', chrome.runtime.lastError || res);
      return;
    }
    console.log('[CHEESE EYES] 원본 쿠키 존재 여부:', res.raw);
    console.log('[CHEESE EYES] 파티션(CHIPS) 쿠키 존재 여부:', res.partitioned);
  });
};

const PLATFORM_META = {
  chzzk:   { label: '치지직', brand: 'CHZZK',   color: '#00ffa3', enabled: true },
  soop:    { label: '숲',     brand: 'SOOP',    color: '#3385ff', enabled: true },
  youtube: { label: '유튜브', brand: 'YouTube', color: '#FF0000', enabled: true },
  twitch:  { label: '트위치', brand: 'Twitch',  color: '#9146FF', enabled: false }
};

function getPlatformLabel(key) {
  const meta = PLATFORM_META[key];
  return t(`platform.${key}`, meta ? meta.label : key);
}

// 검색 "전체" 탭의 플랫폼 순서(점수 동률 시 앞선 쪽이 위). 저장 순서에 없는 플랫폼은 뒤에 붙인다.
function getSearchPlatformOrder() {
  const available = Object.keys(PLATFORM_META).filter((p) => PLATFORM_META[p].enabled && PlatformAdapters[p]);
  const saved = Array.isArray(mySetting.searchPlatformOrder) ? mySetting.searchPlatformOrder : [];
  const ordered = saved.filter((p) => available.includes(p));
  available.forEach((p) => { if (!ordered.includes(p)) ordered.push(p); });
  return ordered;
}

function moveSearchPlatformOrder(platform, delta) {
  const order = getSearchPlatformOrder();
  const from = order.indexOf(platform);
  const to = from + delta;
  if (from < 0 || to < 0 || to >= order.length) return false;
  order.splice(to, 0, order.splice(from, 1)[0]);
  mySetting.searchPlatformOrder = order;
  saveSetting();
  return true;
}

// 최소 시청자수 드롭다운은 항상 영문 브랜드명으로 표기.
function getPlatformBrand(key) {
  const meta = PLATFORM_META[key];
  return (meta && meta.brand) || key;
}

const UI_LANGUAGE_LABELS = { ko: '한국어', en: 'English' };
function getUiLanguageOptions() {
  const supported = (typeof window !== 'undefined' && window.CHEESE_EYES_SUPPORTED_LANGS) || ['ko', 'en'];
  return supported.map(code => ({ value: code, label: UI_LANGUAGE_LABELS[code] || code }));
}

function getPlatformColor(platform) {
  return (PLATFORM_META[platform] && PLATFORM_META[platform].color) || PLATFORM_META.chzzk.color;
}

// 플랫폼별 최소 시청자수 기본값(검색 결과 필터).
const DEFAULT_MIN_VIEWERS = { chzzk: 10, soop: 10, youtube: 50 };

function getMinViewers(platform) {
  const val = mySetting.minViewers && mySetting.minViewers[platform];
  return (typeof val === 'number' && !isNaN(val)) ? val : (DEFAULT_MIN_VIEWERS[platform] || 0);
}

function isAudioOptimizationEnabled() {
  return true;
}

// 자동 합방과 수동 합방은 따로 켠다. 하나라도 켜지면 합방 처리가 돈다.
function isCollabAutoEnabled() {
  return !!mySetting.collabAutoEnabled;
}

function isCollabManualEnabled() {
  return !!mySetting.collabManualEnabled;
}

function isCollabSettingEnabled() {
  return isCollabAutoEnabled() || isCollabManualEnabled();
}

// AI 음성 감지는 자동 합방과 VOD 싱크에만 필요하다.
function isCollabVadEnabled() {
  return isCollabAutoEnabled() || isVodSyncSettingEnabled();
}

// VOD 싱크(실험적) 하위 토글. 수동 합방이 꺼지면 함께 꺼진다(§getEffectiveCollabGroups).
function isVodSyncSettingEnabled() {
  return isCollabManualEnabled() && !!mySetting.vodSyncEnabled;
}

// 디버그 모드는 상위 스위치 — 꺼지면 하위 스위치 값과 무관하게 전부 꺼진다.
function isDebugModeEnabled() {
  return !!mySetting.debugMode;
}

function isAudioDebugSectionEnabled() {
  return isDebugModeEnabled() && !!mySetting.audioDebugEnabled;
}

function isVodDebugSectionEnabled() {
  return isDebugModeEnabled() && !!mySetting.vodDebugEnabled;
}

// 컴프레서는 오디오 최적화에 포함돼 항상 켜진다(docs/audio-architecture.md §5.5).
function isDynamicsCompressorEnabled() {
  return isAudioOptimizationEnabled();
}

// 그리드/서브 기준 음량은 설정에서만 바꾼다. 채널 슬라이더는 수동 고정값(getChannelOverride)을 다룬다.
function getGridDefaultVolume() {
  const val = mySetting.gridVolume;
  return (typeof val === 'number' && !isNaN(val)) ? val : DEFAULT_CHANNEL_VOLUME;
}

function getSubDefaultVolume() {
  const val = mySetting.subVolume;
  return (typeof val === 'number' && !isNaN(val)) ? val : DEFAULT_CHANNEL_VOLUME;
}

function getMaxChannels() {
  const val = mySetting.maxChannels;
  if (!Number.isInteger(val) || val < MAX_CHANNELS_INPUT_MIN) return DEFAULT_MAX_CHANNELS;
  return Math.min(val, MAX_CHANNELS_INPUT_MAX);
}

function isChannelLimitReached() {
  // 채팅만 추가한 채널은 상한에서 뺀다.
  return channels.filter((c) => !c.chatOnly).length >= getMaxChannels();
}

function notifyChannelLimitReached() {
  showPlatformNotice(t(
    'app.channelLimitReached',
    '채널은 최대 {max}개까지 추가할 수 있습니다. 설정 > 최대 채널 수에서 바꿀 수 있습니다.',
    { max: getMaxChannels() }
  ));
}

function updateMaxChannelsWarning(value) {
  const warning = document.getElementById('max-channels-warning');
  if (warning) warning.hidden = !(Number.isInteger(value) && value > DEFAULT_MAX_CHANNELS);
}

// 오디오 최적화가 꺼지면 기준 음량 설정은 무의미 — 100% 재생, 평준화 없음.
function getChannelBaselineVolume(hash) {
  if (!isAudioOptimizationEnabled()) return DEFAULT_CHANNEL_VOLUME;
  return getChannelRole(hash) === 'sub' ? getSubDefaultVolume() : getGridDefaultVolume();
}

// 채널 슬라이더를 직접 조작하면 그 값으로 고정(자동 보정 제외). 그리드/메인-서브 역할별로 따로 저장.
function getChannelOverride(hash) {
  const role = getChannelRole(hash);
  if (role === 'main') return null;
  const group = audioState.channelVolumeOverrides && audioState.channelVolumeOverrides[role];
  const override = group && group[hash];
  return (typeof override === 'number' && !isNaN(override)) ? override : null;
}

function setChannelOverride(hash, vol) {
  const role = getChannelRole(hash);
  if (role === 'main') return;
  if (!audioState.channelVolumeOverrides) audioState.channelVolumeOverrides = { grid: {}, sub: {} };
  if (!audioState.channelVolumeOverrides[role]) audioState.channelVolumeOverrides[role] = {};
  audioState.channelVolumeOverrides[role][hash] = vol;
}

function clearChannelOverride(hash) {
  const role = getChannelRole(hash);
  if (role === 'main') return;
  const group = audioState.channelVolumeOverrides && audioState.channelVolumeOverrides[role];
  if (group) delete group[hash];
}

// 메인 볼륨은 채널별로 기억한다. 없으면 예전 공용 값 → DEFAULT_MAIN_VOLUME 순으로 폴백.
function getMainVolumeForChannel(hash) {
  if (!hash) return DEFAULT_MAIN_VOLUME;
  const stored = audioState.mainVolumeByChannel && audioState.mainVolumeByChannel[hash];
  if (typeof stored === 'number' && !isNaN(stored)) return stored;
  if (typeof audioState.mainVolume === 'number' && !isNaN(audioState.mainVolume)) return audioState.mainVolume;
  return DEFAULT_MAIN_VOLUME;
}

function setMainVolumeForChannel(hash, vol) {
  if (!hash) return;
  if (!audioState.mainVolumeByChannel) audioState.mainVolumeByChannel = {};
  audioState.mainVolumeByChannel[hash] = vol;
}

// 저장된 0% 상태를 지운다(메인은 기본값으로, 오버라이드는 삭제). 바뀌면 true.
function resetMutedAudioStateOnLoad() {
  let changed = false;
  if (audioState.mainVolume === 0) {
    audioState.mainVolume = DEFAULT_MAIN_VOLUME;
    changed = true;
  }
  if (audioState.mainVolumeByChannel) {
    Object.keys(audioState.mainVolumeByChannel).forEach((hash) => {
      if (audioState.mainVolumeByChannel[hash] === 0) {
        audioState.mainVolumeByChannel[hash] = DEFAULT_MAIN_VOLUME;
        changed = true;
      }
    });
  }
  const overrides = audioState.channelVolumeOverrides;
  if (overrides) {
    ['grid', 'sub'].forEach((role) => {
      const group = overrides[role];
      if (!group) return;
      Object.keys(group).forEach((hash) => {
        if (group[hash] === 0) {
          delete group[hash];
          changed = true;
        }
      });
    });
  }
  return changed;
}

// 사실상 무음인 채널은 평준화에서 제외한다(무음을 기준 삼으면 전부 깎임). -50 LUFS는 잠정값(docs/audio-architecture.md §5.6).
const MIN_VALID_REFERENCE_DB = -50; // LUFS, 잠정값 — docs/audio-architecture.md §5.6

// 'sub'는 메인 제외(메인은 감쇠 기준일 뿐), 'grid'는 전 채널. 합방 비리더는 이미 따로 처리되므로 뺀다.
function getGroupHashes(role) {
  const base = role === 'sub'
    ? displayChannels.filter(c => c.hash !== mainChannel)
    : displayChannels;
  // 합방으로 음소거된 채널만 뺀다(그룹 소속 기준이면 평준화가 사실상 꺼짐).
  return base.filter(c => !isCollabMutedNow(c.hash)).map(c => c.hash);
}

// 선형보간 백분위수. sortedAsc는 오름차순이어야 한다.
function percentileOf(sortedAsc, p) {
  if (sortedAsc.length === 1) return sortedAsc[0];
  const idx = p * (sortedAsc.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return sortedAsc[lo];
  return sortedAsc[lo] + (sortedAsc[hi] - sortedAsc[lo]) * (idx - lo);
}

// 최신값 하나로 비교하면 순간 스파이크에 기준이 요동친다 — 최근 샘플의 사분위 트림 평균으로 비교한다.
const CHANNEL_LEVELING_HISTORY_MAX_SAMPLES = 25; // content.js LEVEL_REPORT_INTERVAL_MS(200ms) 기준 약 5초
const CHANNEL_LEVELING_HISTORY_MIN_SAMPLES = 10; // 원래 500ms 기준 4개(≈2초) 비율 유지
let channelLevelingDbHistory = {};

function pushChannelLevelingDb(hash, db) {
  const arr = channelLevelingDbHistory[hash] || (channelLevelingDbHistory[hash] = []);
  arr.push(db);
  if (arr.length > CHANNEL_LEVELING_HISTORY_MAX_SAMPLES) arr.shift();
}

// 샘플이 부족하면 최신값으로 폴백.
function getChannelLevelingDb(hash) {
  const arr = channelLevelingDbHistory[hash];
  const latest = channelAudioLevels[hash];
  const latestFallback = (typeof latest === 'number' && isFinite(latest)) ? latest : null;
  if (!arr || arr.length < CHANNEL_LEVELING_HISTORY_MIN_SAMPLES) return latestFallback;
  const valid = arr.filter((db) => typeof db === 'number' && isFinite(db) && db >= MIN_VALID_REFERENCE_DB);
  if (valid.length < CHANNEL_LEVELING_HISTORY_MIN_SAMPLES) return latestFallback;
  const sorted = valid.slice().sort((a, b) => a - b);
  const q1 = percentileOf(sorted, 0.25);
  const q3 = percentileOf(sorted, 0.75);
  const trimmed = valid.filter((db) => db >= q1 && db <= q3);
  if (trimmed.length === 0) return (q1 + q3) / 2;
  return trimmed.reduce((sum, db) => sum + db, 0) / trimmed.length;
}

// 기준 채널 히스테리시스 — 도전자가 이 시간 이상 계속 더 조용해야 기준을 넘겨받는다.
const REFERENCE_SWITCH_SUSTAIN_MS = 3000;
let groupReferenceHash = {};
// groupKey -> { hash, since } — 도전자가 언제부터 최솟값이었는지. 도전자가 바뀌면 다시 잰다.
let groupReferenceChallengerSince = {};

// 기준 dB 값 자체도 지수 스무딩한다 — 기준 채널의 말하기 기복만으로도 나머지가 진동했다.
const GROUP_REFERENCE_DB_SMOOTHING_TIME_CONSTANT_SEC = 10;
let smoothedGroupReferenceDb = {}; // groupKey -> 스무딩된 기준 dB
let smoothedGroupReferenceDbUpdatedAt = {}; // groupKey -> 마지막 갱신 시각(ms)

function smoothGroupRefDb(groupKey, targetDb) {
  const now = Date.now();
  const prev = smoothedGroupReferenceDb[groupKey];
  const prevAt = smoothedGroupReferenceDbUpdatedAt[groupKey];
  smoothedGroupReferenceDbUpdatedAt[groupKey] = now;
  if (typeof prev !== 'number' || !isFinite(prev) || typeof prevAt !== 'number') {
    smoothedGroupReferenceDb[groupKey] = targetDb;
    return targetDb;
  }
  const dtSec = Math.max(0, (now - prevAt) / 1000);
  const alpha = 1 - Math.exp(-dtSec / GROUP_REFERENCE_DB_SMOOTHING_TIME_CONSTANT_SEC);
  const next = prev + (targetDb - prev) * alpha;
  smoothedGroupReferenceDb[groupKey] = next;
  return next;
}

// 그룹 기준 dB(측정된 채널 중 가장 조용한 값). 측정치가 없으면 null. groupKey는 히스테리시스 상태 키.
function getGroupRefDb(hashes, groupKey) {
  let rawMinHash = null;
  let rawMinDb = null;
  hashes.forEach((hash) => {
    const db = getChannelLevelingDb(hash);
    if (typeof db !== 'number' || !isFinite(db) || db < MIN_VALID_REFERENCE_DB) return;
    if (rawMinDb === null || db < rawMinDb) {
      rawMinDb = db;
      rawMinHash = hash;
    }
  });
  if (rawMinHash === null) {
    delete groupReferenceHash[groupKey];
    delete groupReferenceChallengerSince[groupKey];
    delete smoothedGroupReferenceDb[groupKey];
    delete smoothedGroupReferenceDbUpdatedAt[groupKey];
    return null;
  }

  const currentHash = groupReferenceHash[groupKey];
  const currentDb = currentHash ? getChannelLevelingDb(currentHash) : null;
  const currentIsValid = !!currentHash
    && hashes.includes(currentHash)
    && typeof currentDb === 'number' && isFinite(currentDb) && currentDb >= MIN_VALID_REFERENCE_DB;

  let targetDb;
  if (!currentIsValid) {
    // 기존 기준이 없거나 무효 — 즉시 넘겨받는다.
    groupReferenceHash[groupKey] = rawMinHash;
    delete groupReferenceChallengerSince[groupKey];
    targetDb = rawMinDb;
  } else if (rawMinHash === currentHash) {
    delete groupReferenceChallengerSince[groupKey];
    targetDb = currentDb;
  } else {
    // 더 조용한 도전자 — REFERENCE_SWITCH_SUSTAIN_MS 유지돼야 넘겨준다.
    const now = Date.now();
    const challenger = groupReferenceChallengerSince[groupKey];
    if (!challenger || challenger.hash !== rawMinHash) {
      groupReferenceChallengerSince[groupKey] = { hash: rawMinHash, since: now };
      targetDb = currentDb;
    } else if (now - challenger.since >= REFERENCE_SWITCH_SUSTAIN_MS) {
      groupReferenceHash[groupKey] = rawMinHash;
      delete groupReferenceChallengerSince[groupKey];
      targetDb = rawMinDb;
    } else {
      targetDb = currentDb;
    }
  }
  return smoothGroupRefDb(groupKey, targetDb);
}

// 감쇠 하한 없음 — MAX_GROUP_DB_DIFFERENCE 초과분만 깎아 항상 한도 안에 둔다.
const MAX_GROUP_DB_DIFFERENCE = 5; // dB — 이 값을 넘는 초과분만 깎는다

// 기준보다 MAX_GROUP_DB_DIFFERENCE 넘게 시끄러운 만큼만 깎는 배율(증폭 없음, 최대 1).
function getChannelDbAttenuation(hash, referenceDb) {
  const db = getChannelLevelingDb(hash);
  if (referenceDb === null || typeof db !== 'number' || !isFinite(db) || db < MIN_VALID_REFERENCE_DB) return 1;
  const diffDb = db - referenceDb;
  const excessDb = Math.max(0, diffDb - MAX_GROUP_DB_DIFFERENCE);
  return Math.min(1, Math.pow(10, -excessDb / 20));
}

// 허용 격차 없이 diffDb 전체를 깎는다 — "서브 ≤ 메인"은 예외 없이 보장해야 하므로.
function getChannelDbAttenuationVsMain(hash, referenceDb) {
  const db = getChannelLevelingDb(hash);
  if (referenceDb === null || typeof db !== 'number' || !isFinite(db) || db < MIN_VALID_REFERENCE_DB) return 1;
  const diffDb = db - referenceDb;
  return Math.min(1, Math.pow(10, -diffDb / 20));
}

// 현재 메인 채널의 dB 이력. 추적 hash가 바뀌면 다음 접근 때 비운다.
let mainDbSamples = [];
let mainDbSamplesHash = null;

function pushMainDbSample(hash, db) {
  if (!mainChannel || hash !== mainChannel) return;
  if (mainDbSamplesHash !== mainChannel) {
    mainDbSamplesHash = mainChannel;
    mainDbSamples = [];
  }
  mainDbSamples.push(db);
}

// 너무 조용한 샘플과 IQR 밖 값을 잘라낸 평균. 샘플이 부족하면 최신값.
const MAIN_DB_MIN_SAMPLES = 10; // 원래 500ms 기준 4개(≈2초) 비율 유지

function getMainAvgDb() {
  if (!mainChannel || mainDbSamplesHash !== mainChannel) {
    const latest = channelAudioLevels[mainChannel];
    return (typeof latest === 'number' && isFinite(latest)) ? latest : null;
  }
  const valid = mainDbSamples.filter((db) => typeof db === 'number' && isFinite(db) && db >= MIN_VALID_REFERENCE_DB);
  if (valid.length < MAIN_DB_MIN_SAMPLES) {
    const latest = channelAudioLevels[mainChannel];
    return (typeof latest === 'number' && isFinite(latest)) ? latest : null;
  }
  const sorted = valid.slice().sort((a, b) => a - b);
  const q1 = percentileOf(sorted, 0.25);
  const q3 = percentileOf(sorted, 0.75);
  const trimmed = valid.filter((db) => db >= q1 && db <= q3);
  if (trimmed.length === 0) return (q1 + q3) / 2;
  return trimmed.reduce((sum, db) => sum + db, 0) / trimmed.length;
}

// 메인을 지금 볼륨으로 들을 때의 체감 음량을 그룹 기준으로 환산한 상한 — 서브가 메인보다 크게 들리지 않게. 없으면 null.
function getMainRefDbAtBaseline(groupBaseline) {
  if (!mainChannel || groupBaseline <= 0) return null;
  const mainVolume = getMainVolumeForChannel(mainChannel);
  if (mainVolume <= 0) return null;
  const mainDb = getMainAvgDb();
  if (typeof mainDb !== 'number' || !isFinite(mainDb) || mainDb < MIN_VALID_REFERENCE_DB) return null;
  const mainPerceivedDb = mainDb + 20 * Math.log10(mainVolume / 100);
  return mainPerceivedDb - 20 * Math.log10(groupBaseline / 100);
}

// 평준화를 반영한 실제 재생 음량(기준 음량 위에 감쇠만). 'sub'만 메인 기준 상한을 추가로 받는다.
function getGroupEffectiveVolumeForChannel(hash, role) {
  const baseline = getChannelBaselineVolume(hash);
  if (!isAudioOptimizationEnabled()) return baseline;
  // 유튜브 특정 영상 고정 항목도 일반 채널과 동일하게 그룹 비교를 받는다.
  const groupHashes = getGroupHashes(role);
  // 그룹 최솟값 기준(감쇠만). role을 히스테리시스 키로 쓴다.
  const referenceDb = getGroupRefDb(groupHashes, role);
  let attenuation = getChannelDbAttenuation(hash, referenceDb);
  if (role === 'sub') {
    // "서브 ≤ 메인" 하드 캡은 별도로 계산해 더 많이 깎는 쪽을 쓴다.
    const mainCapDb = getMainRefDbAtBaseline(baseline);
    if (mainCapDb !== null) {
      const mainAttenuation = getChannelDbAttenuationVsMain(hash, mainCapDb);
      attenuation = Math.min(attenuation, mainAttenuation);
    }
  }
  return Math.round(baseline * attenuation);
}

function hexToRgbString(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return '0, 255, 163';
  const int = parseInt(m[1], 16);
  return `${(int >> 16) & 255}, ${(int >> 8) & 255}, ${int & 255}`;
}

function getPlatformColorRGB(platform) {
  return hexToRgbString(getPlatformColor(platform));
}

// ── 한글 로마자 음역 — 구글 음역(dt=rm) 실패 시 오프라인 폴백 ── 소리 나는 대로 옮기며 한글 외 문자는 그대로.
const HANGUL_INITIALS = ['g', 'kk', 'n', 'd', 'tt', 'r', 'm', 'b', 'pp', 's', 'ss', '', 'j', 'jj', 'ch', 'k', 't', 'p', 'h'];
const HANGUL_MEDIALS = ['a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae', 'oe', 'yo', 'u', 'wo', 'we', 'wi', 'yu', 'eu', 'ui', 'i'];
const HANGUL_FINALS = ['', 'g', 'kk', 'gs', 'n', 'nj', 'nh', 'd', 'l', 'lg', 'lm', 'lb', 'ls', 'lt', 'lp', 'lh', 'm', 'b', 'bs', 's', 'ss', 'ng', 'j', 'ch', 'k', 't', 'p', 'h'];

function romanizeHangulText(text) {
  const s = String(text || '');
  let out = '';
  for (const ch of s) {
    const code = ch.codePointAt(0);
    if (code >= 0xAC00 && code <= 0xD7A3) {
      const base = code - 0xAC00;
      const initial = Math.floor(base / (21 * 28));
      const medial = Math.floor((base % (21 * 28)) / 28);
      const final = base % 28;
      out += HANGUL_INITIALS[initial] + HANGUL_MEDIALS[medial] + HANGUL_FINALS[final];
    } else {
      out += ch;
    }
  }
  return out;
}

// ── 영어 → 한글 음역 — 치지직/숲 검색 보완 ── 구글 번역(tl=ko)이 고유명사를 음역하는 걸 재사용한다.
// 결과에 한글이 없으면 버린다. 세션 동안 캐시.
const _englishToKoreanTranslitCache = new Map();
const ENGLISH_TO_KOREAN_TRANSLIT_CACHE_MAX = 500;
async function transliterateToKorean(text) {
  const s = String(text || '').trim();
  if (!s || !/^[\x00-\x7F]*$/.test(s) || !/[A-Za-z]/.test(s)) return '';
  if (_englishToKoreanTranslitCache.has(s)) return _englishToKoreanTranslitCache.get(s);
  // 캡+FIFO 축출로 오래 켜둔 세션에서 무한히 커지지 않게.
  if (_englishToKoreanTranslitCache.size >= ENGLISH_TO_KOREAN_TRANSLIT_CACHE_MAX) {
    _englishToKoreanTranslitCache.delete(_englishToKoreanTranslitCache.keys().next().value);
  }
  const promise = (async () => {
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=ko&dt=t&q=${encodeURIComponent(s)}`;
      const res = await apiFetch(url);
      if (!res.ok) throw new Error(`http_${res.status}`);
      const raw = await res.text();
      const data = JSON.parse(raw);
      const translated = Array.isArray(data?.[0])
        ? data[0].map(seg => (Array.isArray(seg) ? seg[0] : '') || '').join('').trim()
        : '';
      const result = /[가-힣]/.test(translated) ? translated : '';
      console.log(`[CHEESE EYES][영→한 음역] '${s}' -> '${result || '(실패)'}'`);
      return result;
    } catch (e) {
      console.warn(`[CHEESE EYES][영→한 음역] '${s}' 변환 실패:`, e);
      return '';
    }
  })();
  _englishToKoreanTranslitCache.set(s, promise);
  return promise;
}

const PlatformAdapters = {
  chzzk: {
    async _fetchChannelSearchRaw(keyword, size = 20) {
      try {
        const res = await apiFetch(`https://api.chzzk.naver.com/service/v1/search/channels?keyword=${encodeURIComponent(keyword)}&offset=0&size=${size}&withFirstChannelContent=true`);
        if (!res.ok) return [];
        const data = await res.json();
        return data.content && data.content.data ? data.content.data : [];
      } catch (e) { return []; }
    },
    // options.includeOffline — "r " 다시보기 검색은 방송 중이 아닌 채널도 보여준다.
    async searchAutocomplete(keyword, size = 10, options = {}) {
      try {
        const queries = [keyword];
        const translit = await transliterateToKorean(keyword);
        if (translit) queries.push(translit);
        const dataLists = await Promise.all(queries.map(q => this._fetchChannelSearchRaw(q)));

        const seenChannelId = new Set();
        const rawChannels = [];
        dataLists.forEach(list => {
          list.forEach(entry => {
            const c = entry.channel;
            if (!c || !c.channelId || !c.channelName || seenChannelId.has(c.channelId)) return;
            seenChannelId.add(c.channelId);
            rawChannels.push(c);
          });
        });

        const checked = await Promise.all(rawChannels.map(async (c) => {
          if (options.includeOffline) return { platform: 'chzzk', text: c.channelName };
          const isLive = await checkChzzkLiveByChannelId(c.channelId);
          return isLive ? { platform: 'chzzk', text: c.channelName } : null;
        }));

        const seen = new Set();
        const items = [];
        for (const item of checked) {
          if (!item || seen.has(item.text)) continue;
          seen.add(item.text);
          items.push(item);
          if (items.length >= size) break;
        }
        return items;
      } catch (e) { return []; }
    },
    async searchChannelByName(name) {
      try {
        const queries = [name];
        const translit = await transliterateToKorean(name);
        if (translit) queries.push(translit);
        for (const q of queries) {
          const list = await this._fetchChannelSearchRaw(q, 33);
          if (list.length > 0) {
            const c = list[0].channel;
            return { platform: 'chzzk', hash: c.channelId, name: c.channelName };
          }
        }
      } catch (err) { console.error(`'${name}' 치지직 채널 검색 실패:`, err); }
      return null;
    },
    async searchCandidatesByKeyword(keyword) {
      const queries = [keyword];
      const translit = await transliterateToKorean(keyword);
      if (translit) queries.push(translit);
      const lists = await Promise.all(queries.map(q => this._fetchChannelSearchRaw(q, 33)));
      const seen = new Set();
      const raw = [];
      lists.forEach(list => list.forEach(entry => {
        const c = entry.channel;
        if (!c || !c.channelId || !c.channelName || seen.has(c.channelId)) return;
        seen.add(c.channelId);
        raw.push(c);
      }));

      return await Promise.all(raw.map(async (c) => ({
        platform: 'chzzk',
        hash: c.channelId,
        name: c.channelName,
        live: await checkChzzkLiveByChannelId(c.channelId)
      })));
    },
    async getChannelById(id) {
      try {
        const res = await apiFetch(`https://api.chzzk.naver.com/service/v1/channels/${id}`);
        if (res.ok) {
          const data = await res.json();
          if (data.content && data.content.channelName) {
            return { platform: 'chzzk', hash: id, name: data.content.channelName };
          }
        }
      } catch (err) { console.error('치지직 해시 조회 실패:', err); }
      return { platform: 'chzzk', hash: id, name: id.substring(0, 8) };
    },
    // 방송 종료 채널 VOD 목록(비공식 엔드포인트, 실패 시 빈 배열). size만큼 채워 왔으면 다음 페이지 번호를 nextCursor로 준다.
    async getChannelVideos(channelId, size = 10, cursor = 0) {
      try {
        const page = typeof cursor === 'number' ? cursor : 0;
        const url = new URL(`https://api.chzzk.naver.com/service/v1/channels/${channelId}/videos`);
        url.searchParams.set('sortType', 'LATEST');
        url.searchParams.set('pagingType', 'PAGE');
        url.searchParams.set('page', String(page));
        url.searchParams.set('size', String(size));
        const res = await apiFetch(url.toString());
        if (!res.ok) return { items: [], nextCursor: null };
        const data = await res.json();
        const list = data.content && data.content.data ? data.content.data : [];
        const items = list
          .filter(v => v && v.videoNo)
          .map(v => ({
            videoNo: v.videoNo,
            title: v.videoTitle || '',
            thumbnail: v.thumbnailImageUrl || '',
            duration: v.duration || 0,
            readCount: v.readCount || 0,
            publishDate: v.publishDate || ''
          }));
        return { items, nextCursor: items.length >= size ? page + 1 : null };
      } catch (err) {
        console.error(`[CHEESE EYES] ${channelId} 치지직 다시보기 목록 조회 실패:`, err);
        return { items: [], nextCursor: null };
      }
    },
    // 치지직 VOD 상세 — 목록에 없는 liveOpenDate/livePv/prev·nextVideo를 준다(calcChzzkVodStartTime용).
    async getVodDetail(videoNo) {
      try {
        const res = await apiFetch(`https://api.chzzk.naver.com/service/v2/videos/${videoNo}`);
        if (!res.ok) return null;
        const data = await res.json();
        return data?.content || null;
      } catch (err) {
        console.error(`[CHEESE EYES] ${videoNo} 치지직 VOD 상세 조회 실패:`, err);
        return null;
      }
    },
    // VOD 싱크 앵커: 실제 방송 시작 시각(epoch ms). 실패 시 null.
    async getVodStartTime(ch) {
      const detail = await this.getVodDetail(ch.hash);
      if (!detail) return null;
      const start = calcChzzkVodStartTime(detail);
      return start ? start.getTime() : null;
    },
    async searchTagLives(keywordsList) {
      const fetchChannelsForSingleTag = async (keyword) => {
        const channelMap = new Map();
        let nextParam = null;
        let hasNext = true;

        while (hasNext) {
          const url = new URL('https://api.chzzk.naver.com/service/v1/tag/lives');
          url.searchParams.set('size', '50');
          url.searchParams.set('sortType', 'POPULAR');
          url.searchParams.set('tags', keyword);

          if (nextParam && typeof nextParam === 'object') {
            Object.keys(nextParam).forEach(key => {
              if (nextParam[key] !== null && nextParam[key] !== undefined) {
                url.searchParams.set(key, nextParam[key]);
              }
            });
          }

          const res = await apiFetch(url.toString());
          if (!res.ok) break;

          const data = await res.json();
          const liveList = data.content?.data || data.content?.lives || [];

          liveList.forEach(item => {
            if (item.channel && item.channel.channelId) {
              const viewers = typeof item.concurrentUserCount === 'number' ? item.concurrentUserCount : null;
              if (viewers != null && viewers < getMinViewers('chzzk')) return;
              channelMap.set(item.channel.channelId, {
                platform: 'chzzk',
                hash: item.channel.channelId,
                name: item.channel.channelName,
                title: item.liveTitle || '',
                thumbnail: item.liveImageUrl ? item.liveImageUrl.replace('{type}', '270') : '',
                viewersText: viewers != null ? viewers.toLocaleString() : ''
              });
            }
          });

          const pageNext = data.content?.page?.next;
          if (pageNext && Object.keys(pageNext).length > 0) {
            nextParam = pageNext;
          } else {
            hasNext = false;
          }
        }
        return channelMap;
      };

      const results = await Promise.all(keywordsList.map(k => fetchChannelsForSingleTag(k)));
      const firstMap = results[0];
      const finalMap = new Map();
      firstMap.forEach((info, id) => {
        if (results.slice(1).every(m => m.has(id))) finalMap.set(id, info);
      });
      return Array.from(finalMap.values());
    },
    async fetchFollowingLive() {
      const res = await apiFetch('https://api.chzzk.naver.com/service/v1/channels/followings/live?size=100', { credentials: 'include' });
      if (!res.ok) { const err = new Error('chzzk_following_failed'); err.status = res.status; throw err; }
      const data = await res.json();
      const list = data.content?.followingList || data.content?.data || [];
      // 목록 엔드포인트의 썸네일/제목이 비어 와서 live-detail로 채널별 재조회한다.
      const enriched = await Promise.all(list.map(async (item) => {
        const c = item.channel || item;
        if (!c.channelId) return null;
        try {
          const detailRes = await apiFetch(`https://api.chzzk.naver.com/service/v2/channels/${c.channelId}/live-detail`);
          if (detailRes.ok) {
            const detail = await detailRes.json();
            const content = detail && detail.content;
            if (content && content.status === 'OPEN') {
              return {
                platform: 'chzzk',
                hash: c.channelId,
                name: c.channelName,
                title: content.liveTitle || '',
                thumbnail: content.liveImageUrl ? content.liveImageUrl.replace('{type}', '270') : '',
                viewersText: typeof content.concurrentUserCount === 'number' ? content.concurrentUserCount.toLocaleString() : ''
              };
            }
          }
        } catch (e) { /* 아래 폴백으로 계속 */ }
        // 재조회 실패 시 목록 필드로 폴백(프로필 사진으로 대체하지 않음).
        const liveImg = item.liveImageUrl || item.defaultThumbnailImageUrl || '';
        return {
          platform: 'chzzk',
          hash: c.channelId,
          name: c.channelName,
          title: item.liveTitle || '',
          thumbnail: liveImg ? liveImg.replace('{type}', '270') : '',
          viewersText: typeof item.concurrentUserCount === 'number' ? item.concurrentUserCount.toLocaleString() : ''
        };
      }));
      return enriched.filter(Boolean);
    },
    async checkLoginStatus() {
      try {
        const res = await apiFetch('https://api.chzzk.naver.com/service/v1/channels/followings/live?size=1', { credentials: 'include' });
        return res.ok;
      } catch (e) { return false; }
    },
    getLoginUrl() { return 'https://nid.naver.com/nidlogin.login?url=https://chzzk.naver.com/'; },
    getLogoutUrl() { return 'https://nid.naver.com/nidlogin.logout?returl=https://chzzk.naver.com/'; },
    getVideoEmbedUrl(id) {
      const ch = getChannelObjByHash(id);
      return (ch && ch.isVod) ? `https://chzzk.naver.com/video/${id}` : `https://chzzk.naver.com/live/${id}`;
    },
    getChatEmbedUrl(id) {
      const ch = getChannelObjByHash(id);
      // VOD는 채팅 전용 iframe이 없어 시청 페이지에 cheeseChatEmbed를 붙이고 content.js가 #vod-aside만 띄운다.
      if (ch && ch.isVod) {
        return `https://chzzk.naver.com/video/${id}?cheeseChatEmbed=1`;
      }
      return `https://chzzk.naver.com/live/${id}/chat`;
    },
    getChannelHomeUrl(id) {
      // VOD 채널의 hash는 videoNo — 채널 홈 URL엔 저장된 channelId를 써야 한다.
      const ch = getChannelObjByHash(id);
      if (ch && ch.isVod && ch.channelId) return `https://chzzk.naver.com/${ch.channelId}`;
      return `https://chzzk.naver.com/${id}`;
    },
    getVodUrlAtTime(id, seconds) {
      // 치지직 VOD 시점 지정 파라미터명은 미검증 — 틀리면 이 이름만 고치면 된다.
      const sec = Math.max(0, Math.floor(seconds || 0));
      return `https://chzzk.naver.com/video/${id}?vodTime=${sec}`;
    },
    async checkFollowStatus(id) {
      try {
        const res = await apiFetch(`https://api.chzzk.naver.com/service/v1/channels/${id}`, { credentials: 'include' });
        if (!res.ok) return false;
        const data = await res.json();
        return !!(data.content && data.content.personalData && data.content.personalData.following);
      } catch (e) { return false; }
    },
    async setFollow(id, follow) {
      const url = `https://api.chzzk.naver.com/service/v1/channels/${id}/follow`;
      const init = { method: follow ? 'POST' : 'DELETE' };
      try {
        const res = await frameApiFetch(id, url, init);
        return !!res.ok;
      } catch (frameErr) {
        console.warn('[CHEESE EYES] 치지직 팔로우 프레임 프록시 실패, background로 폴백:', frameErr);
        try {
          const res = await apiFetch(url, { ...init, credentials: 'include' });
          return !!res.ok;
        } catch (e) { console.error('[CHEESE EYES] 치지직 팔로우 처리 실패:', e); return false; }
      }
    }
  },

  soop: {
    async _liveSearch(keyword, { page = 1, count = 20 } = {}) {
      try {
        const sessionKey = await getSoopSessionKey();
        const url = `https://sch.sooplive.com/api.php?l=DF&m=liveSearch&c=UTF-8&w=webk&isMobile=0&onlyParent=1&szType=json` +
          `&sck_session_key=${encodeURIComponent(sessionKey)}&szOrder=score&szKeyword=${encodeURIComponent(keyword)}` +
          `&nPageNo=${page}&nListCnt=${count}&tab=total&location=total_search&isHashSearch=0&v=2.0`;
        const res = await apiFetch(url, { credentials: 'include' });
        if (!res.ok) return [];
        const data = await res.json();
        return data?.REAL_BROAD || data?.data || data?.list || data?.result || [];
      } catch (err) { console.error(`'${keyword}' 숲 liveSearch 실패:`, err); return []; }
    },
    _toChannelData(raw) {
      if (!raw) return null;
      const id = raw.user_id || raw.bj_id;
      if (!id) return null;
      const nm = raw.user_nick || id;
      const broadNo = raw.broad_no;
      return { platform: 'soop', hash: id, broadNo, name: nm };
    },
    async searchAutocomplete(keyword, size = 10) {
      try {
        const queries = [keyword];
        const translit = await transliterateToKorean(keyword);
        if (translit) queries.push(translit);
        const seen = new Set();
        const items = [];
        for (const q of queries) {
          const list = await this._liveSearch(q, { count: size });
          const kw = String(q || '').trim().toLowerCase();
          for (const raw of list) {
            const text = String(raw.user_nick || raw.user_id || '').trim();
            if (!text || seen.has(text)) continue;
            if (kw && !text.toLowerCase().includes(kw)) continue;
            seen.add(text);
            items.push({ platform: 'soop', type: 'bj', text, user_id: raw.user_id || '', broadNo: raw.broad_no || '' });
            if (items.length >= size) break;
          }
          if (items.length >= size) break;
        }
        return items;
      } catch (e) { return []; }
    },
    async searchChannelByName(name) {
      const queries = [name];
      const translit = await transliterateToKorean(name);
      if (translit) queries.push(translit);
      for (const q of queries) {
        const list = await this._liveSearch(q);
        const first = list[0];
        if (first && String(first.user_nick || '').trim() === String(q).trim()) {
          return this._toChannelData(first);
        }
      }
      return null;
    },
    async searchChannelById(id) {
      const list = await this._liveSearch(id);
      const matched = list.find(c => (c.user_id || '').trim() === id.trim()) || list[0];
      return this._toChannelData(matched);
    },
    async getChannelById(id) {
      const found = await this.searchChannelById(id);
      if (found) return found;
      return { platform: 'soop', hash: id, name: id };
    },
    async searchCandidatesByKeyword(keyword) {
      const queries = [keyword];
      const translit = await transliterateToKorean(keyword);
      if (translit) queries.push(translit);
      const lists = await Promise.all(queries.map(q => this._liveSearch(q, { count: 20 })));
      const seen = new Set();
      const results = [];
      lists.forEach(list => list.forEach(raw => {
        const ch = this._toChannelData(raw);
        if (!ch || seen.has(ch.hash)) return;
        seen.add(ch.hash);
        results.push(ch);
      }));
      return results;
    },
    async _fetchByCategoryNo(categoryNo) {
      const map = new Map();
      try {
        const url = `https://sch.sooplive.com/api.php?m=categoryContentsList&szType=live&nPageNo=1&nListCnt=60&szPlatform=pc&szCateNo=${encodeURIComponent(categoryNo)}&szOrder=view_cnt_desc&strmLangType=`;
        const res = await apiFetch(url);
        if (!res.ok) {
          console.warn(`[숲] 카테고리 '${categoryNo}' 요청 실패 (status=${res.status})`);
          return map;
        }
        const data = await res.json();
        const list = data?.data?.list;
        if (!Array.isArray(list)) {
          console.warn(`[숲] 카테고리 '${categoryNo}' 응답에서 list 배열을 찾지 못함`, data);
          return map;
        }
        list.forEach(item => {
          const viewers = item.total_view_cnt ?? item.view_cnt ?? item.m_current_view_cnt;
          const viewersNum = viewers != null ? Number(viewers) : null;
          if (viewersNum != null && !isNaN(viewersNum) && viewersNum < getMinViewers('soop')) return;
          const c = this._toChannelData(item);
          if (c) {
            map.set(c.hash, {
              ...c,
              title: item.broad_title || '',
              thumbnail: item.thumbnail || item.broad_img || '',
              viewersText: viewersNum != null && !isNaN(viewersNum) ? viewersNum.toLocaleString() : ''
            });
          }
        });
        console.log(`[숲] 카테고리 '${categoryNo}' 검색 결과: ${map.size}개`);
      } catch (err) {
        console.error(`[숲] 카테고리 '${categoryNo}' 검색 실패:`, err);
      }
      return map;
    },
    async _fetchByHashtag(keyword, { page = 1, count = 60 } = {}) {
      const map = new Map();
      try {
        const sessionKey = await getSoopSessionKey();
        const url = `https://sch.sooplive.com/api.php?l=DF&m=liveSearch&c=UTF-8&w=webk&isMobile=0&onlyParent=1&szType=json` +
          `&sck_session_key=${encodeURIComponent(sessionKey)}&szOrder=view_cnt&szOrderType=desc&szKeyword=${encodeURIComponent(keyword)}` +
          `&nPageNo=${page}&nListCnt=${count}&tab=live&location=hash&isHashSearch=1&v=2.0`;
        const res = await apiFetch(url, { credentials: 'include' });
        if (!res.ok) {
          console.warn(`[숲] 태그 '${keyword}' 요청 실패 (status=${res.status})`);
          return map;
        }
        const data = await res.json();
        const list = data?.REAL_BROAD;
        if (!Array.isArray(list)) {
          console.warn(`[숲] 태그 '${keyword}' 응답에서 REAL_BROAD 배열을 찾지 못함`, data);
          return map;
        }
        list.forEach(item => {
          const viewers = item.total_view_cnt ?? item.view_cnt ?? item.m_current_view_cnt;
          const viewersNum = viewers != null ? Number(viewers) : null;
          if (viewersNum != null && !isNaN(viewersNum) && viewersNum < getMinViewers('soop')) return;
          const c = this._toChannelData(item);
          if (c) {
            map.set(c.hash, {
              ...c,
              title: item.broad_title || '',
              thumbnail: item.thumbnail || item.broad_img || '',
              viewersText: viewersNum != null && !isNaN(viewersNum) ? viewersNum.toLocaleString() : ''
            });
          }
        });
        console.log(`[숲] 태그 '${keyword}' 검색 결과: ${map.size}개`);
      } catch (err) {
        console.error(`[숲] 태그 '${keyword}' 검색 실패:`, err);
      }
      return map;
    },
    async searchTagLives(categoryNoList) {
      try {
        const perCategory = await Promise.all(categoryNoList.map(async (tag) => {
          const catMap = await this._fetchByCategoryNo(tag);
          if (catMap.size > 0) return catMap;
          console.log(`[숲] '${tag}' 카테고리 결과 없음 → 태그 검색으로 폴백`);
          return await this._fetchByHashtag(tag);
        }));

        const firstMap = perCategory[0] || new Map();
        const finalMap = new Map();
        firstMap.forEach((info, id) => {
          if (perCategory.slice(1).every(m => m.has(id))) finalMap.set(id, info);
        });
        console.log(`[숲] 태그 검색 최종 교집합: ${finalMap.size}개`);
        return Array.from(finalMap.values());
      } catch (err) { console.error('숲 카테고리 검색 실패:', err); return []; }
    },
    async fetchFollowingLive() {
      const res = await apiFetch('https://myapi.sooplive.com/api/favorite', { credentials: 'include' });
      if (!res.ok) { const err = new Error('soop_following_failed'); err.status = res.status; throw err; }
      const data = await res.json();
      const list = Array.isArray(data?.data) ? data.data : [];
      const liveFavorites = list.filter(item => item && Array.isArray(item.broad_info) && item.broad_info.length > 0);

      // favorite 엔드포인트의 썸네일/제목이 비어 와서 liveSearch 결과로 재조회한다(user_id 완전일치 우선).
      const enriched = await Promise.all(liveFavorites.map(async (item) => {
        const userId = item.user_id;
        if (userId) {
          try {
            const searched = await this._liveSearch(userId, { count: 5 });
            const matched = searched.find(raw => (raw.user_id || '').trim() === userId.trim()) || searched[0];
            if (matched) {
              const ch = this._toChannelData(matched);
              if (ch) {
                const viewers = matched.total_view_cnt ?? matched.view_cnt ?? matched.m_current_view_cnt;
                return {
                  ...ch,
                  title: matched.broad_title || matched.title || '',
                  thumbnail: matched.broad_img || matched.thumbnail || '',
                  viewersText: viewers != null ? Number(viewers).toLocaleString() : ''
                };
              }
            }
          } catch (e) { /* 아래 폴백으로 계속 */ }
        }
        const info = item.broad_info[0] || {};
        const c = this._toChannelData({
          ...item,
          broad_no: info.broad_no || info.BROAD_NO || item.broad_no
        });
        if (!c) return null;
        const viewers = info.total_view_cnt ?? info.view_cnt ?? info.m_current_view_cnt;
        return {
          ...c,
          title: info.broad_title || info.title || '',
          thumbnail: info.broad_img || info.thumbnail || '',
          viewersText: viewers != null ? Number(viewers).toLocaleString() : ''
        };
      }));
      return enriched.filter(c => c && c.hash);
    },
    _favoriteListPromise: null,
    _favoriteListFetchedAt: 0,
    async _fetchFavoriteList(force = false) {
      const now = Date.now();
      if (!force && this._favoriteListPromise && (now - this._favoriteListFetchedAt) < 5000) {
        return this._favoriteListPromise;
      }
      this._favoriteListFetchedAt = now;
      this._favoriteListPromise = (async () => {
        try {
          const res = await apiFetch('https://myapi.sooplive.com/api/favorite', { credentials: 'include' });
          if (!res.ok) return [];
          const data = await res.json();
          return Array.isArray(data?.data) ? data.data : [];
        } catch (e) { return []; }
      })();
      return this._favoriteListPromise;
    },
    getChannelHomeUrl(id) { return `https://www.sooplive.com/station/${id}`; },
    async checkFollowStatus(id) {
      try {
        const list = await this._fetchFavoriteList();
        const found = list.find(item => item && item.user_id === id);
        return !!(found && found.is_favorite);
      } catch (e) { return false; }
    },
    async setFollow(id, follow) {
      const url = follow ? 'https://myapi.sooplive.com/api/favorite' : `https://myapi.sooplive.com/api/favorite/${id}`;
      const init = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(follow ? { user_id: id } : { _method: 'delete' })
      };
      try {
        let res;
        try {
          res = await frameApiFetch(id, url, init);
        } catch (frameErr) {
          console.warn('[CHEESE EYES] 숲 팔로우 프레임 프록시 실패, background로 폴백:', frameErr);
          res = await apiFetch(url, { ...init, credentials: 'include' });
        }
        if (res.ok) this._favoriteListFetchedAt = 0;
        return !!res.ok;
      } catch (e) { console.error('[CHEESE EYES] 숲 팔로우 처리 실패:', e); return false; }
    },
    async checkLoginStatus() {
      // 쿠키가 있어도 서버 세션은 만료됐을 수 있다 — 항상 IS_LOGIN 응답으로 판단한다.
      try {
        const res = await apiFetch('https://afevent2.sooplive.com/api/get_private_info.php', { credentials: 'include' });
        if (!res.ok) return false;
        const data = await res.json();
        return !!(data && data.CHANNEL && Number(data.CHANNEL.IS_LOGIN) === 1);
      } catch (e) { return false; }
    },
    getLoginUrl() {
      const redirect = 'https%3A%2F%2Fwww.sooplive.com%2F%3FNaPm%3Dct%253Dms449q61%257Cci%253Dcheckout%257Ctr%253Dds%257Ctrx%253Dnull%257Chk%253Db35fd46bed07395082f04cfc18718246fc96e156';
      return `https://login.sooplive.com/afreeca/login.php?szFrom=pop&request_uri=${redirect}`;
    },
    getLogoutUrl() { return null; },
    async logout() {
      return new Promise((resolve) => {
        chrome.runtime.sendMessage({ type: 'SOOP_LOGOUT' }, (res) => {
          resolve(!!(res && res.ok));
        });
      });
    },
    getVideoEmbedUrl(id) {
      const ch = getChannelObjByHash(id);
      if (ch && ch.isVod) return `https://vod.sooplive.com/player/${id}`;
      const broadNo = ch && ch.broadNo;
      return broadNo ? `https://play.sooplive.com/${id}/${broadNo}` : `https://play.sooplive.com/${id}`;
    },
    getChatEmbedUrl(id) {
      const ch = getChannelObjByHash(id);
      if (ch && ch.isVod) return 'about:blank';
      const broadNo = ch && ch.broadNo;
      return broadNo ? `https://play.sooplive.com/${id}/${broadNo}?vtype=chat` : `https://play.sooplive.com/${id}?vtype=chat`;
    }
  },

  youtube: {
    async _context() {
      return {
        client: {
          clientName: 'WEB',
          clientVersion: '2.20260101.00.00',
          hl: (typeof window !== 'undefined' && window.CHEESE_EYES_CURRENT_LANG) || 'ko'
        }
      };
    },
    INNERTUBE_API_KEY: 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8',
    // 후보 채널명 음역 캐시 — 같은 이름의 번역 API 중복 호출 방지.
    _channelNameTranslitCache: new Map(),
    async _innerTubePost(path, body, requiresAuth = false) {
      const res = await apiFetch(`https://www.youtube.com/youtubei/v1/${path}?key=${this.INNERTUBE_API_KEY}&prettyPrint=false`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Youtube-Client-Name': '1',
          'X-Youtube-Client-Version': body?.context?.client?.clientVersion || '2.20260101.00.00'
        },
        body: JSON.stringify(body),
        requiresAuth
      });
      if (!res.ok) {
        const reason = res.statusText ? ` (${res.statusText})` : '';
        console.warn(`[CHEESE EYES] InnerTube ${path} 요청 실패: status=${res.status}${reason}`);
        return null;
      }
      try { return await res.json(); } catch (e) {
        console.warn(`[CHEESE EYES] InnerTube ${path} 응답 JSON 파싱 실패:`, e);
        return null;
      }
    },
    // VOD 싱크 앵커: InnerTube microformat liveBroadcastDetails.startTimestamp(UNPLAYABLE이어도 채워짐). 라이브 콘텐츠가 아니면 null.
    async getVodStartTime(ch) {
      if (!ch || !ch.videoId) return null;
      const data = await this._innerTubePost('player', { context: await this._context(), videoId: ch.videoId });
      if (!data?.videoDetails?.isLiveContent) return null;
      const details = data.microformat?.playerMicroformatRenderer?.liveBroadcastDetails;
      if (!details?.startTimestamp) return null;
      const start = new Date(details.startTimestamp);
      return isNaN(start.getTime()) ? null : start.getTime();
    },
    // 렌더러 키 이름 대신 videoId + 라이브 배지를 가진 객체를 구조적으로 찾는다(피드마다 렌더러 키가 다름).
    _isLiveVideoNode(node) {
      if (!node || typeof node !== 'object' || typeof node.videoId !== 'string') return false;
      const badges = node.badges || node.thumbnailOverlayBadges || [];
      const hasLiveBadge = Array.isArray(badges) && badges.some(b =>
        b?.metadataBadgeRenderer?.style === 'BADGE_STYLE_TYPE_LIVE_NOW'
        || b?.metadataBadgeRenderer?.label === 'LIVE'
      );
      const overlays = node.thumbnailOverlays || [];
      const hasLiveOverlay = Array.isArray(overlays) && overlays.some(o =>
        o?.thumbnailOverlayTimeStatusRenderer?.style === 'LIVE'
        || o?.thumbnailOverlayTimeStatusRenderer?.icon?.iconType === 'LIVE'
      );
      return hasLiveBadge || hasLiveOverlay;
    },
    // 신형 Kevlar UI(lockupViewModel): videoId 대신 contentId, 라이브 배지는 thumbnail overlay badges 또는 아바타 liveData.
    _isLiveLockupNode(node) {
      if (!node || typeof node !== 'object' || typeof node.contentId !== 'string') return false;
      const overlays = node.contentImage?.thumbnailViewModel?.overlays || [];
      const hasLiveThumbBadge = Array.isArray(overlays) && overlays.some(o =>
        (o?.thumbnailBottomOverlayViewModel?.badges || []).some(b =>
          b?.thumbnailBadgeViewModel?.badgeStyle === 'THUMBNAIL_OVERLAY_BADGE_STYLE_LIVE'
        )
      );
      const avatarLiveData = node.metadata?.lockupMetadataViewModel?.image?.decoratedAvatarViewModel
        ?.avatar?.avatarViewModel?.liveData;
      return hasLiveThumbBadge || !!avatarLiveData;
    },
    _findContinuationTokens(node, out = []) {
      if (!node || typeof node !== 'object') return out;
      const token = node?.continuationEndpoint?.continuationCommand?.token
        || node?.continuationCommand?.token;
      if (typeof token === 'string' && token) out.push(token);
      for (const key in node) {
        const val = node[key];
        if (val && typeof val === 'object') this._findContinuationTokens(val, out);
      }
      return out;
    },
    _collectLiveVideoRenderers(node, out = [], seenRendererKeys = null) {
      if (!node || typeof node !== 'object') return out;
      if (this._isLiveVideoNode(node)) out.push(node);
      if (node.lockupViewModel && this._isLiveLockupNode(node.lockupViewModel)) out.push(node.lockupViewModel);
      // 쇼츠는 수집 단계에서 제외.
      for (const key in node) {
        const val = node[key];
        if (val && typeof val === 'object') {
          if (seenRendererKeys && /Renderer$/.test(key)) seenRendererKeys.add(key);
          this._collectLiveVideoRenderers(val, out, seenRendererKeys);
        }
      }
      return out;
    },
    _videoRendererToChannel(vr) {
      try {
        const owner = vr.ownerText?.runs?.[0] || vr.longBylineText?.runs?.[0] || vr.shortBylineText?.runs?.[0];
        const channelId = owner?.navigationEndpoint?.browseEndpoint?.browseId;
        const name = owner?.text || vr.title?.runs?.[0]?.text || '';
        const videoId = vr.videoId;
        if (!channelId || !videoId) return null;
        const title = vr.title?.runs?.[0]?.text || vr.title?.simpleText || '';
        const thumbs = vr.thumbnail?.thumbnails;
        const thumbnail = Array.isArray(thumbs) && thumbs.length > 0 ? thumbs[thumbs.length - 1].url : '';
        const viewersText = (vr.viewCountText?.runs || []).map(r => r.text).join('')
          || vr.shortViewCountText?.simpleText
          || '';
        return { platform: 'youtube', hash: channelId, name, videoId, title, thumbnail, viewersText };
      } catch (e) { return null; }
    },
    _lockupToChannel(node) {
      try {
        const videoId = node.contentId;
        const lm = node.metadata?.lockupMetadataViewModel;
        if (!videoId || !lm) return null;
        const title = lm.title?.content || '';
        const rows = lm.metadata?.contentMetadataViewModel?.metadataRows || [];
        const firstPart = rows[0]?.metadataParts?.[0];
        const name = firstPart?.text?.content || '';
        const channelId = firstPart?.text?.commandRuns?.[0]?.onTap?.innertubeCommand?.browseEndpoint?.browseId;
        if (!channelId || !videoId) return null;
        const viewersText = rows[1]?.metadataParts?.[0]?.text?.content || '';
        const thumbs = node.contentImage?.thumbnailViewModel?.image?.sources;
        const thumbnail = Array.isArray(thumbs) && thumbs.length > 0 ? thumbs[thumbs.length - 1].url : '';
        return { platform: 'youtube', hash: channelId, name, videoId, title, thumbnail, viewersText };
      } catch (e) { return null; }
    },
    _anyLiveNodeToChannel(node) {
      if (!node) return null;
      if (typeof node.contentId === 'string') return this._lockupToChannel(node);
      if (typeof node.videoId === 'string') return this._videoRendererToChannel(node);
      return null;
    },
    // ── "/vod" 검색용 업로드 목록 ── 동영상 탭 API가 없어 UC→UU 자동 업로드 재생목록을 browse한다.
    _isVideoListNode(node) {
      if (!node || typeof node !== 'object') return false;
      if (typeof node.videoId === 'string' && (node.title || node.lengthText || node.thumbnailOverlays)) return true;
      return false;
    },
    _collectVideoListNodes(node, out = []) {
      if (!node || typeof node !== 'object') return out;
      if (this._isVideoListNode(node)) out.push(node);
      if (node.lockupViewModel && typeof node.lockupViewModel.contentId === 'string') out.push(node.lockupViewModel);
      for (const key in node) {
        const val = node[key];
        if (val && typeof val === 'object') this._collectVideoListNodes(val, out);
      }
      return out;
    },
    // 구형/신형 노드에서 { videoId, title, thumbnail, duration, publishDate }를 뽑는다(chzzk와 같은 필드명).
    _anyVideoNodeToVideoItem(node) {
      try {
        if (typeof node.contentId === 'string') {
          const videoId = node.contentId;
          const lm = node.metadata?.lockupMetadataViewModel;
          const title = lm?.title?.content || '';
          if (!videoId || !title) return null;
          const thumbs = node.contentImage?.thumbnailViewModel?.image?.sources;
          const thumbnail = Array.isArray(thumbs) && thumbs.length > 0 ? thumbs[thumbs.length - 1].url : '';
          const overlays = node.contentImage?.thumbnailViewModel?.overlays || [];
          const durationText = overlays
            .flatMap(o => (o?.thumbnailBottomOverlayViewModel?.badges || []))
            .map(b => b?.thumbnailBadgeViewModel?.text || '')
            .find(Boolean) || '';
          const rows = lm?.metadata?.contentMetadataViewModel?.metadataRows || [];
          const metaTexts = rows.flatMap(r => (r.metadataParts || []).map(p => p?.text?.content || '')).filter(Boolean);
          const publishDate = metaTexts[metaTexts.length - 1] || '';
          return { videoId, title, thumbnail, duration: youtubeTsToSeconds(durationText), publishDate };
        }
        if (typeof node.videoId === 'string') {
          const videoId = node.videoId;
          const title = node.title?.runs?.[0]?.text || node.title?.simpleText || '';
          if (!videoId || !title) return null;
          const thumbs = node.thumbnail?.thumbnails;
          const thumbnail = Array.isArray(thumbs) && thumbs.length > 0 ? thumbs[thumbs.length - 1].url : '';
          const durationText = node.lengthText?.simpleText
            || (node.thumbnailOverlays || []).map(o => o?.thumbnailOverlayTimeStatusRenderer?.text?.simpleText).find(Boolean)
            || '';
          const publishDate = node.publishedTimeText?.simpleText || '';
          return { videoId, title, thumbnail, duration: youtubeTsToSeconds(durationText), publishDate };
        }
        return null;
      } catch (e) { return null; }
    },
    // 채널 탭 전환용 고정 params(비공식, yt-dlp와 동일). 바뀌면 빈 목록으로 폴백.
    _YT_CHANNEL_TAB_PARAMS: {
      videos: 'EgZ2aWRlb3PyBgQKAjoA',
      streams: 'EgdzdHJlYW1z8gYECgJ6AA=='
    },
    // cursor = continuation 토큰(첫 페이지 null). tab: 'videos'|'streams'. continuation엔 탭이 이미 인코딩돼 있다.
    async getChannelVideos(channelId, size = 20, cursor = null, tab = 'videos') {
      try {
        const context = await this._context();
        let data;
        if (cursor) {
          data = await this._innerTubePost('browse', { context, continuation: cursor });
        } else {
          if (!/^UC[a-zA-Z0-9_-]{22}$/.test(channelId)) return { items: [], nextCursor: null };
          const params = this._YT_CHANNEL_TAB_PARAMS[tab] || this._YT_CHANNEL_TAB_PARAMS.videos;
          data = await this._innerTubePost('browse', { context, browseId: channelId, params });
        }
        if (!data) return { items: [], nextCursor: null };
        const nodes = this._collectVideoListNodes(data);
        const seen = new Set();
        const results = [];
        for (const node of nodes) {
          // 진행 중/예약 방송은 탭 구분 없이 항상 걸러낸다.
          if (this._isUpcomingOrLiveStreamNode(node)) continue;
          const v = this._anyVideoNodeToVideoItem(node);
          if (!v || seen.has(v.videoId)) continue;
          seen.add(v.videoId);
          results.push(v);
          if (results.length >= size) break;
        }
        const tokens = this._findContinuationTokens(data);
        return { items: results, nextCursor: tokens.length > 0 ? tokens[0] : null };
      } catch (err) {
        console.error(`[CHEESE EYES] ${channelId} 유튜브 업로드 목록 조회 실패:`, err);
        return { items: [], nextCursor: null };
      }
    },
    _collectTabRenderers(node, out = []) {
      if (!node || typeof node !== 'object') return out;
      if (node.tabRenderer) out.push(node.tabRenderer);
      for (const key in node) {
        const val = node[key];
        if (val && typeof val === 'object') this._collectTabRenderers(val, out);
      }
      return out;
    },
    // streams 탭이 없는 채널은 유튜브가 업로드 탭으로 조용히 폴백하므로 채널 홈에서 탭 존재를 먼저 확인한다.
    async hasLiveTab(channelId) {
      try {
        if (!/^UC[a-zA-Z0-9_-]{22}$/.test(channelId)) return true;
        const context = await this._context();
        const data = await this._innerTubePost('browse', { context, browseId: channelId });
        if (!data) return true;
        const tabs = this._collectTabRenderers(data);
        // 탭 params는 URL 인코딩돼 온다 — decodeURIComponent 후 비교.
        return tabs.some(tb => {
          const params = tb?.endpoint?.browseEndpoint?.params;
          if (!params) return false;
          try {
            return decodeURIComponent(params) === this._YT_CHANNEL_TAB_PARAMS.streams;
          } catch (e) { return params === this._YT_CHANNEL_TAB_PARAMS.streams; }
        });
      } catch (err) {
        console.error(`[CHEESE EYES] ${channelId} 유튜브 라이브 탭 존재 확인 실패:`, err);
        return true;
      }
    },
    // 진행 중/예약 방송 제외. 구조 신호 우선, ko/en 텍스트는 보조이며 "아직 아님"만 판정한다(오래된 다시보기 오탐 방지).
    _isUpcomingOrLiveStreamNode(node) {
      if (this._isLiveVideoNode(node) || this._isLiveLockupNode(node)) return true;
      if (node && typeof node === 'object' && node.upcomingEventData) return true;
      const overlays = (node && node.thumbnailOverlays) || [];
      if (Array.isArray(overlays) && overlays.some(o => o?.thumbnailOverlayTimeStatusRenderer?.style === 'UPCOMING')) return true;
      const metaRows = node?.metadata?.lockupMetadataViewModel?.metadata?.contentMetadataViewModel?.metadataRows || [];
      const lockupText = metaRows.flatMap(r => (r.metadataParts || []).map(p => p?.text?.content || '')).join(' ');
      const text = [node?.publishedTimeText?.simpleText, node?.viewCountText?.simpleText, lockupText].filter(Boolean).join(' ');
      return this._looksLikeUpcomingOrLiveText(text);
    },
    _looksLikeUpcomingOrLiveText(text) {
      if (!text) return false;
      const s = String(text);
      if (/scheduled for/i.test(s)) return true;
      if (/\bwatching\b/i.test(s)) return true;
      if (/premieres?\b/i.test(s)) return true;
      if (/예정/.test(s)) return true;
      if (/시청\s*중/.test(s)) return true;
      if (/대기\s*중/.test(s)) return true;
      return false;
    },
    // Kevlar 채널 카드(lockupViewModel) — 영상 lockup과 같은 래퍼라 contentId가 채널ID 형식(UC+22자)인지로 구분한다.
    _channelLockupToChannel(node) {
      try {
        const channelId = node.contentId;
        const lm = node.metadata?.lockupMetadataViewModel;
        if (!channelId || !lm) return null;
        const name = lm.title?.content || '';
        if (!name) return null;
        const rows = lm.metadata?.contentMetadataViewModel?.metadataRows || [];
        const rowTexts = rows.flatMap(r => (r.metadataParts || []).map(p => p?.text?.content || '')).filter(Boolean);
        const handle = rowTexts.find(t => t.startsWith('@')) || '';
        const subscriberText = rowTexts.find(t => t !== handle) || '';
        return { platform: 'youtube', hash: channelId, name, handle, subscriberText };
      } catch (e) { return null; }
    },
    _collectChannelRenderers(node, out = []) {
      if (!node || typeof node !== 'object') return out;
      if (node.channelRenderer) {
        const cr = node.channelRenderer;
        const channelId = cr.channelId;
        if (channelId) {
          const name = cr.title?.simpleText || cr.title?.runs?.[0]?.text || '';
          const handleCandidate = cr.channelHandleText?.simpleText
            || (cr.subscriberCountText?.simpleText?.startsWith('@') ? cr.subscriberCountText.simpleText : '')
            || '';
          const subscriberText = (!handleCandidate && cr.subscriberCountText?.simpleText) || cr.videoCountText?.simpleText || '';
          out.push({ platform: 'youtube', hash: channelId, name, handle: handleCandidate, subscriberText });
        }
      }
      // 채널 검색인데도 lockupViewModel로 오는 경우가 있다 — 놓치면 검색이 빈 결과가 된다.
      if (node.lockupViewModel && typeof node.lockupViewModel.contentId === 'string'
        && /^UC[a-zA-Z0-9_-]{22}$/.test(node.lockupViewModel.contentId)) {
        const ch = this._channelLockupToChannel(node.lockupViewModel);
        if (ch) out.push(ch);
      }
      for (const key in node) {
        if (key === 'channelRenderer') continue;
        const val = node[key];
        if (val && typeof val === 'object') this._collectChannelRenderers(val, out);
      }
      return out;
    },
    // 유사도 필터 전 원본 후보 — 핸들 완전일치처럼 표기 체계가 다른 경로는 이걸 써야 한다.
    async _rawSearchChannelCandidates(keyword) {
      const context = await this._context();
      const matchTerms = await this._buildKeywordMatchTerms(keyword);

      // 원본어로는 결과가 안 나오는 경우가 많아 음역 키워드로도 검색해 합친다.
      const searchQueries = new Set([keyword]);
      if (matchTerms.translated) searchQueries.add(matchTerms.translated);
      if (matchTerms.alias) searchQueries.add(matchTerms.alias);

      const dataList = await Promise.all(
        Array.from(searchQueries).map(q => this._innerTubePost('search', { context, query: q, params: 'EgIQAg%3D%3D' }))
      );

      const seenHash = new Set();
      const rawChannels = [];
      dataList.forEach(data => {
        if (!data) return;
        this._collectChannelRenderers(data).forEach(ch => {
          if (!ch.hash || !ch.name || seenHash.has(ch.hash)) return;
          seenHash.add(ch.hash);
          rawChannels.push(ch);
        });
      });
      return { rawChannels, matchTerms, searchQueries };
    },
    async _searchChannelRenderers(keyword) {
      const { rawChannels, matchTerms, searchQueries } = await this._rawSearchChannelCandidates(keyword);

      // 음역 판정이 비동기라 Promise.all로 병렬 실행한다.
      const matchResults = await Promise.all(
        rawChannels.map(ch => this._candidateMatchesKeyword(ch, matchTerms))
      );
      const filtered = rawChannels.filter((_, idx) => matchResults[idx].matched);
      console.log(`[CHEESE EYES][음역 필터] '${keyword}' 채널명 검색 결과(검색어 ${searchQueries.size}개 합산): 통과 ${filtered.length}건 / 제외 ${rawChannels.length - filtered.length}건`);
      return filtered;
    },
    _parseSubscriberCountText(text) {
      if (!text) return null;
      const cleaned = String(text).replace(/,/g, '');

      const koMatch = cleaned.match(/([\d.]+)\s*(만|천)?/);
      if (/구독자|명/.test(cleaned) && koMatch) {
        const num = parseFloat(koMatch[1]);
        if (isNaN(num)) return null;
        const unit = koMatch[2];
        if (unit === '만') return num * 10000;
        if (unit === '천') return num * 1000;
        return num;
      }

      const enMatch = cleaned.match(/([\d.]+)\s*([KMB])?/i);
      if (/subscribers?/i.test(cleaned) && enMatch) {
        const num = parseFloat(enMatch[1]);
        if (isNaN(num)) return null;
        const unit = (enMatch[2] || '').toUpperCase();
        if (unit === 'K') return num * 1_000;
        if (unit === 'M') return num * 1_000_000;
        if (unit === 'B') return num * 1_000_000_000;
        return num;
      }

      return null;
    },
    // 확인된 핸들 캐시 중 keyword로 시작하는 것(입력 횟수 순) — 자동완성보다 신뢰도가 높다.
    async _matchedCachedHandles(keyword) {
      try {
        const cached = await readYoutubeHandleCache();
        const kw = keyword.toLowerCase();
        return cached
          .filter(e => e && typeof e.handle === 'string' && e.handle.toLowerCase().startsWith(kw))
          .sort((a, b) => (b.count || 0) - (a.count || 0))
          .map(e => e.handle);
      } catch (e) { return []; }
    },
    async searchAutocomplete(keyword, size = 10) {
      const isHandleMode = keyword.startsWith('@');
      const cachedMatches = isHandleMode ? await this._matchedCachedHandles(keyword) : [];

      // '@' 뒤가 한글이면 자동완성이 핸들 제안을 안 준다 — alias 기반 검색으로 드롭다운에 실제 핸들을 보여준다.
      let aliasHandleMatches = [];
      if (isHandleMode) {
        const afterAt = keyword.slice(1).trim();
        console.log(`[CHEESE EYES][@핸들검색] afterAt="${afterAt}" isEnglish=${afterAt ? this._isEnglishQuery(afterAt) : null}`);
        if (afterAt && !this._isEnglishQuery(afterAt)) {
          try {
            const candidates = await this._searchChannelRenderers(afterAt);
            console.log(`[CHEESE EYES][@핸들검색] 후보 ${candidates.length}개:`, candidates.map(c => ({ name: c.name, handle: c.handle })));
            aliasHandleMatches = candidates
              .map(c => c.handle)
              .filter(h => typeof h === 'string' && h.startsWith('@'));
            console.log(`[CHEESE EYES][@핸들검색] 핸들 있는 후보 ${aliasHandleMatches.length}개:`, aliasHandleMatches);
          } catch (e) { console.warn('[CHEESE EYES][@핸들검색] alias 기반 검색 실패:', e); }
        }
      }

      try {
        const hl = (typeof window !== 'undefined' && window.CHEESE_EYES_CURRENT_LANG) || 'ko';
        const url = `https://suggestqueries-clients6.youtube.com/complete/search?client=firefox&ds=yt&hl=${encodeURIComponent(hl)}&q=${encodeURIComponent(keyword)}`;
        const res = await apiFetch(url);

        let suggestions = [];
        if (res.ok) {
          try {
            const raw = await res.text();
            const parsed = JSON.parse(raw);
            suggestions = Array.isArray(parsed?.[1])
              ? parsed[1].map(s => Array.isArray(s) ? s[0] : s).filter(s => typeof s === 'string')
              : [];
          } catch (e) { suggestions = []; }
        }

        const filtered = isHandleMode
          ? suggestions.filter(s => s.startsWith('@'))
          : suggestions.filter(s => !this._looksLikeNonChannelQuery(s, keyword));

        // 캐시·alias 매칭을 API 추천 앞에 두고 중복 제거해 합친다.
        const seen = new Set();
        const merged = [];
        [...cachedMatches, ...aliasHandleMatches, ...filtered].forEach(text => {
          const key = text.toLowerCase();
          if (seen.has(key)) return;
          seen.add(key);
          merged.push(text);
        });

        return merged.slice(0, size).map(text => ({ platform: 'youtube', text }));
      } catch (e) {
        console.error('유튜브 자동완성(Stage A) 실패:', e);
        const seen = new Set();
        const merged = [];
        [...cachedMatches, ...aliasHandleMatches].forEach(text => {
          const key = text.toLowerCase();
          if (seen.has(key)) return;
          seen.add(key);
          merged.push(text);
        });
        return merged.slice(0, size).map(text => ({ platform: 'youtube', text }));
      }
    },
    _countPlainSpaces(text) {
      return (String(text || '').match(/ /g) || []).length;
    },
    _looksLikeNonChannelQuery(text, queryText) {
      const s = String(text).trim();
      if (!s) return true;
      if (/[?!]/.test(s)) return true;

      // 연관 검색어가 원래보다 단어가 많으면 주제성 검색어로 보고 제외한다.
      const querySpaces = this._countPlainSpaces(String(queryText || '').trim());
      const suggestionSpaces = this._countPlainSpaces(s);
      if (suggestionSpaces > querySpaces) return true;

      const topicWords = ['리뷰', 'review', 'vs', '비교', '모음', '총정리', '순위', 'top', '베스트', 'best', '하는법', 'how to', 'tutorial'];
      const lower = s.toLowerCase();
      if (topicWords.some(w => lower.includes(w))) return true;

      if (s.split(' ').filter(Boolean).length > 5) return true;

      if (/\d/.test(s) && /(결산|가지|선정|추천)/.test(s)) return true;

      return false;
    },
    // 가나 또는 한자 포함 여부(한글 제외). 표의문자만 구글 음역 API를 쓴다.
    _containsCJKIdeographOrKana(text) {
      return /[\u3040-\u30FF\u4E00-\u9FFF\uF900-\uFAFF]/.test(String(text || ''));
    },
    // 언어별 음역 정책 — 한글/기타: 정식 엔드포인트 dt=t, 일본어/한자: 발음 표기용 dt=rm.
    async _transliterateByLanguagePolicy(text) {
      const s = String(text || '').trim();
      if (!s) return '';
      if (this._containsCJKIdeographOrKana(s)) {
        return await this._transliterateToLatin(s);
      }
      return await this._translateGeneral(s);
    },
    // 구글 번역 dt=t(정식 엔드포인트). data[0]의 번역 조각만 이어 붙인다.
    async _translateGeneral(text) {
      const s = String(text || '').trim();
      if (!s) return '';
      try {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(s)}`;
        const res = await apiFetch(url);
        console.log(`[CHEESE EYES][번역] '${s}' 요청 -> ok=${res.ok} status=${res.status}`);
        if (!res.ok) throw new Error(`http_${res.status}`);
        const raw = await res.text();
        const data = JSON.parse(raw);
        const translated = Array.isArray(data?.[0])
          ? data[0].map(seg => (Array.isArray(seg) ? seg[0] : '') || '').join('').trim()
          : '';
        console.log(`[CHEESE EYES][번역] '${s}' -> '${translated}'`);
        return translated;
      } catch (e) {
        console.warn(`[CHEESE EYES][번역] '${s}' 구글 번역 실패:`, e);
        return '';
      }
    },
    // 발음 그대로의 음역(dt=rm). 일본어/한자에만 쓰며 응답 포맷이 비공식이라 방어적으로 파싱한다.
    async _transliterateToLatin(text) {
      const s = String(text || '').trim();
      if (!s) return '';
      try {
        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=rm&q=${encodeURIComponent(s)}`;
        const res = await apiFetch(url);
        console.log(`[CHEESE EYES][음역] '${s}' 요청 -> ok=${res.ok} status=${res.status}`);
        if (!res.ok) throw new Error(`http_${res.status}`);
        const raw = await res.text();
        const data = JSON.parse(raw);
        console.log(`[CHEESE EYES][음역] '${s}' 원본 응답:`, data);
        const pron = this._extractRomanizationFromResponse(data, s);
        if (!pron) throw new Error('empty_pronunciation');
        console.log(`[CHEESE EYES][음역] '${s}' -> '${pron}'`);
        return pron;
      } catch (e) {
        console.warn(`[CHEESE EYES][음역] '${s}' 구글 음역 실패, 오프라인 폴백 시도:`, e);
        // 구글 음역 실패 시 한글이면 로컬 변환표로 폴백.
        const romanized = romanizeHangulText(s).trim();
        if (romanized && romanized !== s) {
          console.log(`[CHEESE EYES][음역] '${s}' -> '${romanized}' (오프라인 폴백)`);
          return romanized;
        }
        return '';
      }
    },
    // dt=rm 응답은 비문서화 — 전체 JSON에서 원본과 다른 순수 로마자 문자열 중 가장 긴 것을 고른다.
    _extractRomanizationFromResponse(data, original) {
      const candidates = [];
      const walk = (node) => {
        if (typeof node === 'string') {
          const v = node.trim();
          if (v && v !== original && /^[A-Za-z0-9 '\-.,!?]+$/.test(v)) candidates.push(v);
        } else if (Array.isArray(node)) {
          node.forEach(walk);
        }
      };
      walk(data);
      if (candidates.length === 0) return '';
      candidates.sort((a, b) => b.length - a.length);
      return candidates[0];
    },
    // 이미 ASCII면 음역을 생략한다.
    _isEnglishQuery(text) {
      const s = String(text || '');
      if (!s) return false;
      return /^[\x00-\x7F]*$/.test(s);
    },
    // 검색어가 제목/채널명/핸들(원본·음역) 어디에도 없으면 제외. translated는 로마자 음역.
    // 애칭 테이블(youtube_aliases.js)에 있으면 실제 채널명을 돌려준다.
    _lookupChannelAlias(normalizedText) {
      const map = window.CHEESE_EYES_YOUTUBE_ALIASES;
      if (!map || !normalizedText) return null;
      const textNoSpace = normalizedText.replace(/\s+/g, '');

      const exact = map.get(normalizedText) || map.get(textNoSpace);
      if (exact) return exact;

      // 부분 포함도 확인한다. 여럿이면 긴 별칭 우선, 최소 2자.
      let bestKey = null;
      let bestName = null;
      for (const [key, name] of map.entries()) {
        const keyNoSpace = key.replace(/\s+/g, '');
        const matches =
          (key.length >= 2 && normalizedText.includes(key)) ||
          (normalizedText.length >= 2 && key.includes(normalizedText)) ||
          (keyNoSpace.length >= 2 && textNoSpace.includes(keyNoSpace)) ||
          (textNoSpace.length >= 2 && keyNoSpace.includes(textNoSpace));
        if (matches && (!bestKey || key.length > bestKey.length)) {
          bestKey = key;
          bestName = name;
        }
      }
      return bestName;
    },
    async _buildKeywordMatchTerms(query) {
      // NFKC 정규화로 전각/반각 등 표기 차이를 흡수한다.
      const original = String(query || '').trim().normalize('NFKC').toLowerCase();
      if (!original) return { original: '', translated: null, alias: null };

      const alias = this._lookupChannelAlias(original);
      if (alias) console.log(`[CHEESE EYES][별칭 보정] '${original}' → '${alias}'`);

      if (this._isEnglishQuery(original)) {
        console.log(`[CHEESE EYES][음역] '${original}' 은 이미 영어라 음역 생략`);
        return { original, translated: null, alias };
      }

      const translatedRaw = await this._transliterateByLanguagePolicy(original);
      let translated = null;
      if (translatedRaw) {
        // 음역 결과의 불필요한 공백을 제거한다.
        const normalized = translatedRaw.toLowerCase().replace(/\s+/g, '');
        if (normalized && normalized !== original) translated = normalized;
      }
      console.log(`[CHEESE EYES][음역] '${original}' 매칭 키워드: 원본="${original}" 음역="${translated || ''}"`);
      return { original, translated, alias };
    },
    // ── 후보 채널명 음역 ── 검색어만 음역하면 표기 체계가 달라 비교가 무의미하므로 채널명도 로마자로 바꾼다.
    // 채널명만 대상(title 제외), 세션 동안 캐시.
    async _getCandidateNameTransliteration(name) {
      const s = String(name || '').trim().normalize('NFKC');
      if (!s) return '';
      if (this._isEnglishQuery(s)) return '';
      if (this._channelNameTranslitCache.has(s)) {
        return this._channelNameTranslitCache.get(s);
      }
      const translatedRaw = await this._transliterateByLanguagePolicy(s);
      const translated = translatedRaw ? translatedRaw.toLowerCase().replace(/\s+/g, '') : '';
      this._channelNameTranslitCache.set(s, translated);
      return translated;
    },
    // ── Levenshtein 매칭 ── 완전 포함이 안 되면 haystack 구간들과의 편집 거리로 판정한다.
    _levenshteinDistance(a, b) {
      const al = a.length, bl = b.length;
      if (al === 0) return bl;
      if (bl === 0) return al;
      const dp = new Array(bl + 1);
      for (let j = 0; j <= bl; j++) dp[j] = j;
      for (let i = 1; i <= al; i++) {
        let prev = dp[0];
        dp[0] = i;
        for (let j = 1; j <= bl; j++) {
          const temp = dp[j];
          dp[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[j], dp[j - 1]);
          prev = temp;
        }
      }
      return dp[bl];
    },
    _similarityRatio(a, b) {
      const maxLen = Math.max(a.length, b.length);
      if (maxLen === 0) return 1;
      return 1 - this._levenshteinDistance(a, b) / maxLen;
    },
    // haystack에서 term 길이 ±3 구간을 슬라이딩하며 최고 유사도를 반환(포함되면 1).
    _bestSimilarityInText(term, text) {
      if (!term || !text) return 0;
      if (text.includes(term)) return 1;
      const termLen = term.length;
      const minWin = Math.max(1, termLen - 3);
      const maxWin = Math.min(text.length, termLen + 3);
      let best = 0;
      for (let winLen = minWin; winLen <= maxWin; winLen++) {
        for (let i = 0; i + winLen <= text.length; i++) {
          const sim = this._similarityRatio(term, text.substr(i, winLen));
          if (sim > best) {
            best = sim;
            if (best >= 0.999) return best;
          }
        }
      }
      return best;
    },
    // 양방향 — 후보가 검색어보다 짧은 경우도 본다.
    _bestSimilarityBidirectional(term, text) {
      if (!term || !text) return 0;
      return text.length >= term.length
        ? this._bestSimilarityInText(term, text)
        : this._bestSimilarityInText(text, term);
    },
    // 채널명만 비교한다(제목/핸들은 우연한 겹침이 많음).
    async _candidateMatchesKeyword(candidate, matchTerms) {
      if (!matchTerms || (!matchTerms.original && !matchTerms.translated)) return { matched: true, score: 1 };
      const haystack = (candidate?.name || '')
        .normalize('NFKC')
        .toLowerCase();
      if (!haystack) {
        console.log(`[CHEESE EYES][음역 필터] 제외 (haystack 없음) - name="${candidate?.name || ''}" title="${candidate?.title || ''}"`);
        return { matched: false, score: 0 };
      }
      const haystackNoSpace = haystack.replace(/\s+/g, '');

      // ── 별칭 보정(최우선) ── 등록된 애칭이면 실제 채널명이 후보명에 들어 있는지만 본다.
      if (matchTerms.alias) {
        const aliasNorm = matchTerms.alias.normalize('NFKC').toLowerCase();
        const aliasNormNoSpace = aliasNorm.replace(/\s+/g, '');
        if (haystack.includes(aliasNorm) || haystackNoSpace.includes(aliasNormNoSpace)) {
          console.log(`[CHEESE EYES][별칭 필터] 통과(별칭-포함) - name="${candidate?.name || ''}" 별칭="${matchTerms.alias}"`);
          return { matched: true, score: 1 };
        }
      }

      const SIMILARITY_THRESHOLD = 0.72;
      let matched = false;
      let bestScore = 0;
      let matchedBy = '';

      // ── 원본어 매칭 ── 단어 2개 이상이면 과반 포함으로 통과.
      const orig = matchTerms.original;
      if (orig) {
        const words = orig.split(' ').filter(Boolean);
        const presentCount = words.filter(w => haystack.includes(w) || haystackNoSpace.includes(w)).length;
        const requiredCount = words.length <= 1 ? words.length : Math.max(1, Math.ceil(words.length * 0.6));
        const allWordsPresent = words.length > 0 && presentCount >= requiredCount;
        if (allWordsPresent) {
          matched = true;
          bestScore = 1;
          matchedBy = `원본-단어포함(${presentCount}/${words.length})`;
        } else {
          const longerThanQuery = haystack.length > orig.length;
          const longerThanQueryNoSpace = haystackNoSpace.length > orig.length;
          if (longerThanQuery || longerThanQueryNoSpace) {
            const score = Math.max(
              longerThanQuery ? this._bestSimilarityInText(orig, haystack) : 0,
              longerThanQueryNoSpace ? this._bestSimilarityInText(orig, haystackNoSpace) : 0
            );
            if (score > bestScore) bestScore = score;
            if (score >= SIMILARITY_THRESHOLD) {
              matched = true;
              matchedBy = '원본-유사도';
            }
          }
        }
      }

      // ── 음역 매칭 ── 검색어/채널명이 영어인지 각각 따로 판단해 준비한다(검색어만 영어인 경우도 비교).
      if (!matched) {
        const queryLatin = matchTerms.translated || matchTerms.original;
        if (queryLatin) {
          const candidateNameHasCJK = this._containsCJKIdeographOrKana(candidate?.name || '');
          const nameTranslit = await this._getCandidateNameTransliteration(candidate?.name);
          // 한자/가나가 섞인 채널명은 음역 결과가 있을 때만 비교한다(원문의 영단어 조각으로 오탐 방지).
          const compareTargets = candidateNameHasCJK
            ? [nameTranslit].filter(Boolean)
            : [haystack, haystackNoSpace].filter(Boolean);
          for (const hs of compareTargets) {
            if (hs.includes(queryLatin) || queryLatin.includes(hs)) {
              matched = true;
              bestScore = 1;
              matchedBy = '음역-포함';
              break;
            }
            const score = this._bestSimilarityBidirectional(queryLatin, hs);
            if (score > bestScore) bestScore = score;
            if (score >= SIMILARITY_THRESHOLD) {
              matched = true;
              matchedBy = '음역-유사도';
              break;
            }
          }
        }
      }

      console.log(`[CHEESE EYES][음역 필터] ${matched ? `통과(${matchedBy})` : '제외'} (유사도=${bestScore.toFixed(2)}) - name="${candidate?.name || ''}" title="${candidate?.title || ''}" 원본="${matchTerms.original}" 음역="${matchTerms.translated || ''}"`);
      return { matched, score: bestScore };
    },
    async _resolveKeywordCandidatesForStageB(query) {
      const matchTerms = await this._buildKeywordMatchTerms(query);

      // 원본어로는 라이브 검색 결과가 안 나오는 경우가 많아 음역 키워드로도 검색해 합친다.
      const searchQueries = new Set([query]);
      if (matchTerms.translated) searchQueries.add(matchTerms.translated);
      if (matchTerms.alias) searchQueries.add(matchTerms.alias);

      const dataList = await Promise.all(
        Array.from(searchQueries).map(q => this._fetchLiveSearchResults(q))
      );

      const liveRenderers = [];
      dataList.forEach(data => {
        if (data) liveRenderers.push(...this._collectLiveVideoRenderers(data));
      });
      if (liveRenderers.length === 0) return [];

      // 1) 같은 채널 중복 제거(음역 호출 중복 방지).
      const seen = new Set();
      const dedupedChannels = [];
      for (const vr of liveRenderers) {
        const ch = this._anyLiveNodeToChannel(vr);
        if (!ch || seen.has(ch.hash)) continue;
        seen.add(ch.hash);
        const thumbnail = vr.thumbnail?.thumbnails?.slice(-1)?.[0]?.url || '';
        const viewersText = vr.viewCountText?.runs?.map(r => r.text).join('') || vr.viewCountText?.simpleText || '';
        const title = vr.title?.runs?.map(r => r.text).join('') || vr.title?.simpleText || '';
        dedupedChannels.push({ ...ch, thumbnail, viewersText, title });
      }

      // 1.5) 최소 시청자수 필터를 매칭보다 먼저 적용(매칭은 API 비용이 큼).
      const minViewers = getMinViewers('youtube');
      const viewerFiltered = dedupedChannels
        .map(c => ({ ...c, _viewers: this._parseViewerCountText(c.viewersText) }))
        // 시청자 수를 파싱 못 한 채널은 제외한다.
        .filter(c => c._viewers != null && c._viewers >= minViewers);
      const viewerExcludedCount = dedupedChannels.length - viewerFiltered.length;
      if (viewerExcludedCount > 0) {
        console.log(`[CHEESE EYES][최소 시청자수 필터] '${query}' : 시청자수 미달 ${viewerExcludedCount}건 선제외 (기준=${minViewers})`);
      }

      // 2) 매칭 판정 병렬 처리.
      const matchResults = await Promise.all(
        viewerFiltered.map(c => this._candidateMatchesKeyword(c, matchTerms))
      );
      const candidates = [];
      viewerFiltered.forEach((c, idx) => {
        const r = matchResults[idx];
        if (r.matched) candidates.push({ ...c, _relevance: r.score });
      });
      const excludedCount = viewerFiltered.length - candidates.length;
      console.log(`[CHEESE EYES][음역 필터] '${query}' 라이브 검색 결과(검색어 ${searchQueries.size}개 합산, 최소 시청자수 통과 ${viewerFiltered.length}건 대상): 통과 ${candidates.length}건 / 제외 ${excludedCount}건`);

      const withIndex = candidates.map((c, idx) => ({ ...c, _idx: idx }));
      const filtered = withIndex;
      // 정렬: 관련성 → 시청자 수 → 원래 순서.
      filtered.sort((a, b) => {
        if (b._relevance !== a._relevance) return b._relevance - a._relevance;
        if (a._viewers == null && b._viewers == null) return a._idx - b._idx;
        if (a._viewers == null) return 1;
        if (b._viewers == null) return -1;
        if (b._viewers !== a._viewers) return b._viewers - a._viewers;
        return a._idx - b._idx;
      });
      return filtered.map(({ _idx, _viewers, _relevance, ...rest }) => rest);
    },
    async _fetchLiveSearchResults(query) {
      try {
        const context = await this._context();
        return await this._innerTubePost('search', { context, query, params: 'EgJAAQ%3D%3D' });
      } catch (e) { console.error(`'${query}' 유튜브 라이브 검색 실패:`, e); return null; }
    },
    async _resolveHandleCandidatesForStageB(handleText) {
      const resolved = await this._resolveByHandleOrText(handleText);
      if (!resolved) return [];
      return [{
        platform: 'youtube',
        hash: resolved.hash,
        name: resolved.name,
        videoId: resolved.videoId || null,
        thumbnail: '',
        viewersText: ''
      }];
    },
    _parseViewerCountText(text) {
      if (!text) return null;
      const cleaned = String(text).replace(/,/g, '');

      const koMatch = cleaned.match(/([\d.]+)\s*(만|천)?/);
      if (koMatch) {
        const num = parseFloat(koMatch[1]);
        if (!isNaN(num)) {
          if (koMatch[2] === '만') return num * 10000;
          if (koMatch[2] === '천') return num * 1000;
          return num;
        }
      }

      const enMatch = cleaned.match(/([\d.]+)\s*([KMB])?/i);
      if (enMatch) {
        const num = parseFloat(enMatch[1]);
        if (!isNaN(num)) {
          const unit = (enMatch[2] || '').toUpperCase();
          if (unit === 'K') return num * 1_000;
          if (unit === 'M') return num * 1_000_000;
          if (unit === 'B') return num * 1_000_000_000;
          return num;
        }
      }
      return null;
    },
    async searchChannelByName(name) {
      try {
        const channels = await this._searchChannelRenderers(name);
        if (channels.length === 0) return null;
        return await this._resolveByChannelId(channels[0].hash);
      } catch (err) { console.error(`'${name}' 유튜브 채널 검색 실패:`, err); return null; }
    },
    // 라이브 여부와 무관한 이름 검색(프리셋용). 기준 미달 후보는 제외된다.
    async searchCandidatesByKeyword(keyword) {
      try {
        const context = await this._context();
        const matchTerms = await this._buildKeywordMatchTerms(keyword);

        // 음역·별칭 키워드로도 검색해 합친다(_searchChannelRenderers와 같은 패턴).
        const searchQueries = new Set([keyword]);
        if (matchTerms.translated) searchQueries.add(matchTerms.translated);
        if (matchTerms.alias) searchQueries.add(matchTerms.alias);

        const dataList = await Promise.all(
          Array.from(searchQueries).map(q => this._innerTubePost('search', { context, query: q, params: 'EgIQAg%3D%3D' }))
        );

        const seen = new Set();
        const rawCandidates = [];
        dataList.forEach(data => {
          if (!data) return;
          this._collectChannelRenderers(data).forEach(ch => {
            if (!ch.hash || !ch.name || seen.has(ch.hash)) return;
            seen.add(ch.hash);
            rawCandidates.push(ch);
          });
        });

        const matchResults = await Promise.all(
          rawCandidates.map(ch => this._candidateMatchesKeyword(ch, matchTerms))
        );

        return rawCandidates
          .filter((_, idx) => matchResults[idx].matched)
          .map(ch => ({ platform: 'youtube', hash: ch.hash, name: ch.name }));
      } catch (err) {
        console.error(`'${keyword}' 유튜브 채널 검색 실패:`, err);
        return [];
      }
    },
    async _resolveByChannelId(channelId) {
      let name = channelId;
      try {
        const context = await this._context();
        const data = await this._innerTubePost('browse', { context, browseId: channelId });
        console.log(`[CHEESE EYES][YT-DEBUG] browse(${channelId}) 응답 여부:`, !!data);
        if (data) {
          const liveRenderers = this._collectLiveVideoRenderers(data);
          console.log(`[CHEESE EYES][YT-DEBUG] browse(${channelId}) liveRenderers 개수:`, liveRenderers.length);
          const match = liveRenderers.map(vr => this._anyLiveNodeToChannel(vr)).find(c => c && c.hash === channelId);
          if (match) {
            console.log(`[CHEESE EYES][YT-DEBUG] browse에서 videoId 확보 성공:`, match.videoId);
            return match;
          }
          const metaTitle = data?.metadata?.channelMetadataRenderer?.title;
          if (metaTitle) name = metaTitle;
          console.log(`[CHEESE EYES][YT-DEBUG] browse에서는 라이브 카드를 못 찾음, /live 폴백 시도`);
        }
      } catch (err) {
        console.error(`'${channelId}' 유튜브 채널 browse 실패:`, err);
      }

      // browse에 라이브 카드가 없을 때의 폴백 — /channel/<id>/live의 watch 캐노니컬에서 videoId만 뽑는다(live_stream 임베드는 오류153).
      try {
        const videoId = await this._resolveLiveVideoIdFromLivePage(channelId);
        console.log(`[CHEESE EYES][YT-DEBUG] /live 폴백 결과 videoId:`, videoId);
        if (videoId) return { platform: 'youtube', hash: channelId, name, videoId };
      } catch (err) {
        console.error(`'${channelId}' 유튜브 /live 페이지 조회 실패:`, err);
      }

      console.warn(`[CHEESE EYES][YT-DEBUG] ${channelId}: videoId를 끝내 확보하지 못함 (browse도, /live 폴백도 실패) -> live_stream?channel= 폴백으로 임베드될 예정`);
      return { platform: 'youtube', hash: channelId, name };
    },
    async _resolveLiveVideoIdFromLivePage(channelId) {
      const res = await apiFetch(`https://www.youtube.com/channel/${channelId}/live`);
      console.log(`[CHEESE EYES][YT-DEBUG] /channel/${channelId}/live 응답: ok=${res.ok} status=${res.status}`);
      if (!res.ok) return null;
      const html = await res.text();
      const m = html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})"/);
      console.log(`[CHEESE EYES][YT-DEBUG] /live 페이지 canonical 매치:`, m ? m[1] : null, '(html 길이:', html.length, ')');
      return m ? m[1] : null;
    },
    // checkChannelStillLive 전용. /live 캐노니컬은 방송 종료 직후에도 한동안 직전 방송을 돌려주므로
    // 라이브 배지 카드 또는 새 videoId일 때만 라이브로 본다. 조회 실패 시 null(안 지움).
    async _checkStillLive(channelId, knownVideoId) {
      let browseOk = false;
      try {
        const context = await this._context();
        const data = await this._innerTubePost('browse', { context, browseId: channelId });
        if (data) {
          browseOk = true;
          const liveRenderers = this._collectLiveVideoRenderers(data);
          const match = liveRenderers.map(vr => this._anyLiveNodeToChannel(vr)).find(c => c && c.hash === channelId);
          if (match) return true;
        }
      } catch (err) {
        console.error(`'${channelId}' 유튜브 라이브 재확인 browse 실패:`, err);
      }

      let liveVideoId = null;
      let liveCheckOk = false;
      try {
        liveVideoId = await this._resolveLiveVideoIdFromLivePage(channelId);
        liveCheckOk = true;
      } catch (err) {
        console.error(`'${channelId}' 유튜브 라이브 재확인 /live 페이지 조회 실패:`, err);
      }

      if (liveVideoId && liveVideoId !== knownVideoId) return true;
      if (!browseOk && !liveCheckOk) return null;
      return false;
    },
    async _resolveByHandleOrText(text) {
      try {
        if (text.startsWith('@')) {
          // 핸들은 채널명과 표기가 다른 경우가 많아 필터 전 원본 후보에서 완전일치부터 찾는다.
          const { rawChannels } = await this._rawSearchChannelCandidates(text);
          const exact = rawChannels.find(ch => ch.handle && ch.handle.toLowerCase() === text.toLowerCase());
          if (exact) return await this._resolveByChannelId(exact.hash);
        }
        const channels = await this._searchChannelRenderers(text);
        if (channels.length === 0) return null;
        const target = text.startsWith('@')
          ? (channels.find(ch => ch.handle && ch.handle.toLowerCase() === text.toLowerCase()) || channels[0])
          : channels[0];
        return await this._resolveByChannelId(target.hash);
      } catch (err) { console.error(`'${text}' 유튜브 채널 조회 실패:`, err); return null; }
    },
    async getChannelById(id) {
      const YT_CHANNEL_ID_RE = /^UC[a-zA-Z0-9_-]{22}$/;
      const YT_VIDEO_ID_RE = /^[a-zA-Z0-9_-]{11}$/;
      if (YT_CHANNEL_ID_RE.test(id)) return await this._resolveByChannelId(id);
      if (id.startsWith('@')) {
        const found = await this._resolveByHandleOrText(id);
        if (found) return found;
        return { platform: 'youtube', hash: id, name: id };
      }
      if (YT_VIDEO_ID_RE.test(id)) {
        // "특정 영상 고정" 경로 — 영상 메타로 채널명/제목/라이브챗 여부를 채운다.
        const meta = await this._resolveVideoMeta(id);
        return {
          platform: 'youtube',
          hash: id,
          name: (meta && meta.channelName) || id,
          title: (meta && meta.title) || '',
          videoId: id,
          hasLiveChat: meta ? meta.hasLiveChat : true,
          channelId: (meta && meta.channelId) || null,
          // 특정 영상 고정 표식. videoId는 엔딩화면 클릭으로 바뀔 수 있으니 hash는 최초 식별자로 고정.
          isPinnedVideoSlot: true,
          // meta.isLive로 라이브/VOD를 판정한다(메타 실패 시 라이브 간주). VOD는 숨기면 재생이 멈춘다.
          isVod: meta ? !meta.isLive : false
        };
      }
      const found = await this._resolveByHandleOrText(id);
      if (found) return found;
      return { platform: 'youtube', hash: id, name: id };
    },
    // InnerTube next로 영상 메타 조회(embed_domain 검증 없음). hasLiveChat은 conversationBar.liveChatRenderer 존재 여부.
    async _resolveVideoMeta(videoId) {
      try {
        const context = await this._context();
        const data = await this._innerTubePost('next', { context, videoId });
        if (!data) return null;
        const twoCol = data?.contents?.twoColumnWatchNextResults;
        const contents = twoCol?.results?.results?.contents;
        const primary = Array.isArray(contents) ? contents.find(c => c.videoPrimaryInfoRenderer) : null;
        const secondary = Array.isArray(contents) ? contents.find(c => c.videoSecondaryInfoRenderer) : null;
        const title = (primary?.videoPrimaryInfoRenderer?.title?.runs || []).map(r => r.text).join('')
          || primary?.videoPrimaryInfoRenderer?.title?.simpleText || '';
        const ownerRenderer = secondary?.videoSecondaryInfoRenderer?.owner?.videoOwnerRenderer;
        const channelName = ownerRenderer?.title?.runs?.[0]?.text || '';
        const channelId = ownerRenderer?.title?.runs?.[0]?.navigationEndpoint?.browseEndpoint?.browseId || '';
        const hasLiveChat = !!twoCol?.conversationBar?.liveChatRenderer;
        // 지금 라이브 중인지는 videoViewCountRenderer.isLive만 믿는다(hasLiveChat은 다시보기 채팅에도 켜짐).
        const isLive = !!primary?.videoPrimaryInfoRenderer?.viewCount?.videoViewCountRenderer?.isLive;
        return { title, channelName, channelId, hasLiveChat, isLive };
      } catch (err) {
        console.error(`[CHEESE EYES] 유튜브 영상 메타 조회 실패 (${videoId}):`, err);
        return null;
      }
    },
    // 라이브챗 없는 영상의 댓글(InnerTube next). 본문/작성자는 entityBatchUpdate의 commentEntityPayload를 commentKey로 조인한다.
    async _fetchComments(videoId, continuationToken) {
      try {
        const context = await this._context();
        let data;
        if (continuationToken) {
          data = await this._innerTubePost('next', { context, continuation: continuationToken });
        } else {
          const first = await this._innerTubePost('next', { context, videoId });
          const token = first && this._findCommentsSectionToken(first);
          if (!token) return { items: [], nextToken: null };
          data = await this._innerTubePost('next', { context, continuation: token });
        }
        if (!data) return null;

        let continuationItems = null;
        const endpoints = data.onResponseReceivedEndpoints || [];
        for (const ep of endpoints) {
          if (ep.reloadContinuationItemsCommand && ep.reloadContinuationItemsCommand.slot === 'RELOAD_CONTINUATION_SLOT_BODY') {
            continuationItems = ep.reloadContinuationItemsCommand.continuationItems;
            break;
          }
          if (ep.appendContinuationItemsAction) {
            continuationItems = ep.appendContinuationItemsAction.continuationItems;
            break;
          }
        }
        if (!Array.isArray(continuationItems)) return { items: [], nextToken: null };

        const entities = this._collectCommentEntities(data);
        const items = [];
        let nextToken = null;
        let commentNodeCount = 0;
        continuationItems.forEach((node) => {
          if (node.continuationItemRenderer) {
            const tok = node.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token;
            if (tok) nextToken = tok;
            return;
          }
          // 답글은 commentThreadRenderer 없이 오므로 _parseCommentThread가 기대하는 모양으로 감싼다.
          let thread = node.commentThreadRenderer;
          if (!thread && node.commentViewModel) {
            thread = { commentViewModel: { commentViewModel: node.commentViewModel } };
          }
          if (thread) commentNodeCount++;
          const parsed = thread && this._parseCommentThread(thread, entities);
          if (parsed) items.push(parsed);
        });

        // 노드는 왔는데 하나도 못 파싱함 — parseFailed로 표시하고 원본을 콘솔에 남긴다.
        const parseFailed = commentNodeCount > 0 && items.length === 0;
        if (parseFailed) {
          console.warn('[CHEESE EYES] 유튜브 댓글/답글: commentThreadRenderer는 왔는데 파싱된 항목이 0개입니다. 콘솔에 copy(JSON.stringify(window.__ceLastFailedCommentsResponse)) 입력해서 구조를 확인해주세요.', { commentNodeCount });
          window.__ceLastFailedCommentsResponse = data;
        }

        return { items, nextToken: parseFailed ? null : nextToken, parseFailed };
      } catch (err) {
        console.error(`[CHEESE EYES] 유튜브 댓글 조회 실패 (${videoId}):`, err);
        return null;
      }
    },
    _findCommentsSectionToken(data) {
      try {
        const contents = data?.contents?.twoColumnWatchNextResults?.results?.results?.contents;
        if (!Array.isArray(contents)) return null;
        for (const c of contents) {
          const items = c?.itemSectionRenderer?.contents;
          if (!Array.isArray(items)) continue;
          for (const it of items) {
            const token = it?.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token;
            if (token) return token;
          }
        }
      } catch (e) {}
      return null;
    },
    _collectCommentEntities(data) {
      const map = new Map();
      const mutations = data?.frameworkUpdates?.entityBatchUpdate?.mutations;
      if (Array.isArray(mutations)) {
        mutations.forEach((m) => {
          const payload = m?.payload?.commentEntityPayload;
          if (payload && m.entityKey) map.set(m.entityKey, payload);
        });
      }
      return map;
    },
    _parseCommentThread(thread, entities) {
      try {
        const key = thread.commentViewModel?.commentViewModel?.commentKey;
        const payload = key ? entities.get(key) : null;
        if (!payload) return null;
        const commentId = payload.properties?.commentId || key;
        const text = payload.properties?.content?.content || '';
        const author = payload.author?.displayName || '';
        const avatarUrl = payload.author?.avatarThumbnailUrl || '';
        const publishedTime = payload.properties?.publishedTime || '';
        const likeCount = payload.toolbar?.likeCountLiked || payload.toolbar?.likeCountNotliked || '';
        const isOwner = !!payload.author?.isCreator;
        const isPinned = thread.renderingPriority === 'RENDERING_PRIORITY_PINNED_COMMENT';
        const replyCount = parseInt(String(payload.toolbar?.replyCount || '').replace(/[^0-9]/g, ''), 10) || 0;
        // 답글 진입 토큰은 얇은 context에선 contents로 온다. contents → subThreads → _findContinuationTokens 순.
        const repliesToken = thread.replies?.commentRepliesRenderer?.contents?.[0]
          ?.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token
          || thread.replies?.commentRepliesRenderer?.subThreads?.[0]
            ?.continuationItemRenderer?.continuationEndpoint?.continuationCommand?.token
          || this._findContinuationTokens(thread.replies || {})[0]
          || null;
        // 답글 작성창 params를 찾으려고 원본 노드를 보관한다.
        return { id: commentId, text, author, avatarUrl, publishedTime, likeCount, isOwner, isPinned, replyCount, repliesToken, _raw: thread };
      } catch (e) { return null; }
    },
    // 로그인 상태에서만 있는 commentSimpleboxRenderer의 createCommentParams를 트리 전체에서 찾는다. 없으면 null.
    _findCreateCommentParams(node) {
      if (!node || typeof node !== 'object') return null;
      const params = node?.commentSimpleboxRenderer?.submitButton?.buttonRenderer
        ?.serviceEndpoint?.createCommentEndpoint?.createCommentParams;
      if (params) return params;
      for (const key in node) {
        const val = node[key];
        if (val && typeof val === 'object') {
          const found = this._findCreateCommentParams(val);
          if (found) return found;
        }
      }
      return null;
    },
    // 새 댓글 작성 params. 비로그인이면 null(호출부가 로그인 안내).
    async _getCommentComposerParams(videoId) {
      try {
        const context = await this._context();
        const first = await this._innerTubePost('next', { context, videoId }, true);
        const token = first && this._findCommentsSectionToken(first);
        if (!token) return null;
        const data = await this._innerTubePost('next', { context, continuation: token }, true);
        return data ? this._findCreateCommentParams(data) : null;
      } catch (err) {
        console.error(`[CHEESE EYES] 유튜브 댓글 작성 파라미터 조회 실패 (${videoId}):`, err);
        return null;
      }
    },
    // 답글 작성 params. 스레드에 작성창이 있으면 바로 쓰고, 없으면 답글 토큰으로 인증 next를 다시 호출한다.
    async _getReplyComposerParams(comment) {
      try {
        if (comment._raw) {
          const found = this._findCreateCommentParams(comment._raw);
          if (found) return found;
        }
        if (!comment.repliesToken) return null;
        const context = await this._context();
        const data = await this._innerTubePost('next', { context, continuation: comment.repliesToken }, true);
        return data ? this._findCreateCommentParams(data) : null;
      } catch (err) {
        console.error('[CHEESE EYES] 유튜브 답글 작성 파라미터 조회 실패:', err);
        return null;
      }
    },
    async _postComment(createCommentParams, text) {
      try {
        const context = await this._context();
        const data = await this._innerTubePost('comment/create_comment', { context, createCommentParams, commentText: text }, true);
        return !!data;
      } catch (err) {
        console.error('[CHEESE EYES] 유튜브 댓글 작성 실패:', err);
        return false;
      }
    },
    async fetchFollowingLive() {
      const context = await this._context();
      const data = await this._innerTubePost('browse', { context, browseId: 'FEsubscriptions' }, true);
      if (!data) { const err = new Error('youtube_following_failed'); throw err; }

      const results = new Map();
      const collectFrom = (node) => {
        const liveNodes = this._collectLiveVideoRenderers(node);
        for (const n of liveNodes) {
          const ch = this._anyLiveNodeToChannel(n);
          if (ch && ch.videoId) results.set(ch.videoId, ch);
        }
      };
      collectFrom(data);

      // richGridRenderer 피드는 한 페이지 더 continuation으로 이어 받는다.
      const tokens = this._findContinuationTokens(data);
      if (tokens.length > 0) {
        const contData = await this._innerTubePost('browse', { context, continuation: tokens[0] }, true);
        if (contData) collectFrom(contData);
      }

      console.log(`[CHEESE EYES][YT-DEBUG] FEsubscriptions에서 라이브 채널 ${results.size}개 확보`);
      return Array.from(results.values());
    },
    async checkLoginStatus() {
      return await checkLoginCookie('https://www.youtube.com/', ['SAPISID', '__Secure-3PAPISID']);
    },
    getLoginUrl() { return 'https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&continue=https://www.youtube.com/'; },
    getLogoutUrl() { return 'https://www.youtube.com/logout'; },
    getVideoEmbedUrl(id) {
      const ch = getChannelObjByHash(id);
      const videoId = ch && ch.videoId;
      // 오류153(확장 출처라 Referer 없음) 우회용 relay.html?type=video. 마지막 재생 위치가 있으면 이어서 재생.
      const resumeAt = lastKnownPlaybackTimeSec[id];
      const startParam = (typeof resumeAt === 'number' && resumeAt > 1) ? `&start=${Math.floor(resumeAt)}` : '';
      const url = videoId
        ? `${YT_RELAY_ORIGIN}/relay.html?type=video&v=${encodeURIComponent(videoId)}&autoplay=1${startParam}`
        : `${YT_RELAY_ORIGIN}/relay.html?type=video&channel=${encodeURIComponent(id)}&autoplay=1`;
      console.log(`[CHEESE EYES][YT-DEBUG] getVideoEmbedUrl(${id}) -> videoId=${videoId || '(없음)'} url=${url}`);
      return url;
    },
    getChatEmbedUrl(id) {
      const ch = getChannelObjByHash(id);
      const videoId = ch && ch.videoId;
      if (!videoId) return 'about:blank';
      // 채팅도 relay.html?type=chat으로 embed_domain을 통과시킨다. 끝난 방송은 live_chat_replay를 써야 한다.
      const replayParam = (ch && ch.isVod) ? '&replay=1' : '';
      return `${YT_RELAY_ORIGIN}/relay.html?type=chat&v=${encodeURIComponent(videoId)}${replayParam}`;
    },
    getChannelHomeUrl(id) {
      const YT_CHANNEL_ID_RE = /^UC[a-zA-Z0-9_-]{22}$/;
      if (YT_CHANNEL_ID_RE.test(id)) return `https://www.youtube.com/channel/${id}`;
      // 특정 영상 고정 채널은 id가 영상ID라 저장된 실제 채널ID를 쓴다.
      const ch = getChannelObjByHash(id);
      if (ch && ch.channelId && YT_CHANNEL_ID_RE.test(ch.channelId)) {
        return `https://www.youtube.com/channel/${ch.channelId}`;
      }
      return `https://www.youtube.com/${id}`;
    },
    getVodUrlAtTime(id, seconds) {
      const ch = getChannelObjByHash(id);
      const videoId = (ch && ch.videoId) || id;
      const sec = Math.max(0, Math.floor(seconds || 0));
      // cheese_direct=1은 background의 추천영상 새 탭 차단에서 빼달라는 표식.
      return `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}&t=${sec}s&cheese_direct=1`;
    }
  }
};

function getAdapter(platform) {
  return PlatformAdapters[platform] || PlatformAdapters.chzzk;
}

// 채팅 번역용(대상 언어 인자). client=gtx 무료 엔드포인트, 클릭 시에만 호출.
// content.js와 같은 휴리스틱 — 확신이 없으면 false를 돌려 API의 detectedLang으로 판단하게 한다.
function looksLikeAlreadyInLang(text, targetLang) {
  const s = String(text || '');
  if (!s.trim()) return false;
  const hangul = (s.match(/[가-힣]/g) || []).length;
  const latin = (s.match(/[A-Za-z]/g) || []).length;
  if (targetLang === 'ko') return hangul > 0 && hangul >= latin;
  if (targetLang === 'en') {
    const otherScript = (s.match(/[가-힣぀-ヿ一-鿿]/g) || []).length;
    return latin > 0 && otherScript === 0;
  }
  return false;
}

const chatTranslationCache = new Map();
const CHAT_TRANSLATION_CACHE_MAX = 500;
// { translated, detectedLang } — 원문이 대상 언어면 호출부가 결과를 숨긴다.
async function translateChatMsgText(text, targetLang) {
  const s = String(text || '').trim();
  const lang = String(targetLang || 'ko');
  if (!s) return { translated: '', detectedLang: '' };
  const cacheKey = `${lang}:${s}`;
  if (chatTranslationCache.has(cacheKey)) return chatTranslationCache.get(cacheKey);
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(lang)}&dt=t&q=${encodeURIComponent(s)}`;
    const res = await apiFetch(url);
    if (!res.ok) throw new Error(`http_${res.status}`);
    const raw = await res.text();
    const data = JSON.parse(raw);
    const translated = Array.isArray(data?.[0])
      ? data[0].map(seg => (Array.isArray(seg) ? seg[0] : '') || '').join('').trim()
      : '';
    const detectedLang = typeof data?.[2] === 'string' ? data[2] : '';
    const result = { translated, detectedLang };
    if (translated) {
      // 캡 초과 시 가장 오래된 항목부터 지운다.
      if (chatTranslationCache.size >= CHAT_TRANSLATION_CACHE_MAX) {
        chatTranslationCache.delete(chatTranslationCache.keys().next().value);
      }
      chatTranslationCache.set(cacheKey, result);
    }
    return result;
  } catch (e) {
    console.warn(`[CHEESE EYES][채팅번역] '${s}' -> '${lang}' 번역 실패:`, e);
    return { translated: '', detectedLang: '' };
  }
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'TRANSLATE_CHAT_MESSAGE') return;
  const matchedHash = findChatHashByWindow(event.source);
  if (!matchedHash) {
    console.warn('[CHEESE EYES][채팅번역] TRANSLATE_CHAT_MESSAGE를 받았지만 발신 프레임을 chat-iframe으로 매칭 못 함 — 무시됨');
    return;
  }
  const requestId = event.data.requestId;
  const text = event.data.text;
  const targetLang = window.CHEESE_EYES_CURRENT_LANG || 'ko';
  translateChatMsgText(text, targetLang).then(({ translated, detectedLang }) => {
    event.source.postMessage({ type: 'TRANSLATE_CHAT_RESULT', requestId, translated, detectedLang, targetLang }, '*');
  });
});

// 채팅 iframe이 주기적으로 묻는 표시 언어 — 이미 그 언어인 메시지는 번역 호출을 건너뛴다.
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'REQUEST_UI_LANGUAGE') return;
  const matchedHash = findChatHashByWindow(event.source);
  if (!matchedHash) return;
  event.source.postMessage({ type: 'UI_LANGUAGE_RESULT', lang: window.CHEESE_EYES_CURRENT_LANG || 'ko' }, '*');
});

async function refreshSoopBroadNo(hash) {
  try {
    const fresh = await PlatformAdapters.soop.searchChannelById(hash);
    if (!fresh || !fresh.broadNo) return;
    [channels, displayChannels].forEach(arr => {
      const c = arr.find(c => c.hash === hash && c.platform === 'soop');
      if (c) c.broadNo = fresh.broadNo;
    });
  } catch (e) {
    console.error(`[CHEESE EYES] 숲 broadNo 갱신 실패 (${hash}):`, e);
  }
}

function getChannelObjByHash(hash) {
  return displayChannels.find(c => c.hash === hash) || channels.find(c => c.hash === hash);
}

async function refreshYoutubeVideoId(hash) {
  try {
    const YT_CHANNEL_ID_RE = /^UC[a-zA-Z0-9_-]{22}$/;
    if (!YT_CHANNEL_ID_RE.test(hash)) return; 
    const fresh = await PlatformAdapters.youtube._resolveByChannelId(hash);
    if (!fresh || !fresh.videoId) return;
    [channels, displayChannels].forEach(arr => {
      const c = arr.find(c => c.hash === hash && c.platform === 'youtube');
      if (c) c.videoId = fresh.videoId;
    });
  } catch (e) {
    console.error(`[CHEESE EYES] 유튜브 videoId 갱신 실패 (${hash}):`, e);
  }
}

function buildTabsBar(tabs, activeTab, onSelect, extraClass) {
  const bar = document.createElement('div');
  bar.className = 'search-platform-tabs' + (extraClass ? ` ${extraClass}` : '');
  tabs.forEach(tabInfo => {
    const el = document.createElement('div');
    el.className = 'search-platform-tab' + (tabInfo.key === activeTab ? ' active' : '');
    el.textContent = tabInfo.label;
    if (tabInfo.color) el.style.setProperty('--tab-color', tabInfo.color);
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      onSelect(tabInfo.key);
    });
    bar.appendChild(el);
  });
  return bar;
}

function buildPlatformTabsBar(activeTab, onSelect, excludePlatforms = []) {
  const tabs = [
    { key: 'all', label: t('platformTabs.all', '전체'), color: '#FFC800' },
    ...Object.keys(PLATFORM_META)
      .filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p] && !excludePlatforms.includes(p))
      .map(p => ({ key: p, label: getPlatformLabel(p), color: PLATFORM_META[p].color }))
  ];
  return buildTabsBar(tabs, activeTab, onSelect);
}

let currentSearchPlatformTab = 'all';
let currentListPlatformTab = 'all';
let listNoticeBuilder = null;

function saveSearchPlatformTab() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ search_platform_tab: currentSearchPlatformTab });
  } else {
    localStorage.setItem('search_platform_tab', currentSearchPlatformTab);
  }
}

const videoWrapperMap = new Map();

// ── 플레이어 조작 잠금 ── 투명 캐처가 첫 클릭을 가로채 채널을 선택하고, 바로 꺼서 다음 클릭부터 iframe에 전달한다.
// 다른 채널을 클릭하면 이전 채널은 다시 잠긴다.
let controlUnlockedHash = null; // 현재 조작(플레이어 직접 클릭) 가능한 채널

function lockChannelControl(hash) {
  if (!hash) return;
  const wrapper = videoWrapperMap.get(hash);
  const catcher = wrapper?.querySelector('.video-select-catcher');
  if (catcher) catcher.style.pointerEvents = '';
  wrapper?.classList.remove('control-unlocked');
  if (controlUnlockedHash === hash) controlUnlockedHash = null;
}

function unlockChannelControl(hash) {
  if (!hash) return;
  const wrapper = videoWrapperMap.get(hash);
  const catcher = wrapper?.querySelector('.video-select-catcher');
  if (catcher) catcher.style.pointerEvents = 'none';
  wrapper?.classList.add('control-unlocked');
  controlUnlockedHash = hash;
}

function resetChannelControlState() {
  if (controlUnlockedHash) lockChannelControl(controlUnlockedHash);
  controlUnlockedHash = null;
}


const videoGrid = document.getElementById('video-grid');

function clearVideoGrid() {
  videoWrapperMap.forEach((wrapper) => {
    const iframe = wrapper.querySelector('iframe');
    if (iframe) iframe.src = 'about:blank';
    wrapper.remove();
  });
  videoWrapperMap.clear();
  if (videoGrid) videoGrid.innerHTML = '';
}

const chatTabs = document.getElementById('chat-tabs');
const chatContainer = document.getElementById('chat-frame-container');
const chatSidebar = document.getElementById('chat-sidebar');
const channelInput = document.getElementById('channel-input');
const autocompleteList = document.getElementById('autocomplete-list');
const chatToggleBtn = document.getElementById('chat-toggle');
const presetContainer = document.getElementById('preset-container');
const controlPanel = document.getElementById('control-panel');
const queueSidebar = document.getElementById('queue-sidebar');
const queueToggleBtn = document.getElementById('queue-toggle');
const queueList = document.getElementById('queue-list');
const queuePauseBtn = document.getElementById('queue-pause-btn');

if (controlPanel) {
  controlPanel.addEventListener('wheel', (e) => {
    if (e.deltaY !== 0) {
      e.preventDefault();
      controlPanel.scrollLeft += e.deltaY;
    }
  }, { passive: false });
}

if (videoGrid) {
  videoGrid.addEventListener('wheel', (e) => {
    if (currentLayout === 'main_sub' && e.deltaY !== 0 &&
        videoGrid.scrollHeight <= videoGrid.clientHeight) {
      e.preventDefault();
      videoGrid.scrollLeft += e.deltaY;
    }
  }, { passive: false });
}

document.getElementById('add-btn')?.addEventListener('click', addChannelFromInput);
document.getElementById('audio-settings-btn')?.addEventListener('click', (e) => {
  e.stopPropagation();
  toggleAudioSettingsPanel();
});
document.getElementById('mode-grid')?.addEventListener('click', () => switchLayout('grid'));
document.getElementById('mode-main_sub')?.addEventListener('click', () => switchLayout('main_sub'));
document.getElementById('chat-toggle')?.addEventListener('click', toggleChat);
document.getElementById('queue-toggle')?.addEventListener('click', toggleQueueSidebar);
document.getElementById('queue-add-btn')?.addEventListener('click', batchAddUntargetedToGrid);
document.getElementById('queue-pause-btn')?.addEventListener('click', toggleQueuePause);
document.getElementById('queue-clear-btn')?.addEventListener('click', clearQueue);
document.getElementById('queue-hide-btn')?.addEventListener('click', () => {
  if (queueSidebarVisible) toggleQueueSidebar();
});

// 대기열 사이드바는 열림 상태만 저장한다(목록은 my_video_queue).
(function restoreQueueSidebarVisible() {
  const apply = (visible) => {
    queueSidebarVisible = !!visible;
    queueSidebar?.classList.toggle('active', queueSidebarVisible);
    queueToggleBtn?.classList.toggle('active', queueSidebarVisible);
  };
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['my_queue_sidebar_visible'], (result) => apply(result.my_queue_sidebar_visible));
  } else {
    apply(localStorage.getItem('my_queue_sidebar_visible') === '1');
  }
})();

function toggleQueueSidebar() {
  queueSidebarVisible = !queueSidebarVisible;
  queueSidebar?.classList.toggle('active', queueSidebarVisible);
  queueToggleBtn?.classList.toggle('active', queueSidebarVisible);
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ my_queue_sidebar_visible: queueSidebarVisible });
  } else {
    localStorage.setItem('my_queue_sidebar_visible', queueSidebarVisible ? '1' : '0');
  }
  if (typeof renderVideo === 'function') renderVideo();
}

// ── 화면 숨김(채널별) ── 숨긴 채널은 그리드에서 빠지고 나머지가 커진다. VOD는 일시정지,
// 라이브는 화면만 숨긴다(재개 시 재연결 끊김 방지). 버튼은 채팅탭에 둔다.
let videoHiddenChannels = new Set();
// 메인을 숨기면 서브를 임시 메인으로 올리고, 원래 메인을 기억했다가 숨김 해제 시 되돌린다(직접 승격하면 취소).
let pendingMainRestoreHash = null;
// 자동 승격의 setMainChannel이 위 복귀 약속을 지우지 않게 하는 플래그.
let suppressPendingMainInvalidate = false;
const VIDEO_SCREEN_EYE_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"></path><circle cx="12" cy="12" r="3"></circle></svg>`;
const VIDEO_SCREEN_EYE_OFF_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a21.8 21.8 0 0 1 5.06-6.06"></path><path d="M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a21.79 21.79 0 0 1-3.22 4.44"></path><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"></path><path d="M1 1l22 22"></path></svg>`;

// "c "/"ㅊ "로 채팅만 추가한 채널 — 프레임을 아예 만들지 않아 상한·합방·오디오 목록에서도 빠진다.
function isChatOnlyChannel(hash) {
  const ch = getChannelObjByHash(hash);
  return !!(ch && ch.chatOnly);
}

// 채팅만 추가한 채널의 눈 아이콘은 "채팅만 ↔ 표시"로 순환한다(숨김은 프레임을 살려 두므로).
function isChatOnlyToggleChannel(hash) {
  const ch = getChannelObjByHash(hash);
  return !!(ch && ch.chatOnlyAdded);
}

function isChannelVideoHidden(hash) {
  return videoHiddenChannels.has(hash) || isChatOnlyChannel(hash);
}

// 채팅만 채널은 메인 후보에서 뺀다(메인-서브 큰 자리가 빔).
function getFirstVideoChannelHash(list = displayChannels) {
  const ch = (list || []).find((c) => c && !c.chatOnly);
  return ch ? ch.hash : null;
}

function applyVideoScreenToggleState(btn, hash) {
  if (!btn || !hash) return;
  const hidden = isChannelVideoHidden(hash);
  btn.classList.toggle('active', hidden);
  btn.innerHTML = hidden ? VIDEO_SCREEN_EYE_OFF_ICON : VIDEO_SCREEN_EYE_ICON;
  if (isChatOnlyToggleChannel(hash)) {
    btn.title = hidden
      ? t('chat.chatOnlyShowVideo', '영상도 받기')
      : t('chat.chatOnlyHideVideo', '채팅만 보기(영상 끄기)');
    return;
  }
  btn.title = hidden
    ? t('mode.showScreen', '화면 표시')
    : t('mode.hideScreen', '화면 숨김(일시정지)');
}

// 탭마다 버튼이 있으니 각 탭 채널 상태로 다시 그린다.
function updateChatTabVideoToggleIcons() {
  if (!chatTabs) return;
  chatTabs.querySelectorAll('.chat-tab').forEach((tab) => {
    const btn = tab.querySelector('.chat-tab-video-toggle-btn');
    const hash = tab.getAttribute('data-hash');
    applyVideoScreenToggleState(btn, hash);
  });
}

function toggleChannelVideoHidden(hash) {
  if (!hash) return;
  // 채팅만 채널의 눈 아이콘 = 영상도 받기(chatOnly 해제 후 프레임 생성).
  if (isChatOnlyToggleChannel(hash)) {
    const showVideo = isChatOnlyChannel(hash);
    [channels.find(c => c.hash === hash), displayChannels.find(c => c.hash === hash)]
      .forEach((c) => {
        if (!c) return;
        if (showVideo) delete c.chatOnly;
        else c.chatOnly = true;
      });
    videoHiddenChannels.delete(hash);
    if (showVideo) {
      if (!mainChannel) mainChannel = hash;
    } else if (mainChannel === hash) {
      // 메인 영상을 없앴으면 메인 자리를 남은 영상 채널에 넘긴다.
      mainChannel = getFirstVideoChannelHash();
    }
    saveChannelsToStorage();
    renderAll();
    return;
  }
  if (videoHiddenChannels.has(hash)) {
    // 숨김 해제 — 원래 메인이었고 약속이 살아 있으면 메인 자리를 돌려준다.
    videoHiddenChannels.delete(hash);
    setChannelVideoPlaying(hash, true);
    if (pendingMainRestoreHash === hash) {
      pendingMainRestoreHash = null;
      if (mainChannel !== hash) setMainChannel(hash);
    }
  } else {
    videoHiddenChannels.add(hash);
    // 라이브는 화면만 숨기고 VOD만 멈춘다(isVod 없으면 라이브).
    const channelObj = getChannelObjByHash(hash);
    if (channelObj && channelObj.isVod) setChannelVideoPlaying(hash, false);
    // 숨긴 채널이 메인이면 보이는 첫 서브를 임시 메인으로 올린다.
    if (currentLayout === 'main_sub' && hash === mainChannel) {
      const fallback = displayChannels.find(c => c.hash !== hash && !videoHiddenChannels.has(c.hash));
      if (fallback) {
        pendingMainRestoreHash = hash;
        suppressPendingMainInvalidate = true;
        setMainChannel(fallback.hash);
        suppressPendingMainInvalidate = false;
      }
    }
  }
  renderVideo();
  updateChatTabVideoToggleIcons();
  // 보이는 채널이 1개 경계를 넘으면 음량 역할 판정이 바뀌므로 전 채널 음량을 다시 계산한다.
  if (isCollabSettingEnabled()) recomputeCollabMuting();
  applyVolumeToAllChannels(true);
  renderAudioSettingsList();
  renderCollabSettingsSection();
}

document.getElementById('save-preset-btn')?.addEventListener('click', openPresetModal);
document.getElementById('clear-all-btn')?.addEventListener('click', clearAllPresets);

const tagSearchBtn = document.getElementById('tag-search-btn');
if (tagSearchBtn) {
  tagSearchBtn.addEventListener('click', () => openList('tag'));
}

const followingBtn = document.getElementById('following-btn');
if (followingBtn) {
  followingBtn.addEventListener('click', () => openList('following'));
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.input-wrapper')) {
    hideAutocomplete();
  }
});

// 저장소 채널을 창 형식으로 맞춘다(초기 로드·다른 창 변경 공용 — 필드 누락 방지).
// videoId/isVod를 옮기지 않으면 특정 영상 고정/VOD가 일반 채널처럼 깨진다.
function migrateStoredChannel(c) {
  return ({ platform: c.platform || 'chzzk', hash: c.hash, name: c.name, broadNo: c.broadNo, videoId: c.videoId, isVod: c.isVod, title: c.title, hasLiveChat: c.hasLiveChat, startSec: c.startSec, channelId: c.channelId, isPinnedVideoSlot: c.isPinnedVideoSlot, broadcastDate: c.broadcastDate, chatOnly: c.chatOnly, chatOnlyAdded: c.chatOnlyAdded });
}

document.addEventListener('DOMContentLoaded', () => {
  const loadInitialData = (savedChannels, savedPresets, savedLayout, savedSearchTab, savedChatVisible, savedMainChannel, savedAudioState, savedVideoQueue, savedQueuePaused, savedActiveChatChannel, savedSecondaryChatChannel) => {
    channels = (savedChannels || []).map(migrateStoredChannel);
    videoQueue = Array.isArray(savedVideoQueue) ? savedVideoQueue : [];
    queuePaused = !!savedQueuePaused;
    displayChannels = [...channels];
    channelAddOrder = channels.map(c => c.hash);
    // 저장된 재생 위치 복원(getVideoEmbedUrl이 start=로 사용).
    channels.forEach((c) => {
      if (typeof c.startSec === 'number' && c.startSec > 1) lastKnownPlaybackTimeSec[c.hash] = c.startSec;
    });
    presets = (savedPresets || []).map(p => ({ ...p, channels: (p.channels || []).map(migrateStoredChannel) }));
    currentLayout = savedLayout || 'grid';
    currentSearchPlatformTab = savedSearchTab || 'all';
    audioState = {
      // 예전 공용 값(마이그레이션 폴백 전용).
      mainVolume: (savedAudioState && typeof savedAudioState.mainVolume === 'number') ? savedAudioState.mainVolume : undefined,
      mainVolumeByChannel: (savedAudioState && savedAudioState.mainVolumeByChannel && typeof savedAudioState.mainVolumeByChannel === 'object') ? savedAudioState.mainVolumeByChannel : {},
      channelVolumeOverrides: (savedAudioState && savedAudioState.channelVolumeOverrides) ? savedAudioState.channelVolumeOverrides : {},
      // 예전 직접 만든 라이브 그룹은 버리고 vod-sync/manual 그룹만 남긴다.
      collabGroups: (savedAudioState && Array.isArray(savedAudioState.collabGroups)) ? savedAudioState.collabGroups.filter((g) => g && (g.mode === 'vod-sync' || g.mode === 'manual')) : [],
      collabGroupNames: (savedAudioState && savedAudioState.collabGroupNames && typeof savedAudioState.collabGroupNames === 'object') ? savedAudioState.collabGroupNames : {},
      collabGroupColors: (savedAudioState && savedAudioState.collabGroupColors && typeof savedAudioState.collabGroupColors === 'object') ? savedAudioState.collabGroupColors : {},
      vodStartTimeMsByHash: (savedAudioState && savedAudioState.vodStartTimeMsByHash && typeof savedAudioState.vodStartTimeMsByHash === 'object') ? savedAudioState.vodStartTimeMsByHash : {}
    };
    // 다시 불러올 땐 0% 뮤트만 초기화한다(낮은 값은 의도된 설정이라 유지).
    if (resetMutedAudioStateOnLoad()) saveAudioState();
    if (pruneCollabGroups()) saveAudioState();

    if (displayChannels.length > 0) {
      // 저장된 메인이 목록에 있으면 맨 앞으로 옮긴다. 없으면 이 창 첫 채널을 메인으로(§3.7).
      const firstOwnedHash = (displayChannels.find(c => isChannelOwnedByThisWindow(c.hash)) || displayChannels[0]).hash;
      const restoredMainHash = (savedMainChannel && displayChannels.some(c => c.hash === savedMainChannel))
        ? savedMainChannel
        : firstOwnedHash;

      // 맨 앞도 이 창 채널일 때만 바꾼다(순서는 모든 창 공용).
      if (restoredMainHash !== displayChannels[0].hash && isChannelOwnedByThisWindow(displayChannels[0].hash)) {
        // splice+unshift는 중간 채널을 전부 밀어서 두 자리만 swap한다.
        const swapToFront = (arr) => {
          const idx = arr.findIndex(c => c.hash === restoredMainHash);
          if (idx > 0) {
            const temp = arr[0];
            arr[0] = arr[idx];
            arr[idx] = temp;
          }
        };
        swapToFront(channels);
        swapToFront(displayChannels);
      }

      mainChannel = restoredMainHash;
      activeChatChannel = (savedActiveChatChannel && displayChannels.some(c => c.hash === savedActiveChatChannel))
        ? savedActiveChatChannel
        : restoredMainHash;
      secondaryChatChannel = (savedSecondaryChatChannel
        && savedSecondaryChatChannel !== activeChatChannel
        && displayChannels.some(c => c.hash === savedSecondaryChatChannel))
        ? savedSecondaryChatChannel
        : null;
    } else {
      mainChannel = null;
      activeChatChannel = null;
      secondaryChatChannel = null;
    }

    updateLayoutModeButtons(currentLayout);

    chatVisible = !!savedChatVisible;
    chatSidebar?.classList.toggle('active', chatVisible);
    chatToggleBtn?.classList.toggle('active', chatVisible);

    renderPresets();
    renderAll();
    renderQueueSidebar();
  };

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    // 창 등록이 끝나야 이 창 몫을 안다 — 먼저 그리면 다른 창 채널까지 잠깐 뜬다.
    windowRegistrationReady.then(() => loadWindowState()).then((windowState) => chrome.storage.local.get(['my_channels', 'my_presets', 'my_layout', 'search_platform_tab', 'my_chat_visible', 'main_channel', 'my_audio_state', 'my_video_queue', 'my_queue_paused'], (result) => {
      // 새로고침한 창은 창별 상태로 복원, 새 보조 창은 대표의 메인을 물려받지 않는다(§3.7).
      const isNewSecondaryWindow = !windowState && isWindowRegistered() && !isRepresentativeWindow();
      loadInitialData(
        result.my_channels,
        result.my_presets,
        windowState ? windowState.layout : result.my_layout,
        result.search_platform_tab,
        windowState ? windowState.chatVisible : result.my_chat_visible,
        windowState ? windowState.mainChannel : (isNewSecondaryWindow ? null : result.main_channel),
        result.my_audio_state,
        result.my_video_queue,
        result.my_queue_paused,
        windowState ? windowState.activeChatChannel : null,
        windowState ? windowState.secondaryChatChannel : null
      );
      if (ensureMainChannelOwnedByThisWindow()) renderAll();
      saveWindowState();
      sharedMainChannel = result.main_channel || null;
      refreshExtendedMainSubState();
      // 예전 리더/팔로워 방식 값은 쓰지 않는다(§3.9).
      chrome.storage.local.remove(['monitor_layout_mode', 'monitor_assignment', 'monitor_role_override']);
      processPendingMultiviewAdd();
      processPendingQueueAdd();
    }));
  } else {
    const savedChannels = JSON.parse(localStorage.getItem('my_channels') || '[]');
    const savedPresets = JSON.parse(localStorage.getItem('my_presets') || '[]');
    const savedLayout = localStorage.getItem('my_layout') || 'grid';
    const savedSearchTab = localStorage.getItem('search_platform_tab') || 'all';
    const savedChatVisible = localStorage.getItem('my_chat_visible') === '1';
    const savedMainChannel = localStorage.getItem('main_channel') || null;
    const savedAudioState = JSON.parse(localStorage.getItem('my_audio_state') || 'null');
    const savedVideoQueue = JSON.parse(localStorage.getItem('my_video_queue') || '[]');
    const savedQueuePaused = localStorage.getItem('my_queue_paused') === '1';
    loadInitialData(savedChannels, savedPresets, savedLayout, savedSearchTab, savedChatVisible, savedMainChannel, savedAudioState, savedVideoQueue, savedQueuePaused);
    processPendingMultiviewAdd();
    processPendingQueueAdd();
  }
});

// 다른 창의 my_channels/main_channel 변경을 받아 반영한다(§3.2, §3.7).
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    if (!changes.my_channels && !changes.main_channel) return;
    // 메인 채널은 창마다 따로 — 이 창 채널이 아니면 따르지 않는다.
    if (changes.main_channel) {
      const incomingMain = changes.main_channel.newValue || null;
      sharedMainChannel = incomingMain;
      if (extendedMainSubActive || !incomingMain || isChannelOwnedByThisWindow(incomingMain)) {
        mainChannel = incomingMain;
      }
    }

    // 치지직/숲 VOD는 URL 이어보기가 안 돼 로드 후 seekChannelToTime으로 맞춘다.
    const seekAfterLoad = [];

    if (changes.my_channels) {
      const incoming = (changes.my_channels.newValue || []).map(migrateStoredChannel);
      const incomingHashes = new Set(incoming.map((c) => c.hash));
      const localByHash = new Map(channels.map((c) => [c.hash, c]));

      incoming.forEach((c) => {
        const local = localByHash.get(c.hash);
        // chatOnly 변경도 반영한다.
        if (local && (!!local.chatOnly !== !!c.chatOnly || !!local.chatOnlyAdded !== !!c.chatOnlyAdded)) {
          local.chatOnly = c.chatOnly;
          local.chatOnlyAdded = c.chatOnlyAdded;
          const dcHidden = displayChannels.find((d) => d.hash === c.hash);
          if (dcHidden) { dcHidden.chatOnly = c.chatOnly; dcHidden.chatOnlyAdded = c.chatOnlyAdded; }
        }
        if (!local) {
          channels.push(c);
          displayChannels.push(c);
          channelAddOrder.push(c.hash);
          if (typeof c.startSec === 'number' && c.startSec > 1) {
            lastKnownPlaybackTimeSec[c.hash] = c.startSec;
            if (c.platform !== 'youtube') seekAfterLoad.push({ hash: c.hash, sec: c.startSec });
          }
        } else if (typeof c.startSec === 'number' && c.startSec > 1 && c.startSec !== local.startSec) {
          local.startSec = c.startSec;
          const dc = displayChannels.find((d) => d.hash === c.hash);
          if (dc) dc.startSec = c.startSec;
          lastKnownPlaybackTimeSec[c.hash] = c.startSec;
          if (c.platform !== 'youtube') seekAfterLoad.push({ hash: c.hash, sec: c.startSec });
        }
      });

      const removedHashes = [...localByHash.keys()].filter((h) => !incomingHashes.has(h));
      if (removedHashes.length > 0) {
        channels = channels.filter((c) => !removedHashes.includes(c.hash));
        displayChannels = displayChannels.filter((c) => !removedHashes.includes(c.hash));
        removedHashes.forEach((h) => {
          const wrapper = videoWrapperMap.get(h);
          if (wrapper) { wrapper.remove(); videoWrapperMap.delete(h); }
          // 채널별 측정·중계 기록도 비운다.
          forgetChannelRuntimeState(h);
        });
      }

      const orderByHash = new Map(incoming.map((c, i) => [c.hash, i]));
      const orderOf = (c) => (orderByHash.has(c.hash) ? orderByHash.get(c.hash) : Number.MAX_SAFE_INTEGER);
      channels.sort((a, b) => orderOf(a) - orderOf(b));
      displayChannels.sort((a, b) => orderOf(a) - orderOf(b));
    }

    // 이 창 메인이 지워졌으면 이 창 채널에서 다시 고른다.
    const mainReassigned = ensureMainChannelOwnedByThisWindow();
    renderAll();
    if (mainReassigned) applyVolumeToAllChannels(true);
    if (changes.main_channel) applyVolumeToAllChannels(true);
    if (changes.my_channels) refreshRepresentativeWindowListIfOpen();

    seekAfterLoad.forEach(({ hash, sec }) => {
      setTimeout(() => {
        if (isChannelShownInThisWindow(hash)) {
          seekChannelToTime(hash, sec);
        }
      }, 1800);
    });
  });
}

window.addEventListener('resize', () => {
  renderVideo();
});

if (chatTabs) {
  chatTabs.addEventListener('wheel', (e) => {
    if (e.deltaY !== 0) {
      e.preventDefault();
      chatTabs.scrollLeft += e.deltaY;
    }
  });
}

if (presetContainer) {
  presetContainer.addEventListener('wheel', (e) => {
    if (e.deltaY !== 0) {
      e.preventDefault();
      presetContainer.scrollLeft += e.deltaY;
    }
  });
}

window.addEventListener('message', (event) => {
  if (event.data && (event.data.type === 'FRAME_CLICKED' || event.data.type === 'CHZZK_FRAME_CLICKED')) {
    const clickedUrl = event.data.url;
    // 유튜브는 임베드 URL에 videoId가 들어 있어 videoId로도 매칭한다.
    const matchedChannel = channels.find(c => clickedUrl.includes(c.hash) || (c.videoId && clickedUrl.includes(c.videoId)));
    if (!matchedChannel) return;

    // 어느 레이아웃이든 프레임 클릭 시 메인(=합방 대표)이 그 채널로 바뀐다.
    if (mainChannel !== matchedChannel.hash) {
      setMainChannel(matchedChannel.hash);
    }

    if (activeChatChannel !== matchedChannel.hash) {
      setChatChannel(matchedChannel.hash);
    }
  }
});

function findChannelHashByWindow(sourceWindow) {
  let matchedHash = null;
  videoWrapperMap.forEach((wrapper, hash) => {
    if (matchedHash) return;
    const iframe = wrapper.querySelector('iframe');
    // 유튜브 내부 프레임 메시지도 relay.html이 window.parent로 올려 주므로 event.source는 항상 직계 iframe이다.
    if (iframe && iframe.contentWindow === sourceWindow) matchedHash = hash;
  });
  return matchedHash;
}

// 채팅탭 iframe에서 온 메시지 매칭용(videoWrapperMap엔 없음).
function findChatHashByWindow(sourceWindow) {
  if (!chatContainer) return null;
  let matchedHash = null;
  chatContainer.querySelectorAll('iframe.chat-iframe').forEach((iframe) => {
    if (matchedHash) return;
    if (iframe.contentWindow === sourceWindow) matchedHash = iframe.getAttribute('data-hash');
  });
  return matchedHash;
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'USER_VOLUME_CHANGE') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (matchedHash) handleUserVolumeChange(matchedHash, event.data.volume);
});

// VOD 재생 끝 신호 — 그 채널을 자동으로 뺀다(라이브 종료는 pollLiveStatusAndAutoRemove 담당).
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_VIDEO_ENDED') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (!matchedHash) return;

  // 이 자리 예약 또는 미지정 대기열 항목이 있으면 그걸로 채운다(삭제 판단보다 우선).
  if (tryConsumeQueueForSlot(matchedHash)) {
    console.log(`[CHEESE EYES] ${matchedHash}: 영상 재생 종료 감지 -> 대기열 영상으로 교체`);
    return;
  }

  // 챗탭이 이 채널을 보고 있으면 빼지 않는다(댓글 읽는 중일 수 있음). 이 시점에만 검사.
  if (chatVisible && activeChatChannel === matchedHash) {
    console.log(`[CHEESE EYES] ${matchedHash}: 영상 재생 종료 감지했지만 챗탭이 열려있어 자동 삭제 보류`);
    return;
  }
  console.log(`[CHEESE EYES] ${matchedHash}: 영상 재생 종료 감지 -> 자동 삭제`);
  removeChannel(matchedHash);
});

// 치지직 "다음 라이브를 기대해주세요" 화면 감지 — API 폴링보다 빨라 바로 다시보기 선택 패널로 전환한다.
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHZZK_LIVE_ENDED_SCREEN_DETECTED') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (!matchedHash) return;
  if (debugForcedEndedHashes.has(matchedHash)) return;
  const ch = channels.find(c => c.hash === matchedHash);
  if (!ch || ch.platform !== 'chzzk' || ch.isVod) return;
  if (vodPickerShownByHash[matchedHash]) return;
  delete offlineStreakByHash[matchedHash];
  console.log(`[CHEESE EYES] ${matchedHash}: 치지직 자체 방종 화면 감지 -> 다시보기 선택 패널 즉시 표시`);
  showVodPickerForChannel(ch);
});

// 유튜브 추천 영상 클릭 — 바로 바꾸지 않고 이 채널 대기열에 담는다.
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'YT_SUGGESTION_CLICKED') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (matchedHash) enqueueYoutubeVideo(matchedHash, event.data.videoId, undefined, undefined, true);
});

// 재생 중인 영상 자체가 바뀜(유튜브 infoDelivery / 치지직 VOD URL 변경) — 같은 자리에서 새 영상으로 교체한다.
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_VIDEO_CHANGED') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (matchedHash) handleVodVideoChanged(matchedHash, event.data);
});

async function handleVodVideoChanged(hash, data) {
  const ch = getChannelObjByHash(hash);
  const newVideoId = data && data.videoId;
  if (!ch || !newVideoId) return;

  if (ch.platform === 'youtube') {
    if (ch.videoId === newVideoId) return; // 이미 반영된 값의 중복 보고
    console.log(`[CHEESE EYES] ${hash}: 엔딩화면에서 다른 영상 클릭 감지 -> ${newVideoId}로 교체`);
    // hash는 그대로라 합방 판정을 잠깐 보류한다(과도기 판정이 결정을 뒤집지 않게).
    markCollabResetHold(hash);
    [channels, displayChannels].forEach(arr => {
      const c = arr.find(x => x.hash === hash && x.platform === 'youtube');
      if (!c) return;
      c.videoId = newVideoId;
      if (data.author) c.name = data.author;
      if (data.title) c.title = data.title;
      c.channelId = undefined;
    });
    saveChannelsToStorage();
    removeYoutubeCommentsPanel(hash);
    const iframe = chatContainer && chatContainer.querySelector(`iframe[data-hash="${hash}"]`);
    if (iframe) recreateChatIframe(iframe, hash, 'youtube');
    updateChatSession();

    // 채널ID는 InnerTube 조회로 비동기로 채운다.
    const meta = await PlatformAdapters.youtube._resolveVideoMeta(newVideoId);
    if (!meta) return;
    let stillCurrent = false;
    [channels, displayChannels].forEach(arr => {
      const c = arr.find(x => x.hash === hash && x.platform === 'youtube');
      if (!c || c.videoId !== newVideoId) return; // 그 사이 또 바뀌었으면 낡은 값 반영 안 함
      stillCurrent = true;
      c.channelId = meta.channelId || null;
      if (meta.channelName) c.name = meta.channelName;
      if (meta.title) c.title = meta.title;
    });
    if (stillCurrent) { saveChannelsToStorage(); updateChatSession(); }
    return;
  }

  if (ch.platform === 'chzzk') {
    if (ch.hash === newVideoId) return;
    console.log(`[CHEESE EYES] ${hash}: 엔딩화면에서 다른 치지직 VOD 클릭 감지 -> ${newVideoId}로 교체`);
    // 같은 채널의 다른 영상이라 channelId를 물려준다.
    replaceVodChannelInPlace(hash, { platform: 'chzzk', hash: newVideoId, name: newVideoId.substring(0, 8), isVod: true, channelId: ch.channelId || null });
  }
}

// ── 대기열 ── 전역 목록. targetHash 없으면 자동으로 빈 자리에 앞에서부터, 있으면 그 채널 전용 예약.

// 그리드에 언젠가 끝날 슬롯(VOD 등)이 없으면 대기열에 쌓지 않고 바로 새 타일로 추가한다.
function hasEndableSlot() {
  return channels.some(ch => ch.isVod || (ch.platform === 'youtube' && ch.videoId));
}

// 대기열 항목을 그리드 끝에 새 타일로 추가(같은 videoId가 있으면 생략).
function appendQueueItemAsNewChannel(item) {
  const newCh = {
    platform: 'youtube',
    hash: item.videoId,
    // 채널명이 없으면 영상 제목, 그것도 없으면 videoId.
    name: item.channelName || item.title || item.videoId,
    videoId: item.videoId,
    title: item.title || '',
    isPinnedVideoSlot: true,
    // 대기열 항목은 항상 VOD로 취급한다.
    isVod: true
  };
  if (channels.some(c => c.hash === newCh.hash) || displayChannels.some(c => c.hash === newCh.hash)) return false;
  if (isChannelLimitReached()) {
    notifyChannelLimitReached();
    return false;
  }
  channels.push(newCh);
  displayChannels.push(newCh);
  channelAddOrder.push(newCh.hash);
  if (!mainChannel && !newCh.chatOnly) mainChannel = newCh.hash;
  if (!activeChatChannel) activeChatChannel = newCh.hash;
  saveChannelsAfterClaim([newCh.hash]);
  renderAll();
  return true;
}

// 유튜브 추천 영상 클릭은 대기열에 담는다(치지직은 SPA라 가로챌 수 없음). 이미 있으면 무시.
// presetTitle/presetChannelName: 이미 아는 값을 빈 메타로 덮지 않기 위함. toFront면 맨 앞에 꽂는다.
async function enqueueYoutubeVideo(sourceHash, videoId, presetTitle, presetChannelName, toFront) {
  if (!videoId) return;
  if (channels.some(c => c.platform === 'youtube' && c.videoId === videoId)) return;
  if (videoQueue.some(v => v.videoId === videoId)) return;

  const item = { videoId, title: presetTitle || '', channelName: presetChannelName || '', targetHash: null };
  if (toFront) videoQueue.unshift(item); else videoQueue.push(item);
  saveQueueToStorage();
  renderQueueSidebar();

  const meta = await PlatformAdapters.youtube._resolveVideoMeta(videoId);
  // 메타 도착 전에 소비됐으면 그 슬롯에 실제 이름을 채운다(직접 지웠으면 아무 일 없음).
  if (!videoQueue.includes(item)) {
    if (meta && (meta.channelName || meta.title)) {
      let stillCurrent = false;
      [channels, displayChannels].forEach(arr => {
        const c = arr.find(x => x.platform === 'youtube' && x.hash === videoId);
        if (!c) return;
        stillCurrent = true;
        if (meta.channelName) c.name = meta.channelName;
        if (meta.title) c.title = meta.title;
        if (meta.channelId) c.channelId = meta.channelId;
      });
      if (stillCurrent) { saveChannelsToStorage(); updateChatSession(); }
    }
    return;
  }
  if (meta) {
    if (meta.title) item.title = meta.title;
    if (meta.channelName) item.channelName = meta.channelName;
  }

  if (!hasEndableSlot() && !isChannelLimitReached()) {
    videoQueue.splice(videoQueue.indexOf(item), 1);
    appendQueueItemAsNewChannel(item);
  }
  saveQueueToStorage();
  renderQueueSidebar();
}

// 슬롯이 자동으로 비려 할 때 호출(직접 삭제는 제외). 예약 항목 → 미지정 맨 앞 순으로 채운다. 채웠으면 true(호출부는 삭제 생략).
function tryConsumeQueueForSlot(hash) {
  if (queuePaused) return false;
  if (!Array.isArray(videoQueue) || videoQueue.length === 0) return false;
  let idx = videoQueue.findIndex(v => v.targetHash === hash);
  if (idx === -1) idx = videoQueue.findIndex(v => !v.targetHash);
  if (idx === -1) return false;

  const item = videoQueue[idx];
  videoQueue.splice(idx, 1);
  saveQueueToStorage();
  replaceVodChannelInPlace(hash, {
    platform: 'youtube',
    hash: item.videoId,
    name: item.channelName || item.title || item.videoId,
    videoId: item.videoId,
    title: item.title || '',
    isPinnedVideoSlot: true,
    isVod: true // §appendQueueItemAsNewChannel과 동일한 이유
  });
  renderQueueSidebar();
  return true;
}

function removeQueuedVideo(index) {
  if (index < 0 || index >= videoQueue.length) return;
  videoQueue.splice(index, 1);
  saveQueueToStorage();
  renderQueueSidebar();
}

// 대기열 카드 클릭 — 곧장 새 타일로 추가.
function promoteQueueItemToGrid(index) {
  const item = videoQueue[index];
  if (!item) return;
  if (isChannelLimitReached()) {
    notifyChannelLimitReached();
    return;
  }
  videoQueue.splice(index, 1);
  saveQueueToStorage();
  appendQueueItemAsNewChannel(item);
  renderQueueSidebar();
}

// 채널 타일에 드롭하면 그 채널 전용으로 예약(null이면 해제).
function setQueueItemTarget(index, targetHash) {
  const item = videoQueue[index];
  if (!item) return;
  item.targetHash = targetHash || null;
  saveQueueToStorage();
  renderQueueSidebar();
}

// 다른 항목 위에 드롭하면 순서를 바꾼다.
function reorderQueue(fromIndex, toIndex) {
  if (fromIndex === toIndex || fromIndex < 0 || fromIndex >= videoQueue.length) return;
  const [moved] = videoQueue.splice(fromIndex, 1);
  videoQueue.splice(toIndex, 0, moved);
  saveQueueToStorage();
  renderQueueSidebar();
}

function clearQueue() {
  if (videoQueue.length === 0) return;
  videoQueue = [];
  saveQueueToStorage();
  renderQueueSidebar();
}

function toggleQueuePause() {
  queuePaused = !queuePaused;
  saveQueueToStorage();
  renderQueueSidebar();
}

// '대기열에 추가' — 미지정 항목을 전부 새 타일로 추가(예약 항목은 남는다).
function batchAddUntargetedToGrid() {
  const untargeted = videoQueue.filter(v => !v.targetHash);
  if (untargeted.length === 0) return;
  for (const item of untargeted) {
    if (isChannelLimitReached()) {
      notifyChannelLimitReached();
      break;
    }
    const idx = videoQueue.indexOf(item);
    if (idx !== -1) videoQueue.splice(idx, 1);
    appendQueueItemAsNewChannel(item);
  }
  saveQueueToStorage();
  renderQueueSidebar();
}

function renderQueueSidebar() {
  if (!queueList) return;
  queueList.innerHTML = '';

  if (videoQueue.length === 0) {
    const emptyEl = document.createElement('div');
    emptyEl.className = 'queue-empty-state';
    emptyEl.textContent = t('queue.emptyState', '유튜브 추천 영상/영상 카드를 클릭하면 여기 대기열에 담깁니다. 슬롯이 자동으로 비면(영상 종료/라이브 오프라인) 이어서 채워 넣습니다.');
    queueList.appendChild(emptyEl);
  } else {
    const fragment = document.createDocumentFragment();
    videoQueue.forEach((item, index) => {
      const row = document.createElement('div');
      row.className = 'queue-item';
      row.draggable = true;
      row.addEventListener('dragstart', (e) => {
        if (!e.dataTransfer) return;
        e.dataTransfer.setData('text/plain', String(index));
        e.dataTransfer.effectAllowed = 'move';
      });
      // 다른 대기열 항목 위에 놓으면 순서를 바꾼다(타일 위 드롭과는 별개).
      row.addEventListener('dragover', (e) => {
        if (!e.dataTransfer) return;
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        row.classList.add('drag-over');
      });
      row.addEventListener('dragleave', () => row.classList.remove('drag-over'));
      row.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        row.classList.remove('drag-over');
        const raw = e.dataTransfer && e.dataTransfer.getData('text/plain');
        const fromIndex = raw ? parseInt(raw, 10) : NaN;
        if (Number.isNaN(fromIndex)) return;
        reorderQueue(fromIndex, index);
      });

      const thumb = document.createElement('img');
      thumb.className = 'queue-item-thumb';
      thumb.loading = 'lazy';
      thumb.src = `https://i.ytimg.com/vi/${item.videoId}/mqdefault.jpg`;
      thumb.alt = '';
      row.appendChild(thumb);

      const info = document.createElement('div');
      info.className = 'queue-item-info';
      const titleEl = document.createElement('div');
      titleEl.className = 'queue-item-title';
      titleEl.textContent = item.title || item.videoId;
      info.appendChild(titleEl);

      const metaEl = document.createElement('div');
      metaEl.className = 'queue-item-meta';
      if (item.targetHash) {
        const targetCh = getChannelObjByHash(item.targetHash);
        const label = document.createElement('span');
        label.textContent = t('queue.reservedForTemplate', '{name} 전용으로 예약됨', { name: (targetCh && targetCh.name) || item.targetHash });
        metaEl.appendChild(label);
        const clearTargetBtn = document.createElement('button');
        clearTargetBtn.type = 'button';
        clearTargetBtn.className = 'queue-item-clear-target';
        clearTargetBtn.textContent = '×';
        clearTargetBtn.title = t('queue.clearTarget', '지정 해제');
        clearTargetBtn.addEventListener('click', (e) => { e.stopPropagation(); setQueueItemTarget(index, null); });
        metaEl.appendChild(clearTargetBtn);
      } else {
        metaEl.textContent = t('queue.pendingLabel', '대기 중');
      }
      info.appendChild(metaEl);
      row.appendChild(info);

      const removeBtn = document.createElement('button');
      removeBtn.type = 'button';
      removeBtn.className = 'queue-item-remove';
      removeBtn.textContent = '×';
      removeBtn.title = t('queue.removeItem', '대기열에서 제거');
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        removeQueuedVideo(index);
      });
      row.appendChild(removeBtn);

      // 카드 클릭(×/지정 해제 버튼 제외) — 대기열에서 빼서 바로 새 타일로 추가.
      row.title = t('queue.clickToApply', '클릭하면 대기열에서 빼서 바로 멀티뷰에 추가합니다');
      row.addEventListener('click', () => promoteQueueItemToGrid(index));

      fragment.appendChild(row);
    });
    queueList.appendChild(fragment);
  }

  if (queuePauseBtn) {
    queuePauseBtn.classList.toggle('active', queuePaused);
    queuePauseBtn.title = queuePaused ? t('queue.resume', '재생(자동 채우기 재개)') : t('queue.pause', '멈춤(자동 채우기 중지)');
    queuePauseBtn.textContent = queuePaused ? '▶' : '⏸';
  }
}

// 유튜브 재생 위치(3초마다 보고) — iframe이 다시 만들어질 때 start=로 이어서 재생한다.
const lastKnownPlaybackTimeSec = {};
const lastKnownPlaybackTimeAt = {}; // hash -> 위 값을 받은 시각(라이브 싱크 맞춤의 유튜브 시크 계산용)
const lastKnownPlaybackPaused = {}; // hash -> 위 값을 받을 때 정지 상태였는지

// 지금 재생 위치 추정 — 마지막 보고 + 경과 시간(정지 중이면 그대로). 보고가 3초 넘게 없으면 null.
function getExtrapolatedPlaybackSec(hash) {
  const sec = lastKnownPlaybackTimeSec[hash];
  const at = lastKnownPlaybackTimeAt[hash];
  if (typeof sec !== 'number' || !at || Date.now() - at > 3000) return null;
  return lastKnownPlaybackPaused[hash] ? sec : sec + (Date.now() - at) / 1000;
}

// 정지 복구 — 라이브 재생 위치가 일정 시간 진행이 없으면 그 채널 iframe만 다시 불러온다.
// 새 치지직 플레이어는 30초 가까이 멈췄다 스스로 풀리기도 해서 넉넉히 기다리고, 연속 복구할수록 대기를 두 배로 늘린다.
const STALL_RECOVERY_THRESHOLD_MS = 45000; // 이만큼 진행 없으면 정체로 간주(첫 복구 기준)
const STALL_RECOVERY_COOLDOWN_MS = 20000; // 재로드 직후 재탐지까지 최소 간격(창 전체)
const STALL_RECOVERY_MAX_BACKOFF_STEPS = 4; // 연속 복구마다 기준 ×2, 최대 ×16
const STALL_RECOVERY_RESET_PLAYED_SEC = 120; // 복구 뒤 이만큼 정상 재생되면 연속 횟수를 지운다
const channelStallTracker = {}; // hash -> { lastSec, lastChangeAt }
const channelStallRecoveryCount = {}; // hash -> 연속으로 복구한 횟수
// 마지막 재로드 시각 — 창 전체 쿨다운(줄줄이 재로드 방지).
let lastPlayerReloadAt = 0;

function trackPlaybackStall(hash, currentTime, paused) {
  const ch = getChannelObjByHash(hash);
  // VOD는 vod-sync가 일부러 멈춰 두는 경우가 있어 제외한다.
  if (!ch || ch.isVod || paused) {
    delete channelStallTracker[hash];
    return;
  }

  const now = Date.now();
  const prev = channelStallTracker[hash];
  if (!prev || Math.abs(currentTime - prev.lastSec) > 0.3) {
    channelStallTracker[hash] = { lastSec: currentTime, lastChangeAt: now };
    // 재로드 후 충분히 정상 재생되면 연속 복구 횟수를 지운다.
    if (currentTime >= STALL_RECOVERY_RESET_PLAYED_SEC) delete channelStallRecoveryCount[hash];
    return;
  }

  const backoffSteps = Math.min(channelStallRecoveryCount[hash] || 0, STALL_RECOVERY_MAX_BACKOFF_STEPS);
  if (now - prev.lastChangeAt < STALL_RECOVERY_THRESHOLD_MS * 2 ** backoffSteps) return;
  if (now - lastPlayerReloadAt < STALL_RECOVERY_COOLDOWN_MS) return;

  lastPlayerReloadAt = now;
  channelStallRecoveryCount[hash] = (channelStallRecoveryCount[hash] || 0) + 1;
  delete channelStallTracker[hash];
  silentlyReloadStalledChannel(hash);
}

function silentlyReloadStalledChannel(hash) {
  const ch = getChannelObjByHash(hash);
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (!ch || !iframe) return;

  console.log(`🔁 [STALL RECOVERY] [${hash}] ${STALL_RECOVERY_THRESHOLD_MS / 1000}초 이상 재생 진행 없음 — 이 채널만 조용히 재로드`);
  // 같은 URL 재대입은 재로드가 생략될 수 있어 about:blank로 한 번 끊는다.
  iframe.src = 'about:blank';
  iframeLoadQueue.push({
    iframe,
    url: getAdapter(ch.platform).getVideoEmbedUrl(hash),
    hash
  });
  processIframeQueue();
}

// 채널이 보고한 영상 길이(초, 메타데이터 전엔 null) — vod-sync 교집합 판정용.
const channelDurationSecByHash = {};

// expectedSec(대표 위치 + 오프셋)이 멤버의 재생 가능 구간 [0, duration] 안인지. duration을 모르면 위쪽은 통과시킨다.
function isVodSyncExpectedSecInWindow(expectedSec, memberDurationSec) {
  if (expectedSec < 0) return false;
  if (typeof memberDurationSec === 'number' && expectedSec > memberDurationSec) return false;
  return true;
}

// VOD 싱크: 대표 대비 ±1.5초를 넘을 때만 시크한다(잦은 시크는 끊김).
const VOD_SYNC_DRIFT_THRESHOLD_SEC = 1.5;
// 멤버를 옮긴 직후엔 다시 옮기지 않는다 — 새 위치 보고 전에 옛 위치로 거듭 시크하며 더 밀렸다.
const VOD_SYNC_SEEK_COOLDOWN_MS = 3000;
const vodSyncLastSeekAt = {}; // memberHash -> 마지막으로 옮긴 시각

// 멤버별 마지막으로 보낸 재생 상태 — 바뀔 때만 PLAY/PAUSE를 보낸다.
const vodSyncLastCommandedPlaying = {};

// 대표→멤버 한 방향만(멤버 직접 정지 정책은 미정, docs/vod-collab-sync-architecture.md §8).
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_PLAYBACK_TIME') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (matchedHash && typeof event.data.currentTime === 'number' && isFinite(event.data.currentTime)) {
    lastKnownPlaybackTimeSec[matchedHash] = event.data.currentTime;
    lastKnownPlaybackTimeAt[matchedHash] = Date.now();
    lastKnownPlaybackPaused[matchedHash] = !!event.data.paused;
    trackLiveSyncPlayback(matchedHash, event.data.currentTime, !!event.data.paused);
    if (isCollabMovePaused() && hasMovedChannelStartedPlaying(matchedHash)) finishCollabMovePauseFor(matchedHash);
    trackPlaybackStall(matchedHash, event.data.currentTime, !!event.data.paused);
  }
  if (matchedHash && typeof event.data.duration === 'number' && isFinite(event.data.duration)) {
    channelDurationSecByHash[matchedHash] = event.data.duration;
  }
  // VOD 싱크: 대표의 위치/정지 상태를 멤버에 반영한다. 오프셋 없는(정렬 전) 멤버는 건드리지 않는다.
  if (matchedHash && typeof event.data.currentTime === 'number' && isFinite(event.data.currentTime)) {
    const group = findCollabGroupForChannel(matchedHash);
    if (group && isVodSyncGroup(group) && getCollabLeaderHash(group) === matchedHash) {
      const repTime = event.data.currentTime;
      const repPlaying = !event.data.paused;
      group.memberHashes.forEach((memberHash) => {
        if (memberHash === matchedHash) return;
        const offsetSec = getVodSyncOffsetSec(group, memberHash);
        if (offsetSec === null) return;

        // 두 VOD가 일부 구간만 겹칠 때, 교집합 밖에선 시크하지 않고 멤버를 정지시킨다
        // (음수는 0으로 뭉개져 계속 끌려가고, 길이 초과는 ended로 채널이 삭제됐다). 정지 명령은 중복 전송하지 않는다.
        const expectedSec = repTime + offsetSec;
        const memberDurationSec = channelDurationSecByHash[memberHash];
        if (!isVodSyncExpectedSecInWindow(expectedSec, memberDurationSec)) {
          if (vodSyncLastCommandedPlaying[memberHash] !== false) {
            vodSyncLastCommandedPlaying[memberHash] = false;
            setChannelVideoPlaying(memberHash, false);
          }
          return;
        }

        if (vodSyncLastCommandedPlaying[memberHash] !== repPlaying) {
          vodSyncLastCommandedPlaying[memberHash] = repPlaying;
          setChannelVideoPlaying(memberHash, repPlaying);
        }

        // 멤버 보고는 최대 1초 묵은 값이라 경과 시간을 더한다.
        const memberActualSec = getExtrapolatedPlaybackSec(memberHash);
        if (memberActualSec === null) return;
        if (Math.abs(memberActualSec - expectedSec) > VOD_SYNC_DRIFT_THRESHOLD_SEC &&
            Date.now() - (vodSyncLastSeekAt[memberHash] || 0) > VOD_SYNC_SEEK_COOLDOWN_MS) {
          vodSyncLastSeekAt[memberHash] = Date.now();
          seekChannelToTime(memberHash, expectedSec);
        }
      });
    }
  }
  // 치지직 VOD 채팅탭은 숨겨진 영상으로 채팅 위치를 따라가므로 메인 타일의 위치/정지 상태를 릴레이해 맞춘다.
  const ch = matchedHash && getChannelObjByHash(matchedHash);
  if (ch && ch.platform === 'chzzk' && ch.isVod) {
    const chatIframe = chatContainer && chatContainer.querySelector(`iframe[data-hash="${matchedHash}"]`);
    if (chatIframe && chatIframe.contentWindow) {
      chatIframe.contentWindow.postMessage({
        type: 'CHZZK_VOD_CHAT_SYNC',
        currentTime: event.data.currentTime,
        paused: !!event.data.paused
      }, '*');
    }
  }
});

// 재생 위치를 startSec로 저장해 새로고침 후 이어서 재생한다.
function persistYoutubePlaybackPos() {
  let changed = false;
  channels.forEach((ch) => {
    if (ch.platform !== 'youtube') return;
    const sec = lastKnownPlaybackTimeSec[ch.hash];
    if (typeof sec !== 'number' || !isFinite(sec) || sec <= 1) return;
    const rounded = Math.floor(sec);
    if (ch.startSec !== rounded) { ch.startSec = rounded; changed = true; }
  });
  if (changed) saveChannelsToStorage();
}
window.addEventListener('beforeunload', persistYoutubePlaybackPos);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') persistYoutubePlaybackPos();
});

// 슬라이더 드래그 중엔 목록 재렌더링을 건너뛴다(DOM 교체로 조작이 끊김).
let audioSettingsDragActive = false;
document.addEventListener('pointerup', () => { audioSettingsDragActive = false; });

function refreshAudioSettingsListIfSafe() {
  if (!audioSettingsDragActive && document.getElementById('audio-settings-panel')) {
    renderAudioSettingsList();
    renderCollabSettingsSection({ skipWhileHovered: true });
  }
}

// content.js가 보고한 채널 dBFS — 음량 재적용은 살짝 묶어서 처리한다.
let audioLevelApplyTimer = null;
// 재렌더링/음량 재적용은 500ms 디바운스(보고 주기 200ms보다 길어야 디바운스가 동작한다).
const AUDIO_LEVEL_APPLY_DEBOUNCE_MS = 500;

// 합방 유사도용 이력 — 200ms 기준 35개(약 7초). 짧을수록 반응이 빠르지만 COLLAB_LAG_RANGE_MS보다 여유(≈+2초)가 있어야 한다.
const COLLAB_HISTORY_MAX_SAMPLES = 35;

function pushChannelAudioLevelHistory(hash, db, t) {
  const history = channelAudioLevelHistory[hash] || (channelAudioLevelHistory[hash] = []);
  history.push({ t, db });
  if (history.length > COLLAB_HISTORY_MAX_SAMPLES) history.shift();
}

// 디버그 패널 전용 dB 이력(합방용과 분리). 합방이 꺼져 있어도 쌓는다.
const DEBUG_DB_HISTORY_MAX_SAMPLES = 150; // content.js LEVEL_REPORT_INTERVAL_MS(200ms) 기준 약 30초
let debugDbHistory = {};

// db: 합방용 음성대역(300~3400Hz) 값. levelDb: 평준화용 전체 대역 LUFS.
// volPercent: 그 순간 재생 볼륨 — 체감 음량(levelDb + 20*log10(vol/100))을 그리기 위해.
function pushDebugDbHistory(hash, db, levelDb, volPercent, t) {
  const arr = debugDbHistory[hash] || (debugDbHistory[hash] = []);
  arr.push({ t, db, levelDb, volPercent });
  if (arr.length > DEBUG_DB_HISTORY_MAX_SAMPLES) arr.shift();
}

// 보고값(200ms 피크)이 배경음악 박자와 에일리어싱돼 출렁여서, 합방/디버그용 값에만 짧은 이동평균(8개)을 얹는다.
const COLLAB_DB_SMOOTH_SAMPLES = 8;
let collabDbSmoothBuffer = {};

function smoothCollabDb(hash, rawDb) {
  const buf = collabDbSmoothBuffer[hash] || (collabDbSmoothBuffer[hash] = []);
  buf.push(rawDb);
  if (buf.length > COLLAB_DB_SMOOTH_SAMPLES) buf.shift();
  return buf.reduce((sum, v) => sum + v, 0) / buf.length;
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_AUDIO_LEVEL') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (!matchedHash) return;
  const db = event.data.db;
  if (typeof db !== 'number' || !isFinite(db)) return;
  // voiceDb(음성대역)를 합방 판정에 우선 쓰고 없으면 db로 폴백. 평준화는 원본 db(LUFS)를 계속 쓴다.
  const voiceDb = event.data.voiceDb;
  const collabDbRaw = (typeof voiceDb === 'number' && isFinite(voiceDb)) ? voiceDb : db;
  const collabDb = smoothCollabDb(matchedHash, collabDbRaw);
  // channelAudioLevels는 최신값 하나(폴백용). 평준화 비교는 getChannelLevelingDb.
  channelAudioLevels[matchedHash] = db;
  if (isAudioOptimizationEnabled()) pushChannelLevelingDb(matchedHash, db);
  if (isCollabSettingEnabled()) pushChannelAudioLevelHistory(matchedHash, collabDb, Date.now());
  if (isAudioOptimizationEnabled()) pushMainDbSample(matchedHash, db);
  pushDebugDbHistory(matchedHash, collabDb, db, getDisplayVolumeForChannel(matchedHash), Date.now());
  // 대표가 아닌 창은 합방용 dB만 대표 창에 넘긴다.
  if (isCollabSettingEnabled() && isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive()) {
    window.CheeseProfileSync.send('collabLevel', { hash: matchedHash, db: collabDb, t: Date.now() });
  }

  if (audioLevelApplyTimer) return;
  audioLevelApplyTimer = setTimeout(() => {
    audioLevelApplyTimer = null;
    if (isCollabSettingEnabled()) recomputeCollabMuting();
    // 측정치 갱신마다 바뀌는 감쇠라 부드럽게 넘긴다.
    applyVolumeToAllChannels(true);
    refreshAudioSettingsListIfSafe();
  }, AUDIO_LEVEL_APPLY_DEBOUNCE_MS);
});

// content.js가 보고한 레이턴시(1.5초 간격). 저장만 하고 각 소비자가 자기 주기로 읽는다.
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_LIVE_LATENCY') return;
  const matchedHash = findChannelHashByWindow(event.source);
  if (!matchedHash) return;
  const latencySec = event.data.latencySec;
  if (typeof latencySec !== 'number' || !isFinite(latencySec)) return;
  channelLatencySecByHash[matchedHash] = smoothChannelLatency(matchedHash, latencySec);
  // 싱크 맞춤은 250ms 표본의 최근 평균을 쓴다. 평균이 없으면 판단하지 않는다.
  const avgLatencySec = event.data.avgLatencySec;
  if (typeof avgLatencySec === 'number' && isFinite(avgLatencySec)) {
    liveSyncLatencySample[matchedHash] = { sec: avgLatencySec, at: Date.now() };
    liveSyncLastLatencySec[matchedHash] = avgLatencySec;
  }
  if (typeof event.data.playbackRate === 'number' && isFinite(event.data.playbackRate)) {
    liveSyncReportedRate[matchedHash] = { rate: event.data.playbackRate, at: Date.now() };
  }
  if (isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive()) {
    window.CheeseProfileSync.send('collabLatency', { hash: matchedHash, latencySec: channelLatencySecByHash[matchedHash] });
  }
});

// ── 라이브 싱크 맞춤 ── 채널마다 라이브 끝 대비 지연이 달라 합방이 안 묶이면 소리가 어긋난다.
// 플레이어가 새로 뜰 때 한 번 메인 채널 지연에 맞추고, 이후엔 재생 속도(±5%, 치지직/숲만)로 따라잡는다.
// 조작 키(기본 S)는 즉시 전체 맞춤. 메인이 없거나 라이브가 아니면 설정의 기준 지연. 송출 지연 차이는 못 맞춘다.
// 기준에서 이보다 더 벗어났을 때만 옮긴다(지연값은 3초 평균).
const LIVE_SYNC_TOLERANCE_SEC = 0.2;
// 새 플레이어는 지연이 안정될 때까지 기다렸다 맞춘다. 시간 안에 못 맞추면 포기.
const LIVE_SYNC_NEW_PLAYER_SETTLE_MS = 5000;
const LIVE_SYNC_NEW_PLAYER_GIVE_UP_MS = 60000;
const LIVE_SYNC_PENDING_CHECK_MS = 1000;
// 기준 지연 — 메인이 없거나 라이브가 아닐 때. 설정 > 비디오.
const LIVE_SYNC_DEFAULT_TARGET_SEC = 1.5;
const LIVE_SYNC_TARGET_MIN_SEC = 0.5;
const LIVE_SYNC_TARGET_MAX_SEC = 10;
const LIVE_SYNC_SAMPLE_MAX_AGE_MS = 4000;
// 재생이 고르게 흐른 채널만 시크한다 — 버퍼링 중 당기면 다시 버퍼링하는 악순환이 된다.
const LIVE_SYNC_STEADY_WINDOW_MS = 5000;
const LIVE_SYNC_STEADY_MIN_RATIO = 0.9;
// 메인이 기준에서 너무 멀면(버퍼링) 나머지를 메인에 맞추지 않는다.
const LIVE_SYNC_MAIN_TRUST_SEC = 3;
const LIVE_SYNC_MAX_SEEK_SEC = 60;
const liveSyncLatencySample = {}; // hash -> { sec, at } — 최근 평균 지연값
const liveSyncLastSeekAt = {}; // hash -> 마지막으로 옮긴 시각
const liveSyncPendingSince = {}; // hash -> 플레이어가 새로 뜬 시각(아직 한 번도 안 맞춤)
const liveSyncPlaybackTrail = {}; // hash -> [{ at, sec }] — 최근 재생 위치(고르게 재생 중인지 판단)

function trackLiveSyncPlayback(hash, currentTime, paused) {
  if (paused) {
    delete liveSyncPlaybackTrail[hash];
    return;
  }
  const trail = liveSyncPlaybackTrail[hash] || (liveSyncPlaybackTrail[hash] = []);
  const now = Date.now();
  trail.push({ at: now, sec: currentTime });
  while (trail.length > 2 && now - trail[0].at > LIVE_SYNC_STEADY_WINDOW_MS * 2) trail.shift();
}

// 최근 창 동안 실제 시간만큼 재생됐는지(버퍼링 중이면 false).
function isLiveSyncPlaybackSteady(hash) {
  const trail = liveSyncPlaybackTrail[hash];
  if (!trail || trail.length < 2) return false;
  const last = trail[trail.length - 1];
  if (Date.now() - last.at > 2000) return false;
  const first = trail.find((p) => last.at - p.at <= LIVE_SYNC_STEADY_WINDOW_MS);
  if (!first || last.at - first.at < LIVE_SYNC_STEADY_WINDOW_MS * 0.6) return false;
  const elapsed = (last.at - first.at) / 1000;
  const played = last.sec - first.sec;
  return played >= elapsed * LIVE_SYNC_STEADY_MIN_RATIO && played <= elapsed * 1.2;
}

function isLiveSyncEnabled() {
  return mySetting.liveSyncEnabled !== false;
}

function getLiveSyncTargetSetting() {
  const v = mySetting.liveSyncTargetSec;
  return typeof v === 'number' && v >= LIVE_SYNC_TARGET_MIN_SEC && v <= LIVE_SYNC_TARGET_MAX_SEC ? v : LIVE_SYNC_DEFAULT_TARGET_SEC;
}

// 싱크 대상 제외 사유 'vod' | 'noSample' | 'stalled', 대상이면 null.
function getLiveSyncExclusion(ch, now) {
  if (ch.isVod) return 'vod';
  // isVod 판정이 빠진 유튜브 영상은 길이가 유한하면 영상으로 보고 뺀다.
  if (ch.platform === 'youtube' && typeof channelDurationSecByHash[ch.hash] === 'number') return 'vod';
  const sample = liveSyncLatencySample[ch.hash];
  if (!sample || now - sample.at > LIVE_SYNC_SAMPLE_MAX_AGE_MS) return 'noSample';
  const stall = channelStallTracker[ch.hash];
  if (!stall || now - stall.lastChangeAt > 3000) return 'stalled';
  if (!isLiveSyncPlaybackSteady(ch.hash)) return 'unsteady';
  return null;
}

// 맞출 기준 지연과 기준 메인 hash. 메인 자신은 설정 기준 지연에 맞춘다 — 메인이 늦으면 전부 실시간에서 멀어졌다.
function getLiveSyncState(now) {
  const main = mainChannel ? getChannelObjByHash(mainChannel) : null;
  const setting = getLiveSyncTargetSetting();
  if (main && !getLiveSyncExclusion(main, now)) {
    const mainLatency = liveSyncLatencySample[main.hash].sec;
    if (Math.abs(mainLatency - setting) <= LIVE_SYNC_MAIN_TRUST_SEC) {
      return { target: mainLatency, mainHash: main.hash };
    }
    return { target: setting, mainHash: main.hash };
  }
  return { target: setting, mainHash: null };
}

// 메인은 설정 기준 지연, 나머지는 메인 지연.
function getLiveSyncTargetFor(hash, state) {
  return hash === state.mainHash ? getLiveSyncTargetSetting() : state.target;
}

function syncLiveChannelToTarget(ch, now) {
  if (getLiveSyncExclusion(ch, now)) return false;
  const state = getLiveSyncState(now);
  // 양수: 뒤처짐 → 당김, 음수: 앞섬 → 늦춤.
  const deltaSec = liveSyncLatencySample[ch.hash].sec - getLiveSyncTargetFor(ch.hash, state);
  if (Math.abs(deltaSec) <= LIVE_SYNC_TOLERANCE_SEC || Math.abs(deltaSec) > LIVE_SYNC_MAX_SEEK_SEC) return false;
  return seekLiveChannelBy(ch, deltaSec, now);
}

// 조작 키 직접 맞춤 — 설정이 꺼져 있어도 모든 라이브 채널. 옮긴 채널 수를 반환.
function syncLiveChannelLatencies() {
  const now = Date.now();
  let moved = 0;
  liveSyncManualHashes.clear(); // 방향키로 직접 옮긴 채널도 다시 자동 맞춤 대상으로
  (displayChannels || []).forEach((ch) => {
    if (syncLiveChannelToTarget(ch, now)) moved++;
  });
  return moved;
}

// 새로 뜬 플레이어를 표시해 두면 지연이 안정된 뒤 한 번 맞춘다.
function markLiveSyncNewPlayer(hash) {
  liveSyncPendingSince[hash] = Date.now();
  liveSyncManualHashes.delete(hash);
}

function processLiveSyncPending() {
  const now = Date.now();
  Object.keys(liveSyncPendingSince).forEach((hash) => {
    const since = liveSyncPendingSince[hash];
    const ch = getChannelObjByHash(hash);
    if (!ch || !isLiveSyncEnabled() || now - since > LIVE_SYNC_NEW_PLAYER_GIVE_UP_MS) {
      delete liveSyncPendingSince[hash];
      return;
    }
    if (now - since < LIVE_SYNC_NEW_PLAYER_SETTLE_MS) return;
    if (ch.isVod) {
      delete liveSyncPendingSince[hash];
      return;
    }
    if (getLiveSyncExclusion(ch, now)) return;
    const main = mainChannel ? getChannelObjByHash(mainChannel) : null;
    if (main && !main.isVod && getLiveSyncExclusion(main, now)) return;
    syncLiveChannelToTarget(ch, now);
    delete liveSyncPendingSince[hash];
  });
}

function seekLiveChannelBy(ch, deltaSec, now) {
  const wrapper = videoWrapperMap.get(ch.hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (!iframe || !iframe.contentWindow) return false;
  if (liveSyncRate[ch.hash]) stopLiveSyncRate(ch.hash);
  if (ch.platform === 'youtube') {
    const cur = lastKnownPlaybackTimeSec[ch.hash];
    const at = lastKnownPlaybackTimeAt[ch.hash];
    if (typeof cur !== 'number' || !at || now - at > 3000) return false;
    seekChannelToTime(ch.hash, cur + (now - at) / 1000 + deltaSec);
  } else {
    iframe.contentWindow.postMessage({ type: 'LIVE_SYNC_SEEK_BY', deltaSec }, '*');
    markCollabResetHold(ch.hash);
  }
  liveSyncLastSeekAt[ch.hash] = now;
  liveSyncLastSeekDeltaSec[ch.hash] = deltaSec;
  // 새 지연값이 올 때까지 이 채널은 다시 보지 않는다.
  delete liveSyncLatencySample[ch.hash];
  return true;
}

setInterval(processLiveSyncPending, LIVE_SYNC_PENDING_CHECK_MS);

// ── 재생 속도로 맞추기 ── 메인과의 차이에 비례해(2~5%) 속도를 바꾸고 STOP 안이면 1배로.
// 1초마다 재전송하며 content.js는 3초 무명령 시 1배로 돌린다. 플레이어가 스스로 속도를 바꾸면 한동안 손대지 않는다.
// 차이가 SEEK_OVER보다 크면 한 번 시크.
const LIVE_SYNC_RATE_CHECK_MS = 1000;
const LIVE_SYNC_RATE_START_SEC = 0.3;
const LIVE_SYNC_RATE_STOP_SEC = 0.1;
const LIVE_SYNC_RATE_GAIN_PER_SEC = 0.05;
const LIVE_SYNC_RATE_MIN_DELTA = 0.02;
const LIVE_SYNC_RATE_MAX_DELTA = 0.05;
const LIVE_SYNC_RATE_SEEK_OVER_SEC = 3;
const LIVE_SYNC_RATE_BIG_GAP_SEEK_COOLDOWN_MS = 60000;
// 크게 시크한 채널이 곧 또 벌어지면 회선 문제로 보고 한동안 둔다.
const LIVE_SYNC_BIG_GAP_GIVE_UP_AFTER = 2;
const LIVE_SYNC_BIG_GAP_WINDOW_MS = 600000;
const LIVE_SYNC_BIG_GAP_REST_MS = 600000;
const liveSyncBigGapSeeks = {}; // hash -> [시각]
const LIVE_SYNC_RATE_MAX_EPISODE_MS = 120000; // 한 번에 이보다 오래 조절해도 못 맞추면 잠시 쉰다
const LIVE_SYNC_RATE_BACKOFF_MS = 60000;
const liveSyncRate = {}; // hash -> { rate, startedAt, changedAt } — 지금 우리가 조절 중인 속도
const liveSyncRateBackoffUntil = {}; // hash -> 이 시각까지 속도 조절을 안 한다
const liveSyncReportedRate = {}; // hash -> { rate, at } — content.js가 보고한 실제 재생 속도

function postLiveSyncRate(hash, rate) {
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'LIVE_SYNC_RATE', rate }, '*');
}

function stopLiveSyncRate(hash, backoffMs) {
  if (liveSyncRate[hash]) {
    postLiveSyncRate(hash, 1);
    delete liveSyncRate[hash];
  }
  if (backoffMs) liveSyncRateBackoffUntil[hash] = Date.now() + backoffMs;
}

// 지연이 이만큼 쌓이면 조건과 무관하게 기준으로 당긴다(같은 채널은 쿨다운).
const LIVE_SYNC_FAR_BEHIND_SEC = 7;
const LIVE_SYNC_FAR_BEHIND_COOLDOWN_MS = 15000;

function pullFarBehindLiveChannel(ch, now, syncState) {
  const exclusion = getLiveSyncExclusion(ch, now);
  if (exclusion === 'vod' || exclusion === 'noSample') return false;
  const latency = liveSyncLatencySample[ch.hash].sec;
  if (latency < LIVE_SYNC_FAR_BEHIND_SEC) return false;
  if (now - (liveSyncLastSeekAt[ch.hash] || 0) < LIVE_SYNC_FAR_BEHIND_COOLDOWN_MS) return false;
  const diff = latency - getLiveSyncTargetFor(ch.hash, syncState);
  if (diff <= 0 || diff > LIVE_SYNC_MAX_SEEK_SEC) return false;
  return seekLiveChannelBy(ch, diff, now);
}

function updateLiveSyncRates() {
  const now = Date.now();
  const enabled = isLiveSyncEnabled();
  const { target, mainHash } = getLiveSyncState(now);
  Object.keys(liveSyncRate).forEach((hash) => {
    if (!getChannelObjByHash(hash)) delete liveSyncRate[hash];
  });
  (displayChannels || []).forEach((ch) => {
    const hash = ch.hash;
    const state = liveSyncRate[hash];
    if (enabled && !liveSyncPendingSince[hash] && pullFarBehindLiveChannel(ch, now, { target, mainHash })) return;
    const canAdjust = enabled && ch.platform !== 'youtube'
      && !liveSyncPendingSince[hash] && !getLiveSyncExclusion(ch, now)
      && !(liveSyncManualHashes.has(hash) && !isChannelInCollab(hash));
    if (!canAdjust) {
      if (state) stopLiveSyncRate(hash);
      return;
    }
    const reported = liveSyncReportedRate[hash];
    if (state && reported && reported.at > state.changedAt + 2000 && Math.abs(reported.rate - state.rate) > 0.005) {
      delete liveSyncRate[hash];
      liveSyncRateBackoffUntil[hash] = now + LIVE_SYNC_RATE_BACKOFF_MS;
      return;
    }
    // 양수: 뒤처짐 → 빠르게, 음수: 앞섬 → 느리게.
    const diff = liveSyncLatencySample[hash].sec - getLiveSyncTargetFor(hash, { target, mainHash });
    const abs = Math.abs(diff);
    if (abs > LIVE_SYNC_RATE_SEEK_OVER_SEC) {
      if (state) stopLiveSyncRate(hash);
      if (now - (liveSyncLastSeekAt[hash] || 0) > LIVE_SYNC_RATE_BIG_GAP_SEEK_COOLDOWN_MS && abs <= LIVE_SYNC_MAX_SEEK_SEC) {
        const trail = (liveSyncBigGapSeeks[hash] = (liveSyncBigGapSeeks[hash] || []).filter((t) => now - t < LIVE_SYNC_BIG_GAP_WINDOW_MS));
        if (trail.length >= LIVE_SYNC_BIG_GAP_GIVE_UP_AFTER) {
          if (now - trail[trail.length - 1] < LIVE_SYNC_BIG_GAP_REST_MS) return;
          trail.length = 0;
        }
        trail.push(now);
        seekLiveChannelBy(ch, diff, now);
      }
      return;
    }
    if (state) {
      if (abs <= LIVE_SYNC_RATE_STOP_SEC || Math.sign(diff) !== Math.sign(state.rate - 1)) {
        stopLiveSyncRate(hash);
        return;
      }
      if (now - state.startedAt > LIVE_SYNC_RATE_MAX_EPISODE_MS) {
        stopLiveSyncRate(hash, LIVE_SYNC_RATE_BACKOFF_MS);
        return;
      }
    } else if (abs <= LIVE_SYNC_RATE_START_SEC || now < (liveSyncRateBackoffUntil[hash] || 0)) {
      return;
    }
    const magnitude = Math.min(LIVE_SYNC_RATE_MAX_DELTA, Math.max(LIVE_SYNC_RATE_MIN_DELTA, abs * LIVE_SYNC_RATE_GAIN_PER_SEC));
    const rate = Math.round((1 + Math.sign(diff) * magnitude) * 1000) / 1000;
    if (!state || state.rate !== rate) {
      liveSyncRate[hash] = { rate, startedAt: state ? state.startedAt : now, changedAt: now };
    }
    postLiveSyncRate(hash, rate);
  });
}

setInterval(updateLiveSyncRates, LIVE_SYNC_RATE_CHECK_MS);

// ── 방향키 지연 조절(합방이 아닌 라이브) ── 왼쪽 당김, 오른쪽 늦춤. 직접 옮긴 채널은 자동 조절에서 뺀다
// (싱크 키나 재로드 시 복귀). 합방 채널은 대상 아님.
const LIVE_LATENCY_KEY_STEP_SEC = 1;
const liveSyncManualHashes = new Set();

// 자동 합방 풀은 모든 라이브를 담으므로 실제 클러스터만 합방으로 본다.
function isChannelInCollab(hash) {
  if (getCollabLiveClusterForHash(hash)) return true;
  const group = findCollabGroupForChannel(hash);
  return !!group && group.id !== LIVE_AUTO_GROUP_ID;
}

function nudgeLiveChannelLatency(hash, dir) {
  const ch = getChannelObjByHash(hash);
  if (!ch || ch.isVod || isChannelInCollab(hash)) return false;
  if (getLiveSyncExclusion(ch, Date.now()) === 'vod') return false;
  const latencyBefore = liveSyncLastLatencySec[hash];
  if (!seekLiveChannelBy(ch, dir * LIVE_LATENCY_KEY_STEP_SEC, Date.now())) return false;
  liveSyncManualHashes.add(hash);
  delete liveSyncPendingSince[hash];
  showLatencyNudgeToast(hash, dir, typeof latencyBefore === 'number' ? latencyBefore - dir * LIVE_LATENCY_KEY_STEP_SEC : null);
  return true;
}

// 방향키 조절 표시(연달아 누르면 갱신).
const LATENCY_NUDGE_TOAST_MS = 1500;
function showLatencyNudgeToast(hash, dir, estimatedLatencySec) {
  const wrapper = videoWrapperMap.get(hash);
  if (!wrapper) return;
  let toast = wrapper.querySelector(':scope > .latency-nudge-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'latency-nudge-toast';
    wrapper.appendChild(toast);
  }
  const action = dir > 0
    ? t('settings.latencyNudgePulled', '지연 {sec}초 당김')
    : t('settings.latencyNudgeDelayed', '지연 {sec}초 늦춤');
  let text = action.replace('{sec}', String(LIVE_LATENCY_KEY_STEP_SEC));
  if (typeof estimatedLatencySec === 'number' && estimatedLatencySec > 0) {
    text += ' · ' + t('settings.latencyNudgeNow', '약 {sec}초').replace('{sec}', estimatedLatencySec.toFixed(1));
  }
  toast.textContent = text;
  toast.classList.toggle('is-delay', dir < 0);
  toast.classList.add('visible');
  clearTimeout(toast._hideTimer);
  toast._hideTimer = setTimeout(() => toast.classList.remove('visible'), LATENCY_NUDGE_TOAST_MS);
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'LIVE_LATENCY_KEY') return;
  const hash = findChannelHashByWindow(event.source);
  if (hash) nudgeLiveChannelLatency(hash, event.data.dir < 0 ? 1 : -1);
});

// 대시보드 포커스 시엔 호버 타일 — 메인-서브에선 좌우 키가 메인 전환이라 그리드일 때만.
document.addEventListener('keydown', (e) => {
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
  if (currentLayout === 'main_sub' && !isMainSubTreatedAsGrid()) return;
  const active = document.activeElement;
  if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable)) return;
  let hoveredHash = null;
  videoWrapperMap.forEach((wrapper, hash) => {
    if (!hoveredHash && wrapper.isConnected && wrapper.matches(':hover')) hoveredHash = hash;
  });
  if (!hoveredHash) return;
  if (nudgeLiveChannelLatency(hoveredHash, e.key === 'ArrowLeft' ? 1 : -1)) e.preventDefault();
});

// ── 싱크 디버그 표시 ── 타일 왼쪽 위에 지연·기준·최근 이동량을 1초마다.
const liveSyncLastSeekDeltaSec = {}; // hash -> 마지막으로 옮긴 양(초, +는 당김, -는 늦춤)
const liveSyncLastLatencySec = {}; // hash -> 마지막으로 받은 지연값(당긴 뒤 샘플이 지워져도 표시용으로 남긴다)
const SYNC_DEBUG_RECENT_SEEK_MS = 30000;

function isSyncDebugEnabled() {
  return isDebugModeEnabled() && !!mySetting.syncDebugEnabled;
}

// VOD 싱크 채널은 대표 대비 오프셋과 어긋남을 보여준다. 그룹 밖 VOD면 null.
function getVodSyncDebugLines(hash) {
  const group = findCollabGroupForChannel(hash);
  if (!isVodSyncGroup(group)) return null;
  const representativeHash = getCollabLeaderHash(group);
  if (representativeHash === hash) return [t('settings.syncDebugVodRep', 'VOD 싱크 대표')];
  const offsetSec = getVodSyncOffsetSec(group, hash);
  if (offsetSec === null) return [t('settings.syncDebugVodNoOffset', '오프셋 계산 전')];
  const signed = (v) => `${v >= 0 ? '+' : ''}${v.toFixed(2)}s`;
  const lines = [`${t('settings.syncDebugOffset', '오프셋')} ${signed(offsetSec)}`];
  const repNow = getExtrapolatedPlaybackSec(representativeHash);
  const memberNow = getExtrapolatedPlaybackSec(hash);
  if (repNow !== null && memberNow !== null) {
    lines.push(`${t('settings.syncDebugDrift', '어긋남')} ${signed(memberNow - (repNow + offsetSec))}`);
  }
  if (!vodSyncFineAlignedHashes.has(hash)) lines.push(t('settings.syncDebugVodFineAligning', '파형 정렬 대기'));
  return lines;
}

function renderSyncDebugOverlays() {
  const enabled = isSyncDebugEnabled();
  const now = Date.now();
  const { target, mainHash } = enabled ? getLiveSyncState(now) : { target: null, mainHash: null };
  videoWrapperMap.forEach((wrapper, hash) => {
    let box = wrapper.querySelector(':scope > .sync-debug-overlay');
    if (!enabled) {
      if (box) box.remove();
      return;
    }
    const ch = getChannelObjByHash(hash);
    if (!ch) return;
    if (!box) {
      box = document.createElement('div');
      box.className = 'sync-debug-overlay';
      wrapper.appendChild(box);
    }
    const lines = [];
    const exclusion = getLiveSyncExclusion(ch, now);
    const latency = liveSyncLastLatencySec[hash];
    if (exclusion === 'vod') {
      lines.push(...(getVodSyncDebugLines(hash) || [t('settings.syncDebugVod', 'VOD — 대상 아님')]));
    } else {
      lines.push(`${t('settings.syncDebugDelay', '지연')} ${typeof latency === 'number' ? latency.toFixed(2) + 's' : '-'}`);
      if (target !== null && typeof latency === 'number') {
        const own = getLiveSyncTargetFor(hash, { target, mainHash });
        const diff = latency - own;
        const mainMark = hash === mainHash ? t('settings.syncDebugMain', '메인') + ' · ' : '';
        lines.push(`${mainMark}${t('settings.syncDebugTarget', '기준')} ${own.toFixed(2)}s (${diff >= 0 ? '+' : ''}${diff.toFixed(2)})`);
      }
      if (exclusion === 'stalled') lines.push(t('settings.syncDebugStalled', '멈춤 — 대상 아님'));
      else if (exclusion === 'unsteady') lines.push(t('settings.syncDebugUnsteady', '재생 불안정 — 대상 아님'));
      else if (exclusion === 'noSample') lines.push(t('settings.syncDebugNoSample', '측정 대기'));
    }
    const rateState = liveSyncRate[hash];
    const reportedRate = liveSyncReportedRate[hash];
    if (rateState) {
      lines.push(`${t('settings.syncDebugRate', '속도')} ${rateState.rate.toFixed(2)}× · ${Math.round((now - rateState.startedAt) / 1000)}s`);
    } else if (reportedRate && now - reportedRate.at < 3000 && Math.abs(reportedRate.rate - 1) > 0.005) {
      lines.push(`${t('settings.syncDebugPlayerRate', '플레이어 속도')} ${reportedRate.rate.toFixed(2)}×`);
    }
    const seekAt = liveSyncLastSeekAt[hash];
    if (seekAt && now - seekAt <= SYNC_DEBUG_RECENT_SEEK_MS) {
      const moved = liveSyncLastSeekDeltaSec[hash];
      lines.push(`${moved >= 0 ? t('settings.syncDebugPulled', '당김') : t('settings.syncDebugDelayed', '늦춤')} ${Math.abs(moved).toFixed(2)}s · ${Math.round((now - seekAt) / 1000)}s`);
    }
    box.classList.toggle('behind', typeof latency === 'number' && target !== null
      && Math.abs(latency - getLiveSyncTargetFor(hash, { target, mainHash })) > LIVE_SYNC_TOLERANCE_SEC);
    box.textContent = lines.join('\n');
  });
}

setInterval(renderSyncDebugOverlays, 1000);


// 합방 레이턴시 playbackRate 정렬은 제거됨(사유: docs/collab-architecture.md §21).

function saveChannelsToStorage() {
  const dataToSave = { 'my_channels': channels };
  // 메인 채널은 창별 상태에 두고, 영구 값은 대표 창만 남긴다(§3.7).
  if (isRepresentativeWindow() || extendedMainSubActive) dataToSave.main_channel = mainChannel;
  saveWindowState();

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set(dataToSave);
  } else {
    localStorage.setItem('my_channels', JSON.stringify(channels));
    if (mainChannel) {
      localStorage.setItem('main_channel', mainChannel);
    }
  }
}

// 대기열은 별도 키로 저장한다(채널이 없어도 유지). 모든 창 공용이라 다른 창 변경을 받아 맞추고
// 이 창 에코는 무시한다(§createWriteEchoTracker).
const queueWriteEchoes = createWriteEchoTracker();

function saveQueueToStorage() {
  const dataToSave = { 'my_video_queue': videoQueue, 'my_queue_paused': queuePaused };
  queueWriteEchoes.remember(JSON.stringify(dataToSave));
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set(dataToSave);
  } else {
    localStorage.setItem('my_video_queue', JSON.stringify(videoQueue));
    localStorage.setItem('my_queue_paused', queuePaused ? '1' : '0');
  }
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || (!changes.my_video_queue && !changes.my_queue_paused)) return;
    const nextQueue = changes.my_video_queue
      ? (Array.isArray(changes.my_video_queue.newValue) ? changes.my_video_queue.newValue : [])
      : videoQueue;
    const nextPaused = changes.my_queue_paused ? !!changes.my_queue_paused.newValue : queuePaused;
    if (queueWriteEchoes.consumeIfEcho(JSON.stringify({ my_video_queue: nextQueue, my_queue_paused: nextPaused }))) return;
    videoQueue = nextQueue;
    queuePaused = nextPaused;
    renderQueueSidebar();
  });
}

function savePresetsToStorage() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ 'my_presets': presets });
  } else {
    localStorage.setItem('my_presets', JSON.stringify(presets));
  }
}

function saveLayoutToStorage() {
  saveWindowState();
  if (!isRepresentativeWindow()) return;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ 'my_layout': currentLayout });
  } else {
    localStorage.setItem('my_layout', currentLayout);
  }
}

// 이 창이 쓴 값의 onChanged 에코를 구분한다. 쓸 때마다 대기 목록에 넣고 에코가 오면 한 번 건너뛴다
// (마지막 값만 기억하면 되돌린 변경을 놓친다). 저장값과 같은 쓰기는 onChanged가 안 오므로 넣지 않는다.
function createWriteEchoTracker() {
  const pending = [];
  let lastStoredJson = null;
  return {
    remember(json) {
      if (json === lastStoredJson) return;
      lastStoredJson = json;
      pending.push(json);
      if (pending.length > 8) pending.shift();
    },
    consumeIfEcho(json) {
      lastStoredJson = json;
      const idx = pending.indexOf(json);
      if (idx === -1) return false;
      pending.splice(0, idx + 1);
      return true;
    }
  };
}

const audioStateWriteEchoes = createWriteEchoTracker();
const profileWriteEchoes = createWriteEchoTracker();

function saveAudioState() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    audioStateWriteEchoes.remember(JSON.stringify(audioState));
    chrome.storage.local.set({ 'my_audio_state': audioState });
  } else {
    localStorage.setItem('my_audio_state', JSON.stringify(audioState));
  }
}

// 다른 창의 설정·채널 음량·합방 그룹 변경을 받아 다시 맞춘다. 이 창 에코는 건너뛴다.
if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local') return;
    let changed = false;
    if (changes.my_profile && changes.my_profile.newValue) {
      const json = JSON.stringify(changes.my_profile.newValue);
      if (!profileWriteEchoes.consumeIfEcho(json) && json !== JSON.stringify(mySetting)) {
        mySetting = changes.my_profile.newValue;
        changed = true;
      }
    }
    if (changes.my_audio_state && changes.my_audio_state.newValue) {
      const json = JSON.stringify(changes.my_audio_state.newValue);
      if (!audioStateWriteEchoes.consumeIfEcho(json) && json !== JSON.stringify(audioState)) {
        audioState = { ...audioState, ...changes.my_audio_state.newValue };
        changed = true;
      }
    }
    if (!changed) return;
    if (isCollabSettingEnabled()) recomputeCollabMuting();
    applyVolumeToAllChannels(true);
    refreshAudioSettingsListIfSafe();
    renderCollabSettingsSection();
    refreshExtendedMainSubState();
    // 다른 창에서 AI 음성 감지 모델을 바꿨으면 워커를 다시 띄운다.
    if (vadWorker && vadRequestedModel !== getCollabVadModelSetting()) {
      resetVadWorker();
      if (isCollabVadNeededInThisWindow()) ensureVadWorker();
    }
  });
}

// smooth=true면 약 0.5초 램프(모드 전환 등 큰 변화용). 마지막 전송 값을 기억해 같으면 보내지 않는다 —
// 반복 재전송이 램프를 계속 새로 걸어 플레이어 직접 조작이 무시됐다.
let lastSentVolumeMessage = {}; // hash -> { volume, needsGraph, compressorEnabled }

function postVolumeMsg(hash, value, smooth) {
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (iframe && iframe.contentWindow) {
    // needsGraph: dB 측정용 Web Audio 그래프 필요 여부. 합방·오디오 디버그가 켜져 있으면 최적화가 꺼져도 만든다.
    const needsGraph = isAudioOptimizationEnabled()
      || isAudioDebugSectionEnabled()
      || (isCollabSettingEnabled() && !!findCollabGroupForChannel(hash));
    const compressorEnabled = isDynamicsCompressorEnabled();
    // 합방 음소거는 volume 0이 아니라 gainNode로 출력만 죽인다 — 측정은 계속 산다(docs/collab-architecture.md §13).
    const collabMuted = isCollabMutedNow(hash);

    const last = lastSentVolumeMessage[hash];
    if (last && last.volume === value && last.needsGraph === needsGraph
      && last.compressorEnabled === compressorEnabled && last.collabMuted === collabMuted) {
      return;
    }
    lastSentVolumeMessage[hash] = { volume: value, needsGraph, compressorEnabled, collabMuted };

    iframe.contentWindow.postMessage({
      type: 'SET_CHANNEL_VOLUME',
      volume: value,
      smooth: !!smooth,
      needsGraph,
      compressorEnabled,
      collabMuted
    }, '*');
  }
}

// 메인/레이아웃 전환 직후엔 플레이어가 volume을 순간 건드릴 수 있어, 잠깐 "사용자 조작" 보고를 억제한다(수동 고정 오저장 방지).
function suppressVolumeEchoReports(durationMs) {
  videoWrapperMap.forEach((wrapper) => {
    const iframe = wrapper.querySelector('iframe');
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ type: 'SUPPRESS_VOLUME_ECHO', durationMs }, '*');
    }
  });
}

// 채널을 해당 초로 시크한다. 유튜브는 relay.html이 seekTo로, 치지직/숲은 content.js가 currentTime으로 처리.
function seekChannelToTime(hash, seconds) {
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (iframe && iframe.contentWindow) {
    iframe.contentWindow.postMessage({ type: 'SEEK_TO_TIME', seconds }, '*');
    // 모든 시크가 여기를 거치므로 판정 보류 표시도 여기서 한다.
    markCollabResetHold(hash);
  }
}

// 숨긴 채널 영상 정지/재생(유튜브는 relay.html이 IFrame API로 릴레이).
function setChannelVideoPlaying(hash, playing) {
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (iframe && iframe.contentWindow) {
    iframe.contentWindow.postMessage({ type: playing ? 'PLAY' : 'PAUSE' }, '*');
  }
}

// VOD 재생 속도 맞춤 — 메인 VOD 속도가 바뀌면 나머지도 따른다. 메인 변경 직후 첫 보고는 기준값으로만 쓴다.
let vodMainRateRef = null; // { hash, rate }

function isVodPlaybackChannel(ch) {
  if (!ch) return false;
  return !!ch.isVod || (ch.platform === 'youtube' && typeof channelDurationSecByHash[ch.hash] === 'number');
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_PLAYBACK_TIME') return;
  const rate = event.data.diag && Number(event.data.diag.rate);
  if (!isFinite(rate) || rate <= 0) return;
  const hash = findChannelHashByWindow(event.source);
  if (!hash || hash !== mainChannel || !isVodPlaybackChannel(getChannelObjByHash(hash))) return;
  if (!vodMainRateRef || vodMainRateRef.hash !== hash) {
    vodMainRateRef = { hash, rate };
    return;
  }
  if (Math.abs(vodMainRateRef.rate - rate) < 0.001) return;
  vodMainRateRef.rate = rate;
  channels.forEach((ch) => {
    if (ch.hash === hash || !isVodPlaybackChannel(ch)) return;
    const iframe = videoWrapperMap.get(ch.hash)?.querySelector('iframe');
    if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'SET_PLAYBACK_RATE', rate }, '*');
  });
});

// 메인-서브인데 보이는 채널이 1개면 그리드처럼 취급한다(currentLayout은 유지). 숨긴 채널은 세지 않는다.
function isMainSubTreatedAsGrid() {
  if (currentLayout !== 'main_sub') return false;
  const visibleCount = displayChannels.filter(c => !videoHiddenChannels.has(c.hash)).length;
  return visibleCount === 1;
}

// 채널의 오디오 역할('main'|'sub'|'grid')을 한 곳에서 판정한다. 그리드에선 mainChannel도 'grid'.
// isMainSubTreatedAsGrid는 화면 배열만 바꾸고 오디오 역할은 바꾸지 않는다.
function getChannelRole(hash) {
  if (extendedMainSubActive) return hash === mainChannel ? 'main' : 'sub';
  if (currentLayout !== 'main_sub') return 'grid';
  return hash === mainChannel ? 'main' : 'sub';
}

// ── 합방 그룹 헬퍼 ── 라이브는 모든 채널을 비교하는 가상 그룹 'live-auto'로 자동 편성,
// VOD 싱크와 수동('manual', 감지 없이 항상 하나만 남김)은 직접 만든다(docs/collab-auto-grouping-design.md).
const LIVE_AUTO_GROUP_ID = 'live-auto';

function getLiveAutoGroup() {
  const groupedMembers = new Set();
  if (isCollabManualEnabled()) audioState.collabGroups.forEach((g) => {
    if (isVodSyncGroup(g)) {
      g.memberHashes.forEach((h) => groupedMembers.add(h));
    } else if (isManualCollabGroup(g)) {
      // 실제로 묶이는(떠 있는 멤버 2명 이상) 수동 그룹만 자동 풀에서 뺀다.
      const present = g.memberHashes.filter((h) => displayChannels.some((c) => c.hash === h));
      if (present.length >= 2) present.forEach((h) => groupedMembers.add(h));
    }
  });
  // 채팅만 채널은 합방 감지 대상이 아니다.
  const memberHashes = displayChannels.filter((c) => !c.isVod && !c.chatOnly && !groupedMembers.has(c.hash)).map((c) => c.hash);
  return { id: LIVE_AUTO_GROUP_ID, memberHashes, mode: 'live', vodOffsetSecByHash: {} };
}

// 실제로 도는 그룹 — 자동 풀(채널 2개 이상), 수동 그룹, VOD 싱크 그룹.
function getEffectiveCollabGroups() {
  const manualGroups = isCollabManualEnabled() ? audioState.collabGroups.filter(isManualCollabGroup) : [];
  const vodGroups = isCollabManualEnabled() ? audioState.collabGroups.filter(isVodSyncGroup) : [];
  const live = isCollabAutoEnabled() ? getLiveAutoGroup() : { memberHashes: [] };
  return [...(live.memberHashes.length >= 2 ? [live] : []), ...manualGroups, ...vodGroups];
}

function isManualCollabGroup(group) {
  return !!group && group.mode === 'manual';
}

// 직접 묶을 수 있는 채널 — VOD 싱크 그룹 밖의 라이브.
function getManualCollabCandidateChannels() {
  const vodSyncMembers = new Set();
  audioState.collabGroups.forEach((g) => {
    if (isVodSyncGroup(g)) g.memberHashes.forEach((h) => vodSyncMembers.add(h));
  });
  return displayChannels.filter((c) => !c.isVod && !c.chatOnly && !vodSyncMembers.has(c.hash));
}

// 멤버가 다 빠지면 그룹을 지운다.
function setManualCollabGroupMember(groupId, hash, include) {
  const group = audioState.collabGroups.find((g) => g.id === groupId);
  if (!group) return;
  if (include) {
    if (!group.memberHashes.includes(hash)) group.memberHashes.push(hash);
  } else {
    group.memberHashes = group.memberHashes.filter((h) => h !== hash);
  }
  if (group.memberHashes.length === 0) {
    audioState.collabGroups = audioState.collabGroups.filter((g) => g.id !== groupId);
    delete leaderChangedAtByGroupId[groupId];
  }
  saveAudioState();
  recomputeCollabMuting();
  applyVolumeToAllChannels(true);
  refreshAudioSettingsListIfSafe();
  renderCollabSettingsSection();
}

function findCollabGroupForChannel(hash) {
  return getEffectiveCollabGroups().find(g => g.memberHashes.includes(hash)) || null;
}

// 'vod-sync' 그룹은 겹침 감지 없이 대표 외 음소거 + 위치 동기화. mode 없으면 'live'.
function isVodSyncGroup(group) {
  return !!group && group.mode === 'vod-sync';
}

// 대표 대비 오프셋(초, 양수=늦게 시작). 시작 시각 캐시가 둘 다 있으면 즉시 계산, 없으면 저장된 수동 값,
// 그것도 없으면 null(정렬 전 — 음소거/시크 대상 제외).
function getVodSyncOffsetSec(group, hash) {
  if (!group) return null;
  const representativeHash = getCollabLeaderHash(group);
  if (representativeHash && representativeHash !== hash) {
    const repStartMs = audioState.vodStartTimeMsByHash[representativeHash];
    const memberStartMs = audioState.vodStartTimeMsByHash[hash];
    if (typeof repStartMs === 'number' && typeof memberStartMs === 'number') {
      return (repStartMs - memberStartMs) / 1000;
    }
  }
  const v = group.vodOffsetSecByHash && group.vodOffsetSecByHash[hash];
  return (typeof v === 'number' && isFinite(v)) ? v : null;
}

// 그룹 리더 = 메인 채널(그룹 소속일 때). 아니면 첫 멤버.
function getCollabLeaderHash(group) {
  if (!group || group.memberHashes.length === 0) return null;
  if (mainChannel && group.memberHashes.includes(mainChannel)) {
    return mainChannel;
  }
  // 자동 풀·수동 그룹은 메인이 없으면 대표 없이 keeper를 고른다(§pickClusterKeeper).
  if (group.id === LIVE_AUTO_GROUP_ID || isManualCollabGroup(group)) return null;
  return group.memberHashes[0];
}

// 삭제된 채널을 그룹에서 빼고, 멤버 1명 이하가 된 그룹은 지운다.
function pruneCollabGroups() {
  const validHashes = new Set(displayChannels.map(c => c.hash));
  const before = JSON.stringify(audioState.collabGroups);
  audioState.collabGroups = audioState.collabGroups
    .map((g) => {
      const memberHashes = g.memberHashes.filter(h => validHashes.has(h));
      const mode = (g.mode === 'vod-sync' || g.mode === 'manual') ? g.mode : 'live';
      // 예전 데이터엔 없을 수 있는 필드 — 항상 존재를 보장한다.
      const vodOffsetSecByHash = {};
      if (g.vodOffsetSecByHash) {
        memberHashes.forEach((h) => {
          const v = g.vodOffsetSecByHash[h];
          if (typeof v === 'number' && isFinite(v)) vodOffsetSecByHash[h] = v;
        });
      }
      return { ...g, memberHashes, mode, vodOffsetSecByHash };
    })
    // 라이브 그룹은 저장하지 않는다.
    .filter(g => (g.mode === 'vod-sync' || g.mode === 'manual') && g.memberHashes.length >= 2);
  return JSON.stringify(audioState.collabGroups) !== before;
}

function isChannelCollabMuted(hash) {
  return collabMutedHashes.has(hash);
}

// 순서 무관한 쌍 키(pairKey(a,b) === pairKey(b,a)).
function pairKey(a, b) {
  return a < b ? `${a}|${b}` : `${b}|${a}`;
}

// 채널 삭제 시 그 채널이 낀 쌍 상태를 한 번에 지운다(디버그용 맵은 자동 정리 대상이 아님).
function deletePairEntriesForHash(hash) {
  [collabDebugLagCorrByPair, collabEdgeMuteCandidateSince, collabEdgeUnmuteProgressMs,
    collabWaveformScoreByPair, collabPairCandidateLastSeenAt, collabPairLastConfirmedAt,
    waveformDivergeStreakByPairKey, collabMeasuredGccLagByPair, collabFirstMatchCandidateByPair, collabSplitAtByPair,
    collabChannelSplitAtByPair].forEach((map) => {
    Object.keys(map).forEach((key) => {
      if (key.split('|').includes(hash)) delete map[key];
    });
  });
  [collabActiveEdges, collabWaveformRefreshInFlight].forEach((set) => {
    Array.from(set).forEach((key) => {
      if (key.split('|').includes(hash)) set.delete(key);
    });
  });
}

// 그룹 내 모든 미순서쌍 — 대표가 끼지 않은 부분 겹침도 잡는다.
function getGroupPairs(group) {
  const hashes = group.memberHashes;
  const pairs = [];
  for (let i = 0; i < hashes.length; i++) {
    for (let j = i + 1; j < hashes.length; j++) {
      pairs.push([hashes[i], hashes[j]]);
    }
  }
  return pairs;
}

function getPairsForHash(hash) {
  const group = findCollabGroupForChannel(hash);
  if (!group) return [];
  return getGroupPairs(group).filter(([a, b]) => a === hash || b === hash);
}

function getPartnerInPair(hash, pair) {
  return pair[0] === hash ? pair[1] : pair[0];
}

// hash가 낀 쌍 중 Stage1 유사도가 가장 높은 쌍(측정된 쌍 우선). 없으면 null.
function getStrongestPairForHash(hash) {
  const pairs = getPairsForHash(hash);
  let best = null;
  pairs.forEach((pair) => {
    const key = pairKey(pair[0], pair[1]);
    const similarity = collabPairSimilarity[key];
    if (best === null) {
      best = { partner: getPartnerInPair(hash, pair), key, similarity };
      return;
    }
    const bestHasValue = typeof best.similarity === 'number';
    const curHasValue = typeof similarity === 'number';
    if (curHasValue && (!bestHasValue || similarity > best.similarity)) {
      best = { partner: getPartnerInPair(hash, pair), key, similarity };
    }
  });
  return best;
}

// ── 합방 오디오 유사도 ── 원본 파형에 접근할 수 없어(크로스오리진) dB 시계열의 지연 상관으로
// 같은 소리가 섞였는지 근사한다. lag 탐색 범위 ±5초 — COLLAB_HISTORY_MAX_SAMPLES와 항상 같이 조정할 것.
const COLLAB_LAG_RANGE_MS = 5000;
const COLLAB_LAG_STEP_MS = 500;
const COLLAB_MATCH_TOLERANCE_MS = 260;
// 샘플 수 기준값을 보고 간격(200ms)에 맞춰 늘려 원래 의도한 시간(≈3초/2초)을 유지한다.
const COLLAB_MIN_SAMPLES = 15;
const COLLAB_MIN_PAIRS = 10;

// 합방 비리더는 레이아웃과 무관하게 항상 음소거된다. 아래 임계값은 UI 표시용 판정에만 쓴다.
const COLLAB_OVERLAP_MUTE_THRESHOLD = 0.10;
const COLLAB_OVERLAP_UNMUTE_THRESHOLD = 0.10;

// pairKey → 최근 Stage1 유사도(-1~1, 부족하면 null). UI "겹침 %" 표시용.
let collabPairSimilarity = {};

// pairKey → lag별 원본 상관계수(디버그 표시 전용).
let collabDebugLagCorrByPair = {};

function pearsonCorrelation(xs, ys) {
  const n = xs.length;
  if (n < 2) return null;
  let sumX = 0, sumY = 0;
  for (let i = 0; i < n; i++) { sumX += xs[i]; sumY += ys[i]; }
  const meanX = sumX / n, meanY = sumY / n;
  let num = 0, denX = 0, denY = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX, dy = ys[i] - meanY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }
  if (denX === 0 || denY === 0) return null;
  return num / Math.sqrt(denX * denY);
}

// 레이턴시 차이로 Stage1 탐색 중심 lag(ms)를 추정한다(없으면 0). lag ≈ latencyB - latencyA.
function getEstimatedLagMsForPair(hashA, hashB) {
  const latA = channelLatencySecByHash[hashA];
  const latB = channelLatencySecByHash[hashB];
  if (typeof latA !== 'number' || typeof latB !== 'number' || !isFinite(latA) || !isFinite(latB)) return 0;
  return (latB - latA) * 1000;
}

// dB 이력을 lag만큼 밀어 각 lag의 상관을 구한다(부족하면 null).
// 고립된 튐을 거르려고 이웃 lag와 평균한 봉우리 중 최댓값을 쓰고, 탐색 중심은 레이턴시 차이로 옮긴다.
// MIN_VALID_REFERENCE_DB 미만은 무음으로 보고 뺀다.
function computeCollabSimilarity(hashA, hashB) {
  const histA = channelAudioLevelHistory[hashA];
  const histB = channelAudioLevelHistory[hashB];
  if (!histA || !histB || histA.length < COLLAB_MIN_SAMPLES || histB.length < COLLAB_MIN_SAMPLES) return null;

  const centerLagMs = getEstimatedLagMsForPair(hashA, hashB);
  const perLagCorr = [];
  for (let lag = centerLagMs - COLLAB_LAG_RANGE_MS; lag <= centerLagMs + COLLAB_LAG_RANGE_MS; lag += COLLAB_LAG_STEP_MS) {
    const xs = [];
    const ys = [];
    histA.forEach((sampleA) => {
      if (sampleA.db < MIN_VALID_REFERENCE_DB) return;
      const targetT = sampleA.t + lag;
      let closest = null;
      let closestDiff = Infinity;
      histB.forEach((sampleB) => {
        const diff = Math.abs(sampleB.t - targetT);
        if (diff < closestDiff) { closestDiff = diff; closest = sampleB; }
      });
      if (closest && closestDiff <= COLLAB_MATCH_TOLERANCE_MS && closest.db >= MIN_VALID_REFERENCE_DB) {
        xs.push(sampleA.db);
        ys.push(closest.db);
      }
    });
    perLagCorr.push(xs.length >= COLLAB_MIN_PAIRS ? pearsonCorrelation(xs, ys) : null);
  }
  collabDebugLagCorrByPair[pairKey(hashA, hashB)] = perLagCorr;

  let best = null;
  for (let i = 0; i < perLagCorr.length; i++) {
    const neighborhood = [perLagCorr[i - 1], perLagCorr[i], perLagCorr[i + 1]]
      .filter((v) => typeof v === 'number');
    if (neighborhood.length < 2) continue; // 이웃 lag와 함께 확인 안 되면 신뢰하지 않는다
    const smoothed = neighborhood.reduce((sum, v) => sum + v, 0) / neighborhood.length;
    if (best === null || smoothed > best) best = smoothed;
  }
  return best;
}

// ── 합방 판정 로거(디버그) ── 대표 창 콘솔에서 cheeseCollabLog.start(10) / summary() / export().
// 대조군: B를 COLLAB_LOG_CONTROL_SHIFT_SEC초 전 스니펫으로 바꿔 같은 조건으로 점수를 낸다(오탐 기준선).
const COLLAB_LOG_CONTROL_SHIFT_SEC = 9;
const COLLAB_LOG_MAX_EVENTS = 300000;
const collabTimingLog = { active: false, startedAt: 0, until: 0, events: [], snippets: {} };

function isCollabTimingLogActive() {
  if (!collabTimingLog.active) return false;
  if (Date.now() <= collabTimingLog.until) return true;
  collabTimingLog.active = false;
  console.log('[COLLAB LOG] 기록 종료 — cheeseCollabLog.summary()');
  return false;
}

function logCollabEvent(type, data) {
  if (!isCollabTimingLogActive() || collabTimingLog.events.length >= COLLAB_LOG_MAX_EVENTS) return;
  collabTimingLog.events.push({ t: Date.now() - collabTimingLog.startedAt, type, ...data });
}

function logCollabWaveformScore(snipA, snipB, bufA, bufB, entry) {
  if (!isCollabTimingLogActive()) return;
  logCollabEvent('score', entry);
  const now = Date.now();
  const hashB = entry.p.split('|').find((h) => h !== entry.a);
  const history = collabTimingLog.snippets[hashB] || (collabTimingLog.snippets[hashB] = []);
  if (!history.length || now - history[history.length - 1].at >= 1000) {
    history.push({ at: now, samples: snipB.samples, sampleRate: snipB.sampleRate });
  }
  while (history.length && now - history[0].at > (COLLAB_LOG_CONTROL_SHIFT_SEC + 6) * 1000) history.shift();
  const old = history.find((h) => now - h.at >= COLLAB_LOG_CONTROL_SHIFT_SEC * 1000);
  if (!old) return;
  const shiftedB = takeMostRecentSamples(old.samples, old.sampleRate, bufB.length / snipB.sampleRate);
  computeGccPhatAsync(bufA, snipA.sampleRate, shiftedB, old.sampleRate, entry.maxLag, entry.c).then((res) => {
    if (res) logCollabEvent('ctrl', { p: entry.p, sc: +res.score.toFixed(4), lag: +res.lagSec.toFixed(3), c: entry.c, q: entry.q });
  });
}

function summarizeCollabTimingLog() {
  const events = collabTimingLog.events;
  const sec = (ms) => +(ms / 1000).toFixed(2);
  const stats = (arr) => {
    if (!arr.length) return { n: 0 };
    const s = arr.slice().sort((a, b) => a - b);
    const at = (p) => sec(s[Math.min(s.length - 1, Math.floor(p * s.length))]);
    return { n: s.length, p50: at(0.5), p90: at(0.9), max: sec(s[s.length - 1]) };
  };
  const byPair = {};
  events.forEach((e) => { if (e.p) (byPair[e.p] || (byPair[e.p] = [])).push(e); });
  const muteLatency = [];
  const unmuteLatency = [];
  const lockDurations = [];
  let locks = 0;
  Object.values(byPair).forEach((list) => {
    let onset = null;
    let lastMatch = null;
    let lockedAt = null;
    list.forEach((e) => {
      if (e.type === 'score') {
        if (lockedAt === null) {
          if (onset === null && e.sc >= COLLAB_WAVEFORM_FIRST_MATCH_THRESHOLD && !e.off) onset = e.t;
          else if (e.sc < COLLAB_WAVEFORM_MATCH_THRESHOLD) onset = null;
        }
        if (e.m) lastMatch = e.t;
      } else if (e.type === 'lock') {
        locks++;
        lockedAt = e.t;
        if (onset !== null) muteLatency.push(e.t - onset);
        onset = null;
      } else if (e.type === 'unlock') {
        if (lockedAt !== null) lockDurations.push(e.t - lockedAt);
        if (lastMatch !== null) unmuteLatency.push(e.t - lastMatch);
        lockedAt = null;
      }
    });
  });
  const controls = events.filter((e) => e.type === 'ctrl');
  const rate = (list, threshold) => (list.length ? +(list.filter((e) => e.sc >= threshold).length / list.length).toFixed(3) : null);
  const minutes = (Math.min(Date.now(), collabTimingLog.until) - collabTimingLog.startedAt) / 60000;
  return {
    minutes: +minutes.toFixed(1),
    scores: events.filter((e) => e.type === 'score').length,
    locks,
    locksPerMin: +(locks / Math.max(minutes, 0.01)).toFixed(2),
    shortLocksUnder5s: lockDurations.filter((ms) => ms < 5000).length,
    muteLatencySec: stats(muteLatency),
    unmuteLatencySec: stats(unmuteLatency),
    lockDurationSec: stats(lockDurations),
    controlFalseMatchRate: {
      full: { n: controls.filter((e) => !e.q).length, over010: rate(controls.filter((e) => !e.q), COLLAB_WAVEFORM_MATCH_THRESHOLD), over015: rate(controls.filter((e) => !e.q), COLLAB_WAVEFORM_FIRST_MATCH_THRESHOLD) },
      quick: { n: controls.filter((e) => e.q).length, over010: rate(controls.filter((e) => e.q), COLLAB_WAVEFORM_MATCH_THRESHOLD) }
    }
  };
}

// 기록 중 사용자 표시(숫자 키, 판정에 영향 없음): 1 = 잠겨야 함, 0 = 풀려야 함, 5 = 오탐.
const COLLAB_LOG_USER_MARKS = { 1: 'lock', 0: 'unlock', 5: 'fp' };
const COLLAB_LOG_USER_MARK_LABELS = { lock: '1 잠금', unlock: '0 풀림', fp: '5 오탐' };
let collabLogMarkToastTimer = null;

function showCollabLogMarkToast(text) {
  let el = document.getElementById('collab-log-mark-toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'collab-log-mark-toast';
    el.className = 'collab-log-mark-toast';
    document.body.appendChild(el);
  }
  el.textContent = text;
  el.classList.add('visible');
  clearTimeout(collabLogMarkToastTimer);
  collabLogMarkToastTimer = setTimeout(() => el.classList.remove('visible'), 1500);
}

document.addEventListener('keydown', (e) => {
  const mark = COLLAB_LOG_USER_MARKS[e.key];
  if (!mark || e.ctrlKey || e.metaKey || e.altKey || !isCollabTimingLogActive()) return;
  const active = document.activeElement;
  if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.tagName === 'SELECT' || active.isContentEditable)) return;
  e.preventDefault();
  e.stopImmediatePropagation();
  logCollabEvent('user', { mark, edges: Array.from(collabActiveEdges), muted: Array.from(collabMutedHashes) });
  const count = collabTimingLog.events.filter((ev) => ev.type === 'user').length;
  console.log(`[COLLAB LOG] 표시: ${mark} (${count}번째)`);
  showCollabLogMarkToast(`기록: ${COLLAB_LOG_USER_MARK_LABELS[mark]} (${count})`);
}, true);

window.cheeseCollabLog = {
  start(minutes = 10) {
    Object.assign(collabTimingLog, { active: true, startedAt: Date.now(), until: Date.now() + minutes * 60000, events: [], snippets: {} });
    console.log(`[COLLAB LOG] ${minutes}분 기록 시작`);
  },
  stop() {
    collabTimingLog.until = Date.now();
    isCollabTimingLogActive();
  },
  summary: summarizeCollabTimingLog,
  export() {
    const names = Object.fromEntries(displayChannels.map((c) => [c.hash, c.name]));
    return { startedAt: collabTimingLog.startedAt, until: collabTimingLog.until, vadModel: vadActiveModel, names, events: collabTimingLog.events };
  }
};

// 음소거 전환 전 상태가 이 시간 동안 이어져야 한다(깜빡임 방지). 첫 확정 조건이 이미 엄격해 400ms로 줄였다.
const COLLAB_MUTE_SUSTAIN_MS = 400;
const COLLAB_UNMUTE_SUSTAIN_MS = 2500;

// pairKey → 음소거 임계값을 처음 넘긴 시각(아직 활성 간선이 아닌 쌍만).
let collabEdgeMuteCandidateSince = {};
// pairKey → 해제 누적 진행도(leaky bucket). 겹침이 다시 나오면 전부 비우지 않고 DECAY만큼만 깎는다 —
// 판정이 오락가락할 때 sustain을 처음부터 다시 기다려 지연이 10초 넘게 쌓였다.
let collabEdgeUnmuteProgressMs = {};
// 겹침 한 번에 깎는 양(사이클 간격의 2~3배).
const COLLAB_UNMUTE_PROGRESS_DECAY_MS = 1500;
// 'pending'(아직 모름)은 'different'보다 훨씬 약하게(이 배율) 해제 게이지를 채운다 — 무시하면 영영 안 풀릴 수 있다.
const COLLAB_PENDING_UNMUTE_FILL_RATE = 0.25;
// 사이클 dt 상한(백그라운드 복귀 시 한 번에 차지 않게).
let collabMutingLastTickAt = null;
// 겹침 확정 쌍 — 이 간선으로 클러스터를 구한다(getGroupClusters).
let collabActiveEdges = new Set();

// hash → 이 시각까지 이 채널이 낀 쌍의 판정을 건너뛴다(마지막 상태 유지). 시크·영상 교체 직후엔
// Stage1/2가 새 내용을 반영 못 해 음소거가 잠깐 풀렸다 다시 걸렸다.
let collabResetHoldUntilByHash = {};
// 대략 Stage1 이력과 Stage2 버퍼가 다시 찰 시간(추정치).
const COLLAB_RESET_HOLD_MS = 4000;
function markCollabResetHold(hash) {
  collabResetHoldUntilByHash[hash] = Date.now() + COLLAB_RESET_HOLD_MS;
}
function isCollabResetHoldActive(hash) {
  const until = collabResetHoldUntilByHash[hash];
  return typeof until === 'number' && Date.now() < until;
}

// ── 합방 겹침 감지 Stage 2: 파형 GCC-PHAT ── Stage 1(dB 엔벨로프)은 타이밍만 보므로 다른 말도 걸린다.
// Stage 1 후보 쌍만 실제 파형 스니펫으로 "같은 소리가 새어 들어왔는지" 확인한다.

const COLLAB_WAVEFORM_MAX_LAG_SEC = COLLAB_LAG_RANGE_MS / 1000;

// VOD 싱크 전용 넓은 캡처 창·탐색 범위 — 메타데이터 오프셋 잔차가 ±3초를 넘을 수 있다. 버퍼 끝은 신뢰도가 낮아 3초 여유를 둔다.
const VOD_SYNC_CAPTURE_WINDOW_SEC = 15;
const VOD_SYNC_WAVEFORM_MAX_LAG_SEC = 12;
// vod-sync 재확인 창/탐색 범위. 탐색 범위는 드리프트 허용치(1.5초)보다 넓어야 한다 — 좁히면 정상 오차 안의 피크를 못 찾았다.
const VOD_SYNC_WAVEFORM_QUICK_VERIFY_WINDOW_SEC = 3;
const VOD_SYNC_WAVEFORM_QUICK_VERIFY_MAX_LAG_SEC = 1.5;
// quick-verify 재확인 중 "다른 소리"로 확정하는 데 필요한 연속 저점수 횟수(라이브/vod-sync 공용).
// 실측 로그 재생 결과 4가 해제 지연과 재잠김의 절충.
const WAVEFORM_DIVERGE_MIN_CONFIRMATIONS = 4;
// vod-sync Stage2 유예 — 캡처 창(15초)이 다 찰 때까지 + 여유. 짧으면 정렬 시크마다 음소거가 풀린다.
const VOD_SYNC_WAVEFORM_CONFIRM_GRACE_MS = 17000;
// 파형 유사도 임계값(gcc-phat score ≈ -1~1). 합성 신호 기준 크로스토크 ~0.17, 무관 ~0.03.
const COLLAB_WAVEFORM_MATCH_THRESHOLD = 0.10;
// 확인 이력 없는 라이브 쌍의 첫 확정 문턱(더 높게) — 비합방 오탐의 대부분이 0.10~0.15 잡음 점수였다. vod-sync 제외.
const COLLAB_WAVEFORM_FIRST_MATCH_THRESHOLD = 0.15;

function getWaveformMatchThresholdForPair(hashA, hashB) {
  if (getVodSyncRepMemberPair(hashA, hashB)) return COLLAB_WAVEFORM_MATCH_THRESHOLD;
  return typeof collabPairLastConfirmedAt[pairKey(hashA, hashB)] === 'number'
    ? COLLAB_WAVEFORM_MATCH_THRESHOLD
    : COLLAB_WAVEFORM_FIRST_MATCH_THRESHOLD;
}
// 첫 확정은 문턱을 연속 두 번 넘고 두 피크 lag 차이가 이 값 이하일 때만(단발 잡음 피크 차단).
const COLLAB_WAVEFORM_FIRST_MATCH_LAG_TOLERANCE_SEC = 0.2;
// 연속 두 점수가 둘 다 약하면 확정하지 않는다 — 하나는 이 값을 넘어야 한다.
const COLLAB_WAVEFORM_FIRST_MATCH_PEAK_THRESHOLD = 0.20;
// 정밀 모델(pyannote)일 때의 같은 문턱(실측 로그 기준 0.27).
const COLLAB_WAVEFORM_FIRST_MATCH_PEAK_THRESHOLD_PRECISE = 0.27;

function getFirstMatchPeakThreshold() {
  return vadActiveModel === 'pyannote' ? COLLAB_WAVEFORM_FIRST_MATCH_PEAK_THRESHOLD_PRECISE : COLLAB_WAVEFORM_FIRST_MATCH_PEAK_THRESHOLD;
}
// 첫 확정 피크 lag가 탐색 중심에서 이만큼보다 멀면 잡음 피크로 보고 후보로도 치지 않는다. vod-sync·재확인 제외.
const COLLAB_WAVEFORM_FIRST_MATCH_MAX_CENTER_OFFSET_SEC = 1.0;
// pairKey → { lagSec, at } 첫 확정 대기 후보(lagSec는 pairKey 앞 hash를 A로 본 방향).
let collabFirstMatchCandidateByPair = {};
// Stage 2 재계산 주기(후보 쌍만, FFT는 워커 풀).
const COLLAB_WAVEFORM_REFRESH_MS = 700;
const COLLAB_WAVEFORM_SNIPPET_TIMEOUT_MS = 800;
// 이미 확인된 쌍 재확인용 짧은 창(초) — 전체 버퍼엔 옛 겹침이 남아 해제가 늦어진다. 첫 확정은 전체 창.
// 흔들림은 해제 게이지가 흡수한다.
const COLLAB_WAVEFORM_QUICK_VERIFY_WINDOW_SEC = 1.5;
// 이보다 오래된 Stage 2 점수는 신선하지 않음.
const COLLAB_WAVEFORM_MAX_AGE_MS = COLLAB_WAVEFORM_REFRESH_MS * 3;
// 최근 확인된 쌍은 Stage 2 워밍업 동안 이 유예만큼 겹침 상태를 유지한다(깜빡임 방지).
const COLLAB_WAVEFORM_CONFIRM_GRACE_MS = 8000;

// 캡처를 켜 둔 채널(Stage 1 후보 쌍에 속한 채널).
const collabCaptureHashes = new Set();
// pairKey → { score, lagSec, at, computeMs } 최근 Stage 2 결과(둘 다 filled일 때만).
let collabWaveformScoreByPair = {};
// pairKey → 마지막 "같은 소리" 확인 시각. "다른 소리"로 판정되면 즉시 지운다(유예는 재확인 전에만).
let collabPairLastConfirmedAt = {};
// pairKey → quick-verify 중 연속 저점수 횟수. 매치가 나오거나 트래킹에서 빠지면 지운다.
let waveformDivergeStreakByPairKey = {};
const collabWaveformRefreshInFlight = new Set();
// content.js가 unavailable로 답한 채널 — 이 채널만 Stage 1 단독으로 폴백한다("아직 준비 안 됨"과 구분).
const collabWaveformUnavailableHashes = new Set();

let collabSnippetRequestSeq = 0;
const pendingSnippetRequests = {};

function setChannelCapture(hash, enabled, windowSec, forceReset) {
  const wrapper = videoWrapperMap.get(hash);
  const iframe = wrapper && wrapper.querySelector('iframe');
  if (iframe && iframe.contentWindow) {
    iframe.contentWindow.postMessage({ type: 'SET_CHANNEL_CAPTURE', enabled, windowSec, forceReset }, '*');
  } else if (isCrossWindowCollabRelayActive() && !isCollabRelayWorkerWindow()) {
    window.CheeseProfileSync.send('collabSetCapture', { hash, enabled, windowSec, forceReset: !!forceReset });
  }
}

// 워클릿 파형 스니펫 요청. 워클릿 없는 채널은 즉시 samples:null. recentSec: 최근 N초만(생략 시 전체 창).
function reqAudioSnippet(hash, timeoutMs, recentSec) {
  return new Promise((resolve) => {
    const wrapper = videoWrapperMap.get(hash);
    const iframe = wrapper && wrapper.querySelector('iframe');
    if (!iframe || !iframe.contentWindow) {
      if (isCrossWindowCollabRelayActive() && !isCollabRelayWorkerWindow()) {
        // 다른 창 채널은 그 창이 받아 돌려준다(왕복만큼 더 기다림).
        const remoteRequestId = `rsnip-${++collabSnippetRequestSeq}`;
        const remoteTimer = setTimeout(() => {
          delete pendingSnippetRequests[remoteRequestId];
          resolve(null);
        }, timeoutMs + REMOTE_SNIPPET_EXTRA_TIMEOUT_MS);
        pendingSnippetRequests[remoteRequestId] = (data) => {
          clearTimeout(remoteTimer);
          resolve(data);
        };
        window.CheeseProfileSync.send('collabSnippetRequest', { requestId: remoteRequestId, hash, recentSec, timeoutMs });
        return;
      }
      resolve(null);
      return;
    }
    const requestId = `snip-${++collabSnippetRequestSeq}`;
    const timer = setTimeout(() => {
      delete pendingSnippetRequests[requestId];
      resolve(null);
    }, timeoutMs);
    pendingSnippetRequests[requestId] = (data) => {
      clearTimeout(timer);
      resolve(data);
    };
    iframe.contentWindow.postMessage({ type: 'REQUEST_AUDIO_SNIPPET', requestId, recentSec }, '*');
  });
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHANNEL_AUDIO_SNIPPET') return;
  const { requestId, samples, sampleRate, filled, unavailable } = event.data;
  const resolver = pendingSnippetRequests[requestId];
  if (!resolver) return;
  delete pendingSnippetRequests[requestId];
  // unavailable(영구 불가)와 이번만 실패를 구분해 넘긴다.
  resolver(samples ? { samples, sampleRate, filled } : { samples: null, unavailable: !!unavailable });
});

const REMOTE_SNIPPET_EXTRA_TIMEOUT_MS = 400;
const COLLAB_RELAY_MAINTENANCE_INTERVAL_MS = 3000;
let lastBroadcastCollabMutedKey = null;
let lastCollabRelayMaintenanceAt = 0;

// 대표 창: 음소거 결과를 다른 창에 보낸다(바뀌었을 때만, force면 항상).
function broadcastCollabMutedIfChanged(force) {
  if (!isCrossWindowCollabRelayActive() || isCollabRelayWorkerWindow()) return;
  const hashes = Array.from(collabMutedHashes).sort();
  const key = `${hashes.join(',')}#${collabLiveClustersSignature}`;
  if (!force && key === lastBroadcastCollabMutedKey) return;
  lastBroadcastCollabMutedKey = key;
  window.CheeseProfileSync.send('collabMuted', { hashes, clusters: collabLiveClusters });
}

// 다른 창 iframe이 새로 만들어지면 캡처가 꺼지므로 주기적으로 캡처와 음소거 결과를 다시 보낸다.
function maintainCrossWindowCollabRelay() {
  if (!isCrossWindowCollabRelayActive() || isCollabRelayWorkerWindow()) return;
  const now = Date.now();
  if (now - lastCollabRelayMaintenanceAt < COLLAB_RELAY_MAINTENANCE_INTERVAL_MS) return;
  lastCollabRelayMaintenanceAt = now;
  collabCaptureHashes.forEach((hash) => {
    setChannelCapture(hash, true, collabCaptureWindowSecByHash[hash]);
  });
  broadcastCollabMutedIfChanged(true);
}

if (window.CheeseProfileSync) {
  window.CheeseProfileSync.on('channelVolumes', (p) => {
    if (!p || !p.volumes || !extendedMainSubActive) return;
    let changed = false;
    Object.entries(p.volumes).forEach(([hash, vol]) => {
      if (typeof vol !== 'number' || hasLocalChannelIframe(hash)) return;
      if (lastAppliedDisplayVolume[hash] !== vol) {
        lastAppliedDisplayVolume[hash] = vol;
        changed = true;
      }
    });
    if (changed) refreshAudioSettingsListIfSafe();
  });

  window.CheeseProfileSync.on('collabLevel', (p) => {
    if (!p || isCollabRelayWorkerWindow() || !isCollabSettingEnabled()) return;
    if (hasLocalChannelIframe(p.hash)) return; // 이 창이 직접 받는 채널
    if (typeof p.db !== 'number' || !isFinite(p.db)) return;
    pushChannelAudioLevelHistory(p.hash, p.db, typeof p.t === 'number' ? p.t : Date.now());
    if (audioLevelApplyTimer) return;
    audioLevelApplyTimer = setTimeout(() => {
      audioLevelApplyTimer = null;
      if (isCollabSettingEnabled()) recomputeCollabMuting();
      applyVolumeToAllChannels(true);
      refreshAudioSettingsListIfSafe();
    }, AUDIO_LEVEL_APPLY_DEBOUNCE_MS);
  });
  window.CheeseProfileSync.on('collabLatency', (p) => {
    if (!p || isCollabRelayWorkerWindow() || hasLocalChannelIframe(p.hash)) return;
    if (typeof p.latencySec === 'number' && isFinite(p.latencySec)) channelLatencySecByHash[p.hash] = p.latencySec;
  });
  window.CheeseProfileSync.on('collabSnippetResponse', (p) => {
    if (!p || isCollabRelayWorkerWindow()) return;
    const resolver = pendingSnippetRequests[p.requestId];
    if (!resolver) return;
    delete pendingSnippetRequests[p.requestId];
    resolver(p.data || null);
  });
  // 판정 안 하는 창: 캡처/스니펫 요청을 자기 iframe에 중계하고 판정 결과를 적용한다.
  window.CheeseProfileSync.on('collabSetCapture', (p) => {
    if (!p || !isCollabRelayWorkerWindow() || !hasLocalChannelIframe(p.hash)) return;
    setChannelCapture(p.hash, p.enabled, p.windowSec, p.forceReset);
  });
  window.CheeseProfileSync.on('collabSnippetRequest', (p) => {
    if (!p || !isCollabRelayWorkerWindow() || !hasLocalChannelIframe(p.hash)) return;
    reqAudioSnippet(p.hash, p.timeoutMs || COLLAB_WAVEFORM_SNIPPET_TIMEOUT_MS, p.recentSec).then((data) => {
      window.CheeseProfileSync.send('collabSnippetResponse', { requestId: p.requestId, data });
    });
  });
  window.CheeseProfileSync.on('collabSplitRequest', (p) => {
    if (!p || isCollabRelayWorkerWindow()) return;
    if (typeof p.hash === 'string') splitCollabChannel(p.hash);
    else if (Array.isArray(p.members)) splitCollabMembers(p.members);
  });
  window.CheeseProfileSync.on('collabMuted', (p) => {
    if (!p || !isCollabRelayWorkerWindow() || !Array.isArray(p.hashes)) return;
    if (Array.isArray(p.clusters)) applyCollabLiveClusters(p.clusters);
    const same = p.hashes.length === collabMutedHashes.size && p.hashes.every((h) => collabMutedHashes.has(h));
    if (same) return;
    collabMutedHashes = new Set(p.hashes);
    applyVolumeToAllChannels(true);
    updateChatTabCollabIcons();
  });
}

// VOD 싱크 오프셋 — 오디오 분석 대신 치지직 VOD 상세 API의 liveOpenDate로 계산한다
// (VOD Master calculateVodStartTime 이식, docs/vod-collab-sync-architecture.md §8).

// 긴 방송은 VOD가 여러 조각으로 나뉜다 — livePv가 같은 인접 조각 길이가 17시간에 가까우면 그만큼 더해 보정한다.
function calcChzzkVodStartTime(vodDetail) {
  if (!vodDetail || !vodDetail.liveOpenDate) return null;
  const liveOpenDate = new Date(String(vodDetail.liveOpenDate).replace(' ', 'T'));
  if (isNaN(liveOpenDate.getTime())) return null;

  const curLivePv = vodDetail.livePv;
  const prevLivePv = vodDetail.prevVideo?.livePv;
  const nextLivePv = vodDetail.nextVideo?.livePv;
  const prevDuration = vodDetail.prevVideo?.duration;
  const nextDuration = vodDetail.nextVideo?.duration;
  const CHZZK_VOD_MAX_DURATION_SEC = 61200; // 17시간
  const prevIsNearMaxDuration = typeof prevDuration === 'number' && Math.abs(prevDuration - CHZZK_VOD_MAX_DURATION_SEC) <= 1;
  const nextIsNearMaxDuration = typeof nextDuration === 'number' && Math.abs(nextDuration - CHZZK_VOD_MAX_DURATION_SEC) <= 1;
  const isPrevLivePvSame = !!prevLivePv && curLivePv === prevLivePv;
  const isNextLivePvSame = !!nextLivePv && curLivePv === nextLivePv;

  if (isPrevLivePvSame && isNextLivePvSame) {
    // 세 조각 livePv가 같으면 중간 조각일 수 있어 앞뒤 각각 확인한다.
    let startDate = liveOpenDate;
    if (prevIsNearMaxDuration) startDate = new Date(startDate.getTime() + prevDuration * 1000);
    if (nextIsNearMaxDuration) startDate = new Date(startDate.getTime() + nextDuration * 1000);
    return startDate;
  }
  if (isPrevLivePvSame) {
    return prevIsNearMaxDuration ? new Date(liveOpenDate.getTime() + prevDuration * 1000) : liveOpenDate;
  }
  if (isNextLivePvSame) {
    return nextIsNearMaxDuration ? new Date(liveOpenDate.getTime() + nextDuration * 1000) : liveOpenDate;
  }
  return liveOpenDate;
}

// 채널별 실제 방송 시작 시각 캐시(audioState.vodStartTimeMsByHash, 저장됨). 오프셋은 두 값의 차라 대표가 바뀌어도 재계산 불필요.

// 시작 시각을 캐시에서 찾고 없으면 플랫폼 어댑터로 계산한다(숲 등 미지원이면 null). 새로 채웠으면 호출부가 저장한다.
async function ensureVodStartTimeCached(hash) {
  if (typeof audioState.vodStartTimeMsByHash[hash] === 'number') return audioState.vodStartTimeMsByHash[hash];
  const ch = displayChannels.find((c) => c.hash === hash);
  if (!ch || !ch.isVod) return null;
  const adapter = PlatformAdapters[ch.platform];
  if (!adapter || typeof adapter.getVodStartTime !== 'function') return null;
  const startMs = await adapter.getVodStartTime(ch);
  if (startMs === null || typeof startMs !== 'number' || isNaN(startMs)) return null;
  audioState.vodStartTimeMsByHash[hash] = startMs;
  return audioState.vodStartTimeMsByHash[hash];
}

// 두 VOD 시작 시각 차로 오프셋(초)을 구한다. 부호는 expectedSec = repTime + offsetSec 기준 — 바꿀 땐 그 식으로 검증할 것.
async function computeVodMetadataOffsetSec(representativeHash, memberHash) {
  const [repStartMs, memberStartMs] = await Promise.all([
    ensureVodStartTimeCached(representativeHash),
    ensureVodStartTimeCached(memberHash)
  ]);
  if (repStartMs === null) return { ok: false, error: '대표 VOD의 방송 시작 시각을 가져오지 못함(liveOpenDate/liveBroadcastDetails 없음, 지원하지 않는 플랫폼 등)' };
  if (memberStartMs === null) return { ok: false, error: '멤버 VOD의 방송 시작 시각을 가져오지 못함(liveOpenDate/liveBroadcastDetails 없음, 지원하지 않는 플랫폼 등)' };

  const offsetSec = (repStartMs - memberStartMs) / 1000;
  return { ok: true, offsetSec };
}

// GCC-PHAT은 워커 풀에서 돌린다(메인 스레드 보호). 한 틱의 쌍을 한꺼번에 넘기므로 워커 수 = 한 틱 처리량,
// 코어가 넉넉하면 최대 4개.
const GCC_PHAT_WORKER_POOL_SIZE = Math.max(2, Math.min(4, Math.floor((navigator.hardwareConcurrency || 4) / 4)));
let gccPhatWorkers = [];
let gccPhatWorkerBusyCount = [];
let gccPhatWorkerRequestSeq = 0;
const gccPhatWorkerPending = {};

function createGccPhatWorker(idx) {
  let worker;
  try {
    worker = new Worker(chrome.runtime.getURL('src/js/audio/gcc-phat-worker.js'));
  } catch (err) {
    return null;
  }
  worker.onmessage = (event) => {
    const { requestId, result } = event.data || {};
    const pending = gccPhatWorkerPending[requestId];
    if (pending) {
      delete gccPhatWorkerPending[requestId];
      pending.resolve(result);
    }
    gccPhatWorkerBusyCount[idx] = Math.max(0, gccPhatWorkerBusyCount[idx] - 1);
  };
  // 워커가 죽으면 걸려 있던 요청을 null로 풀어 준다 — 안 풀면 Stage 2가 영구히 "확인 중"에 멈췄다.
  worker.onerror = () => {
    gccPhatWorkers[idx] = null; // 이 워커만 폐기 — 나머지 풀은 계속 쓴다.
    Object.keys(gccPhatWorkerPending).forEach((requestId) => {
      const pending = gccPhatWorkerPending[requestId];
      if (pending.idx !== idx) return;
      delete gccPhatWorkerPending[requestId];
      pending.resolve(null);
    });
    gccPhatWorkerBusyCount[idx] = 0;
  };
  return worker;
}

if (typeof Worker !== 'undefined' && typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
  for (let i = 0; i < GCC_PHAT_WORKER_POOL_SIZE; i++) {
    gccPhatWorkers.push(createGccPhatWorker(i));
    gccPhatWorkerBusyCount.push(0);
  }
}

// 대기 요청이 가장 적은 살아 있는 워커. 없으면 -1(메인 스레드 폴백).
function pickLeastBusyGccPhatWorkerIndex() {
  let bestIdx = -1;
  let bestCount = Infinity;
  for (let i = 0; i < gccPhatWorkers.length; i++) {
    if (!gccPhatWorkers[i]) continue;
    if (gccPhatWorkerBusyCount[i] < bestCount) {
      bestCount = gccPhatWorkerBusyCount[i];
      bestIdx = i;
    }
  }
  return bestIdx;
}

// 조용히 멈춘 워커 대비 타임아웃.
const GCC_PHAT_WORKER_TIMEOUT_MS = 5000;

// timeoutMs: 큰 버퍼 계산은 호출부가 더 길게 준다(전역 기본값은 빠른 재시도를 위해 짧게 유지).
function computeGccPhatAsync(bufA, rateA, bufB, rateB, maxLagSec, centerLagSec, timeoutMs) {
  const effectiveTimeoutMs = timeoutMs || GCC_PHAT_WORKER_TIMEOUT_MS;
  const idx = pickLeastBusyGccPhatWorkerIndex();
  if (idx === -1) {
    if (typeof computeGccPhat !== 'function') return Promise.resolve(null);
    return Promise.resolve(computeGccPhat(bufA, rateA, bufB, rateB, maxLagSec, undefined, centerLagSec));
  }
  return new Promise((resolve) => {
    const requestId = ++gccPhatWorkerRequestSeq;
    const timer = setTimeout(() => {
      if (!gccPhatWorkerPending[requestId]) return;
      delete gccPhatWorkerPending[requestId];
      resolve(null);
    }, effectiveTimeoutMs);
    gccPhatWorkerPending[requestId] = {
      idx,
      resolve: (result) => { clearTimeout(timer); resolve(result); }
    };
    gccPhatWorkerBusyCount[idx]++;
    gccPhatWorkers[idx].postMessage({ requestId, bufA, rateA, bufB, rateB, maxLagSec, centerLagSec });
  });
}

// ── Stage 2 보조: AI 음성 감지(VAD) ── 말하는 구간만 남겨 상관을 구하면 배경음 상관이 줄어든다(docs/collab-architecture.md §10).
// 모델+런타임이 커서 "AI 음성 감지 사용"을 켰을 때만 워커에서 비동기 로딩하고, 로딩 중엔 마스킹 없이 진행한다.
let vadState = 'idle'; // 'idle' | 'loading' | 'ready' | 'unavailable'
let vadWorker = null;
let vadInitPromise = null;
let vadRequestSeq = 0;
const vadPending = {};
const VAD_SPEECH_THRESHOLD = 0.5;
// 말하는 구간이 이보다 짧으면 이번 주기 판정을 건너뛴다.
const VAD_MIN_ACTIVE_RATIO = 0.15;
// hash → 마지막 VAD 결과(디버그 그래프 전용).
let collabVadDebugByHash = {};

function updateVadStatusUI() {
  const statusEl = document.getElementById('collab-vad-status');
  if (!statusEl) return;
  if (vadState === 'loading') {
    statusEl.textContent = t('settings.collabVadStatusLoading', 'AI 음성 감지 모델을 불러오는 중입니다... (최초 1회, 최대 몇십 초)');
    statusEl.className = 'yt-settings-hint collab-vad-status loading';
  } else if (vadState === 'ready') {
    let model;
    if (vadActiveModel === 'pyannote') model = t('settings.collabVadModelPrecise', '정밀 (pyannote)');
    else if (vadModelFallbackReason) model = t('settings.collabVadModelFallback', '정밀 모델을 쓸 수 없어 기본으로 대체 — {reason}', { reason: vadModelFallbackReason });
    else model = t('settings.collabVadModelBasic', '기본 (Silero)');
    statusEl.textContent = `${t('settings.collabVadStatusReady', 'AI 음성 감지 사용 중')} (${model})`;
    statusEl.className = 'yt-settings-hint collab-vad-status ready';
  } else if (vadState === 'unavailable') {
    statusEl.textContent = t('settings.collabVadStatusUnavailable', 'AI 음성 감지를 사용할 수 없어 이전 방식으로 대체합니다.');
    statusEl.className = 'yt-settings-hint collab-vad-status unavailable';
  } else {
    statusEl.textContent = '';
    statusEl.className = 'yt-settings-hint collab-vad-status';
  }
}

// 여러 번 불러도 안전(로딩 중/완료 재사용). 판정하는 창(대표)에서만 로딩한다.
function isCollabVadNeededInThisWindow() {
  return isCollabVadEnabled() && !(isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive());
}

// AI 음성 감지 모델 — 기본 Silero, 정밀 pyannote(실패 시 기본으로 대체). 둘 다 WASM.
const VAD_WORKERS = {
  pyannote: { script: 'src/js/audio/ort/vad-pyannote-worker.js', model: 'src/js/audio/pyannote_segmentation.onnx' },
  silero: { script: 'src/js/audio/ort/vad-worker.js', model: 'src/js/audio/silero_vad.onnx' }
};
let vadRequestedModel = null; // 워커를 띄울 때 설정에서 고른 모델
let vadActiveModel = null; // 지금 워커가 쓰는 모델('pyannote' | 'silero')
let vadModelFallbackReason = ''; // 정밀을 골랐지만 기본으로 대체한 이유

function getCollabVadModelSetting() {
  return mySetting.collabVadModel === 'pyannote' ? 'pyannote' : 'silero';
}

// 모델 교체 — 워커를 내리고 대기 중 추론은 결과 없음으로 끝낸다.
function resetVadWorker() {
  if (vadWorker) vadWorker.terminate();
  vadWorker = null;
  vadInitPromise = null;
  vadRequestedModel = null;
  vadActiveModel = null;
  vadModelFallbackReason = '';
  vadState = 'idle';
  Object.keys(vadPending).forEach((id) => {
    const resolve = vadPending[id];
    delete vadPending[id];
    resolve(null);
  });
  updateVadStatusUI();
}

function startVadWorker(model) {
  let worker;
  try {
    worker = new Worker(chrome.runtime.getURL(VAD_WORKERS[model].script));
  } catch (err) {
    return Promise.resolve({ ok: false, error: String(err && err.message || err) });
  }
  vadWorker = worker;
  vadActiveModel = model;
  worker.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.type !== 'infer-result') return;
    const resolve = vadPending[data.requestId];
    if (!resolve) return;
    delete vadPending[data.requestId];
    resolve(data.error ? null : data);
  });
  return new Promise((resolve) => {
    worker.addEventListener('error', (e) => resolve({ ok: false, error: (e && e.message) || 'worker error' }), { once: true });
    worker.addEventListener('message', function onInit(event) {
      const data = event.data || {};
      if (data.type !== 'init-result') return;
      worker.removeEventListener('message', onInit);
      resolve(data);
    });
    worker.postMessage({
      cmd: 'init',
      modelUrl: chrome.runtime.getURL(VAD_WORKERS[model].model),
      wasmBaseUrl: chrome.runtime.getURL('src/js/audio/ort/')
    });
  });
}

function ensureVadWorker() {
  if (vadWorker) return vadInitPromise;
  if (typeof Worker === 'undefined' || typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.getURL) {
    vadState = 'unavailable';
    updateVadStatusUI();
    return Promise.resolve(false);
  }
  vadState = 'loading';
  updateVadStatusUI();
  const wanted = getCollabVadModelSetting();
  vadRequestedModel = wanted;
  const initPromise = (async () => {
    let result = await startVadWorker(wanted);
    if (!result.ok && wanted === 'pyannote' && vadInitPromise === initPromise) {
      console.warn('[CHEESE EYES][AI 음성 감지] 정밀 모델을 쓸 수 없어 기본으로 대체:', result.error);
      if (vadWorker) vadWorker.terminate();
      vadModelFallbackReason = result.error || 'unknown';
      result = await startVadWorker('silero');
    }
    if (vadInitPromise !== initPromise) return false; // 기다리는 사이 모델을 바꿨다
    vadState = result.ok ? 'ready' : 'unavailable';
    updateVadStatusUI();
    return !!result.ok;
  })();
  vadInitPromise = initPromise;
  return vadInitPromise;
}

function reqVadInference(samples, sampleRate) {
  if (!vadWorker || vadState !== 'ready') return Promise.resolve(null);
  return new Promise((resolve) => {
    const requestId = ++vadRequestSeq;
    vadPending[requestId] = resolve;
    vadWorker.postMessage({ cmd: 'infer', requestId, samples, sampleRate });
  });
}

// VAD 프레임 확률을 대상 버퍼 길이/레이트의 0/1 마스크로 확장한다(iframe마다 레이트가 달라 시간 기준으로 매핑).
function buildVadMask(vadResult, targetRate, targetLength) {
  const mask = new Float32Array(targetLength);
  const frameDurationSec = vadResult.frameSamplesAtOutputRate / vadResult.outputSampleRate;
  const lastFrameIdx = vadResult.probs.length - 1;
  for (let i = 0; i < targetLength; i++) {
    const tSec = i / targetRate;
    let frameIdx = Math.floor(tSec / frameDurationSec);
    if (frameIdx < 0) frameIdx = 0;
    if (frameIdx > lastFrameIdx) frameIdx = lastFrameIdx;
    mask[i] = vadResult.probs[frameIdx] >= VAD_SPEECH_THRESHOLD ? 1 : 0;
  }
  return mask;
}

function applyMask(samples, mask) {
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i++) out[i] = samples[i] * mask[i];
  return out;
}

function maskActiveRatio(mask) {
  let active = 0;
  for (let i = 0; i < mask.length; i++) active += mask[i];
  return mask.length > 0 ? active / mask.length : 0;
}

// 한 틱 안에서 여러 쌍에 속한 채널의 스니펫/VAD를 재사용하는 캐시(틱마다 비움).
let collabSnippetCycleCache = {};
let collabVadResultCycleCache = {};

// recentSec은 이번 틱에 미리 정한 값(여러 쌍 중 하나라도 전체 창이 필요하면 전체).
function getOrReqSnippetForCycle(hash, recentSec) {
  if (!collabSnippetCycleCache[hash]) {
    collabSnippetCycleCache[hash] = reqAudioSnippet(hash, COLLAB_WAVEFORM_SNIPPET_TIMEOUT_MS, recentSec);
  }
  return collabSnippetCycleCache[hash];
}

function getOrComputeVadResultForCycle(hash, snip) {
  if (!collabVadResultCycleCache[hash]) {
    collabVadResultCycleCache[hash] = reqVadInference(snip.samples, snip.sampleRate);
  }
  return collabVadResultCycleCache[hash];
}

// 두 VAD 중 하나라도 말하는 구간이면 1인 합집합 마스크(크로스토크는 양방향).
function buildUnionVadMask(vadResultA, vadResultB, targetRate, targetLength) {
  const maskA = buildVadMask(vadResultA, targetRate, targetLength);
  const maskB = buildVadMask(vadResultB, targetRate, targetLength);
  const out = new Float32Array(targetLength);
  for (let i = 0; i < targetLength; i++) out[i] = (maskA[i] || maskB[i]) ? 1 : 0;
  return out;
}

// 양쪽 VAD 합집합 마스크를 적용한 버퍼 쌍. VAD 실패면 null(원본 비교), 활성 비율이 낮으면 'insufficient'.
async function getVadMaskedSnippets(hashA, snipA, hashB, snipB) {
  const [vadResultA, vadResultB] = await Promise.all([
    getOrComputeVadResultForCycle(hashA, snipA),
    getOrComputeVadResultForCycle(hashB, snipB)
  ]);
  if (!vadResultA || !vadResultB) return null;

  const ownMaskA = buildVadMask(vadResultA, snipA.sampleRate, snipA.samples.length);
  const ownMaskB = buildVadMask(vadResultB, snipB.sampleRate, snipB.samples.length);
  collabVadDebugByHash[hashA] = {
    probs: vadResultA.probs,
    frameSamplesAtOutputRate: vadResultA.frameSamplesAtOutputRate,
    outputSampleRate: vadResultA.outputSampleRate,
    activeRatio: maskActiveRatio(ownMaskA),
    at: Date.now(),
  };
  collabVadDebugByHash[hashB] = {
    probs: vadResultB.probs,
    frameSamplesAtOutputRate: vadResultB.frameSamplesAtOutputRate,
    outputSampleRate: vadResultB.outputSampleRate,
    activeRatio: maskActiveRatio(ownMaskB),
    at: Date.now(),
  };

  const maskForA = buildUnionVadMask(vadResultA, vadResultB, snipA.sampleRate, snipA.samples.length);
  const maskForB = buildUnionVadMask(vadResultA, vadResultB, snipB.sampleRate, snipB.samples.length);
  const activeRatio = Math.max(maskActiveRatio(maskForA), maskActiveRatio(maskForB));
  if (activeRatio < VAD_MIN_ACTIVE_RATIO) return 'insufficient';
  return {
    samplesA: applyMask(snipA.samples, maskForA),
    samplesB: applyMask(snipB.samples, maskForB),
  };
}

// GCC-PHAT 탐색 중심 — Stage1 추정과 부호가 반대다(합치지 말 것).
// 최근 전체 창 확정 피크 lag가 충분하면 그 중앙값, 아니면 레이턴시 추정으로 폴백한다(quick-verify lag는 불안정해 기록 안 함).
const MEASURED_GCC_LAG_MAX_SAMPLES = 7;
const MEASURED_GCC_LAG_MIN_SAMPLES = 3;
const MEASURED_GCC_LAG_MAX_AGE_MS = 30000;
// pairKey → [{ lagSec, at }] (pairKey 앞 hash를 A로 본 방향).
let collabMeasuredGccLagByPair = {};

function recordMeasuredGccLag(hashA, hashB, lagSec) {
  const key = pairKey(hashA, hashB);
  const oriented = hashA < hashB ? lagSec : -lagSec;
  const list = collabMeasuredGccLagByPair[key] || (collabMeasuredGccLagByPair[key] = []);
  list.push({ lagSec: oriented, at: Date.now() });
  if (list.length > MEASURED_GCC_LAG_MAX_SAMPLES) list.splice(0, list.length - MEASURED_GCC_LAG_MAX_SAMPLES);
}

function getMeasuredGccLagSec(hashA, hashB) {
  const list = collabMeasuredGccLagByPair[pairKey(hashA, hashB)];
  if (!list) return null;
  const now = Date.now();
  const recent = list.filter((e) => now - e.at <= MEASURED_GCC_LAG_MAX_AGE_MS).map((e) => e.lagSec).sort((x, y) => x - y);
  if (recent.length < MEASURED_GCC_LAG_MIN_SAMPLES) return null;
  const mid = Math.floor(recent.length / 2);
  const median = recent.length % 2 ? recent[mid] : (recent[mid - 1] + recent[mid]) / 2;
  return hashA < hashB ? median : -median;
}

function getEstimatedGccCenterLagSec(hashA, hashB) {
  const measured = getMeasuredGccLagSec(hashA, hashB);
  if (measured !== null) return measured;
  const latA = channelLatencySecByHash[hashA];
  const latB = channelLatencySecByHash[hashB];
  if (typeof latA !== 'number' || typeof latB !== 'number' || !isFinite(latA) || !isFinite(latB)) return 0;
  return latA - latB;
}

// VOD 싱크 — 메타데이터 오프셋 잔차를 Stage 2 결과로 깎아낸다.
// 부호: offsetSec_true = offsetSec_current - lagSec (hashA=대표, hashB=멤버). 순서가 반대면 부호도 반대.
const VOD_SYNC_OFFSET_REFINE_DEADBAND_SEC = 0.3;

// 쌍이 vod-sync 대표-멤버면 역할과 부호(sign)를, 아니면 null.
function getVodSyncRepMemberPair(hashA, hashB) {
  const group = findCollabGroupForChannel(hashA);
  if (!group || !isVodSyncGroup(group)) return null;
  const representativeHash = getCollabLeaderHash(group);
  if (!representativeHash) return null;
  if (hashA === representativeHash && hashB !== representativeHash) {
    return { group, representativeHash, memberHash: hashB, sign: -1 };
  }
  if (hashB === representativeHash && hashA !== representativeHash) {
    return { group, representativeHash, memberHash: hashA, sign: 1 };
  }
  return null;
}

// 오프셋 보정 안전장치 — 보정 → 시크 → 섞인 버퍼 → 오탐 보정의 폭주 루프가 있었다.
// (1) 보정 직후 멤버 캡처를 리셋하고, (2) 단일 고점수 대신 최근 여러 틱의 잔차가 서로 일치할 때만 적용한다.
const VOD_SYNC_OFFSET_REFINE_MIN_SCORE = COLLAB_WAVEFORM_MATCH_THRESHOLD;
const VOD_SYNC_OFFSET_REFINE_MIN_CONFIRMATIONS = 3;
// 최근 확인끼리 이 이내로 일치해야 진짜 신호로 본다.
const VOD_SYNC_OFFSET_REFINE_AGREEMENT_SEC = 0.5;
// 확인 기록 유효 기간.
const VOD_SYNC_OFFSET_REFINE_HISTORY_MAX_AGE_MS = 10000;

// memberHash → 음소거 판정이 유지되는 동안 관측된 잔차 기록.
const vodSyncRefineHistoryByMemberHash = {};
// 파형 미세 정렬은 멤버를 넣은 뒤 한 번만 한다 — 계속 보정하면 시크·캡처 리셋이 반복돼 음소거가 늦게 잠겼다.
const vodSyncFineAlignedHashes = new Set();

// 멤버를 대표 위치에 맞게 바로 옮기고 캡처를 비운다. 옮겼으면 true.
function alignVodSyncMemberNow(group, memberHash, offsetSec) {
  const repNow = getExtrapolatedPlaybackSec(getCollabLeaderHash(group));
  if (offsetSec === null || repNow === null) return false;
  const expectedSec = repNow + offsetSec;
  if (!isVodSyncExpectedSecInWindow(expectedSec, channelDurationSecByHash[memberHash])) return false;
  vodSyncLastSeekAt[memberHash] = Date.now();
  seekChannelToTime(memberHash, expectedSec);
  setChannelCapture(memberHash, true, VOD_SYNC_CAPTURE_WINDOW_SEC, true);
  delete vodSyncRefineHistoryByMemberHash[memberHash];
  return true;
}

function maybeRefineVodSyncOffsetFromLag(hashA, hashB, lagSec, score) {
  const pair = getVodSyncRepMemberPair(hashA, hashB);
  if (!pair) return;
  const { group, representativeHash, memberHash, sign } = pair;
  if (vodSyncFineAlignedHashes.has(memberHash)) return;

  if (typeof score !== 'number' || score < VOD_SYNC_OFFSET_REFINE_MIN_SCORE) {
    // 낮은 점수는 기존 기록을 지우지 않고 무시만 한다 — 지우면 노이즈 때문에 확인이 영영 안 쌓였다. 오래된 값은 시간 트리밍이 거른다.
    return;
  }
  const residualErrorSec = sign * lagSec;

  const repStartMs = audioState.vodStartTimeMsByHash[representativeHash];
  if (typeof repStartMs !== 'number') return; // 대표 쪽 앵커가 없으면(비치지직 등) 보정 불가
  const currentOffset = getVodSyncOffsetSec(group, memberHash);
  if (currentOffset === null) return; // 메타데이터 오프셋 자체가 아직 없음

  const now = Date.now();
  const history = (vodSyncRefineHistoryByMemberHash[memberHash] || [])
    .filter((entry) => now - entry.at < VOD_SYNC_OFFSET_REFINE_HISTORY_MAX_AGE_MS);
  history.push({ residualErrorSec, at: now });
  vodSyncRefineHistoryByMemberHash[memberHash] = history;

  if (history.length < VOD_SYNC_OFFSET_REFINE_MIN_CONFIRMATIONS) return; // 아직 "유지"라 부를 만큼 안 쌓임

  const recent = history.slice(-VOD_SYNC_OFFSET_REFINE_MIN_CONFIRMATIONS);
  const values = recent.map((e) => e.residualErrorSec);
  const spread = Math.max(...values) - Math.min(...values);
  if (spread > VOD_SYNC_OFFSET_REFINE_AGREEMENT_SEC) return; // 최근 확인들끼리 안 맞음 — 아직 믿지 않고 계속 관찰

  const sorted = [...values].sort((a, b) => a - b);
  const medianResidualSec = sorted[Math.floor(sorted.length / 2)];
  if (Math.abs(medianResidualSec) < VOD_SYNC_OFFSET_REFINE_DEADBAND_SEC) {
    delete vodSyncRefineHistoryByMemberHash[memberHash]; // 이미 충분히 정확함
    vodSyncFineAlignedHashes.add(memberHash);
    return;
  }

  // 잔차는 실제 위치 기준으로 잰 값이라 현재 실제 위치 차이에 더해 새 오프셋을 구한다(누적 오차 방지).
  const repNow = getExtrapolatedPlaybackSec(representativeHash);
  const memberNow = getExtrapolatedPlaybackSec(memberHash);
  if (repNow === null || memberNow === null) return;
  const nextOffset = (memberNow - repNow) + medianResidualSec;

  // 멤버 앵커만 밀어 보정한다(대표 앵커 고정). 전역 앵커 캐시에 반영해야 대표가 바뀌어도 유효하다.
  audioState.vodStartTimeMsByHash[memberHash] = repStartMs - nextOffset * 1000;
  saveAudioState();
  vodSyncFineAlignedHashes.add(memberHash);
  logCollabEvent('vodAlign', { m: memberHash, r: Math.round(medianResidualSec * 100) / 100 });

  // 새 오프셋 자리로 바로 옮기고 캡처를 비운다(작은 잔차는 드리프트 보정이 안 옮기므로).
  alignVodSyncMemberNow(group, memberHash, nextOffset);
}

// samples의 마지막 seconds초만 자른다.
function takeMostRecentSamples(samples, sampleRate, seconds) {
  const n = Math.round(sampleRate * seconds);
  if (!samples || samples.length <= n) return samples;
  return samples.subarray(samples.length - n);
}

// 이번 틱에 필요한 창 길이 — undefined = 전체, 숫자 = 꼬리 구간. 최근에 "같은 소리"로 확인된 쌍만 짧은 꼬리를 쓴다.
function getRequiredRecentSecForPair(hashA, hashB) {
  const prevScore = collabWaveformScoreByPair[pairKey(hashA, hashB)];
  // 첫 확정 대기 후보의 두 번째 확인은 전체 창으로.
  const wasConfirmedMatch = prevScore &&
    typeof collabPairLastConfirmedAt[pairKey(hashA, hashB)] === 'number' &&
    (Date.now() - prevScore.at) <= COLLAB_WAVEFORM_MAX_AGE_MS &&
    prevScore.score >= getWaveformMatchThresholdForPair(hashA, hashB);
  if (!wasConfirmedMatch) return undefined;
  return getVodSyncRepMemberPair(hashA, hashB)
    ? VOD_SYNC_WAVEFORM_QUICK_VERIFY_WINDOW_SEC
    : COLLAB_WAVEFORM_QUICK_VERIFY_WINDOW_SEC;
}

// 쌍 하나의 파형 상관을 계산해 캐시한다. 스니펫 결과: null(재시도) | unavailable | { samples, sampleRate, filled }.
async function refreshWaveformScoreForPair(hashA, hashB, recentSecA, recentSecB) {
  const [snipA, snipB] = await Promise.all([
    getOrReqSnippetForCycle(hashA, recentSecA),
    getOrReqSnippetForCycle(hashB, recentSecB)
  ]);
  if (snipA && snipA.unavailable) collabWaveformUnavailableHashes.add(hashA);
  if (snipB && snipB.unavailable) collabWaveformUnavailableHashes.add(hashB);
  // 실제 샘플이 왔으면 unavailable 등록을 즉시 해제한다(오등록 자기치유).
  if (snipA && snipA.samples && !snipA.unavailable) collabWaveformUnavailableHashes.delete(hashA);
  if (snipB && snipB.samples && !snipB.unavailable) collabWaveformUnavailableHashes.delete(hashB);
  if (!snipA || !snipB || !snipA.samples || !snipB.samples) return;
  // 전체 캡처 창이 아직 안 찼으면 다음 주기에 다시 시도한다.
  if (!snipA.filled || !snipB.filled) return;

  // vod-sync 대표-멤버 첫 확정은 더 넓은 범위로 찾고, 재확인은 좁게. 라이브는 재확인에도 범위를 안 좁힌다.
  const isVodSyncPair = !!getVodSyncRepMemberPair(hashA, hashB);
  const requiredRecentSec = getRequiredRecentSecForPair(hashA, hashB);
  const usingQuickVerify = requiredRecentSec !== undefined;
  const maxLagSec = isVodSyncPair
    ? (usingQuickVerify ? VOD_SYNC_WAVEFORM_QUICK_VERIFY_MAX_LAG_SEC : VOD_SYNC_WAVEFORM_MAX_LAG_SEC)
    : COLLAB_WAVEFORM_MAX_LAG_SEC;
  const centerLagSec = isVodSyncPair ? 0 : getEstimatedGccCenterLagSec(hashA, hashB);

  // VAD가 준비돼 있으면 말하는 구간만 남긴 버퍼로 계산(null이면 원본, 'insufficient'면 건너뜀).
  let bufA = snipA.samples;
  let bufB = snipB.samples;
  if (isCollabVadEnabled()) {
    const masked = await getVadMaskedSnippets(hashA, snipA, hashB, snipB);
    if (masked === 'insufficient') return;
    if (masked) {
      bufA = masked.samplesA;
      bufB = masked.samplesB;
    }
  }

  // 이 쌍에 필요한 꼬리 길이로 다시 자른다.
  if (requiredRecentSec !== undefined) {
    bufA = takeMostRecentSamples(bufA, snipA.sampleRate, requiredRecentSec);
    bufB = takeMostRecentSamples(bufB, snipB.sampleRate, requiredRecentSec);
  }

  // computeMs는 워커 왕복 포함 시간(디버그용).
  const computeStart = performance.now();
  const result = await computeGccPhatAsync(
    bufA, snipA.sampleRate,
    bufB, snipB.sampleRate,
    maxLagSec,
    centerLagSec
  );
  const computeMs = performance.now() - computeStart;
  if (!result) return;
  const key = pairKey(hashA, hashB);
  // quick: 짧은 창으로 계산됐는지(디버그 기록용).
  collabWaveformScoreByPair[key] = { score: result.score, lagSec: result.lagSec, at: Date.now(), computeMs, quick: usingQuickVerify };
  // "같은 소리" 문턱 — 이력 갱신 전에 구해야 첫 확정 문턱이 적용된다.
  const matchThreshold = getWaveformMatchThresholdForPair(hashA, hashB);
  let isMatch = result.score >= matchThreshold;
  // 확인 이력 없는 라이브 쌍은 직전 점수도 넘었고 피크 lag가 거의 같을 때만 확정한다.
  if (!isVodSyncPair && typeof collabPairLastConfirmedAt[key] !== 'number') {
    // 탐색 중심에서 먼 피크는 후보로 안 친다(centerLagSec와 lagSec는 같은 방향).
    if (isMatch && Math.abs(result.lagSec - centerLagSec) > COLLAB_WAVEFORM_FIRST_MATCH_MAX_CENTER_OFFSET_SEC) {
      isMatch = false;
      collabWaveformScoreByPair[key].offCenter = true;
    }
    const orientedLagSec = hashA < hashB ? result.lagSec : -result.lagSec;
    const candidate = collabFirstMatchCandidateByPair[key];
    if (!isMatch) {
      delete collabFirstMatchCandidateByPair[key];
    } else if (candidate &&
        Date.now() - candidate.at <= COLLAB_WAVEFORM_MAX_AGE_MS &&
        Math.abs(candidate.lagSec - orientedLagSec) <= COLLAB_WAVEFORM_FIRST_MATCH_LAG_TOLERANCE_SEC) {
      const peak = Math.max(candidate.peak || 0, result.score);
      if (peak >= getFirstMatchPeakThreshold()) {
        delete collabFirstMatchCandidateByPair[key];
      } else {
        // 둘 다 약하면 후보를 이어 가고 우선순위에서 뺀다.
        collabFirstMatchCandidateByPair[key] = { lagSec: orientedLagSec, at: Date.now(), peak, weak: true };
        isMatch = false;
      }
    } else {
      collabFirstMatchCandidateByPair[key] = { lagSec: orientedLagSec, at: Date.now(), peak: result.score };
      isMatch = false;
    }
  }
  // 전체 창 확정 매치의 피크 lag만 탐색 중심 후보로 쌓는다(vod-sync 제외).
  if (!isVodSyncPair && !usingQuickVerify && isMatch) {
    recordMeasuredGccLag(hashA, hashB, result.lagSec);
  }

  // 확인 이력/스트릭은 새 Stage2 결과가 나온 여기서만 갱신한다(getWaveformVerdict는 읽기 전용).
  if (isMatch) {
    delete waveformDivergeStreakByPairKey[key]; // 다시 매치 — 저점수 스트릭 리셋
    collabPairLastConfirmedAt[key] = Date.now();
  } else if (typeof collabPairLastConfirmedAt[key] === 'number') {
    // 확인 이력(collabPairLastConfirmedAt)이 있는 쌍만 디바운스한다 — 창 길이(quick-verify 여부)로 가르면
    // 신선도 창을 한 번 놓친 매치 쌍이 단 한 번의 저점수로 풀렸다. 이력 없으면 즉시 확정.
    // Stage1도 "안 겹침"에 동의하면 디바운스를 즉시 통과한다(독립 신호). vod-sync는 Stage1이 없어 해당 없음.
    const stage1Similarity = !isVodSyncPair ? collabPairSimilarity[key] : null;
    const stage1Agrees = typeof stage1Similarity === 'number' && stage1Similarity < COLLAB_OVERLAP_UNMUTE_THRESHOLD;
    const streak = stage1Agrees
      ? WAVEFORM_DIVERGE_MIN_CONFIRMATIONS
      : (waveformDivergeStreakByPairKey[key] || 0) + 1;
    waveformDivergeStreakByPairKey[key] = streak;
    if (streak >= WAVEFORM_DIVERGE_MIN_CONFIRMATIONS) {
      delete collabPairLastConfirmedAt[key]; // 연속 확인 완료(또는 Stage1 동시 확인) — "다른 소리"로 확정
    }
    // 문턱 미만이면 확인 이력을 그대로 둔다(디바운스 유예 판단에 쓰임).
  } else {
    delete collabPairLastConfirmedAt[key]; // 명시적으로 "다른 소리"로 확인됨
  }

  logCollabWaveformScore(snipA, snipB, bufA, bufB, {
    p: key, a: hashA, sc: +result.score.toFixed(4), lag: +result.lagSec.toFixed(3), c: +centerLagSec.toFixed(3),
    q: usingQuickVerify, m: isMatch, off: !!collabWaveformScoreByPair[key].offCenter,
    conf: typeof collabPairLastConfirmedAt[key] === 'number', vod: isVodSyncPair, maxLag: maxLagSec,
    s1: typeof collabPairSimilarity[key] === 'number' ? +collabPairSimilarity[key].toFixed(3) : null
  });

  if (isVodSyncPair) {
    // 오프셋 변경은 음소거보다 위험해 같은 문턱이라도 여러 틱이 합의할 때만 적용한다.
    maybeRefineVodSyncOffsetFromLag(hashA, hashB, result.lagSec, result.score);
  }
}

// Stage 2 틱당 상한(워커당 동시 2건). 우선순위: ① 음소거 중인 쌍·VOD 싱크 대표-멤버 ② 첫 확정 후보 ③ 나머지(순환).
const COLLAB_WAVEFORM_MAX_IN_FLIGHT = GCC_PHAT_WORKER_POOL_SIZE * 2;
let collabWaveformRoundRobinOffset = 0;

function selectWaveformPairsForTick(candidatePairs) {
  const budget = COLLAB_WAVEFORM_MAX_IN_FLIGHT - collabWaveformRefreshInFlight.size;
  if (budget <= 0) return [];
  if (candidatePairs.length <= budget) return candidatePairs;
  const urgent = [];
  const firstMatch = [];
  const rest = [];
  candidatePairs.forEach((pair) => {
    const key = pairKey(pair[0], pair[1]);
    if (collabActiveEdges.has(key) || getVodSyncRepMemberPair(pair[0], pair[1])) urgent.push(pair);
    // 약한 후보는 끝없이 이어질 수 있어 우선하지 않는다.
    else if (collabFirstMatchCandidateByPair[key] && !collabFirstMatchCandidateByPair[key].weak) firstMatch.push(pair);
    else rest.push(pair);
  });
  if (rest.length > 0) {
    const offset = collabWaveformRoundRobinOffset % rest.length;
    rest.push(...rest.splice(0, offset));
    collabWaveformRoundRobinOffset = offset + Math.max(0, budget - urgent.length - firstMatch.length);
  }
  return [...urgent, ...firstMatch, ...rest].slice(0, budget);
}

// Stage 1 후보 쌍의 Stage 2 재계산을 트리거한다(진행 중 쌍 제외). 매 틱 스니펫/VAD 캐시를 비운다.
function refreshAllWaveformScores() {
  if (!isCollabSettingEnabled()) return;
  maintainCrossWindowCollabRelay();
  if (isCollabMovePaused()) return; // 창 사이 이동 중에는 파형 비교·AI 음성 감지를 쉰다
  // 판정하지 않는 창은 파형 비교를 하지 않는다.
  if (isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive()) return;
  collabSnippetCycleCache = {};
  collabVadResultCycleCache = {};

  const candidatePairs = [];
  getEffectiveCollabGroups().forEach((group) => {
    if (isManualCollabGroup(group)) return; // 수동 합방 그룹은 소리를 비교하지 않는다
    getGroupPairs(group).forEach(([a, b]) => {
      if (!collabCaptureHashes.has(a) || !collabCaptureHashes.has(b)) return;
      if (collabWaveformRefreshInFlight.has(pairKey(a, b))) return;
      candidatePairs.push([a, b]);
    });
  });
  const pairsToRun = selectWaveformPairsForTick(candidatePairs);

  // 채널별 이번 틱 요청 창을 미리 정한다 — 여러 쌍 중 하나라도 전체 창이 필요하면 전체로(캐시는 채널당 1회).
  const fullWindowHashes = new Set();
  const quickWindowMaxSecByHash = {};
  pairsToRun.forEach(([a, b]) => {
    const need = getRequiredRecentSecForPair(a, b);
    [a, b].forEach((h) => {
      if (fullWindowHashes.has(h)) return;
      if (need === undefined) {
        fullWindowHashes.add(h);
        delete quickWindowMaxSecByHash[h];
        return;
      }
      quickWindowMaxSecByHash[h] = Math.max(quickWindowMaxSecByHash[h] || 0, need);
    });
  });
  const recentSecForHash = (h) => (fullWindowHashes.has(h) ? undefined : quickWindowMaxSecByHash[h]);

  pairsToRun.forEach(([a, b]) => {
    const key = pairKey(a, b);
    if (collabWaveformRefreshInFlight.has(key)) return;
    collabWaveformRefreshInFlight.add(key);
    refreshWaveformScoreForPair(a, b, recentSecForHash(a), recentSecForHash(b)).finally(() => {
      collabWaveformRefreshInFlight.delete(key);
    });
  });
}
setInterval(refreshAllWaveformScores, COLLAB_WAVEFORM_REFRESH_MS);

// Stage 1이 대화 텀으로 잠깐 내려가도 이 시간 동안은 캡처를 유지한다(바로 끄면 버퍼가 리셋돼 Stage 2가 영영 확정 못 함).
const COLLAB_CAPTURE_LINGER_MS = 5000;
// pairKey → 마지막으로 Stage 1 후보였던 시각.
const collabPairCandidateLastSeenAt = {};

// Stage 1 후보 쌍(LINGER 포함)의 양쪽 채널만 캡처를 켠다.
// vod-sync 대표-멤버 쌍은 Stage 1 게이트 없이 항상 켜고 캡처 창도 15초로 넓힌다(잔차가 Stage 1 창보다 클 수 있음).
// hash → 이번 사이클 캡처 창(초), undefined면 기본 3초.
let collabCaptureWindowSecByHash = {};
function refreshCollabCaptureState() {
  const now = Date.now();
  const needed = {}; // hash -> windowSec(undefined 가능) — Object.keys로 순회하므로 Map 대신 사용
  if (isCollabSettingEnabled() && !isCollabMovePaused()) {
    getEffectiveCollabGroups().forEach((group) => {
      if (isManualCollabGroup(group)) return; // 수동 합방 그룹은 캡처가 필요 없다
      if (isVodSyncGroup(group)) {
        const representativeHash = getCollabLeaderHash(group);
        if (!representativeHash) return;
        let anyAligned = false;
        group.memberHashes.forEach((h) => {
          if (h === representativeHash) return;
          if (getVodSyncOffsetSec(group, h) === null) return;
          anyAligned = true;
          needed[h] = VOD_SYNC_CAPTURE_WINDOW_SEC;
        });
        if (anyAligned) needed[representativeHash] = VOD_SYNC_CAPTURE_WINDOW_SEC;
        return;
      }
      getGroupPairs(group).forEach(([a, b]) => {
        const key = pairKey(a, b);
        const similarity = collabPairSimilarity[key];
        if (typeof similarity === 'number' && similarity >= COLLAB_OVERLAP_MUTE_THRESHOLD) {
          collabPairCandidateLastSeenAt[key] = now;
        }
        const lastSeen = collabPairCandidateLastSeenAt[key];
        if (typeof lastSeen === 'number' && now - lastSeen <= COLLAB_CAPTURE_LINGER_MS) {
          if (!(a in needed)) needed[a] = undefined;
          if (!(b in needed)) needed[b] = undefined;
        }
      });
    });
  }
  Object.keys(needed).forEach((hash) => {
    const windowSec = needed[hash];
    if (!collabCaptureHashes.has(hash) || collabCaptureWindowSecByHash[hash] !== windowSec) {
      collabCaptureHashes.add(hash);
      collabCaptureWindowSecByHash[hash] = windowSec;
      setChannelCapture(hash, true, windowSec);
    }
  });
  Array.from(collabCaptureHashes).forEach((hash) => {
    if (!(hash in needed)) {
      collabCaptureHashes.delete(hash);
      delete collabCaptureWindowSecByHash[hash];
      setChannelCapture(hash, false);
    }
  });
}

// Stage 2 판정의 단일 표준 뷰 — 배지·디버그·음소거가 모두 이 결과만 본다.
//   'unavailable' 영구 불가 / 'match' 신선한 같은 소리 / 'different' 신선한 다른 소리 /
//   'grace' 신선한 값은 없지만 최근 확인됨(Stage1이 아직 후보로 보고 있을 때만) / 'pending' 첫 측정 대기.
// 순수 읽기 전용 — 이력/스트릭 갱신은 refreshWaveformScoreForPair에서만.
function getWaveformVerdict(hashA, hashB) {
  if (collabWaveformUnavailableHashes.has(hashA) || collabWaveformUnavailableHashes.has(hashB)) {
    return { state: 'unavailable' };
  }
  const key = pairKey(hashA, hashB);
  const waveform = collabWaveformScoreByPair[key];
  const lastConfirmedAt = collabPairLastConfirmedAt[key];
  const fresh = waveform && (Date.now() - waveform.at) <= COLLAB_WAVEFORM_MAX_AGE_MS;
  if (fresh) {
    // 이력 없는 라이브 쌍은 첫 확정 문턱으로 본다.
    if (waveform.score >= getWaveformMatchThresholdForPair(hashA, hashB)) {
      // 이력 없는 쌍의 문턱 통과는 아직 확정 대기 후보일 뿐이다.
      if (typeof lastConfirmedAt !== 'number' && !getVodSyncRepMemberPair(hashA, hashB)) {
        // 탐색 중심에서 먼 피크는 다른 소리로 본다.
        return { state: waveform.offCenter ? 'different' : 'pending', waveform };
      }
      return { state: 'match', waveform };
    }
    // 저점수인데 이력이 남아 있으면 디바운스 유예 중이다. 이력이 없으면 바로 'different'.
    if (typeof lastConfirmedAt === 'number') {
      return { state: 'grace', waveform, lastConfirmedAt };
    }
    return { state: 'different', waveform };
  }
  const stillCandidate = collabCaptureHashes.has(hashA) && collabCaptureHashes.has(hashB);
  const isVodSyncPair = !!getVodSyncRepMemberPair(hashA, hashB);
  const graceMs = isVodSyncPair ? VOD_SYNC_WAVEFORM_CONFIRM_GRACE_MS : COLLAB_WAVEFORM_CONFIRM_GRACE_MS;
  if (stillCandidate && typeof lastConfirmedAt === 'number' && Date.now() - lastConfirmedAt <= graceMs) {
    return { state: 'grace', waveform, lastConfirmedAt };
  }
  return { state: 'pending', waveform };
}

// Stage 1 + Stage 2를 결합한 음소거 판정값(UI "겹침 %"는 Stage 1 원본).
// "확인 전"은 안 겹침으로 본다(오탐 비용 > 지연 비용) — Stage 2를 못 쓰는 채널만 Stage 1 단독.
// 반환: 겹침(match/grace) = COLLAB_OVERLAP_MUTE_THRESHOLD 고정, 'different' = -1, 'pending' = null(약한 신호),
// 'unavailable' = Stage1 원본. Stage 2가 확정한 뒤엔 Stage 1 흔들림으로 뒤집히지 않게 고정값을 쓴다.
function getCombinedOverlapValueForPair(hashA, hashB, envelopeSimilarity) {
  const verdict = getWaveformVerdict(hashA, hashB);
  if (verdict.state === 'unavailable') {
    return envelopeSimilarity;
  }
  if (verdict.state === 'match' || verdict.state === 'grace') {
    return COLLAB_OVERLAP_MUTE_THRESHOLD;
  }
  if (verdict.state === 'pending') {
    return null;
  }
  return -1; // 'different'
}

// 이 그룹 멤버 사이 활성 간선으로 연결 요소를 구한다(BFS). 크기 1도 포함되지만 음소거는 2 이상만.
function getGroupClusters(group) {
  const members = group.memberHashes;
  const adjacency = new Map(members.map((h) => [h, []]));
  getGroupPairs(group).forEach(([a, b]) => {
    if (!collabActiveEdges.has(pairKey(a, b))) return;
    adjacency.get(a).push(b);
    adjacency.get(b).push(a);
  });
  const visited = new Set();
  const clusters = [];
  members.forEach((start) => {
    if (visited.has(start)) return;
    const cluster = [];
    const queue = [start];
    visited.add(start);
    while (queue.length > 0) {
      const cur = queue.shift();
      cluster.push(cur);
      adjacency.get(cur).forEach((next) => {
        if (visited.has(next)) return;
        visited.add(next);
        queue.push(next);
      });
    }
    clusters.push(cluster);
  });
  return clusters;
}

// group.id → 대표가 바뀐 시각. 새 대표와 다른 멤버 사이 Stage2가 한 번 신선하게 돌기 전까지 "대표 우선" 규칙을 보류한다.
let leaderChangedAtByGroupId = {};
// 무기한 대기 방지(잠정치).
const LEADER_CHANGE_KEEPER_HOLD_MAX_MS = 6000;

// 대표 변경 이후 신선한 Stage2 결과가 클러스터 모든 멤버와 있는지.
function hasFreshWaveformSinceLeaderChange(representative, cluster, changedAt) {
  const others = cluster.filter((h) => h !== representative);
  if (others.length === 0) return true; // 대표 혼자인 클러스터 — 확인할 상대가 없음
  return others.every((h) => {
    const waveform = collabWaveformScoreByPair[pairKey(representative, h)];
    return waveform && waveform.at >= changedAt;
  });
}

// 겹침 클러스터에서 계속 들려줄 채널 하나를 고른다.
// 1) 대표가 클러스터에 있으면 대표(대표 변경 직후엔 Stage2 재확인까지 보류).
// 2) 직전에 음소거되지 않았던 멤버 유지(sticky).
// 3) 갓 묶인 클러스터(음소거 안 된 멤버가 여럿)면 볼륨이 가장 높은 멤버.
// 4) 동률이면 레이턴시 최저, 5) 데이터가 없으면 첫 멤버.
// 볼륨은 합방 음소거를 걷어낸 설정 음량(getEffectiveVolumeForChannel) — 측정 dB는 출렁여서 keeper가 흔들린다.
function pickLoudestClusterMember(members) {
  let best = null;
  let bestVol = -Infinity;
  let tied = false;
  members.forEach((h) => {
    const vol = getEffectiveVolumeForChannel(h);
    if (typeof vol !== 'number' || !isFinite(vol)) return;
    if (vol > bestVol) {
      bestVol = vol;
      best = h;
      tied = false;
    } else if (vol === bestVol) {
      tied = true;
    }
  });
  return tied ? null : best; // 동률이면 고르지 않고 다음 규칙으로 넘긴다
}

function pickClusterKeeper(cluster, representative, groupId) {
  if (representative && cluster.includes(representative)) {
    const changedAt = groupId != null ? leaderChangedAtByGroupId[groupId] : undefined;
    const holdExpired = typeof changedAt === 'number' && (Date.now() - changedAt) > LEADER_CHANGE_KEEPER_HOLD_MAX_MS;
    if (typeof changedAt !== 'number' || holdExpired || hasFreshWaveformSinceLeaderChange(representative, cluster, changedAt)) {
      if (typeof changedAt === 'number') delete leaderChangedAtByGroupId[groupId]; // 확인 끝 — 더 볼 필요 없음
      return representative;
    }
  }
  const stillUnmuted = cluster.filter((h) => !collabMutedHashes.has(h));
  if (stillUnmuted.length === 1) return stillUnmuted[0];
  // 여럿이면 그중, 전부 음소거면 클러스터 전체에서 볼륨 높은 쪽.
  const loudest = pickLoudestClusterMember(stillUnmuted.length > 1 ? stillUnmuted : cluster);
  if (loudest) return loudest;
  if (stillUnmuted.length > 1) return stillUnmuted[0];
  let bestHash = null;
  let bestLatency = Infinity;
  cluster.forEach((h) => {
    const lat = channelLatencySecByHash[h];
    if (typeof lat === 'number' && isFinite(lat) && lat < bestLatency) {
      bestLatency = lat;
      bestHash = h;
    }
  });
  return bestHash || cluster[0];
}

// ── 합방 그룹 표시 상태와 합방 해제 ── 사용자 지정 색 우선, 없으면 직전 클러스터와 가장 많이 겹치는 것의 색을 물려받는다.
// 다른 창은 대표 창이 보낸 clusters를 그대로 쓴다.
const COLLAB_CLUSTER_COLORS = ['#4DA3FF', '#B57BFF', '#FF7AC6', '#2ED3C6', '#FF9F43', '#8BD450', '#7F8CFF', '#E5C07B'];
let collabLiveClusters = []; // [{ key, members, keeper, color, groupId? }] — groupId: 수동 합방 그룹
let collabLiveClustersSignature = '';

function getCollabMemberKey(members) {
  return members.slice().sort().join('|');
}

// 사용자 지정 그룹 색 — 자동 그룹은 채널 조합별, 수동 그룹은 그룹에 저장.
function getSavedCollabClusterColor(cluster) {
  if (cluster.groupId) {
    const group = audioState.collabGroups.find((g) => g.id === cluster.groupId);
    return (group && group.color) || null;
  }
  return (audioState.collabGroupColors && audioState.collabGroupColors[cluster.key]) || null;
}

function setCollabLiveClusters(rawClusters) {
  const prev = collabLiveClusters;
  const next = rawClusters.map(({ members, keeper, groupId }) => {
    const cluster = { key: groupId ? `manual:${groupId}` : getCollabMemberKey(members), members, keeper, color: null };
    if (groupId) cluster.groupId = groupId;
    cluster.color = getSavedCollabClusterColor(cluster);
    return cluster;
  });
  const usedColors = new Set(next.map((c) => c.color).filter(Boolean));
  const inherit = [];
  next.forEach((cluster, index) => {
    if (cluster.color) return;
    prev.forEach((old) => {
      const overlap = cluster.members.filter((h) => old.members.includes(h)).length;
      if (overlap > 0) inherit.push({ index, color: old.color, overlap });
    });
  });
  inherit.sort((a, b) => b.overlap - a.overlap).forEach(({ index, color }) => {
    if (next[index].color || !color || usedColors.has(color)) return;
    next[index].color = color;
    usedColors.add(color);
  });
  next.forEach((cluster) => {
    if (cluster.color) return;
    cluster.color = COLLAB_CLUSTER_COLORS.find((c) => !usedColors.has(c)) || COLLAB_CLUSTER_COLORS[0];
    usedColors.add(cluster.color);
  });
  applyCollabLiveClusters(next);
}

// 클러스터를 반영하고 바뀌었을 때만 다시 그린다.
function applyCollabLiveClusters(clusters) {
  collabLiveClusters = clusters;
  const signature = JSON.stringify(clusters.map((c) => [c.key, c.keeper, c.color]));
  if (signature === collabLiveClustersSignature) return;
  collabLiveClustersSignature = signature;
  refreshAudioSettingsListIfSafe(); // 슬라이더를 끄는 중이면 다음 갱신 때 다시 그린다
  updateChatTabCollabIcons();
}

function getCollabLiveClusterForHash(hash) {
  return collabLiveClusters.find((c) => c.members.includes(hash)) || null;
}

function getCollabClusterCustomName(cluster) {
  if (cluster.groupId) {
    const group = audioState.collabGroups.find((g) => g.id === cluster.groupId);
    return (group && group.name) || '';
  }
  return (audioState.collabGroupNames && audioState.collabGroupNames[cluster.key]) || '';
}

function getCollabClusterName(cluster) {
  return getCollabClusterCustomName(cluster) || cluster.members.map(getChannelNameByHash).join(' + ');
}

function getCollabClusterNumberLabel(cluster) {
  return t('audio.collabGroupNumberTemplate', '그룹 {n}', { n: collabLiveClusters.indexOf(cluster) + 1 });
}

function setCollabClusterColor(cluster, color) {
  if (cluster.groupId) {
    const group = audioState.collabGroups.find((g) => g.id === cluster.groupId);
    if (!group) return;
    group.color = color;
  } else {
    if (!audioState.collabGroupColors) audioState.collabGroupColors = {};
    audioState.collabGroupColors[cluster.key] = color;
  }
  saveAudioState();
  setCollabLiveClusters(collabLiveClusters.map(({ members, keeper, groupId }) => ({ members, keeper, groupId })));
  broadcastCollabMutedIfChanged();
  renderCollabSettingsSection();
}

function buildCollabColorPicker(currentColor, onPick) {
  const row = document.createElement('div');
  row.className = 'collab-color-row';
  row.title = t('audio.collabGroupColorHint', '그룹 색 — 타일 테두리·채팅 탭·오디오 패널에 같이 표시됩니다');
  const current = (currentColor || '').toUpperCase();
  const choices = [...new Set([...COLLAB_CLUSTER_COLORS, ...['chzzk', 'soop', 'youtube'].map(getPlatformColor)].map((c) => c.toUpperCase()))];
  choices.forEach((color) => {
    const swatch = document.createElement('button');
    swatch.type = 'button';
    swatch.className = 'collab-color-swatch' + (color === current ? ' selected' : '');
    swatch.style.setProperty('--swatch-color', color);
    swatch.addEventListener('click', () => onPick(color));
    row.appendChild(swatch);
  });
  const custom = document.createElement('input');
  custom.type = 'color';
  custom.className = 'collab-color-custom';
  custom.value = /^#[0-9A-F]{6}$/.test(current) ? current.toLowerCase() : '#ffffff';
  custom.addEventListener('change', () => {
    custom.blur(); // 입력칸에 포커스가 남으면 설정 구역이 다시 그려지지 않는다(§renderCollabSettingsSection)
    onPick(custom.value.toUpperCase());
  });
  row.appendChild(custom);
  return row;
}

function buildCollabGroupNameInput(value, placeholder, onSave) {
  const nameInput = document.createElement('input');
  nameInput.type = 'text';
  nameInput.className = 'collab-group-name-input';
  nameInput.maxLength = 40;
  nameInput.placeholder = placeholder;
  nameInput.value = value;
  nameInput.addEventListener('change', () => onSave(nameInput.value.trim()));
  nameInput.addEventListener('keydown', (e) => {
    e.stopPropagation(); // 대시보드 단축키로 새지 않게
    if (e.key === 'Enter') nameInput.blur();
  });
  return nameInput;
}

// 합방 해제: pairKey → 해제 시각(세션 메모리).
let collabSplitAtByPair = {};
const COLLAB_SPLIT_MAX_MS = 30 * 60 * 1000;

// 합방 해제 — 간선을 즉시 끄고 "다른 소리"로 확정되거나 30분이 지날 때까지 다시 묶지 않는다.
// 판정은 대표 창이 하므로 다른 창에서는 요청을 보낸다.
function splitCollabMembers(members) {
  if (!Array.isArray(members) || members.length < 2) return;
  if (isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive()) {
    window.CheeseProfileSync.send('collabSplitRequest', { members });
    return;
  }
  const now = Date.now();
  for (let i = 0; i < members.length; i++) {
    for (let j = i + 1; j < members.length; j++) {
      const key = pairKey(members[i], members[j]);
      collabSplitAtByPair[key] = now;
      collabActiveEdges.delete(key);
      delete collabEdgeMuteCandidateSince[key];
      delete collabEdgeUnmuteProgressMs[key];
    }
  }
  recomputeCollabMuting();
  applyVolumeToAllChannels(true);
  refreshAudioSettingsListIfSafe();
}

// 채널별 합방 해제: 시간 제한 없이 다른 소리로 확인될 때만 풀린다(파형 'different' 또는 Stage1이 한동안 후보가 아님).
let collabChannelSplitAtByPair = {};
const COLLAB_CHANNEL_SPLIT_IDLE_RELEASE_MS = 60 * 1000;

// 이 채널과 같은 그룹 나머지 사이만 끊는다. 수동 그룹이면 그룹에서 뺀다.
function splitCollabChannel(hash) {
  const cluster = getCollabLiveClusterForHash(hash);
  if (!cluster) return;
  if (cluster.groupId) {
    setManualCollabGroupMember(cluster.groupId, hash, false);
    return;
  }
  if (isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive()) {
    window.CheeseProfileSync.send('collabSplitRequest', { hash });
    return;
  }
  const now = Date.now();
  cluster.members.forEach((other) => {
    if (other === hash) return;
    const key = pairKey(hash, other);
    collabChannelSplitAtByPair[key] = now;
    delete collabSplitAtByPair[key];
    collabActiveEdges.delete(key);
    delete collabEdgeMuteCandidateSince[key];
    delete collabEdgeUnmuteProgressMs[key];
  });
  recomputeCollabMuting();
  applyVolumeToAllChannels(true);
  refreshAudioSettingsListIfSafe();
}

// 그룹마다 모든 쌍을 비교해 활성 간선을 갱신하고, 클러스터마다 keeper만 남겨 나머지를 음소거한다. 빠진 쌍 상태는 정리.
function recomputeCollabMuting() {
  // 대표가 아닌 창은 판정하지 않는다.
  if (isCollabRelayWorkerWindow() && isCrossWindowCollabRelayActive()) return;
  if (!isCollabSettingEnabled()) {
    collabMutedHashes.clear();
    collabPairSimilarity = {};
    collabEdgeMuteCandidateSince = {};
    collabEdgeUnmuteProgressMs = {};
    collabMutingLastTickAt = null;
    collabActiveEdges = new Set();
    collabWaveformScoreByPair = {};
    collabPairLastConfirmedAt = {};
    waveformDivergeStreakByPairKey = {};
    collabMeasuredGccLagByPair = {};
    collabFirstMatchCandidateByPair = {};
    collabSplitAtByPair = {};
    collabChannelSplitAtByPair = {};
    setCollabLiveClusters([]);
    refreshCollabCaptureState(); // needed셋이 비어있으므로 켜져 있던 캡처를 전부 끈다
    updateChatTabCollabIcons();
    return;
  }
  // 창 사이 이동 중에는 판정하지 않고 캡처만 끈다.
  if (isCollabMovePaused()) {
    refreshCollabCaptureState();
    return;
  }

  const now = Date.now();
  // 실제 사이클 간격(상한 있음) — 해제 게이지에 쓴다.
  const dtMs = collabMutingLastTickAt === null
    ? 0
    : Math.min(now - collabMutingLastTickAt, COLLAB_UNMUTE_SUSTAIN_MS);
  collabMutingLastTickAt = now;
  const muteThreshold = COLLAB_OVERLAP_MUTE_THRESHOLD;
  const unmuteThreshold = COLLAB_OVERLAP_UNMUTE_THRESHOLD;
  const nextSimilarity = {};
  const trackedPairKeys = new Set();
  const nextMutedHashes = new Set();
  const nextLiveClusters = [];

  getEffectiveCollabGroups().forEach((group) => {
    const representative = getCollabLeaderHash(group);

    // 수동 합방 그룹은 비교 없이 한 덩어리로 보고 하나만 남긴다. 대표 변경을 바로 따르도록 groupId 없이 keeper를 고른다.
    if (isManualCollabGroup(group)) {
      const members = group.memberHashes.filter((h) => displayChannels.some((c) => c.hash === h));
      if (members.length < 2) return;
      const keeper = pickClusterKeeper(members, representative, null);
      members.forEach((h) => {
        if (h !== keeper) nextMutedHashes.add(h);
      });
      nextLiveClusters.push({ members, keeper, groupId: group.id });
      return;
    }

    // vod-sync 그룹도 라이브와 같은 클러스터 음소거를 탄다 — 실제 겹침이 확인된 뒤에만 음소거한다.

    // 1) 쌍마다 Stage1 → 결합 판정 → 간선 히스테리시스. vod-sync 대표-멤버 쌍은 Stage1을 건너뛰고 Stage2를 직접 쓴다
    // (Stage1 창보다 큰 잔차에서 Stage1이 문지기처럼 막았다).
    getGroupPairs(group).forEach(([a, b]) => {
      const key = pairKey(a, b);
      trackedPairKeys.add(key);

      if (isCollabResetHoldActive(a) || isCollabResetHoldActive(b)) {
        // 시크/영상 전환 직후인 채널이 낀 쌍은 이번 사이클을 건너뛴다.
        return;
      }

      let decision;
      const vodSyncPair = getVodSyncRepMemberPair(a, b);
      if (vodSyncPair) {
        nextSimilarity[key] = null;
        const verdict = getWaveformVerdict(a, b);
        decision = (verdict.state === 'match' || verdict.state === 'grace')
          ? 1
          : (verdict.state === 'pending' ? null : -1);
      } else {
        const similarity = computeCollabSimilarity(a, b);
        nextSimilarity[key] = similarity; // UI "겹침 %"는 항상 이 Stage 1 원본값
        // Stage1이 없어도 이미 잠긴 간선은 Stage2 판정대로 해제 게이지를 진행시킨다(건너뛰면 안 풀렸다).
        if (similarity === null && !collabActiveEdges.has(key)) return;
        decision = getCombinedOverlapValueForPair(a, b, similarity);
      }

      // 합방 해제한 쌍: "다른 소리" 확정 또는 최대 시간 경과 시 해제를 풀고, 그 전엔 묶지 않는다.
      const splitAt = collabSplitAtByPair[key];
      if (typeof splitAt === 'number') {
        if ((decision !== null && decision < unmuteThreshold) || now - splitAt > COLLAB_SPLIT_MAX_MS) {
          delete collabSplitAtByPair[key];
        } else {
          collabActiveEdges.delete(key);
          delete collabEdgeMuteCandidateSince[key];
          delete collabEdgeUnmuteProgressMs[key];
          return;
        }
      }

      // 채널별 해제 쌍 — 다른 소리로 확인될 때만 푼다.
      if (typeof collabChannelSplitAtByPair[key] === 'number') {
        if (decision !== null && decision < unmuteThreshold) {
          delete collabChannelSplitAtByPair[key];
        } else {
          collabActiveEdges.delete(key);
          delete collabEdgeMuteCandidateSince[key];
          delete collabEdgeUnmuteProgressMs[key];
          return;
        }
      }

      const isActive = collabActiveEdges.has(key);
      if (!isActive) {
        delete collabEdgeUnmuteProgressMs[key];
        // null("확인 전")은 mute 후보로 삼지 않는다.
        if (decision !== null && decision >= muteThreshold) {
          if (!collabEdgeMuteCandidateSince[key]) collabEdgeMuteCandidateSince[key] = now;
          if (now - collabEdgeMuteCandidateSince[key] >= COLLAB_MUTE_SUSTAIN_MS) {
            collabActiveEdges.add(key);
            logCollabEvent('lock', { p: key });
            delete collabEdgeMuteCandidateSince[key];
          }
        } else {
          delete collabEdgeMuteCandidateSince[key];
        }
      } else {
        delete collabEdgeMuteCandidateSince[key];
        if (decision === null) {
          // "확인 전"은 느린 배율로만 해제 게이지를 채운다.
          const progress = Math.min(
            COLLAB_UNMUTE_SUSTAIN_MS,
            (collabEdgeUnmuteProgressMs[key] || 0) + dtMs * COLLAB_PENDING_UNMUTE_FILL_RATE
          );
          if (progress >= COLLAB_UNMUTE_SUSTAIN_MS) {
            collabActiveEdges.delete(key);
            logCollabEvent('unlock', { p: key, r: decision === null ? 'pending' : 'different' });
            delete collabEdgeUnmuteProgressMs[key];
          } else {
            collabEdgeUnmuteProgressMs[key] = progress;
          }
        } else if (decision < unmuteThreshold) {
          // 'different' — 게이지를 온전히 채운다.
          const progress = Math.min(COLLAB_UNMUTE_SUSTAIN_MS, (collabEdgeUnmuteProgressMs[key] || 0) + dtMs);
          if (progress >= COLLAB_UNMUTE_SUSTAIN_MS) {
            collabActiveEdges.delete(key);
            logCollabEvent('unlock', { p: key, r: decision === null ? 'pending' : 'different' });
            delete collabEdgeUnmuteProgressMs[key];
          } else {
            collabEdgeUnmuteProgressMs[key] = progress;
          }
        } else {
          // 다시 겹침 — 게이지를 일부만 깎는다.
          const decayed = (collabEdgeUnmuteProgressMs[key] || 0) - COLLAB_UNMUTE_PROGRESS_DECAY_MS;
          if (decayed > 0) collabEdgeUnmuteProgressMs[key] = decayed;
          else delete collabEdgeUnmuteProgressMs[key];
        }
      }
    });

    // 2) 클러스터(크기 ≥2)마다 keeper만 남기고 나머지를 음소거 대상에 넣는다.
    getGroupClusters(group).forEach((cluster) => {
      if (cluster.length < 2) return;
      const keeper = pickClusterKeeper(cluster, representative, group.id);
      cluster.forEach((h) => {
        if (h !== keeper) nextMutedHashes.add(h);
      });
      if (group.id === LIVE_AUTO_GROUP_ID) nextLiveClusters.push({ members: cluster.slice(), keeper });
      // VOD 싱크 그룹도 확인돼 묶인 채널만 그룹으로 표시한다(이름·색은 그룹에 저장).
      else if (isVodSyncGroup(group)) nextLiveClusters.push({ members: cluster.slice(), keeper, groupId: group.id });
    });
  });

  if (collabTimingLog.active) {
    nextMutedHashes.forEach((h) => { if (!collabMutedHashes.has(h)) logCollabEvent('mute', { h }); });
    collabMutedHashes.forEach((h) => { if (!nextMutedHashes.has(h)) logCollabEvent('unmute', { h }); });
  }
  collabMutedHashes = nextMutedHashes;
  setCollabLiveClusters(nextLiveClusters);
  broadcastCollabMutedIfChanged();
  collabPairSimilarity = nextSimilarity;

  Object.keys(collabEdgeMuteCandidateSince).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabEdgeMuteCandidateSince[key];
  });
  Object.keys(collabEdgeUnmuteProgressMs).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabEdgeUnmuteProgressMs[key];
  });
  Array.from(collabActiveEdges).forEach((key) => {
    if (!trackedPairKeys.has(key)) collabActiveEdges.delete(key);
  });
  Object.keys(collabWaveformScoreByPair).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabWaveformScoreByPair[key];
  });
  Object.keys(collabPairCandidateLastSeenAt).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabPairCandidateLastSeenAt[key];
  });
  Object.keys(collabPairLastConfirmedAt).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabPairLastConfirmedAt[key];
  });
  Object.keys(waveformDivergeStreakByPairKey).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete waveformDivergeStreakByPairKey[key];
  });
  Object.keys(collabMeasuredGccLagByPair).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabMeasuredGccLagByPair[key];
  });
  Object.keys(collabFirstMatchCandidateByPair).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabFirstMatchCandidateByPair[key];
  });
  Object.keys(collabSplitAtByPair).forEach((key) => {
    if (!trackedPairKeys.has(key)) delete collabSplitAtByPair[key];
  });
  Object.keys(collabChannelSplitAtByPair).forEach((key) => {
    const lastCandidateAt = Math.max(collabChannelSplitAtByPair[key], collabPairCandidateLastSeenAt[key] || 0);
    if (!trackedPairKeys.has(key) || now - lastCandidateAt > COLLAB_CHANNEL_SPLIT_IDLE_RELEASE_MS) {
      delete collabChannelSplitAtByPair[key];
    }
  });

  refreshCollabCaptureState();
  updateChatTabCollabIcons();
}

function getEffectiveVolumeForChannel(hash) {
  const role = getChannelRole(hash);
  if (role === 'main') return getMainVolumeForChannel(hash);
  const override = getChannelOverride(hash);
  if (override !== null) return override;
  return getGroupEffectiveVolumeForChannel(hash, role);
}

// 실제 적용/표시되는 최종 음량 — 패널 표시도 이 값을 써야 실제 재생과 일치한다.

function getDisplayVolumeForChannel(hash) {
  let vol = getEffectiveVolumeForChannel(hash);
  // 겹침이 감지된 비리더 멤버만 완전 음소거한다(살짝 낮추면 메아리처럼 들림). 저장값은 건드리지 않는 임시 효과.
  if (isCollabMutedNow(hash)) {
    vol = 0;
  }
  return vol;
}

// 채널별 마지막 적용 음량 — 자동 조정 폭 제한용. 기록이 없으면 제한 없이 적용.
let lastAppliedDisplayVolume = {};

// "진짜" 목표 전용 이전값 — 화면용 값(음소거면 0)을 기준으로 쓰면 스텝 제한이 엉뚱하게 걸린다.
let lastAppliedRealVolume = {};

// 자동 재조정 한 번에 바뀔 수 있는 최대 폭(%p). 나머지는 다음 주기에.
const MAX_AUTO_VOLUME_STEP_PERCENT = 25;

function clampVolumeStep(hash, targetVol) {
  const prev = lastAppliedRealVolume[hash];
  if (typeof prev !== 'number') return targetVol;
  const diff = targetVol - prev;
  if (Math.abs(diff) <= MAX_AUTO_VOLUME_STEP_PERCENT) return targetVol;
  return prev + Math.sign(diff) * MAX_AUTO_VOLUME_STEP_PERCENT;
}

// 합방 음소거 여부는 상위 게이트(isCollabSettingEnabled)와 함께 확인한다.
function isCollabMutedNow(hash) {
  return isCollabSettingEnabled() && isChannelCollabMuted(hash);
}

function applyVolumeToAllChannels(smooth) {
  // dB 보정 배율은 채널마다 다시 계산한다.
  videoWrapperMap.forEach((wrapper, hash) => {
    // displayVol: 화면용(음소거면 0). realVol: content.js로 보내는 video.volume 목표(합방과 무관). 출력은 gainNode로 죽인다.
    const displayVol = getDisplayVolumeForChannel(hash);
    let realVol = getEffectiveVolumeForChannel(hash);
    // 폭 제한은 자동(smooth) 조정에만 건다.
    if (smooth) realVol = clampVolumeStep(hash, realVol);
    lastAppliedDisplayVolume[hash] = displayVol;
    lastAppliedRealVolume[hash] = realVol;
    postVolumeMsg(hash, realVol, smooth);
  });
  broadcastLocalChannelVolumes();
}

// 메인-서브 확장 중엔 실제 재생 창의 표시 음량을 다른 창에 넘겨 같은 값을 보인다(§3.8).
let lastBroadcastChannelVolumesKey = null;

function broadcastLocalChannelVolumes() {
  if (!window.CheeseProfileSync || !extendedMainSubActive) return;
  const volumes = {};
  videoWrapperMap.forEach((wrapper, hash) => { volumes[hash] = lastAppliedDisplayVolume[hash]; });
  const key = JSON.stringify(volumes);
  if (key === lastBroadcastChannelVolumesKey) return;
  lastBroadcastChannelVolumesKey = key;
  window.CheeseProfileSync.send('channelVolumes', { volumes });
}

let volumeSaveDebounceTimer = null;

// 채널 슬라이더 직접 조작 — 메인은 채널별 메인 볼륨, 그리드/서브는 수동 고정값(자동 보정 제외).
function setChannelVolume(hash, value) {
  const role = getChannelRole(hash);
  const vol = Math.min(100, Math.max(0, Math.round(Number(value) || 0)));

  if (role === 'main') {
    setMainVolumeForChannel(hash, vol);
  } else {
    setChannelOverride(hash, vol);
  }

  // 저장은 드래그가 끝난 뒤 한 번만(디바운스). 소리 반영은 즉시.
  if (volumeSaveDebounceTimer) clearTimeout(volumeSaveDebounceTimer);
  volumeSaveDebounceTimer = setTimeout(saveAudioState, 300);

  // 고정은 이 채널 출력에만 영향(그룹 기준은 실측 레벨이라 다른 채널 재계산 불필요).
  // 합방 음소거 중이면 video.volume만 맞추고 gainNode는 0으로 둔다.
  lastAppliedDisplayVolume[hash] = vol;
  lastAppliedRealVolume[hash] = vol;
  postVolumeMsg(hash, vol);
}

// 플레이어 직접 조작 보고 — 이미 그 값으로 재생 중이라 SET_CHANNEL_VOLUME은 다시 보내지 않고 상태/표시만 갱신한다.
function handleUserVolumeChange(hash, value) {
  const role = getChannelRole(hash);
  const vol = Math.min(100, Math.max(0, Math.round(Number(value) || 0)));
  // 합방 음소거 중 0%는 음소거가 새어 들어온 값이라 저장하지 않는다.
  if (vol === 0 && isCollabMutedNow(hash)) return;

  if (role === 'main') {
    setMainVolumeForChannel(hash, vol);
  } else {
    setChannelOverride(hash, vol);
  }

  if (volumeSaveDebounceTimer) clearTimeout(volumeSaveDebounceTimer);
  volumeSaveDebounceTimer = setTimeout(saveAudioState, 300);

  // 고정은 이 채널 출력에만 영향(다른 채널 재계산 불필요).
  lastAppliedDisplayVolume[hash] = vol;
  renderAudioSettingsList();
}

function posAudioSettingsPanel() {
  const btn = document.getElementById('audio-settings-btn');
  const panel = document.getElementById('audio-settings-panel');
  if (!btn || !panel) return;
  const rect = btn.getBoundingClientRect();
  panel.style.top = `${rect.bottom + 6}px`;
  panel.style.left = `${rect.left}px`;
}

function handleAudioPanelOutsideClick(e) {
  const panel = document.getElementById('audio-settings-panel');
  const btn = document.getElementById('audio-settings-btn');
  if (!panel) return;
  if (panel.contains(e.target) || (btn && btn.contains(e.target))) return;
  closeAudioSettingsPanel();
}

// 스크롤이 더 남았을 때만 has-more-below 힌트를 단다.
let audioPanelScrollObserver = null;

function updateAudioPanelScrollHint() {
  const panel = document.getElementById('audio-settings-panel');
  const scrollBody = panel && panel.querySelector('.audio-settings-scroll-body');
  if (!panel || !scrollBody) return;
  const hasMore = scrollBody.scrollHeight - scrollBody.scrollTop - scrollBody.clientHeight > 2;
  panel.classList.toggle('has-more-below', hasMore);
}

function closeAudioSettingsPanel() {
  const panel = document.getElementById('audio-settings-panel');
  if (panel) panel.remove();
  document.getElementById('audio-settings-btn')?.classList.remove('active');
  document.removeEventListener('click', handleAudioPanelOutsideClick, true);
  window.removeEventListener('resize', posAudioSettingsPanel);
  if (audioPanelScrollObserver) {
    audioPanelScrollObserver.disconnect();
    audioPanelScrollObserver = null;
  }
}

function openAudioSettingsPanel() {
  const btn = document.getElementById('audio-settings-btn');
  if (!btn) return;

  const panel = document.createElement('div');
  panel.id = 'audio-settings-panel';
  panel.className = 'audio-settings-panel';
  panel.innerHTML = `
    <div id="audio-panel-tabs"></div>
    <div class="audio-settings-scroll-body">
      <div id="audio-settings-list" class="audio-settings-list"></div>
      <div id="collab-settings-section" class="collab-settings-section"></div>
    </div>
    <div class="audio-settings-scroll-hint"><span class="audio-settings-scroll-hint-arrow">▾</span></div>
  `;
  document.body.appendChild(panel);

  posAudioSettingsPanel();
  btn.classList.add('active');
  renderAudioPanelTabs();
  renderAudioSettingsList();
  renderCollabSettingsSection();

  document.addEventListener('click', handleAudioPanelOutsideClick, true);
  window.addEventListener('resize', posAudioSettingsPanel);

  // 내용 변화를 MutationObserver로 감지해 힌트를 갱신한다.
  panel.querySelector('.audio-settings-scroll-body')?.addEventListener('scroll', updateAudioPanelScrollHint);
  audioPanelScrollObserver = new MutationObserver(() => updateAudioPanelScrollHint());
  audioPanelScrollObserver.observe(panel, { childList: true, subtree: true });
  updateAudioPanelScrollHint();
}

// 오디오 패널 탭 — 채널별 오디오 / 합방 설정 / VOD 싱크 그룹. 꺼진 설정의 탭은 없고, 하나뿐이면 제목만. 고른 탭은 유지.
let audioPanelTab = 'audio';

function getAudioPanelTabs() {
  const tabs = [{ key: 'audio', label: t('audio.panelTitle', '채널별 오디오'), color: '#FFC800' }];
  if (isCollabSettingEnabled()) tabs.push({ key: 'collab', label: t('audio.collabSectionTitle', '합방 설정'), color: '#FFC800' });
  if (isVodSyncSettingEnabled()) tabs.push({ key: 'vod', label: t('audio.collabVodSyncGroupsTitle', 'VOD 싱크 그룹'), color: '#FFC800' });
  return tabs;
}

// 탭 목록이나 선택이 바뀔 때만 다시 그린다(자주 그리면 탭 클릭이 사라짐).
function renderAudioPanelTabs() {
  const bar = document.getElementById('audio-panel-tabs');
  if (!bar) return;
  const tabs = getAudioPanelTabs();
  if (!tabs.some((tab) => tab.key === audioPanelTab)) audioPanelTab = 'audio';
  const list = document.getElementById('audio-settings-list');
  if (list) list.style.display = audioPanelTab === 'audio' ? '' : 'none';
  const signature = `${tabs.map((tab) => tab.key).join(',')}|${audioPanelTab}`;
  if (bar.dataset.signature === signature) return;
  bar.dataset.signature = signature;
  bar.innerHTML = '';
  if (tabs.length === 1) {
    const header = document.createElement('div');
    header.className = 'audio-settings-header';
    header.textContent = tabs[0].label;
    bar.appendChild(header);
    return;
  }
  bar.appendChild(buildTabsBar(tabs, audioPanelTab, (key) => {
    if (key === audioPanelTab) return;
    audioPanelTab = key;
    renderAudioPanelTabs();
    renderCollabSettingsSection();
    const scrollBody = document.querySelector('#audio-settings-panel .audio-settings-scroll-body');
    if (scrollBody) scrollBody.scrollTop = 0;
  }, 'audio-panel-tabs'));
}

function toggleAudioSettingsPanel() {
  if (document.getElementById('audio-settings-panel')) {
    closeAudioSettingsPanel();
  } else {
    openAudioSettingsPanel();
  }
}

// 메인은 채널별 메인 볼륨 하나. 그리드/서브는 수동 고정값, 없으면 기준 음량과 (더 낮으면) 실제 재생 음량을 같이 보여준다.
function renderAudioModesStatus(container, hash) {
  container.innerHTML = '';

  if (getChannelRole(hash) === 'main') {
    const mainVolume = getMainVolumeForChannel(hash);
    const mainSpan = document.createElement('span');
    mainSpan.className = 'audio-settings-mode-status active';
    mainSpan.textContent = isAudioOptimizationEnabled()
      ? `${t('audio.roleMain', '메인')} ${mainVolume}%`
      : `${mainVolume}%`;
    container.appendChild(mainSpan);
    return;
  }

  const override = getChannelOverride(hash);
  if (override !== null) {
    const manualSpan = document.createElement('span');
    manualSpan.className = 'audio-settings-mode-status active';
    manualSpan.textContent = `${t('audio.manualLabel', '수동')} ${override}%`;
    container.appendChild(manualSpan);

    const resetBtn = document.createElement('span');
    resetBtn.className = 'audio-settings-mode-reset';
    resetBtn.textContent = t('audio.resetLabel', '자동');
    resetBtn.addEventListener('click', () => {
      clearChannelOverride(hash);
      if (volumeSaveDebounceTimer) clearTimeout(volumeSaveDebounceTimer);
      volumeSaveDebounceTimer = setTimeout(saveAudioState, 300);
      const resetVol = getDisplayVolumeForChannel(hash);
      const realResetVol = getEffectiveVolumeForChannel(hash);
      lastAppliedDisplayVolume[hash] = resetVol;
      lastAppliedRealVolume[hash] = realResetVol;
      postVolumeMsg(hash, realResetVol, true);
      renderAudioSettingsList();
    });
    container.appendChild(resetBtn);
    return;
  }

  // 오디오 최적화가 꺼지면 기준 음량 개념이 없어 퍼센트만 보여준다.
  if (!isAudioOptimizationEnabled()) {
    const plainSpan = document.createElement('span');
    plainSpan.className = 'audio-settings-mode-status active';
    plainSpan.textContent = `${getDisplayVolumeForChannel(hash)}%`;
    container.appendChild(plainSpan);
    return;
  }

  const baseline = getChannelBaselineVolume(hash);
  // 마지막 적용값을 우선 써서 라벨이 미세하게 흔들리지 않게.
  const effective = (typeof lastAppliedDisplayVolume[hash] === 'number')
    ? lastAppliedDisplayVolume[hash]
    : getDisplayVolumeForChannel(hash);

  const baseSpan = document.createElement('span');
  baseSpan.className = 'audio-settings-mode-status active';
  baseSpan.textContent = `${t('audio.baselineLabel', '최대')} ${baseline}%`;
  container.appendChild(baseSpan);

  // 감쇠량은 0일 때도 표시한다(감쇠 없음과 미측정 구분).
  {
    const sep = document.createElement('span');
    sep.className = 'audio-settings-mode-sep';
    sep.textContent = '→';
    container.appendChild(sep);

    const effSpan = document.createElement('span');
    effSpan.className = 'audio-settings-mode-status';
    effSpan.textContent = `${t('audio.playingLabel', '재생')} ${effective}%`;
    container.appendChild(effSpan);
  }
}

// ── 디버그 모드 ── 확장 페이지는 외부 도구가 접근할 수 없어 화면에서 바로 보는 진단 패널(표시 전용).

// 표시용 dB: 하한(-50)을 0으로 놓고 그보다 얼마나 큰지(클수록 큰 숫자).
// 볼륨까지 반영한 체감 음량은 더 낮은 하한을 쓴다(낮은 볼륨 채널이 무음으로 오표기되지 않게).
const MIN_VALID_EFFECTIVE_DB = MIN_VALID_REFERENCE_DB + 20 * Math.log10(1 / 100);

function formatDebugDb(db, floor = MIN_VALID_REFERENCE_DB) {
  return `${Math.max(0, db - floor).toFixed(1)}dB`;
}

// values: 숫자(구멍은 null) 배열. min/max 생략 시 자동 스케일. opts.series로 여러 선을 겹쳐 그린다.
function drawDebugSparkline(canvas, values, opts) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const seriesList = (opts && Array.isArray(opts.series) && opts.series.length > 0)
    ? opts.series
    : [{ values: values || [], color: (opts && opts.color) || '#FFC800' }];

  const allNums = seriesList.reduce((acc, s) => {
    s.values.forEach((v) => { if (typeof v === 'number' && isFinite(v)) acc.push(v); });
    return acc;
  }, []);
  if (allNums.length < 2) {
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.font = '10px sans-serif';
    ctx.fillText(t('audio.debugDataNotReady', 'data not ready'), 4, h / 2 + 3);
    return;
  }
  const min = (opts && typeof opts.min === 'number') ? opts.min : Math.min(...allNums);
  const max = (opts && typeof opts.max === 'number') ? opts.max : Math.max(...allNums);
  const range = (max - min) || 1;

  // opts.gridLines: 고정 범위일 때 기준선과 숫자를 그려 채널 간 절대 음량을 비교하게 한다.
  if (opts && Array.isArray(opts.gridLines) && opts.gridLines.length > 0) {
    ctx.font = '8px sans-serif';
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.lineWidth = 1;
    opts.gridLines.forEach((db) => {
      if (db < min || db > max) return;
      const y = h - ((db - min) / range) * (h - 2) - 1;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
      const labelY = Math.max(8, Math.min(h - 2, y - 1));
      // 축 라벨도 formatDebugDb와 같은 규칙. opts.labelFloor로 실제 축과 같은 하한을 받는다.
      const labelFloor = (opts && typeof opts.labelFloor === 'number') ? opts.labelFloor : MIN_VALID_REFERENCE_DB;
      ctx.fillText(`${Math.round(db - labelFloor)}dB`, 2, labelY);
    });
  }

  seriesList.forEach((series) => {
    ctx.strokeStyle = series.color || '#FFC800';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    let started = false;
    const n = series.values.length;
    series.values.forEach((v, i) => {
      const x = n > 1 ? (i / (n - 1)) * w : 0;
      if (typeof v !== 'number' || !isFinite(v)) { started = false; return; }
      // 범위 밖 값은 클램프해 가장자리에 그린다.
      const clamped = Math.min(max, Math.max(min, v));
      const y = h - ((clamped - min) / range) * (h - 2) - 1;
      if (!started) { ctx.moveTo(x, y); started = true; } else { ctx.lineTo(x, y); }
    });
    ctx.stroke();
  });
}

// lag별 원본 상관 막대 — 진짜 지연 상관이면 이웃 lag도 함께 솟는다.
function drawDebugLagBars(canvas, perLagCorr) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  const n = perLagCorr.length;
  if (n === 0) return;
  const zeroY = h / 2;
  ctx.strokeStyle = 'rgba(255,255,255,0.15)';
  ctx.beginPath();
  ctx.moveTo(0, zeroY);
  ctx.lineTo(w, zeroY);
  ctx.stroke();
  const barW = w / n;
  perLagCorr.forEach((v, i) => {
    if (typeof v !== 'number' || !isFinite(v)) return;
    const clamped = Math.max(-1, Math.min(1, v));
    const barH = Math.abs(clamped) * (h / 2 - 1);
    const x = i * barW + 1;
    const bw = Math.max(1, barW - 2);
    ctx.fillStyle = clamped >= 0 ? 'rgba(120, 200, 255, 0.8)' : 'rgba(255, 120, 120, 0.8)';
    ctx.fillRect(x, clamped >= 0 ? zeroY - barH : zeroY, bw, barH);
  });
}

// VAD 프레임별 발화 확률 막대(threshold 이상 초록 = Stage 2 비교에 쓰이는 구간).
function drawDebugProbBars(canvas, probs, threshold) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  const n = probs.length;
  if (n === 0) return;
  const thresholdY = h * (1 - threshold);
  ctx.strokeStyle = 'rgba(255,255,255,0.25)';
  ctx.setLineDash([3, 3]);
  ctx.beginPath();
  ctx.moveTo(0, thresholdY);
  ctx.lineTo(w, thresholdY);
  ctx.stroke();
  ctx.setLineDash([]);
  const barW = w / n;
  for (let i = 0; i < n; i++) {
    const p = Math.max(0, Math.min(1, probs[i]));
    const barH = p * h;
    const x = i * barW + 1;
    const bw = Math.max(1, barW - 2);
    ctx.fillStyle = p >= threshold ? 'rgba(0, 255, 163, 0.8)' : 'rgba(255,255,255,0.25)';
    ctx.fillRect(x, h - barH, bw, barH);
  }
}

// 채널 디버그 정보를 그린다(오디오 레벨 갱신마다 다시 호출됨).
const DEBUG_CANVAS_WIDTH = 340; // .audio-debug-section 폭(dashboard.css)과 맞춤.
const DEBUG_CANVAS_HEIGHT = 70; // .audio-debug-canvas 높이(dashboard.css)와 맞춤.

function appendDebugSectionHeader(section, title, desc) {
  const titleEl = document.createElement('div');
  titleEl.className = 'audio-debug-title';
  titleEl.textContent = title;
  section.appendChild(titleEl);
  if (desc) {
    const descEl = document.createElement('div');
    descEl.className = 'audio-debug-desc';
    descEl.textContent = desc;
    section.appendChild(descEl);
  }
}

function renderChannelDebugPanel(container, hash) {
  container.innerHTML = '';
  container.className = 'audio-debug-panel';

  // 섹션 번호는 실제 렌더 순서로 매긴다(조건부 섹션 때문에).
  const CIRCLED_DIGITS = ['①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨'];
  let sectionNo = 1;
  const nextSectionMark = () => CIRCLED_DIGITS[sectionNo++ - 1] || `(${sectionNo - 1})`;

  const history = debugDbHistory[hash] || [];
  const dbSection = document.createElement('div');
  dbSection.className = 'audio-debug-section';
  appendDebugSectionHeader(
    dbSection,
    t('audio.debugDbTitleTemplate', '{mark} 채널 음량(dB) 파형', { mark: nextSectionMark() }),
    t('audio.debugDbDesc', '이 채널의 음량이 시간에 따라 어떻게 움직이는지 — 아래 모든 판정의 원본 신호입니다.')
  );
  // levelDb: 평준화용 전체 대역. db(voiceDb): 합방 판정 전용 음성대역(참고용).
  const latest = history.length ? history[history.length - 1] : null;
  const latestLevelDb = latest && typeof latest.levelDb === 'number' ? latest.levelDb : null;
  const latestVoiceDb = latest && typeof latest.db === 'number' ? latest.db : null;
  const spanSec = history.length > 1 ? ((history[history.length - 1].t - history[0].t) / 1000).toFixed(1) : '0';
  const dbLabel = document.createElement('div');
  dbLabel.className = 'audio-debug-label';
  dbLabel.textContent = t('audio.debugSamplesTemplate', '{count}개 샘플, {sec}초 범위', { count: history.length, sec: spanSec })
    + (typeof latestLevelDb === 'number' ? t('audio.debugLatestSuffixTemplate', ' — 최신 {value}', { value: formatDebugDb(latestLevelDb) }) : '');
  dbSection.appendChild(dbLabel);
  const dbLegend = document.createElement('div');
  dbLegend.className = 'audio-debug-label';
  dbLegend.textContent = t('audio.debugDbLegendTemplate', '노랑: 실제 재생 볼륨 계산에 쓰이는 값 / 파랑: 합방 판정용 음성대역 값(참고용){voiceValue} / 빨강: 재생 볼륨(%)까지 반영해 실제로 들리는 크기', {
    voiceValue: typeof latestVoiceDb === 'number' ? t('audio.debugDbLegendVoiceSuffixTemplate', ' (최신 {value})', { value: formatDebugDb(latestVoiceDb) }) : ''
  });
  dbSection.appendChild(dbLegend);
  // 재생 볼륨까지 반영한 체감 음량. 마지막 적용값을 우선 쓴다(스텝 제한으로 목표와 다를 수 있음).
  const currentVolumePercent = (typeof lastAppliedDisplayVolume[hash] === 'number')
    ? lastAppliedDisplayVolume[hash]
    : getDisplayVolumeForChannel(hash);
  const effectiveDb = (typeof latestLevelDb === 'number' && currentVolumePercent > 0)
    ? latestLevelDb + 20 * Math.log10(currentVolumePercent / 100)
    : null;
  const dbEffectiveLabel = document.createElement('div');
  dbEffectiveLabel.className = 'audio-debug-label';
  dbEffectiveLabel.textContent = t('audio.debugEffectiveDbTemplate', '지금 재생 볼륨({volume}%) 반영 시 체감 음량: {value}', {
    volume: currentVolumePercent,
    value: effectiveDb !== null ? formatDebugDb(effectiveDb, MIN_VALID_EFFECTIVE_DB) : t('audio.debugStage1ValueNone', '아직 없음')
  });
  dbSection.appendChild(dbEffectiveLabel);
  // 빨강: 샘플별 volPercent를 반영한 체감 음량 시계열.
  const effectiveDbSeries = history.map((s) => {
    if (typeof s.levelDb !== 'number' || !(s.volPercent > 0)) return null;
    return s.levelDb + 20 * Math.log10(s.volPercent / 100);
  });
  const dbCanvas = document.createElement('canvas');
  dbCanvas.width = DEBUG_CANVAS_WIDTH;
  dbCanvas.height = DEBUG_CANVAS_HEIGHT;
  dbCanvas.className = 'audio-debug-canvas';
  dbSection.appendChild(dbCanvas);
  container.appendChild(dbSection);
  // 고정 범위로 채널 간 차이를 보이게 한다. 하한은 체감 음량 기준(MIN_VALID_EFFECTIVE_DB)으로 세 선이 같은 축을 쓴다.
  drawDebugSparkline(dbCanvas, null, {
    min: MIN_VALID_EFFECTIVE_DB,
    max: 0,
    labelFloor: MIN_VALID_EFFECTIVE_DB,
    gridLines: [0, MIN_VALID_EFFECTIVE_DB / 2, MIN_VALID_EFFECTIVE_DB],
    series: [
      { values: history.map((s) => s.levelDb), color: '#FFC800' },
      { values: history.map((s) => s.db), color: 'rgba(120, 200, 255, 0.85)' },
      { values: effectiveDbSeries, color: '#FF4D4D' }
    ]
  });

  const group = findCollabGroupForChannel(hash);
  if (!isCollabSettingEnabled() || !group) return;

  // 이 채널이 묶인 클러스터와 keeper를 한 줄로 보여준다.
  const myCluster = getGroupClusters(group).find((c) => c.includes(hash));
  if (myCluster && myCluster.length >= 2) {
    const keeperHash = myCluster.find((h) => !collabMutedHashes.has(h)) || null;
    const clusterLabel = document.createElement('div');
    clusterLabel.className = 'audio-debug-label';
    clusterLabel.textContent = t('audio.debugClusterTemplate', '지금 {members}와 겹침으로 묶임 / 유지 채널: {keeper}', {
      members: myCluster.filter((h) => h !== hash).map(getChannelNameByHash).join(', '),
      keeper: keeperHash ? getChannelNameByHash(keeperHash) : t('audio.debugStage1ValueNone', '아직 없음')
    });
    container.appendChild(clusterLabel);
  }

  if (isCollabVadEnabled()) {
    const vadSection = document.createElement('div');
    vadSection.className = 'audio-debug-section';
    appendDebugSectionHeader(
      vadSection,
      t('audio.debugVadTitleTemplate', '{mark} 말소리 감지(AI 음성 활동 검출)', { mark: nextSectionMark() }),
      t('audio.debugVadDesc', '이 채널이 실제로 말하고 있다고 판단된 구간(초록)만 다른 채널과의 겹침 비교에 쓰입니다.')
    );
    const vadInfo = collabVadDebugByHash[hash];
    const vadLabel = document.createElement('div');
    vadLabel.className = 'audio-debug-label';
    if (vadState !== 'ready') {
      vadLabel.textContent = vadState === 'loading'
        ? t('audio.debugVadLoading', '모델 로딩 중 — 그동안은 마스킹 없이 비교합니다.')
        : t('audio.debugVadUnavailable', '사용 불가 — 마스킹 없이 비교합니다.');
      vadSection.appendChild(vadLabel);
    } else if (vadInfo) {
      const vadCanvas = document.createElement('canvas');
      vadCanvas.width = DEBUG_CANVAS_WIDTH;
      vadCanvas.height = DEBUG_CANVAS_HEIGHT;
      vadCanvas.className = 'audio-debug-canvas';
      vadSection.appendChild(vadCanvas);
      drawDebugProbBars(vadCanvas, vadInfo.probs, VAD_SPEECH_THRESHOLD);
      const ageSec = ((Date.now() - vadInfo.at) / 1000).toFixed(1);
      vadLabel.textContent = t('audio.debugVadStatsTemplate', '발화 구간 비율 {ratio}% (기준 {threshold}% 확률 이상) / {age}초 전 계산', {
        ratio: (vadInfo.activeRatio * 100).toFixed(0),
        threshold: Math.round(VAD_SPEECH_THRESHOLD * 100),
        age: ageSec
      });
      vadSection.appendChild(vadLabel);
    } else {
      vadLabel.textContent = t('audio.debugVadPending', '아직 측정 전(합방 후보 쌍이 생기면 계산됩니다)');
      vadSection.appendChild(vadLabel);
    }
    container.appendChild(vadSection);
  }

  // 가장 강한 쌍 하나만 요약해 보여준다.
  const strongest = getStrongestPairForHash(hash);
  if (!strongest) return;
  const { partner, key } = strongest;
  const partnerName = getChannelNameByHash(partner);

  const corrSection = document.createElement('div');
  corrSection.className = 'audio-debug-section';
  appendDebugSectionHeader(
    corrSection,
    t('audio.debugStage1TitleTemplate', '{mark} 1차 신호: {partner} 채널과의 겹침 패턴 상관관계', { mark: nextSectionMark(), partner: partnerName }),
    t('audio.debugStage1Desc', '겹치는 다른 채널과 음량이 같이 커지고 작아지는 정도를 시간차(lag)별로 비교합니다 — 아직 "같은 소리"인지는 확인 전입니다.')
  );
  const perLagCorr = collabDebugLagCorrByPair[key] || [];
  const smoothed = collabPairSimilarity[key];
  const corrLabel = document.createElement('div');
  corrLabel.className = 'audio-debug-label';
  corrLabel.textContent = t('audio.debugStage1ValueTemplate', '최종 겹침 % 계산에 쓰는 값: {value}', {
    value: typeof smoothed === 'number' ? (smoothed * 100).toFixed(1) + '%' : t('audio.debugStage1ValueNone', '아직 없음')
  });
  const corrCanvas = document.createElement('canvas');
  corrCanvas.width = DEBUG_CANVAS_WIDTH;
  corrCanvas.height = DEBUG_CANVAS_HEIGHT;
  corrCanvas.className = 'audio-debug-canvas';
  corrSection.appendChild(corrCanvas);
  corrSection.appendChild(corrLabel);
  container.appendChild(corrSection);
  drawDebugLagBars(corrCanvas, perLagCorr);

  // Stage2 최종 판정을 배지와 같은 문구로 보여준다.
  const wavSection = document.createElement('div');
  wavSection.className = 'audio-debug-section';
  appendDebugSectionHeader(
    wavSection,
    t('audio.debugStage2TitleTemplate', '{mark} 2차 신호: {partner} 채널과 파형 최종 확인', { mark: nextSectionMark(), partner: partnerName }),
    t('audio.debugStage2Desc', '1차 신호로 후보가 된 쌍만 실제 파형을 비교해 "진짜 같은 소리"인지 최종 확인합니다 — 이 결과가 실제 음소거 여부를 결정합니다.')
  );
  const waveVerdict = document.createElement('div');
  waveVerdict.className = 'audio-debug-verdict';
  const waveLabel = document.createElement('div');
  waveLabel.className = 'audio-debug-label';
  // getWaveformVerdict를 공유해 배지·음소거와 항상 같은 상태를 보인다.
  const verdict = getWaveformVerdict(hash, partner);
  if (verdict.state === 'unavailable') {
    waveVerdict.textContent = t('audio.collabWaveformUnavailableLabel', '파형 분석 불가');
    waveVerdict.classList.add('unavailable');
    waveLabel.textContent = t('audio.debugWaveformUnavailableDesc', '이 채널은 워클릿을 못 써서(구형 브라우저 등) 1차 신호만으로 판정합니다.');
  } else if (verdict.state === 'match' || verdict.state === 'different') {
    const waveform = verdict.waveform;
    waveVerdict.textContent = verdict.state === 'match'
      ? t('audio.collabWaveformMatchLabel', '같은 소리 확인됨')
      : t('audio.collabWaveformDifferentLabel', '다른 소리로 판단');
    waveVerdict.classList.add(verdict.state);
    const ageSec = ((Date.now() - waveform.at) / 1000).toFixed(1);
    const computeStr = typeof waveform.computeMs === 'number' ? `${waveform.computeMs.toFixed(1)}ms` : '?';
    waveLabel.textContent = t('audio.debugWaveformStatsTemplate', '유사도 {score}% (기준 {threshold}%) / lag {lag}s / {age}초 전 계산({compute})', {
      score: (waveform.score * 100).toFixed(1),
      threshold: Math.round(getWaveformMatchThresholdForPair(hash, partner) * 100),
      lag: waveform.lagSec.toFixed(2),
      age: ageSec,
      compute: computeStr
    });
  } else if (verdict.state === 'grace') {
    waveVerdict.textContent = t('audio.collabWaveformGraceLabel', '이전 확인 유지 중');
    waveVerdict.classList.add('grace');
    const graceAgeSec = ((Date.now() - verdict.lastConfirmedAt) / 1000).toFixed(1);
    waveLabel.textContent = t('audio.debugWaveformGraceDescTemplate', '{age}초 전 마지막으로 같은 소리로 확인됨 — 말소리가 없어 파형을 다시 확인하는 중이라(유예 최대 {grace}초) 그때까지는 이전 판정(음소거)을 유지합니다.', {
      age: graceAgeSec,
      grace: (COLLAB_WAVEFORM_CONFIRM_GRACE_MS / 1000).toFixed(0)
    });
  } else {
    waveVerdict.textContent = t('audio.collabWaveformPendingLabel', '파형 확인 중');
    waveVerdict.classList.add('pending');
    waveLabel.textContent = t('audio.debugWaveformPendingDesc', '아직 측정 전(캡처 워밍업 중이거나 아직 후보가 아님)');
  }
  wavSection.appendChild(waveVerdict);
  wavSection.appendChild(waveLabel);
  container.appendChild(wavSection);

  if (isCollabVadEnabled()) {
    const vadNoteLabel = document.createElement('div');
    vadNoteLabel.className = 'audio-debug-label';
    vadNoteLabel.textContent = vadState === 'ready'
      ? t('audio.debugVadNoteReady', 'AI 음성 감지: 사용 중 — 위 ③·④ 계산 모두 두 채널 중 하나라도 말하는 구간만 사용')
      : vadState === 'loading'
        ? t('audio.debugVadNoteLoading', 'AI 음성 감지: 모델 로딩 중(그동안은 마스킹 없이 비교)')
        : t('audio.debugVadNoteUnavailable', 'AI 음성 감지: 사용 불가(마스킹 없이 비교)');
    container.appendChild(vadNoteLabel);
  }
}

// 디버그 패널은 독립된 떠 있는 창이다.
let debugPanelEl = null;
let debugPanelRefreshTimer = null;
const DEBUG_PANEL_REFRESH_MS = 200; // content.js LEVEL_REPORT_INTERVAL_MS와 맞춰 새 샘플 나오는 대로 다시 그림
// "×"는 창만 숨긴다(디버그 모드 자체는 유지). 설정에서 디버그 모드를 다시 켜면 리셋.
let debugPanelManuallyClosed = false;

function makeDebugPanelDraggable(panel, handle) {
  let dragging = false;
  let offsetX = 0;
  let offsetY = 0;
  handle.addEventListener('mousedown', (e) => {
    if (e.target.closest('.debug-panel-close')) return;
    dragging = true;
    const rect = panel.getBoundingClientRect();
    offsetX = e.clientX - rect.left;
    offsetY = e.clientY - rect.top;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    const maxLeft = window.innerWidth - panel.offsetWidth;
    const maxTop = window.innerHeight - panel.offsetHeight;
    panel.style.left = `${Math.min(Math.max(0, e.clientX - offsetX), Math.max(0, maxLeft))}px`;
    panel.style.top = `${Math.min(Math.max(0, e.clientY - offsetY), Math.max(0, maxTop))}px`;
  });
  document.addEventListener('mouseup', () => { dragging = false; });
}

function ensureDebugPanel() {
  if (debugPanelEl) return debugPanelEl;
  const panel = document.createElement('div');
  panel.id = 'cheese-debug-panel';
  panel.innerHTML = `
    <div class="debug-panel-header">
      <span class="debug-panel-title">${t('audio.debugPanelTitle', 'CHEESE EYES 디버그')}</span>
      <button type="button" class="debug-panel-close" title="${t('audio.debugPanelClose', '닫기')}">×</button>
    </div>
    <div class="debug-panel-body"></div>
  `;
  document.body.appendChild(panel);
  // 생성 직후 left/top 절대값으로 고정해 right 앵커를 떼어낸다 — 그래야 크기 조절이 끄는 방향으로 늘어난다.
  const initialRect = panel.getBoundingClientRect();
  panel.style.left = `${initialRect.left}px`;
  panel.style.top = `${initialRect.top}px`;
  panel.style.right = 'auto';
  panel.querySelector('.debug-panel-close').addEventListener('click', () => {
    debugPanelManuallyClosed = true;
    updateDebugPanelVisibility();
  });
  makeDebugPanelDraggable(panel, panel.querySelector('.debug-panel-header'));
  debugPanelEl = panel;
  return panel;
}

// 채널별 행 DOM을 재사용한다(매 틱 다시 만들면 캔버스가 깜빡임). 이 창은 오디오 디버그 전용.
const debugAudioRowByHash = new Map();

function getOrCreateDebugAudioRow(ch, container) {
  let entry = debugAudioRowByHash.get(ch.hash);
  if (!entry) {
    const row = document.createElement('div');
    row.className = 'debug-panel-channel';
    const nameEl = document.createElement('div');
    nameEl.className = 'debug-panel-channel-name';
    row.appendChild(nameEl);
    const debugEl = document.createElement('div');
    row.appendChild(debugEl);
    entry = { row, nameEl, debugEl };
    debugAudioRowByHash.set(ch.hash, entry);
  }
  if (entry.row.parentElement !== container) container.appendChild(entry.row);
  return entry;
}

function renderDebugPanel() {
  if (!debugPanelEl || debugPanelEl.hidden) return;
  const body = debugPanelEl.querySelector('.debug-panel-body');
  if (!displayChannels || displayChannels.length === 0) {
    body.innerHTML = `<div class="audio-debug-label">${t('audio.debugPanelNoChannels', '채널이 없습니다.')}</div>`;
    debugAudioRowByHash.clear();
    return;
  }

  const liveHashes = new Set(displayChannels.map(c => c.hash));
  for (const hash of [...debugAudioRowByHash.keys()]) {
    if (liveHashes.has(hash)) continue;
    debugAudioRowByHash.get(hash).row.remove();
    debugAudioRowByHash.delete(hash);
  }

  displayChannels.forEach((ch, index) => {
    const entry = getOrCreateDebugAudioRow(ch, body);
    entry.nameEl.style.color = getPlatformColor(ch.platform);
    entry.nameEl.textContent = `${ch.name} (${getChannelRole(ch.hash)})`;
    renderChannelDebugPanel(entry.debugEl, ch.hash);
    if (body.children[index] !== entry.row) {
      body.insertBefore(entry.row, body.children[index] || null);
    }
  });
}

// 디버그 토글이 바뀔 때마다 창을 띄우거나 접고, 떠 있는 동안만 주기적으로 그린다.
function updateDebugPanelVisibility() {
  if (isAudioDebugSectionEnabled() && !debugPanelManuallyClosed) {
    ensureDebugPanel().hidden = false;
    if (!debugPanelRefreshTimer) {
      debugPanelRefreshTimer = setInterval(renderDebugPanel, DEBUG_PANEL_REFRESH_MS);
    }
    renderDebugPanel();
  } else {
    if (debugPanelEl) debugPanelEl.hidden = true;
    if (debugPanelRefreshTimer) {
      clearInterval(debugPanelRefreshTimer);
      debugPanelRefreshTimer = null;
    }
  }
}

function buildAudioSettingsItem(ch) {
  const item = document.createElement('div');
  item.className = 'audio-settings-item';
  item.style.setProperty('--item-color', getPlatformColor(ch.platform));

  const row = document.createElement('div');
  row.className = 'audio-settings-row';

  const nameEl = document.createElement('span');
  nameEl.className = 'audio-settings-name';
  nameEl.textContent = ch.name;
  row.appendChild(nameEl);

  // 마지막 적용값을 우선 써서 슬라이더/숫자가 미세하게 흔들리지 않게 한다. 드래그하면 수동 고정값으로 전환된다.
  const currentVol = (typeof lastAppliedDisplayVolume[ch.hash] === 'number')
    ? lastAppliedDisplayVolume[ch.hash]
    : getDisplayVolumeForChannel(ch.hash);

  const slider = document.createElement('input');
  slider.type = 'range';
  slider.min = '0';
  slider.max = '100';
  slider.step = '1';
  slider.className = 'audio-settings-slider';
  slider.value = String(currentVol);

  const valueEl = document.createElement('span');
  valueEl.className = 'audio-settings-value';
  valueEl.textContent = `${currentVol}%`;

  const modesEl = document.createElement('div');
  modesEl.className = 'audio-settings-modes';

  slider.addEventListener('pointerdown', () => { audioSettingsDragActive = true; });
  slider.addEventListener('input', () => {
    valueEl.textContent = `${slider.value}%`;
    setChannelVolume(ch.hash, slider.value);
    renderAudioModesStatus(modesEl, ch.hash);
  });

  row.appendChild(slider);
  row.appendChild(valueEl);
  item.appendChild(row);
  item.appendChild(modesEl);
  renderAudioModesStatus(modesEl, ch.hash);

  return item;
}

function renderAudioSettingsList() {
  const listEl = document.getElementById('audio-settings-list');
  if (!listEl) return;
  listEl.innerHTML = '';

  // 메인-서브 일반일 땐 이 창 채널만 보여준다(역할이 창 레이아웃 기준이라 다른 창 채널은 다르게 계산됨). 채팅만 채널은 제외.
  const panelChannels = (extendedMainSubActive ? displayChannels : getChannelsShownInThisWindow(displayChannels)).filter((c) => !c.chatOnly);

  if (panelChannels.length === 0) {
    listEl.innerHTML = `<div class="tag-notice-empty">${t('preset.noChannels', '저장할 채널이 없습니다.')}</div>`;
    return;
  }

  // 합방 그룹이 있으면 목록을 그룹별("그룹 1"…, 그룹 색)과 "그 외"로 나눈다.
  const sections = [];
  const groupedHashes = new Set();
  if (isCollabSettingEnabled()) {
    collabLiveClusters.forEach((cluster) => {
      const members = panelChannels.filter((ch) => cluster.members.includes(ch.hash));
      if (members.length === 0) return;
      const label = getCollabClusterNumberLabel(cluster);
      const name = getCollabClusterCustomName(cluster);
      sections.push({ title: name ? `${label} · ${name}` : label, color: cluster.color, channels: members });
      members.forEach((ch) => groupedHashes.add(ch.hash));
    });
    (isCollabManualEnabled() ? audioState.collabGroups.filter(isVodSyncGroup) : []).forEach((group, index) => {
      const members = panelChannels.filter((ch) => group.memberHashes.includes(ch.hash) && !groupedHashes.has(ch.hash));
      if (members.length === 0) return;
      sections.push({ title: t('audio.collabVodSyncGroupNumberTemplate', 'VOD 싱크 그룹 {n}', { n: index + 1 }), color: null, channels: members });
      members.forEach((ch) => groupedHashes.add(ch.hash));
    });
  }

  if (sections.length === 0) {
    panelChannels.forEach(ch => listEl.appendChild(buildAudioSettingsItem(ch)));
    return;
  }

  const appendSection = (title, color, sectionChannels) => {
    const sectionTitle = document.createElement('div');
    sectionTitle.className = 'audio-settings-section-title' + (color ? ' collab' : '');
    if (color) sectionTitle.style.setProperty('--collab-color', color);
    sectionTitle.textContent = title;
    listEl.appendChild(sectionTitle);
    sectionChannels.forEach(ch => listEl.appendChild(buildAudioSettingsItem(ch)));
  };
  sections.forEach((section) => appendSection(section.title, section.color, section.channels));
  const otherChannels = panelChannels.filter(ch => !groupedHashes.has(ch.hash));
  if (otherChannels.length > 0) appendSection(t('audio.ungroupedSectionLabel', '그 외'), null, otherChannels);
}

function createCollabGroupId() {
  return `collab-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function getChannelNameByHash(hash) {
  const ch = displayChannels.find(c => c.hash === hash);
  return ch ? ch.name : hash;
}

// Stage 2 실제 판정을 별도 배지로 보여준다("겹침 %"는 Stage 1 원본이라 그것만으론 판정을 알 수 없다).
// 가장 강한 쌍 기준. 쌍이 없으면 빈 배지.
function buildCollabWaveformBadge(hash) {
  const badge = document.createElement('span');
  badge.className = 'collab-member-waveform-badge';

  // 판정 보류 중(시크·전환 직후)이면 배지도 그대로 표시한다.
  if (isCollabResetHoldActive(hash)) {
    badge.classList.add('grace');
    badge.textContent = t('audio.collabWaveformResetHoldLabel', '전환 중 — 이전 상태 유지');
    badge.title = t('audio.collabWaveformResetHoldHint', '방금 시크/영상 전환이 있어 판정이 잠깐 불안정할 수 있는 구간이라, 그 직전의 음소거 상태를 그대로 유지하고 있습니다');
    return badge;
  }

  const strongest = getStrongestPairForHash(hash);
  if (!strongest) {
    badge.classList.add('pending');
    badge.textContent = t('audio.collabWaveformPendingLabel', '파형 확인 중');
    return badge;
  }
  const { partner } = strongest;
  const partnerName = getChannelNameByHash(partner);
  const verdict = getWaveformVerdict(hash, partner);

  if (verdict.state === 'unavailable') {
    badge.classList.add('unavailable');
    badge.textContent = t('audio.collabWaveformUnavailableLabel', '파형 분석 불가');
    badge.title = t('audio.collabWaveformUnavailableHint', '이 채널은 오디오 최적화 워클릿을 쓸 수 없어(구형 브라우저 등) 파형 비교 없이 음량 타이밍만으로 판정합니다');
    return badge;
  }

  if (verdict.state === 'pending') {
    badge.classList.add('pending');
    badge.textContent = t('audio.collabWaveformPendingLabel', '파형 확인 중');
    badge.title = t('audio.collabWaveformPendingHint', '파형 비교 결과가 아직 없어 이 채널은 음소거하지 않습니다(확인될 때까지 대기)');
    return badge;
  }

  if (verdict.state === 'grace') {
    badge.classList.add('grace');
    badge.textContent = t('audio.collabWaveformGraceLabel', '이전 확인 유지 중');
    badge.title = t('audio.collabWaveformGraceHintTemplate', '{partner} 채널과 방금까지 같은 소리로 확인됐던 쌍입니다 — 말소리가 잠깐 없어 파형을 다시 확인하는 동안 이전 판정(음소거)을 유지합니다', { partner: partnerName });
    return badge;
  }

  const scorePct = Math.round(verdict.waveform.score * 100);
  if (verdict.state === 'match') {
    badge.classList.add('match');
    badge.textContent = t('audio.collabWaveformMatchLabel', '같은 소리 확인됨');
  } else {
    badge.classList.add('different');
    badge.textContent = t('audio.collabWaveformDifferentLabel', '다른 소리로 판단');
  }
  badge.title = t('audio.collabWaveformScoreHintTemplate', '{partner} 채널과 파형 유사도: {score}% (기준 {threshold}%)', {
    partner: partnerName,
    score: scorePct,
    threshold: Math.round(getWaveformMatchThresholdForPair(hash, partner) * 100)
  });
  return badge;
}

// 메타데이터 자동 계산 진행 중/실패 멤버와 사유(패널에 짧게 표시).
const vodAutoAlignPendingHashes = new Set();
const vodAutoAlignErrorByHash = {};

// vod-sync 멤버를 넣으면 VOD 메타데이터로 오프셋을 자동 계산해 입력칸에 채운다(직접 고치면 덮어쓰지 않음).
// 대표 자신이거나 앵커를 못 구하는 플랫폼이면 건너뛴다(플랫폼이 서로 달라도 됨). VOD 싱크 설정으로 이중 게이팅.
async function triggerVodMetadataAutoAlign(group, memberHash) {
  if (!isVodSyncSettingEnabled()) return;
  const representativeHash = getCollabLeaderHash(group);
  if (!representativeHash || representativeHash === memberHash) return;

  const repCh = displayChannels.find((c) => c.hash === representativeHash);
  const memberCh = displayChannels.find((c) => c.hash === memberHash);
  if (!repCh || !memberCh) return;
  const supportsVodAnchor = (c) => c.isVod && typeof PlatformAdapters[c.platform]?.getVodStartTime === 'function';
  if (!supportsVodAnchor(repCh) || !supportsVodAnchor(memberCh)) return;

  delete vodAutoAlignErrorByHash[memberHash];
  // 새 멤버는 파형 미세 정렬을 한 번 다시 한다.
  vodSyncFineAlignedHashes.delete(memberHash);
  delete vodSyncRefineHistoryByMemberHash[memberHash];
  vodAutoAlignPendingHashes.add(memberHash);
  refreshAudioSettingsListIfSafe();
  renderCollabSettingsSection();
  try {
    const result = await computeVodMetadataOffsetSec(representativeHash, memberHash);
    if (result.ok) {
      // 앵커 캐시에 이미 반영됐으므로 저장만 한다.
      saveAudioState();
      recomputeCollabMuting();
      applyVolumeToAllChannels(true);

      // 대표가 멤버의 교집합 밖이면 동기화가 시작되지 않으므로, 이 순간만 대표를 교집합 시작점(-offsetSec, 음수면 0)으로 옮긴다.
      const offsetSec = getVodSyncOffsetSec(group, memberHash);
      const repTimeNow = lastKnownPlaybackTimeSec[representativeHash];
      if (offsetSec !== null && typeof repTimeNow === 'number') {
        const expectedSecNow = repTimeNow + offsetSec;
        const memberDurationSec = channelDurationSecByHash[memberHash];
        if (!isVodSyncExpectedSecInWindow(expectedSecNow, memberDurationSec)) {
          seekChannelToTime(representativeHash, Math.max(0, -offsetSec));
        } else {
          // 오프셋 자리로 바로 옮긴다 — 기다리면 옮기기 전 소리가 첫 파형 비교에 섞인다.
          alignVodSyncMemberNow(group, memberHash, offsetSec);
        }
      }
    } else {
      vodAutoAlignErrorByHash[memberHash] = result.error;
      console.warn('[CHEESE EYES] VOD 메타데이터 자동 오프셋 계산 실패:', result.error);
    }
  } finally {
    vodAutoAlignPendingHashes.delete(memberHash);
    refreshAudioSettingsListIfSafe();
    renderCollabSettingsSection();
  }
}

// 채널은 최대 한 그룹에만 속한다 — 다른 그룹 소속은 비활성화해서 보여준다.
function renderCollabGroupCard(container, group) {
  const card = document.createElement('div');
  card.className = 'collab-group-card';

  const header = document.createElement('div');
  header.className = 'collab-group-header';

  const title = document.createElement('span');
  title.className = 'collab-group-title';
  title.textContent = group.memberHashes.length > 0
    ? group.memberHashes.map(getChannelNameByHash).join(' + ')
    : t('audio.collabUnnamedGroup', '새 합방 그룹');
  header.appendChild(title);

  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className = 'collab-group-remove';
  removeBtn.textContent = '×';
  removeBtn.title = t('audio.collabRemoveGroup', '그룹 삭제');
  removeBtn.addEventListener('click', () => {
    audioState.collabGroups = audioState.collabGroups.filter(g => g.id !== group.id);
    delete leaderChangedAtByGroupId[group.id];
    saveAudioState();
    recomputeCollabMuting();
    applyVolumeToAllChannels(true);
    renderCollabSettingsSection();
  });
  header.appendChild(removeBtn);
  card.appendChild(header);

  const representative = getCollabLeaderHash(group);

  const memberList = document.createElement('div');
  memberList.className = 'collab-group-members';
  displayChannels.filter((c) => c.isVod).forEach((ch) => {
    const inThisGroup = group.memberHashes.includes(ch.hash);
    const otherGroup = !inThisGroup ? findCollabGroupForChannel(ch.hash) : null;

    // 체크박스와 라디오를 한 label로 감싸면 라디오 클릭이 체크박스까지 토글할 수 있어 분리한다.
    const row = document.createElement('div');
    row.className = 'collab-member-row' + (otherGroup ? ' disabled' : '');

    const memberLabel = document.createElement('label');
    memberLabel.className = 'collab-member-label';

    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'collab-member-checkbox';
    checkbox.checked = inThisGroup;
    checkbox.disabled = !!otherGroup;
    checkbox.addEventListener('change', () => {
      const wasChecked = checkbox.checked;
      if (checkbox.checked) {
        if (!group.memberHashes.includes(ch.hash)) group.memberHashes.push(ch.hash);
      } else {
        group.memberHashes = group.memberHashes.filter(h => h !== ch.hash);
      }
      if (group.memberHashes.length === 0) {
        audioState.collabGroups = audioState.collabGroups.filter(g => g.id !== group.id);
        delete leaderChangedAtByGroupId[group.id];
      }
      saveAudioState();
      recomputeCollabMuting();
      applyVolumeToAllChannels(true);
      renderCollabSettingsSection();

      if (wasChecked && isVodSyncGroup(group)) {
        triggerVodMetadataAutoAlign(group, ch.hash);
      }
    });
    memberLabel.appendChild(checkbox);

    const nameEl = document.createElement('span');
    nameEl.className = 'collab-member-name';
    nameEl.textContent = ch.name;
    memberLabel.appendChild(nameEl);
    row.appendChild(memberLabel);

    if (inThisGroup) {
      // 리더 라디오 = 메인 채널 지정(setMainChannel).
      const leaderRadio = document.createElement('input');
      leaderRadio.type = 'radio';
      leaderRadio.name = `collab-leader-${group.id}`;
      leaderRadio.className = 'collab-leader-radio';
      leaderRadio.checked = ch.hash === representative;
      leaderRadio.title = t('audio.collabSetLeaderHint', '이 채널을 대표로 지정');
      leaderRadio.addEventListener('change', () => {
        setMainChannel(ch.hash);
        // 새 대표의 앵커가 없을 수 있어 정렬 안 된 멤버만 다시 시도한다(캐시 있으면 즉시 끝남).
        if (isVodSyncGroup(group)) {
          group.memberHashes.forEach((h) => {
            if (h === ch.hash) return;
            if (getVodSyncOffsetSec(group, h) !== null) return;
            triggerVodMetadataAutoAlign(group, h);
          });
        }
      });
      row.appendChild(leaderRadio);
    }

    if (inThisGroup) {
      const badge = document.createElement('span');
      if (ch.hash === representative) {
        badge.className = 'collab-member-badge leader';
        badge.textContent = t('audio.collabLeaderLabel', '대표');
        row.appendChild(badge);
      } else {
        // 자동 계산된 오프셋 입력칸(직접 수정 가능). 비어 있으면 정렬 전 — 음소거/시크 제외.
        const offsetLabel = document.createElement('span');
        offsetLabel.className = 'collab-vod-offset-label';
        offsetLabel.textContent = t('audio.collabVodOffsetLabel', '오프셋(초)');
        offsetLabel.title = t('audio.collabVodOffsetHint', '대표 채널보다 이 채널이 몇 초 늦게 시작하는 VOD인지 직접 입력하세요. 비워두면 정렬 전으로 취급해 자동 음소거/시크를 하지 않습니다.');
        row.appendChild(offsetLabel);

        const offsetInput = document.createElement('input');
        offsetInput.type = 'number';
        offsetInput.step = '0.1';
        offsetInput.className = 'collab-vod-offset-input';
        const currentOffset = getVodSyncOffsetSec(group, ch.hash);
        offsetInput.value = currentOffset === null ? '' : String(Math.round(currentOffset * 10) / 10);
        offsetInput.addEventListener('change', () => {
          const parsed = parseFloat(offsetInput.value);
          if (!isFinite(parsed)) {
            // 비우면 정렬 전으로 — 폴백 값과 앵커 캐시를 둘 다 지운다.
            delete group.vodOffsetSecByHash?.[ch.hash];
            delete audioState.vodStartTimeMsByHash[ch.hash];
            delete vodSyncRefineHistoryByMemberHash[ch.hash]; // 쌓인 잔차 확인 기록도 같이 버림 — 재정렬 시 옛 값에 오염되지 않게
          } else {
            // 대표 앵커가 있으면 멤버 시작 시각으로 역산해 캐시에 반영(대표가 바뀌어도 유효). 없으면 이 그룹 한정 값으로 저장.
            const representativeHash = getCollabLeaderHash(group);
            const repStartMs = representativeHash ? audioState.vodStartTimeMsByHash[representativeHash] : undefined;
            if (typeof repStartMs === 'number') {
              audioState.vodStartTimeMsByHash[ch.hash] = repStartMs - parsed * 1000;
              delete group.vodOffsetSecByHash?.[ch.hash];
            } else {
              if (!group.vodOffsetSecByHash) group.vodOffsetSecByHash = {};
              group.vodOffsetSecByHash[ch.hash] = parsed;
            }
          }
          saveAudioState();
          recomputeCollabMuting();
          applyVolumeToAllChannels(true);
          renderCollabSettingsSection();
        });
        row.appendChild(offsetInput);

        const statusBadge = document.createElement('span');
        const muted = isChannelCollabMuted(ch.hash);
        statusBadge.className = 'collab-member-badge' + (muted ? ' muted' : '');
        statusBadge.textContent = currentOffset === null
          ? t('audio.collabVodSyncPendingLabel', '정렬 전')
          : (muted ? t('audio.collabMutedLabel', '음소거') : t('audio.collabVodSyncAlignedLabel', '동기화됨'));
        row.appendChild(statusBadge);
      }
    } else if (otherGroup) {
      const badge = document.createElement('span');
      badge.className = 'collab-member-badge disabled';
      badge.textContent = t('audio.collabInOtherGroupLabel', '다른 그룹 소속');
      row.appendChild(badge);
    }

    memberList.appendChild(row);

    // 자동 계산 중/실패일 때만 row 아래 상태 줄을 붙인다.
    if (vodAutoAlignPendingHashes.has(ch.hash)) {
      const progressEl = document.createElement('div');
      progressEl.className = 'collab-member-align-progress';
      progressEl.textContent = t('audio.collabVodAlignComputing', 'VOD 메타데이터로 오프셋 계산 중…');
      memberList.appendChild(progressEl);
    } else if (vodAutoAlignErrorByHash[ch.hash]) {
      const errorEl = document.createElement('div');
      errorEl.className = 'collab-member-align-progress';
      errorEl.textContent = t('audio.collabVodAlignFailedTemplate', '자동 계산 실패: {error} — 직접 입력하세요', { error: vodAutoAlignErrorByHash[ch.hash] });
      memberList.appendChild(errorEl);
    }
  });
  card.appendChild(memberList);

  container.appendChild(card);
}

function renderCollabSettingsSection(options = {}) {
  const section = document.getElementById('collab-settings-section');
  if (!section) return;
  // 입력 중엔 다시 그리지 않는다(주기 갱신이 입력칸을 지움).
  const focused = document.activeElement;
  if (focused && focused.tagName === 'INPUT' && focused.type !== 'checkbox' && focused.type !== 'radio' && section.contains(focused)) return;
  // 마우스가 이 구역 위에 있으면 주기 갱신을 건너뛴다 — 누르는 사이 다시 그려져 클릭이 사라졌다. 직접 호출은 그대로 그린다.
  if (options.skipWhileHovered && section.matches(':hover')) return;

  // 다시 그려도 스크롤 위치를 복원한다(try/finally).
  const scrollBody = section.closest('.audio-settings-scroll-body');
  const prevScrollTop = scrollBody ? scrollBody.scrollTop : null;
  try {
    renderCollabSettingsSectionBody(section);
  } finally {
    if (scrollBody && prevScrollTop !== null) scrollBody.scrollTop = prevScrollTop;
  }
}

// 탭에 따라 합방 설정 탭은 자동·수동 그룹, VOD 싱크 탭은 VOD 싱크 그룹만 그린다.
function renderCollabSettingsSectionBody(section) {
  renderAudioPanelTabs();
  section.innerHTML = '';
  if (audioPanelTab === 'audio' || !isCollabSettingEnabled()) {
    section.hidden = true;
    section.style.display = 'none';
    return;
  }
  section.hidden = false;
  section.style.display = '';

  if (audioPanelTab === 'vod') {
    renderVodSyncCollabGroupsSection(section);
    return;
  }
  if (isCollabAutoEnabled()) renderAutoCollabGroupsSection(section);
  if (isCollabManualEnabled()) renderManualCollabGroupsSection(section);
}

// 자동 합방 — 지금 같은 소리로 묶인 채널이 곧 그룹이다.
function renderAutoCollabGroupsSection(section) {
  const autoHint = document.createElement('div');
  autoHint.className = 'yt-settings-hint';
  autoHint.textContent = t('audio.collabAutoHint', '라이브 채널끼리 같은 소리가 감지되면 자동으로 묶어 하나만 남기고 음소거합니다. 그룹 이름을 정해두면 같은 채널이 다시 묶일 때 그 이름을 씁니다.');
  section.appendChild(autoHint);

  const list = document.createElement('div');
  list.className = 'collab-group-list';
  const autoClusters = collabLiveClusters.filter((cluster) => !cluster.groupId);
  if (autoClusters.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'tag-notice-empty';
    empty.textContent = t('audio.collabNoActiveGroups', '지금 같은 소리로 묶인 채널이 없습니다.');
    list.appendChild(empty);
  } else {
    autoClusters.forEach((cluster) => renderCollabAutoGroupCard(list, cluster));
  }
  section.appendChild(list);
}

function renderVodSyncCollabGroupsSection(section) {
  if (!isVodSyncSettingEnabled()) return;

  const vodChannelCount = displayChannels.filter((c) => c.isVod).length;
  const vodHeader = document.createElement('div');
  vodHeader.className = 'collab-settings-header';
  const vodTitle = document.createElement('span');
  vodTitle.className = 'collab-settings-subtitle';
  vodTitle.textContent = t('audio.collabVodSyncGroupsTitle', 'VOD 싱크 그룹');
  vodHeader.appendChild(vodTitle);
  const addBtn = document.createElement('button');
  addBtn.type = 'button';
  addBtn.className = 'collab-add-group-btn';
  addBtn.textContent = t('audio.collabAddVodSyncGroup', '+ VOD 싱크 그룹 추가');
  addBtn.disabled = vodChannelCount < 2;
  addBtn.addEventListener('click', () => {
    audioState.collabGroups.push({ id: createCollabGroupId(), memberHashes: [], mode: 'vod-sync', vodOffsetSecByHash: {} });
    saveAudioState();
    renderCollabSettingsSection();
  });
  vodHeader.appendChild(addBtn);
  section.appendChild(vodHeader);

  const vodGroups = audioState.collabGroups.filter(isVodSyncGroup);
  if (vodGroups.length === 0) {
    const vodHint = document.createElement('div');
    vodHint.className = 'yt-settings-hint';
    vodHint.textContent = vodChannelCount < 2
      ? t('audio.collabVodNoChannels', 'VOD 채널이 2개 이상 있어야 VOD 싱크 그룹을 만들 수 있습니다.')
      : t('audio.collabVodNoGroups', '서로 다른 채널의 다시보기를 묶으면 방송 시작 시각 기준으로 재생 위치를 맞춥니다.');
    section.appendChild(vodHint);
    return;
  }
  const vodList = document.createElement('div');
  vodList.className = 'collab-group-list';
  vodGroups.forEach(group => renderCollabGroupCard(vodList, group));
  section.appendChild(vodList);
}

// 수동 합방 그룹 — 자동 감지가 못 묶는 합방을 직접 묶는다.
function renderManualCollabGroupsSection(section) {
  const candidates = getManualCollabCandidateChannels();
  const header = document.createElement('div');
  header.className = 'collab-settings-header';
  const title = document.createElement('span');
  title.className = 'collab-settings-subtitle';
  title.textContent = t('audio.collabManualGroupsTitle', '수동 합방 그룹');
  header.appendChild(title);
  const addBtn = document.createElement('button');
  addBtn.type = 'button';
  addBtn.className = 'collab-add-group-btn';
  addBtn.textContent = t('audio.collabAddManualGroup', '+ 합방 그룹 추가');
  addBtn.disabled = candidates.length < 2;
  addBtn.addEventListener('click', () => {
    audioState.collabGroups.push({ id: createCollabGroupId(), memberHashes: [], mode: 'manual', vodOffsetSecByHash: {}, name: '', color: null });
    saveAudioState();
    renderCollabSettingsSection();
  });
  header.appendChild(addBtn);
  section.appendChild(header);

  const groups = audioState.collabGroups.filter(isManualCollabGroup);
  if (groups.length === 0) {
    const hint = document.createElement('div');
    hint.className = 'yt-settings-hint';
    hint.textContent = candidates.length < 2
      ? t('audio.collabManualNoChannels', '라이브 채널이 2개 이상 있어야 합방 그룹을 만들 수 있습니다.')
      : t('audio.collabManualHint', '방송 싱크가 크게 어긋나 자동으로 안 묶이는 합방은 직접 묶으세요. 묶은 채널은 소리 비교 없이 항상 하나만 남기고 음소거합니다.');
    section.appendChild(hint);
    return;
  }
  const list = document.createElement('div');
  list.className = 'collab-group-list';
  groups.forEach((group) => renderCollabManualGroupCard(list, group, candidates));
  section.appendChild(list);
}

function renderCollabManualGroupCard(container, group, candidates) {
  const cluster = collabLiveClusters.find((c) => c.groupId === group.id) || null;
  const color = (cluster && cluster.color) || group.color;
  const card = document.createElement('div');
  card.className = 'collab-group-card auto';
  if (color) card.style.setProperty('--collab-color', color);

  const header = document.createElement('div');
  header.className = 'collab-group-header';
  if (cluster) header.appendChild(buildCollabGroupNumberEl(cluster));
  const placeholder = group.memberHashes.map(getChannelNameByHash).join(' + ') || t('audio.collabUnnamedGroup', '새 합방 그룹');
  header.appendChild(buildCollabGroupNameInput(group.name || '', placeholder, (name) => {
    group.name = name;
    saveAudioState();
    updateChatTabCollabIcons();
    refreshAudioSettingsListIfSafe();
  }));
  const removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className = 'collab-group-remove';
  removeBtn.textContent = '×';
  removeBtn.title = t('audio.collabRemoveGroup', '그룹 삭제');
  removeBtn.addEventListener('click', () => {
    audioState.collabGroups = audioState.collabGroups.filter((g) => g.id !== group.id);
    delete leaderChangedAtByGroupId[group.id];
    saveAudioState();
    recomputeCollabMuting();
    applyVolumeToAllChannels(true);
    refreshAudioSettingsListIfSafe();
    renderCollabSettingsSection();
  });
  header.appendChild(removeBtn);
  card.appendChild(header);
  card.appendChild(buildCollabColorPicker(color, (picked) => setCollabClusterColor({ groupId: group.id }, picked)));

  const memberList = document.createElement('div');
  memberList.className = 'collab-group-members';
  candidates.forEach((ch) => {
    const inThisGroup = group.memberHashes.includes(ch.hash);
    const inOtherGroup = !inThisGroup && audioState.collabGroups.some((g) => g.id !== group.id && isManualCollabGroup(g) && g.memberHashes.includes(ch.hash));
    const row = document.createElement('div');
    row.className = 'collab-member-row' + (inOtherGroup ? ' disabled' : '');

    const memberLabel = document.createElement('label');
    memberLabel.className = 'collab-member-label';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.className = 'collab-member-checkbox';
    checkbox.checked = inThisGroup;
    checkbox.disabled = inOtherGroup;
    checkbox.addEventListener('change', () => setManualCollabGroupMember(group.id, ch.hash, checkbox.checked));
    memberLabel.appendChild(checkbox);
    const nameEl = document.createElement('span');
    nameEl.className = 'collab-member-name';
    nameEl.textContent = ch.name;
    memberLabel.appendChild(nameEl);
    row.appendChild(memberLabel);

    if (inThisGroup && cluster) {
      // 들을 채널은 메인 채널을 따른다(이 창 채널만 선택 가능).
      if (isChannelShownInThisWindow(ch.hash)) {
        const listenRadio = document.createElement('input');
        listenRadio.type = 'radio';
        listenRadio.name = `collab-listen-${group.id}`;
        listenRadio.className = 'collab-leader-radio';
        listenRadio.checked = ch.hash === cluster.keeper;
        listenRadio.title = t('audio.collabManualListenHint', '이 채널 소리로 듣기(메인 채널로 지정)');
        listenRadio.addEventListener('change', () => setMainChannel(ch.hash));
        row.appendChild(listenRadio);
      }
      const badge = document.createElement('span');
      const muted = ch.hash !== cluster.keeper && isChannelCollabMuted(ch.hash);
      badge.className = 'collab-member-badge' + (ch.hash === cluster.keeper ? ' leader' : (muted ? ' muted' : ''));
      badge.textContent = ch.hash === cluster.keeper
        ? t('audio.collabKeeperLabel', '듣는 중')
        : (muted ? t('audio.collabMutedLabel', '음소거') : '');
      row.appendChild(badge);
    } else if (inOtherGroup) {
      const badge = document.createElement('span');
      badge.className = 'collab-member-badge disabled';
      badge.textContent = t('audio.collabInOtherGroupLabel', '다른 그룹 소속');
      row.appendChild(badge);
    }
    memberList.appendChild(row);
  });
  card.appendChild(memberList);
  container.appendChild(card);
}

function buildCollabGroupNumberEl(cluster) {
  const el = document.createElement('span');
  el.className = 'collab-group-number';
  el.textContent = getCollabClusterNumberLabel(cluster);
  return el;
}

// 자동 합방 그룹 카드 — 이름·색(같은 조합이면 재사용), 합방 해제(그룹 전체/채널 하나), 멤버별 상태.
function renderCollabAutoGroupCard(container, cluster) {
  const card = document.createElement('div');
  card.className = 'collab-group-card auto';
  card.style.setProperty('--collab-color', cluster.color);

  const header = document.createElement('div');
  header.className = 'collab-group-header';
  header.appendChild(buildCollabGroupNumberEl(cluster));

  const nameInput = buildCollabGroupNameInput(
    (audioState.collabGroupNames && audioState.collabGroupNames[cluster.key]) || '',
    cluster.members.map(getChannelNameByHash).join(' + '),
    (name) => {
      if (!audioState.collabGroupNames) audioState.collabGroupNames = {};
      if (name) audioState.collabGroupNames[cluster.key] = name;
      else delete audioState.collabGroupNames[cluster.key];
      saveAudioState();
      updateChatTabCollabIcons();
      refreshAudioSettingsListIfSafe();
    }
  );
  nameInput.title = t('audio.collabGroupNameHint', '그룹 이름 — 같은 채널 조합이 다시 묶이면 이 이름을 씁니다');
  header.appendChild(nameInput);

  const splitBtn = document.createElement('button');
  splitBtn.type = 'button';
  splitBtn.className = 'collab-add-group-btn collab-split-btn';
  splitBtn.textContent = t('audio.collabSplitButton', '합방 해제');
  splitBtn.title = t('audio.collabSplitHint', '같은 소리로 묶인 판정을 풀고, 다른 소리로 확인되거나 30분이 지날 때까지 다시 묶지 않습니다');
  splitBtn.addEventListener('click', () => splitCollabMembers(cluster.members));
  header.appendChild(splitBtn);
  card.appendChild(header);
  card.appendChild(buildCollabColorPicker(cluster.color, (picked) => setCollabClusterColor(cluster, picked)));

  const memberList = document.createElement('div');
  memberList.className = 'collab-group-members';
  cluster.members.forEach((hash) => {
    const row = document.createElement('div');
    row.className = 'collab-member-row';

    const nameEl = document.createElement('span');
    nameEl.className = 'collab-member-name';
    nameEl.textContent = getChannelNameByHash(hash);
    row.appendChild(nameEl);

    const badge = document.createElement('span');
    if (hash === cluster.keeper) {
      badge.className = 'collab-member-badge leader';
      badge.textContent = t('audio.collabKeeperLabel', '듣는 중');
      row.appendChild(badge);
    } else {
      const strongest = getStrongestPairForHash(hash);
      const similarity = strongest ? strongest.similarity : null;
      const muted = isChannelCollabMuted(hash);
      badge.className = 'collab-member-badge' + (muted ? ' muted' : '');
      const pct = typeof similarity === 'number' ? Math.round(Math.max(0, similarity) * 100) : null;
      badge.textContent = muted
        ? t('audio.collabMutedLabel', '음소거')
        : (pct !== null ? `${t('audio.collabOverlapLabel', '겹침')} ${pct}%` : t('audio.collabMeasuringLabel', '측정 중'));
      badge.title = strongest
        ? t('audio.collabOverlapBadgeHintTemplate', '{partner} 채널과 음량이 같이 커지고 작아지는 정도(1차 신호) — 실제 음소거 여부는 옆의 파형 확인 결과도 함께 반영됩니다', { partner: getChannelNameByHash(strongest.partner) })
        : t('audio.collabOverlapBadgeHintGeneric', '음량이 같이 커지고 작아지는 정도(1차 신호) — 실제 음소거 여부는 옆의 파형 확인 결과도 함께 반영됩니다');
      row.appendChild(badge);
      row.appendChild(buildCollabWaveformBadge(hash));
    }
    const rowSplitBtn = document.createElement('button');
    rowSplitBtn.type = 'button';
    rowSplitBtn.className = 'collab-member-split-btn';
    rowSplitBtn.textContent = t('audio.collabChannelSplitButton', '해제');
    rowSplitBtn.title = t('audio.collabChannelSplitHint', '이 채널만 그룹에서 빼고, 다른 소리로 확인될 때까지 다시 묶지 않습니다');
    rowSplitBtn.addEventListener('click', () => splitCollabChannel(hash));
    row.appendChild(rowSplitBtn);
    memberList.appendChild(row);
  });
  card.appendChild(memberList);
  container.appendChild(card);
}

function getParsedKeywords(input) {
  if (!input) return [];
  // 구분자는 쉼표만(공백으로는 나누지 않음).
  return input
    .split(',')
    .map(item => item.trim())
    .filter(item => item !== '');
}

let currentNoticeMode = 'tag';

function openList(mode = 'tag') {
  currentNoticeMode = mode;
  currentListPlatformTab = 'all';
  listNoticeBuilder = null;

  let displayTitle = '';
  let keywords = [];

  if (currentNoticeMode === 'tag') {
    const value = channelInput ? channelInput.value : '';
    keywords = getParsedKeywords(value);

    if (keywords.length === 0) {
      if (channelInput) channelInput.focus();
      return;
    }
    // 태그는 검색한 조합 전체를 하나의 최근 검색어로 남긴다.
    rememberRecentSearch(keywords.join(', '), 'tag');
    displayTitle = t('tagSearch.titleTemplate', `'${keywords.join(', ')}' 태그 방송 채널`, { keywords: keywords.join(', ') });
  } else if (currentNoticeMode === 'following') {
    displayTitle = t('following.titlePrefix', '팔로우 채널 중 ') + t('following.titleLive', '라이브') + t('following.titleSuffix', ' 목록');
  }

  let noticeBackdrop = document.getElementById('tag-notice-modal');

  if (!noticeBackdrop) {
    noticeBackdrop = document.createElement('div');
    noticeBackdrop.id = 'tag-notice-modal';
    noticeBackdrop.className = 'tag-notice-backdrop';
    noticeBackdrop.innerHTML = `
      <div class="tag-notice-window">
        <div class="tag-notice-header">
          <h3 id="tag-notice-title">${t('modal.searchResultTitle', '검색 결과')}</h3>
          <button class="tag-notice-close" id="tag-notice-close-btn">✕</button>
        </div>
        <div class="tag-notice-body" id="tag-notice-body"></div>
        <div class="tag-notice-footer">
          <button id="tag-modal-select-all">${t('modal.selectAll', '전체 선택')}</button>
          <button id="tag-modal-add-confirm">${t('modal.addSelected', '선택한 채널 추가')}</button>
        </div>
      </div>
    `;
    document.body.appendChild(noticeBackdrop);
    
    document.getElementById('tag-notice-close-btn').addEventListener('click', closeTagNoticeModal);
    document.getElementById('tag-modal-select-all').addEventListener('click', toggleSelectAllTagChannels);
    document.getElementById('tag-modal-add-confirm').addEventListener('click', confirmAddTagChannels);
    
    noticeBackdrop.addEventListener('click', (e) => {
      if (e.target === noticeBackdrop) {
        closeTagNoticeModal();
      }
    });

    document.addEventListener('keydown', (e) => {
      const modal = document.getElementById('tag-notice-modal');
      if (!modal || !modal.classList.contains('active')) return;

      if (e.key === 'Escape' || e.key === 'Esc') {
        closeTagNoticeModal();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        confirmAddTagChannels();
      }
    });
  }

  const noticeTitleEl = document.getElementById('tag-notice-title');
  noticeTitleEl.style.color = '#ffc800';
  if (currentNoticeMode === 'following') {
    const prefix = t('following.titlePrefix', '팔로우 채널 중 ');
    const live = t('following.titleLive', '라이브');
    const suffix = t('following.titleSuffix', ' 목록');
    noticeTitleEl.innerHTML = `${prefix}<span style="color:#FFc800">${live}</span>${suffix}`;
  } else {
    noticeTitleEl.textContent = displayTitle;
  }
  noticeBackdrop.classList.add('active');

  if (currentNoticeMode === 'tag') {
    fetchTagLives(keywords);
  } else if (currentNoticeMode === 'following') {
    fetchMyFollowingChannels();
  }
}

function closeTagNoticeModal() {
  const noticeBackdrop = document.getElementById('tag-notice-modal');

  if (noticeBackdrop) {
    noticeBackdrop.classList.remove('active');
  }
  stopFollowingPoll();
}

function buildFollowingLoginRow(platform) {
  const meta = PLATFORM_META[platform];
  const row = document.createElement('div');
  row.className = 'login-notice-row';

  const label = document.createElement('span');
  label.textContent = t('following.loginRequiredTemplate', `${meta.label} 로그인이 필요합니다.`, { platform: getPlatformLabel(platform) });
  label.className = 'login-notice-label';

  const btnGroup = document.createElement('div');
  btnGroup.style.cssText = 'display:flex; gap:6px;';

  const loginBtn = document.createElement('button');
  loginBtn.textContent = t('following.loginButtonTemplate', `${meta.label} 로그인`, { platform: getPlatformLabel(platform) });
  const loginBtnTextColor = (platform === 'soop' || platform === 'youtube') ? '#ffffff' : '#000000';
  loginBtn.style.cssText = `padding:6px 12px; cursor:pointer; border-radius:4px; border:none; background:${meta.color}; color:${loginBtnTextColor}; font-weight:bold; font-size:12px;`;
  loginBtn.addEventListener('click', () => {
    openLoginPopup(getAdapter(platform).getLoginUrl()).then(() => {
      fetchMyFollowingChannels();
    });
  });

  const retryBtn = document.createElement('button');
  retryBtn.textContent = t('following.loginDone', '로그인 완료');
  retryBtn.className = 'login-notice-retry-btn';
  retryBtn.addEventListener('click', () => fetchMyFollowingChannels());

  btnGroup.appendChild(loginBtn);
  btnGroup.appendChild(retryBtn);
  row.appendChild(label);
  row.appendChild(btnGroup);
  return row;
}

const FOLLOWING_CACHE_KEY = 'following_live_cache';
// 캐시가 이보다 오래되면 옛 목록을 보여주지 않고 새로 불러온다.
const FOLLOWING_CACHE_MAX_AGE_MS = 3 * 60 * 1000;
let followingRequestSeq = 0;

function readFollowingCache() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get([FOLLOWING_CACHE_KEY], (result) => {
        const cached = result && result[FOLLOWING_CACHE_KEY];
        if (!cached || !Array.isArray(cached.groups)) { resolve(null); return; }
        if (typeof cached.cachedAt !== 'number' || Date.now() - cached.cachedAt > FOLLOWING_CACHE_MAX_AGE_MS) {
          resolve(null);
          return;
        }
        resolve(cached);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

function writeFollowingCache(groups, loggedOutPlatforms) {
  try {
    chrome.storage.local.set({
      [FOLLOWING_CACHE_KEY]: { groups, loggedOutPlatforms, cachedAt: Date.now() }
    });
  } catch (e) {
    console.warn('[CHEESE EYES] 팔로우 목록 캐시 저장 실패:', e);
  }
}

function getFollowingSignature(groups, loggedOutPlatforms) {
  const groupPart = (groups || []).map(g => [
    g.platform,
    (g.candidates || []).map(ch => `${ch.platform}:${ch.hash}:${ch.name}`).join('|')
  ]);
  return JSON.stringify([groupPart, (loggedOutPlatforms || []).slice().sort()]);
}

function renderFollowingState(groups, loggedOutPlatforms) {
  const bodyContainer = document.getElementById('tag-notice-body');
  const flatChannels = (groups || []).reduce((acc, g) => acc.concat(g.candidates || []), []);

  fetchedTagChannels = flatChannels;
  selectedTagChannels = selectedTagChannels
    .map(sel => flatChannels.find(c => c.hash === sel.hash && c.platform === sel.platform))
    .filter(Boolean);

  listNoticeBuilder = null;
  if ((loggedOutPlatforms || []).length > 0) {
    listNoticeBuilder = () => {
      const wrap = document.createElement('div');
      loggedOutPlatforms.forEach(p => wrap.appendChild(buildFollowingLoginRow(p)));
      return wrap;
    };
  }

  if (flatChannels.length === 0 && !listNoticeBuilder) {
    bodyContainer.innerHTML = `<div class="tag-notice-empty">${t('following.empty', '라이브 중인 채널이 없습니다.')}</div>`;
    return;
  }
  if (flatChannels.length === 0) {
    bodyContainer.innerHTML = '';
    bodyContainer.appendChild(listNoticeBuilder());
    const empty = document.createElement('div');
    empty.className = 'tag-notice-empty';
    empty.textContent = t('following.empty', '라이브 중인 채널이 없습니다.');
    bodyContainer.appendChild(empty);
    return;
  }

  renderFollowingColumns(groups);
}

let followingRenderedSignature = null;
let followingPollTimer = null;
const FOLLOWING_POLL_INTERVAL_MS = 75000;

function startFollowingPoll() {
  stopFollowingPoll();
  followingPollTimer = setInterval(() => {
    const modal = document.getElementById('tag-notice-modal');
    if (!modal || !modal.classList.contains('active') || currentNoticeMode !== 'following') {
      stopFollowingPoll();
      return;
    }
    refreshFollowingChannelsQuietly();
  }, FOLLOWING_POLL_INTERVAL_MS);
}

function stopFollowingPoll() {
  if (followingPollTimer) {
    clearInterval(followingPollTimer);
    followingPollTimer = null;
  }
}

async function fetchMyFollowingChannels() {
  const bodyContainer = document.getElementById('tag-notice-body');
  const requestId = ++followingRequestSeq;

  fetchedTagChannels = [];
  selectedTagChannels = [];
  listNoticeBuilder = null;
  followingRenderedSignature = null;

  bodyContainer.innerHTML = `<div class="tag-notice-empty">${t('following.loading', '팔로우 채널 목록을 불러오는 중...')}</div>`;

  const cached = await readFollowingCache();
  if (requestId !== followingRequestSeq) return;

  if (cached) {
    renderFollowingState(cached.groups, cached.loggedOutPlatforms || []);
    followingRenderedSignature = getFollowingSignature(cached.groups, cached.loggedOutPlatforms || []);
  }

  await fetchFollowingOnce(requestId);
  startFollowingPoll();
}

// 패널이 열려 있는 동안 조용히 재조회하고, 바뀌었을 때만 다시 그린다.
async function refreshFollowingChannelsQuietly() {
  const requestId = ++followingRequestSeq;
  await fetchFollowingOnce(requestId);
}

async function fetchFollowingOnce(requestId) {
  const enabledPlatforms = Object.keys(PLATFORM_META).filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p]);
  const loginStatuses = await Promise.all(enabledPlatforms.map(p => PlatformAdapters[p].checkLoginStatus()));
  const loginStatusByPlatform = Object.fromEntries(enabledPlatforms.map((p, i) => [p, loginStatuses[i]]));

  const loggedInPlatforms = enabledPlatforms.filter(p => loginStatusByPlatform[p]);
  // 플랫폼별 병렬 요청, 모두 도착한 뒤 한 번에 표시.
  const settled = await Promise.allSettled(loggedInPlatforms.map(p => PlatformAdapters[p].fetchFollowingLive()));
  if (requestId !== followingRequestSeq) return;

  const followingGroups = [];
  loggedInPlatforms.forEach((p, i) => {
    const outcome = settled[i];
    if (outcome.status === 'fulfilled') {
      followingGroups.push({ platform: p, candidates: outcome.value || [] });
    } else {
      console.error(`${PLATFORM_META[p].label} 팔로우 목록 요청 실패:`, outcome.reason);
      followingGroups.push({ platform: p, candidates: fetchedTagChannels.filter(c => c.platform === p) });
    }
  });

  const loggedOutPlatforms = enabledPlatforms.filter(p => !loginStatusByPlatform[p]);
  writeFollowingCache(followingGroups, loggedOutPlatforms);

  const freshSignature = getFollowingSignature(followingGroups, loggedOutPlatforms);
  if (followingRenderedSignature !== null && freshSignature === followingRenderedSignature) {
    const freshChannels = followingGroups.reduce((acc, g) => acc.concat(g.candidates || []), []);
    fetchedTagChannels.forEach(ch => {
      const fresh = freshChannels.find(c => c.hash === ch.hash && c.platform === ch.platform);
      if (fresh) Object.assign(ch, fresh);
    });
    return;
  }

  followingRenderedSignature = freshSignature;
  renderFollowingState(followingGroups, loggedOutPlatforms);
}

// 채널이 5개 미만이면 모달 폭도 줄인다(최소 폭 유지).
function applyCardGridWindowWidth(listWrap, itemCount) {
  const CARD_WIDTH = 160;
  const CARD_GAP = 12;
  const MODAL_PADDING = 32; // .tag-notice-body 좌우 패딩(16px * 2)
  const MODAL_MIN_WIDTH = 340;
  const cols = Math.max(1, Math.min(5, itemCount));
  listWrap.style.setProperty('--following-cols', cols);
  listWrap.style.setProperty('--following-card-width', `${CARD_WIDTH}px`);
  const windowWidth = Math.max(
    MODAL_MIN_WIDTH,
    cols * CARD_WIDTH + (cols - 1) * CARD_GAP + MODAL_PADDING
  );
  const noticeWindowEl = document.querySelector('#tag-notice-modal .tag-notice-window');
  if (noticeWindowEl) noticeWindowEl.style.width = `${windowWidth}px`;

  // 4행 높이만큼 스크롤 영역을 잡는다. CARD_HEADROOM은 dashboard.css 카드 스타일과 맞춰야 한다.
  const CARD_HEADROOM = 77;
  const ROWS_VISIBLE = 4;
  const cardHeight = (CARD_WIDTH * 9 / 16) + CARD_HEADROOM;
  listWrap.style.maxHeight = `${Math.round(ROWS_VISIBLE * cardHeight + (ROWS_VISIBLE - 1) * CARD_GAP)}px`;
}

// 팔로우 목록 — 모든 플랫폼 응답 후 한 번에 렌더링.
function renderFollowingColumns(groups) {
  const bodyContainer = document.getElementById('tag-notice-body');
  bodyContainer.innerHTML = '';

  if (listNoticeBuilder) {
    bodyContainer.appendChild(listNoticeBuilder());
  }

  const tabsBar = buildPlatformTabsBar(currentListPlatformTab, (tab) => {
    currentListPlatformTab = tab;
    renderFollowingColumns(groups);
  });
  bodyContainer.appendChild(tabsBar);

  const listWrap = document.createElement('div');
  listWrap.className = 'live-confirm-rows following-mode';

  // 다중 선택용으로 현재 탭 채널을 평탄화해 둔다.
  const flatFollowingChannels = [];

  groups.forEach(group => {
    if (currentListPlatformTab !== 'all' && group.platform !== currentListPlatformTab) return;
    (group.candidates || []).forEach(ch => {
      flatFollowingChannels.push(ch);
      const isSelected = selectedTagChannels.some(item => item.hash === ch.hash && item.platform === ch.platform);
      const row = createLiveResultRow(ch, isSelected, () => {
        const idx = selectedTagChannels.findIndex(s => s.hash === ch.hash && s.platform === ch.platform);
        if (idx > -1) {
          selectedTagChannels.splice(idx, 1);
          row.classList.remove('selected');
        } else {
          selectedTagChannels.push(ch);
          row.classList.add('selected');
        }
      });
      listWrap.appendChild(row);
    });
  });

  if (listWrap.children.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'tag-notice-empty';
    empty.textContent = t('modal.emptyPlatformResult', '해당 플랫폼의 채널이 없습니다.');
    bodyContainer.appendChild(empty);
    return;
  }

  applyCardGridWindowWidth(listWrap, flatFollowingChannels.length);

  bodyContainer.appendChild(listWrap);

  initTagChipDragSelect(
    listWrap,
    '.selectable-channel-item',
    (hash, platform) => flatFollowingChannels.find(c => c.hash === hash && c.platform === platform)
  );
}

async function fetchTagLives(tagKeywords) {
  const bodyContainer = document.getElementById('tag-notice-body');
  bodyContainer.innerHTML = `<div class="tag-notice-empty">${t('tagSearch.loading', '전체 태그 방송 정보를 불러오는 중...')}</div>`;
  
  fetchedTagChannels = [];
  selectedTagChannels = [];
  listNoticeBuilder = null;

  const keywordsList = Array.isArray(tagKeywords) ? tagKeywords : [tagKeywords];

  if (keywordsList.length === 0) {
    bodyContainer.innerHTML = `<div class="tag-notice-empty">${t('tagSearch.noKeyword', '검색할 태그가 없습니다.')}</div>`;
    return;
  }

  try {
    const enabledPlatforms = Object.keys(PLATFORM_META).filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p] && p !== 'youtube');
    const resultsByPlatform = await Promise.all(
      enabledPlatforms.map(p => PlatformAdapters[p].searchTagLives(keywordsList)
        .catch(err => { console.error(`${PLATFORM_META[p].label} 태그 검색 실패:`, err); return []; }))
    );

    const relevanceQuery = keywordsList.join(', ');
    fetchedTagChannels = mergeTagChannelsByRelevance(relevanceQuery, resultsByPlatform);

    if (PLATFORM_META.youtube && PLATFORM_META.youtube.enabled) {
      listNoticeBuilder = () => {
        const notice = document.createElement('div');
        notice.className = 'login-notice-row';
        notice.textContent = t('tagSearch.youtubeUnsupported', '유튜브는 별도의 태그 검색을 지원하지 않습니다.');
        return notice;
      };
    }

    if (fetchedTagChannels.length > 0) {
      renderTagCardsInModal();
    } else {
      bodyContainer.innerHTML = '';
      if (listNoticeBuilder) bodyContainer.appendChild(listNoticeBuilder());
      const empty = document.createElement('div');
      empty.className = 'tag-notice-empty';
      empty.textContent = t('tagSearch.emptyResult', '해당 태그들을 모두 만족하는 방송 채널이 없습니다.');
      bodyContainer.appendChild(empty);
    }

  } catch (err) {
    console.error('태그 검색 요청 실패:', err);
    bodyContainer.innerHTML = `<div class="tag-notice-empty">${t('tagSearch.error', '데이터를 불러오지 못했습니다. 콘솔을 확인하세요.')}</div>`;
  }
}

function renderTagCardsInModal() {
  const bodyContainer = document.getElementById('tag-notice-body');
  bodyContainer.innerHTML = '';

  if (listNoticeBuilder) {
    bodyContainer.appendChild(listNoticeBuilder());
  }

  const tabsBar = buildPlatformTabsBar(currentListPlatformTab, (tab) => {
    currentListPlatformTab = tab;
    renderTagCardsInModal();
  }, currentNoticeMode === 'tag' ? ['youtube'] : []);
  bodyContainer.appendChild(tabsBar);

  const filtered = fetchedTagChannels.filter(c => currentListPlatformTab === 'all' || c.platform === currentListPlatformTab);

  if (filtered.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'tag-notice-empty';
    empty.textContent = t('modal.emptyPlatformResult', '해당 플랫폼의 채널이 없습니다.');
    bodyContainer.appendChild(empty);
    return;
  }

  const listWrap = document.createElement('div');
  listWrap.className = 'live-confirm-rows following-mode';

  filtered.forEach(ch => {
    const isSelected = selectedTagChannels.some(item => item.hash === ch.hash && item.platform === ch.platform);
    const row = createLiveResultRow(ch, isSelected, () => {
      const idx = selectedTagChannels.findIndex(s => s.hash === ch.hash && s.platform === ch.platform);
      if (idx > -1) {
        selectedTagChannels.splice(idx, 1);
        row.classList.remove('selected');
      } else {
        selectedTagChannels.push(ch);
        row.classList.add('selected');
      }
    });
    listWrap.appendChild(row);
  });

  applyCardGridWindowWidth(listWrap, filtered.length);

  bodyContainer.appendChild(listWrap);

  initTagChipDragSelect(
    listWrap,
    '.selectable-channel-item',
    (hash, platform) => fetchedTagChannels.find(c => c.hash === hash && c.platform === platform)
  );
}

function initTagChipDragSelect(scrollContainer, itemSelector, findChannel) {
  itemSelector = itemSelector || '.selectable-channel-item';
  findChannel = findChannel || ((hash, platform) => fetchedTagChannels.find(c => c.hash === hash && c.platform === platform));

  let isMouseDown = false;
  let isDragging = false;
  let startAbsX = 0;
  let startAbsY = 0;
  let dragRect = null;
  let dragEntries = new Map();
  let autoScrollTimer = null;
  let lastMouseEvt = null;
  let lastShiftStartAbsX = null;
  let lastShiftStartAbsY = null;
  let startChip = null;
  function toggleChipState(chip) {
    if (!chip) return;
    const hash = chip.getAttribute('data-hash');
    const platform = chip.getAttribute('data-platform');
    const channelObj = findChannel(hash, platform);
    const isSelected = chip.classList.contains('selected');

    if (isSelected) {
      chip.classList.remove('selected');
      const idx = selectedTagChannels.findIndex(c => c.hash === hash && c.platform === platform);
      if (idx > -1) selectedTagChannels.splice(idx, 1);
    } else {
      chip.classList.add('selected');
      if (channelObj && !selectedTagChannels.some(c => c.hash === hash && c.platform === platform)) {
        selectedTagChannels.push(channelObj);
      }
    }

    // 드래그 엔트리 캐시도 함께 갱신한다.
    const entry = dragEntries.get(chip);
    if (entry) entry.current = !isSelected;
  }

  scrollContainer.addEventListener('mousedown', (e) => {
    if (e.button !== 0) return;

    isMouseDown = true;
    isDragging = false;
    scrollContainer.classList.remove('has-dragged');

    const rect = scrollContainer.getBoundingClientRect();
    const currentChip = e.target.closest(itemSelector);
    if (e.shiftKey && lastShiftStartAbsX !== null && lastShiftStartAbsY !== null) {
      startAbsX = lastShiftStartAbsX;
      startAbsY = lastShiftStartAbsY;
    } else {
      startAbsX = (e.clientX - rect.left) + scrollContainer.scrollLeft;
      startAbsY = (e.clientY - rect.top) + scrollContainer.scrollTop;
      
      lastShiftStartAbsX = startAbsX;
      lastShiftStartAbsY = startAbsY;
      startChip = currentChip; 
    }

    // 칩 위치·소속은 드래그 중 안 바뀌므로 한 번만 읽어 캐시한다.
    dragEntries = new Map();
    scrollContainer.querySelectorAll(itemSelector).forEach(chip => {
      const hash = chip.getAttribute('data-hash');
      const platform = chip.getAttribute('data-platform');
      const wasSelected = chip.classList.contains('selected');
      dragEntries.set(chip, {
        hash,
        platform,
        channelObj: findChannel(hash, platform),
        left: chip.offsetLeft,
        top: chip.offsetTop,
        right: chip.offsetLeft + chip.offsetWidth,
        bottom: chip.offsetTop + chip.offsetHeight,
        wasSelected,
        current: wasSelected,
      });
    });

    dragRect = document.createElement('div');
    dragRect.className = 'drag-select-rect';
    dragRect.style.left = `${startAbsX}px`;
    dragRect.style.top = `${startAbsY}px`;
    dragRect.style.width = '0px';
    dragRect.style.height = '0px';

    scrollContainer.appendChild(dragRect);
    if (e.shiftKey) {
      lastMouseEvt = e;
      updateDragSelection();
      const endChip = currentChip;
      toggleChipState(startChip);
      if (endChip && endChip !== startChip) {
        toggleChipState(endChip);
      }
    }
  });

  let dragUpdateQueued = false;
  window.addEventListener('mousemove', (e) => {
    if (!isMouseDown) return;
    if (!isDragging) {
      isDragging = true;
      scrollContainer.classList.add('has-dragged');
      document.body.classList.add('drag-selecting');
      startAutoScroll();
    }

    lastMouseEvt = e;
    // rAF 한 프레임당 한 번만 계산한다(고폴링 마우스 대비).
    if (!dragUpdateQueued) {
      dragUpdateQueued = true;
      requestAnimationFrame(() => {
        dragUpdateQueued = false;
        updateDragSelection();
      });
    }
  });

  window.addEventListener('mouseup', () => {
    if (!isMouseDown) return;

    isMouseDown = false;
    document.body.classList.remove('drag-selecting');
    stopAutoScroll();

    if (dragRect) {
      dragRect.remove();
      dragRect = null;
    }

    setTimeout(() => {
      scrollContainer.classList.remove('has-dragged');
    }, 50);

    isDragging = false;
    dragEntries.clear();
  });

  function updateDragSelection() {
    if (!dragRect || !lastMouseEvt) return;

    const e = lastMouseEvt;
    const rect = scrollContainer.getBoundingClientRect();

    const currentAbsX = (e.clientX - rect.left) + scrollContainer.scrollLeft;
    const currentAbsY = (e.clientY - rect.top) + scrollContainer.scrollTop;

    const rectLeft = Math.min(startAbsX, currentAbsX);
    const rectTop = Math.min(startAbsY, currentAbsY);
    const rectWidth = Math.abs(currentAbsX - startAbsX);
    const rectHeight = Math.abs(currentAbsY - startAbsY);
    const rectRight = rectLeft + rectWidth;
    const rectBottom = rectTop + rectHeight;

    dragRect.style.left = `${rectLeft}px`;
    dragRect.style.top = `${rectTop}px`;
    dragRect.style.width = `${rectWidth}px`;
    dragRect.style.height = `${rectHeight}px`;

    // 캐시된 엔트리로 상태가 바뀌는 칩만 갱신한다.
    dragEntries.forEach((entry, chip) => {
      const isIntersecting = !(
        rectRight < entry.left ||
        rectLeft > entry.right ||
        rectBottom < entry.top ||
        rectTop > entry.bottom
      );

      const shouldBeSelected = isIntersecting ? !entry.wasSelected : entry.wasSelected;
      if (shouldBeSelected === entry.current) return;
      entry.current = shouldBeSelected;

      if (shouldBeSelected) {
        chip.classList.add('selected');
        if (entry.channelObj && !selectedTagChannels.some(c => c.hash === entry.hash && c.platform === entry.platform)) {
          selectedTagChannels.push(entry.channelObj);
        }
      } else {
        chip.classList.remove('selected');
        const idx = selectedTagChannels.findIndex(c => c.hash === entry.hash && c.platform === entry.platform);
        if (idx > -1) selectedTagChannels.splice(idx, 1);
      }
    });
  }

  function startAutoScroll() {
    stopAutoScroll();
    autoScrollTimer = setInterval(() => {
      if (!isDragging || !lastMouseEvt) return;

      const rect = scrollContainer.getBoundingClientRect();
      const mouseY = lastMouseEvt.clientY;
      const edgeThreshold = 35;
      const scrollSpeed = 10;

      if (mouseY > rect.bottom - edgeThreshold) {
        scrollContainer.scrollTop += scrollSpeed;
        updateDragSelection();
      } else if (mouseY < rect.top + edgeThreshold) {
        scrollContainer.scrollTop -= scrollSpeed;
        updateDragSelection();
      }
    }, 16);
  }

  function stopAutoScroll() {
    if (autoScrollTimer) {
      clearInterval(autoScrollTimer);
      autoScrollTimer = null;
    }
  }

  // 빈 공간 클릭 시 선택 해제(드래그 직후 클릭은 has-dragged로 거름).
  scrollContainer.addEventListener('click', (e) => {
    if (scrollContainer.classList.contains('has-dragged')) return;
    if (e.target.closest(itemSelector)) return;
    if (selectedTagChannels.length === 0) return;
    scrollContainer.querySelectorAll(`${itemSelector}.selected`).forEach(item => item.classList.remove('selected'));
    selectedTagChannels.length = 0;
  });
}

function toggleSelectAllTagChannels() {
  const items = document.querySelectorAll('.selectable-channel-item');
  if (items.length === 0) return;

  const filtered = fetchedTagChannels.filter(c => currentListPlatformTab === 'all' || c.platform === currentListPlatformTab);
  const isAllSelected = filtered.every(ch => selectedTagChannels.some(s => s.hash === ch.hash && s.platform === ch.platform));

  items.forEach((item) => {
    const hash = item.getAttribute('data-hash');
    const platform = item.getAttribute('data-platform');
    const ch = filtered.find(c => c.hash === hash && c.platform === platform);
    if (!ch) return;

    if (!isAllSelected) {
      if (!selectedTagChannels.some(s => s.hash === ch.hash && s.platform === ch.platform)) {
        selectedTagChannels.push(ch);
      }
      item.classList.add('selected');
    } else {
      const idx2 = selectedTagChannels.findIndex(s => s.hash === ch.hash && s.platform === ch.platform);
      if (idx2 > -1) selectedTagChannels.splice(idx2, 1);
      item.classList.remove('selected');
    }
  });
}

async function confirmAddTagChannels() {
  closeTagNoticeModal();

  // commitChannels로 추가한다(직접 push하면 검증·소유·한도를 건너뜀).
  commitChannels(selectedTagChannels);

  channelInput.value = '';
}

let presetModalChannels = [];
let presetSearchDebounceTimer = null;
let presetSearchToken = 0;
let presetSearchSections = [];
let currentPresetSearchKeywordTab = 'all';
let presetSelectedFilterTab = 'all';

function openPresetModal() {
  let modal = document.getElementById('preset-modal');

  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'preset-modal';
    modal.className = 'preset-modal-backdrop';
    modal.innerHTML = `
      <div class="preset-modal-content preset-modal-content-wide">
        <h3 data-i18n="preset.modalTitle">${t('preset.modalTitle', '프리셋 저장')}</h3>
        <div class="modal-field">
          <label data-i18n="preset.nameLabel">${t('preset.nameLabel', '프리셋 이름')}</label>
          <input type="text" id="preset-name-input" data-i18n-placeholder="preset.namePlaceholder" placeholder="${t('preset.namePlaceholder', '예) 종합게임 스트리머')}" />
        </div>
        <div class="modal-field">
          <label data-i18n="preset.colorLabel">${t('preset.colorLabel', '프리셋 색상')}</label>
          <input type="color" id="preset-color-input" value="#FFFFFF" />
        </div>
        <div class="modal-field">
          <label data-i18n="preset.searchLabel">${t('preset.searchLabel', '채널 검색')}</label>
          <input type="text" id="preset-channel-search-input" data-i18n-placeholder="preset.searchPlaceholder" placeholder="${t('preset.searchPlaceholder', '채널명을 입력하세요')}" autocomplete="off" />
          <div id="preset-search-results" class="preset-search-results"></div>
        </div>
        <div class="modal-field">
          <div class="preset-selected-header">
            <label>${t('preset.selectedChannelsLabel', '추가된 채널')} (<span id="preset-selected-count">0</span>)</label>
            <button type="button" id="preset-clear-selected-btn" class="preset-clear-selected-btn" data-i18n="preset.clearSelected">${t('preset.clearSelected', '전체 삭제')}</button>
          </div>
          <div id="preset-selected-filter-tabs"></div>
          <div id="preset-selected-channels" class="preset-selected-channels"></div>
        </div>
        <div class="modal-actions">
          <button id="preset-import-trigger-btn" data-i18n="button.importPreset">${t('button.importPreset', '가져오기')}</button>
          <div class="modal-actions-right">
            <button id="preset-cancel-btn" data-i18n="preset.cancel">${t('preset.cancel', '취소')}</button>
            <button id="preset-save-confirm-btn" class="primary" data-i18n="preset.save">${t('preset.save', '저장')}</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('preset-cancel-btn').addEventListener('click', () => {
      modal.classList.remove('active');
    });

    document.getElementById('preset-save-confirm-btn').addEventListener('click', confirmSavePreset);
    document.getElementById('preset-import-trigger-btn').addEventListener('click', openPresetImportModal);
    document.getElementById('preset-clear-selected-btn').addEventListener('click', clearPresetModalChannels);

    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('active');
    });

    const searchInput = document.getElementById('preset-channel-search-input');
    searchInput.addEventListener('input', () => {
      const rawValue = searchInput.value;
      if (presetSearchDebounceTimer) clearTimeout(presetSearchDebounceTimer);
      if (splitPresetSearchKeywords(rawValue).length === 0) {
        presetSearchToken++;
        presetSearchSections = [];
        currentPresetSearchKeywordTab = 'all';
        renderPresetSearchResults();
        return;
      }
      presetSearchDebounceTimer = setTimeout(() => fetchPresetSearchResults(rawValue), 250);
    });
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') e.preventDefault();
    });
  }

  presetModalChannels = [...channels];
  document.getElementById('preset-name-input').value = '';
  document.getElementById('preset-color-input').value = '#FFFFFF';
  document.getElementById('preset-channel-search-input').value = '';
  presetSearchSections = [];
  currentPresetSearchKeywordTab = 'all';
  presetSelectedFilterTab = 'all';
  renderPresetSearchResults();
  renderPresetSelectedChannels();
  modal.classList.add('active');
  document.getElementById('preset-name-input').focus();
}

function splitPresetSearchKeywords(input) {
  return String(input || '')
    .split(/[,\s]+/)
    .map(s => s.trim())
    .filter(Boolean);
}

function sameChannel(a, b) {
  return a.platform === b.platform && a.hash === b.hash;
}

function dedupeChannels(list) {
  const seen = new Set();
  return list.filter(ch => {
    const key = `${ch.platform}:${ch.hash}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function fetchPresetSearchResults(rawInput) {
  const myToken = ++presetSearchToken;
  const keywords = splitPresetSearchKeywords(rawInput);

  if (keywords.length === 0) {
    presetSearchSections = [];
    currentPresetSearchKeywordTab = 'all';
    renderPresetSearchResults();
    return;
  }

  const enabledPlatforms = Object.keys(PLATFORM_META)
    .filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p] && typeof PlatformAdapters[p].searchCandidatesByKeyword === 'function');

  const sections = await Promise.all(keywords.map(async (keyword) => {
    const resultsByPlatform = await Promise.all(
      enabledPlatforms.map(p => PlatformAdapters[p].searchCandidatesByKeyword(keyword).catch(() => []))
    );
    return { keyword, results: dedupeChannels(resultsByPlatform.flat()) };
  }));

  if (presetSearchToken !== myToken) return;

  presetSearchSections = sections;
  currentPresetSearchKeywordTab = 'all';
  renderPresetSearchResults();
}

function buildPresetKeywordTabsBar(activeTab, onSelect) {
  const tabs = [
    { key: 'all', label: t('platformTabs.all', '전체') },
    ...presetSearchSections.map(section => ({ key: section.keyword, label: section.keyword }))
  ];
  return buildTabsBar(tabs, activeTab, onSelect, 'search-keyword-tabs');
}

function renderPresetSearchResults() {
  const resultsEl = document.getElementById('preset-search-results');
  if (!resultsEl) return;
  resultsEl.innerHTML = '';

  if (presetSearchSections.length === 0) {
    resultsEl.innerHTML = `<div class="tag-notice-empty">${t('preset.searchEmpty', '검색 결과가 없습니다.')}</div>`;
    return;
  }

  if (presetSearchSections.length > 1) {
    const tabsBar = buildPresetKeywordTabsBar(currentPresetSearchKeywordTab, (tab) => {
      currentPresetSearchKeywordTab = tab;
      renderPresetSearchResults();
    });
    resultsEl.appendChild(tabsBar);
  }

  let items;
  if (currentPresetSearchKeywordTab === 'all') {
    items = dedupeChannels(presetSearchSections.flatMap(section => section.results));
  } else {
    const target = presetSearchSections.find(s => s.keyword === currentPresetSearchKeywordTab);
    items = target ? target.results : [];
  }

  if (items.length === 0) {
    resultsEl.insertAdjacentHTML('beforeend', `<div class="tag-notice-empty">${t('preset.searchEmpty', '검색 결과가 없습니다.')}</div>`);
    return;
  }

  items.forEach(ch => {
    const row = document.createElement('div');
    row.className = 'preset-search-row';
    row.setAttribute('data-platform', ch.platform);
    row.setAttribute('data-hash', ch.hash);
    row.style.setProperty('--item-color', getPlatformColor(ch.platform));

    const badge = document.createElement('span');
    badge.className = 'preset-search-platform-badge';
    badge.textContent = getPlatformLabel(ch.platform);
    row.appendChild(badge);

    const nameEl = document.createElement('span');
    nameEl.className = 'preset-search-name';
    nameEl.textContent = ch.name;
    row.appendChild(nameEl);

    if (ch.live) {
      const liveEl = document.createElement('span');
      liveEl.className = 'preset-search-live-badge';
      liveEl.textContent = t('following.titleLive', '라이브');
      row.appendChild(liveEl);
    }

    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'preset-search-add-btn';
    const already = presetModalChannels.some(c => sameChannel(c, ch));
    addBtn.textContent = already ? t('preset.added', '추가됨') : t('preset.add', '추가');
    addBtn.disabled = already;
    addBtn.addEventListener('click', () => {
      if (presetModalChannels.some(c => sameChannel(c, ch))) return;
      const channelData = { platform: ch.platform, hash: ch.hash, name: ch.name };
      if (ch.broadNo) channelData.broadNo = ch.broadNo;
      presetModalChannels.push(channelData);
      renderPresetSelectedChannels();
      addBtn.textContent = t('preset.added', '추가됨');
      addBtn.disabled = true;
    });
    row.appendChild(addBtn);

    resultsEl.appendChild(row);
  });
}

// liveOpenDate 앞 10자리를 YYMMDD로 자른다(문자열 처리라 타임존 오차 없음).
function formatBroadcastDateShort(dateStr) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(dateStr || ''));
  return m ? m[1].slice(2) + m[2] + m[3] : '';
}

// VOD 칩은 "스트리머명 YYMMDD", 날짜를 모르면 이름만.
function getPresetChipLabel(ch) {
  if (!ch.isVod) return ch.name;
  const dateSuffix = formatBroadcastDateShort(ch.broadcastDate);
  return dateSuffix ? `${ch.name} ${dateSuffix}` : ch.name;
}

function renderPresetSelectedChannels() {
  const wrap = document.getElementById('preset-selected-channels');
  const countEl = document.getElementById('preset-selected-count');
  const tabsWrap = document.getElementById('preset-selected-filter-tabs');
  if (countEl) countEl.textContent = String(presetModalChannels.length);

  if (tabsWrap) {
    tabsWrap.innerHTML = '';
    if (presetModalChannels.length > 0) {
      const tabs = [
        { key: 'all', label: t('platformTabs.all', '전체'), color: '#FFC800' },
        { key: 'live', label: t('following.titleLive', '라이브'), color: '#FFC800' },
        { key: 'vod', label: t('input.recentTabVod', 'VOD'), color: '#FFC800' }
      ];
      tabsWrap.appendChild(buildTabsBar(tabs, presetSelectedFilterTab, (key) => {
        presetSelectedFilterTab = key;
        renderPresetSelectedChannels();
      }, 'preset-selected-filter-tabs'));
    }
  }

  if (!wrap) return;
  wrap.innerHTML = '';

  if (presetModalChannels.length === 0) {
    wrap.innerHTML = `<div class="tag-notice-empty">${t('preset.noChannels', '저장할 채널이 없습니다.')}</div>`;
    return;
  }

  const filteredChannels = presetModalChannels.filter(ch => {
    if (presetSelectedFilterTab === 'live') return !ch.isVod;
    if (presetSelectedFilterTab === 'vod') return !!ch.isVod;
    return true;
  });

  if (filteredChannels.length === 0) {
    wrap.innerHTML = `<div class="tag-notice-empty">${t('preset.noChannelsInTab', '이 분류에 해당하는 채널이 없습니다.')}</div>`;
    return;
  }

  filteredChannels.forEach(ch => {
    const chip = document.createElement('div');
    chip.className = 'preset-selected-chip';
    chip.style.setProperty('--item-color', getPlatformColor(ch.platform));

    const nameSpan = document.createElement('span');
    nameSpan.textContent = getPresetChipLabel(ch);
    chip.appendChild(nameSpan);

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'preset-selected-remove-btn';
    removeBtn.innerHTML = '✕';
    removeBtn.addEventListener('click', () => {
      presetModalChannels = presetModalChannels.filter(c => !sameChannel(c, ch));
      renderPresetSelectedChannels();

      const resultsEl = document.getElementById('preset-search-results');
      const row = resultsEl && resultsEl.querySelector(`.preset-search-row[data-platform="${ch.platform}"][data-hash="${CSS.escape(ch.hash)}"]`);
      const btn = row && row.querySelector('.preset-search-add-btn');
      if (btn) {
        btn.disabled = false;
        btn.textContent = t('preset.add', '추가');
      }
    });
    chip.appendChild(removeBtn);

    wrap.appendChild(chip);
  });
}

function clearPresetModalChannels() {
  if (presetModalChannels.length === 0) return;
  presetModalChannels = [];
  renderPresetSelectedChannels();
  renderPresetSearchResults();
}

function confirmSavePreset() {
  const nameInput = document.getElementById('preset-name-input');
  const colorInput = document.getElementById('preset-color-input');
  const name = nameInput.value.trim();
  const color = colorInput.value || '#ffffff';

  if (!name) {
    showPresetNotice(t('preset.nameRequired', '프리셋 이름을 입력해주세요.'));
    return;
  }

  if (presetModalChannels.length === 0) {
    showPresetNotice(t('preset.noChannels', '저장할 채널이 없습니다.'));
    return;
  }

  if (presets.some(p => p.name === name)) {
    showPresetNotice(t('preset.duplicateName', '이미 같은 이름의 프리셋이 있습니다.'));
    return;
  }

  const newPreset = {
    id: Date.now(),
    name: name,
    color: color,
    channels: [...presetModalChannels]
  };

  presets.push(newPreset);
  savePresetsToStorage();
  renderPresets();

  document.getElementById('preset-modal').classList.remove('active');
}

function getContrastTextColor(hexColor) {
  let hex = hexColor.replace('#', '');

  if (hex.length === 3) {
    hex = hex.split('').map(c => c + c).join('');
  }

  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  return luminance > 0.5 ? '#000000' : '#ffffff';
}

function renderPresets() {
  if (!presetContainer) return;

  presetContainer.innerHTML = '';

  presets.forEach(preset => {
    const item = document.createElement('div');
    item.className = 'preset-item';
    item.setAttribute('data-preset-id', String(preset.id));

    const bgColor = preset.color || '#ffffff';
    const textColor = getContrastTextColor(bgColor);

    item.style.backgroundColor = bgColor;
    item.style.color = textColor;

    const nameSpan = document.createElement('span');
    nameSpan.className = 'preset-name';
    nameSpan.textContent = preset.name;
    nameSpan.addEventListener('click', () => loadPreset(preset.id));

    const shareBtn = document.createElement('button');
    shareBtn.type = 'button';
    shareBtn.className = 'preset-share-btn';
    shareBtn.innerHTML = `
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="18" cy="5" r="3"></circle>
        <circle cx="6" cy="12" r="3"></circle>
        <circle cx="18" cy="19" r="3"></circle>
        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
      </svg>
    `;
    shareBtn.style.color = textColor;
    shareBtn.title = t('preset.shareTitle', '프리셋 공유');
    shareBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      openPresetShareModal(preset.id);
    });

    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'preset-delete-btn';
    deleteBtn.innerHTML = '✕';
    deleteBtn.style.color = textColor;
    deleteBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      deletePreset(preset.id);
    });

    item.appendChild(nameSpan);
    item.appendChild(shareBtn);
    item.appendChild(deleteBtn);
    presetContainer.appendChild(item);
  });
}

// VOD는 라이브 여부가 아니라 영상이 여전히 존재하는지 확인한다.
async function getFreshVodChannelData(ch) {
  if (ch.platform === 'chzzk') {
    try {
      const detail = await PlatformAdapters.chzzk.getVodDetail(ch.hash);
      return detail ? { ...ch } : null;
    } catch (e) {}
    return null;
  }

  if (ch.platform === 'youtube') {
    try {
      const meta = await PlatformAdapters.youtube._resolveVideoMeta(ch.videoId || ch.hash);
      if (meta) return { ...ch, name: meta.channelName || ch.name, title: meta.title || ch.title };
    } catch (e) {}
    return null;
  }

  // 숲은 VOD 미지원 — 그대로 통과.
  return { ...ch };
}

async function getFreshLiveChannelData(ch) {
  if (ch.isVod) return getFreshVodChannelData(ch);

  if (ch.platform === 'chzzk') {
    const isLive = await checkChzzkLiveByChannelId(ch.hash);
    return isLive ? { ...ch } : null;
  }

  if (ch.platform === 'soop') {
    try {
      const fresh = await PlatformAdapters.soop.searchChannelById(ch.hash);
      if (fresh && fresh.broadNo) return { ...ch, name: fresh.name || ch.name, broadNo: fresh.broadNo };
    } catch (e) {}
    return null;
  }

  if (ch.platform === 'youtube') {
    try {
      const resolved = await PlatformAdapters.youtube._resolveByChannelId(ch.hash);
      if (resolved && resolved.videoId) return { ...ch, name: resolved.name || ch.name, videoId: resolved.videoId };
    } catch (e) {}
    return null;
  }

  return { ...ch };
}

async function loadPreset(presetId) {
  const target = presets.find(p => p.id === presetId);
  if (!target) return;

  const presetChannels = target.channels || [];
  if (presetChannels.length === 0) return;

  const presetItemEl = presetContainer && presetContainer.querySelector(`.preset-item[data-preset-id="${presetId}"]`);
  if (presetItemEl) presetItemEl.classList.add('preset-loading');

  // 라이브 확인 동안 로딩 오버레이를 띄우고, 실패하면 원래 화면으로 복원한다.
  let loadingOverlay = null;
  if (videoGrid) {
    loadingOverlay = document.createElement('div');
    loadingOverlay.className = 'preset-loading-overlay';
    loadingOverlay.textContent = t('preset.loading', '불러오는 중...');
    videoGrid.appendChild(loadingOverlay);
  }

  // VOD는 존재 여부, 라이브는 방송 여부를 확인해 혼합 프리셋을 복원한다.
  const freshResults = await Promise.all(presetChannels.map(getFreshLiveChannelData));

  if (presetItemEl) presetItemEl.classList.remove('preset-loading');
  if (loadingOverlay) loadingOverlay.remove();

  const availableChannels = freshResults.filter(Boolean);
  if (availableChannels.length === 0) {
    showPresetNotice(t('preset.noLiveChannels', '불러올 수 있는 채널이 없습니다. (라이브 종료 또는 VOD 삭제)'));
    return;
  }

  // 이 창 채널만 프리셋으로 바꾼다. 다른 창에 있는 프리셋 채널은 이 창으로 옮긴다. 상한은 모든 창 합계(§3.3).
  const presetHashSet = new Set(availableChannels.map((c) => c.hash));
  const otherWindowChannels = channels.filter((c) => !isChannelOwnedByThisWindow(c.hash) && !presetHashSet.has(c.hash));

  const limitedChannels = availableChannels.slice(0, Math.max(0, getMaxChannels() - otherWindowChannels.length));
  if (limitedChannels.length === 0) {
    notifyChannelLimitReached();
    return;
  }

  clearVideoGrid();
  controlUnlockedHash = null;
  channels = [...otherWindowChannels, ...limitedChannels];
  displayChannels = [...otherWindowChannels, ...limitedChannels];
  channelAddOrder = channels.map(c => c.hash);
  mainChannel = getFirstVideoChannelHash(limitedChannels);
  activeChatChannel = limitedChannels[0].hash;
  saveChannelsAfterClaim(limitedChannels.map((c) => c.hash));
  renderAll();
  if (limitedChannels.length < availableChannels.length) notifyChannelLimitReached();
}

function deletePreset(presetId) {
  presets = presets.filter(p => p.id !== presetId);
  savePresetsToStorage();
  renderPresets();
}

function clearAllPresets() {
  if (presets.length === 0) return;
  showPresetConfirm(t('preset.clearAllConfirm', '저장된 모든 프리셋을 삭제하시겠습니까?'), () => {
    presets = [];
    savePresetsToStorage();
    renderPresets();
  });
}

function createSimpleModal(id, { windowClass = '', titleKey, titleFallback, bodyHtml, footerHtml }) {
  const modal = document.createElement('div');
  modal.id = id;
  modal.className = 'tag-notice-backdrop';
  modal.innerHTML = `
    <div class="tag-notice-window${windowClass ? ' ' + windowClass : ''}">
      <div class="tag-notice-header">
        <h3 data-i18n="${titleKey}">${t(titleKey, titleFallback)}</h3>
        <button class="tag-notice-close" id="${id}-close-btn">✕</button>
      </div>
      <div class="tag-notice-body">${bodyHtml}</div>
      <div class="tag-notice-footer" style="justify-content:flex-end; gap:8px;">${footerHtml}</div>
    </div>
  `;
  document.body.appendChild(modal);

  const close = () => modal.classList.remove('active');
  document.getElementById(`${id}-close-btn`).addEventListener('click', close);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) close();
  });

  return modal;
}

function ensurePresetNoticeModal() {
  let modal = document.getElementById('preset-notice-modal');
  if (modal) return modal;

  modal = createSimpleModal('preset-notice-modal', {
    windowClass: 'preset-notice-window',
    titleKey: 'preset.noticeTitle',
    titleFallback: '안내',
    bodyHtml: `<p id="preset-notice-message" class="preset-notice-message"></p>`,
    footerHtml: `<button id="preset-notice-ok-btn" class="preset-modal-primary-btn" data-i18n="preset.noticeOk">${t('preset.noticeOk', '확인')}</button>`
  });

  document.getElementById('preset-notice-ok-btn').addEventListener('click', () => modal.classList.remove('active'));

  return modal;
}

function showPresetNotice(message) {
  const modal = ensurePresetNoticeModal();
  document.getElementById('preset-notice-message').textContent = message;
  modal.classList.add('active');
}

function ensurePresetConfirmModal() {
  let modal = document.getElementById('preset-confirm-modal');
  if (modal) return modal;

  modal = createSimpleModal('preset-confirm-modal', {
    windowClass: 'preset-notice-window',
    titleKey: 'preset.noticeTitle',
    titleFallback: '안내',
    bodyHtml: `<p id="preset-confirm-message" class="preset-notice-message"></p>`,
    footerHtml: `
      <button id="preset-confirm-cancel-btn" class="preset-modal-cancel-btn" data-i18n-title="preset.cancel" title="${t('preset.cancel', '취소')}">✕</button>
      <button id="preset-confirm-ok-btn" class="preset-modal-primary-btn" data-i18n="preset.noticeOk">${t('preset.noticeOk', '확인')}</button>
    `
  });

  document.getElementById('preset-confirm-cancel-btn').addEventListener('click', () => modal.classList.remove('active'));

  return modal;
}

function showPresetConfirm(message, onConfirm) {
  const modal = ensurePresetConfirmModal();
  document.getElementById('preset-confirm-message').textContent = message;
  document.getElementById('preset-confirm-ok-btn').onclick = () => {
    modal.classList.remove('active');
    onConfirm();
  };
  modal.classList.add('active');
}

// CE1: 예전 포맷(객체 JSON + base64, 해독만 지원). CE2: [platform, hash, name, broadNo?] 배열 + gzip + base64.
const PRESET_SHARE_CODE_PREFIX = 'CE1:';
const PRESET_SHARE_CODE_PREFIX_V2 = 'CE2:';

const PRESET_SHARE_PLATFORM_CODE = { chzzk: 'c', soop: 's', youtube: 'y', twitch: 't' };
const PRESET_SHARE_CODE_PLATFORM = { c: 'chzzk', s: 'soop', y: 'youtube', t: 'twitch' };

function toShareChannelEntry(c) {
  const entry = { platform: c.platform, hash: c.hash, name: c.name };
  if (c.broadNo) entry.broadNo = c.broadNo;
  // VOD 필드도 담아야 가져온 쪽에서 VOD로 재검증하고 칩도 날짜까지 보인다.
  if (c.isVod) entry.isVod = true;
  if (c.videoId) entry.videoId = c.videoId;
  if (c.channelId) entry.channelId = c.channelId;
  if (typeof c.startSec === 'number') entry.startSec = c.startSec;
  if (c.broadcastDate) entry.broadcastDate = c.broadcastDate;
  return entry;
}

function toCompactShareChannelEntry(c) {
  const platform = PRESET_SHARE_PLATFORM_CODE[c.platform] || c.platform;
  const arr = [platform, c.hash, c.name];
  const tail = [c.broadNo || null, c.isVod ? 1 : 0, c.videoId || null, c.channelId || null, typeof c.startSec === 'number' ? c.startSec : null, c.broadcastDate || null];
  while (tail.length && (tail[tail.length - 1] === null || tail[tail.length - 1] === 0)) tail.pop();
  return arr.concat(tail);
}

function fromCompactShareChannelEntry(arr) {
  if (!Array.isArray(arr) || arr.length < 3) return null;
  const [code, hash, name, broadNo, isVodFlag, videoId, channelId, startSec, broadcastDate] = arr;
  const platform = PRESET_SHARE_CODE_PLATFORM[code] || code;
  if (!platform || !hash || !name) return null;
  const entry = { platform, hash, name };
  if (broadNo) entry.broadNo = broadNo;
  if (isVodFlag) entry.isVod = true;
  if (videoId) entry.videoId = videoId;
  if (channelId) entry.channelId = channelId;
  if (typeof startSec === 'number') entry.startSec = startSec;
  if (broadcastDate) entry.broadcastDate = broadcastDate;
  return entry;
}

async function gzipTextToBase64(text) {
  const bytes = new TextEncoder().encode(text);
  const stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'));
  const compressed = new Uint8Array(await new Response(stream).arrayBuffer());
  let binary = '';
  compressed.forEach((b) => { binary += String.fromCharCode(b); });
  return btoa(binary);
}

async function gzipBase64ToText(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  const decompressed = await new Response(stream).arrayBuffer();
  return new TextDecoder().decode(decompressed);
}

async function encodePresetShareCode(preset) {
  const payload = {
    n: preset.name,
    c: preset.color,
    ch: (preset.channels || []).map(toCompactShareChannelEntry)
  };
  const json = JSON.stringify(payload);
  try {
    const b64 = await gzipTextToBase64(json);
    return PRESET_SHARE_CODE_PREFIX_V2 + b64;
  } catch (e) {
    // CompressionStream이 없는 환경이면 예전 방식으로 폴백.
    const legacyPayload = { name: preset.name, color: preset.color, channels: (preset.channels || []).map(toShareChannelEntry) };
    return PRESET_SHARE_CODE_PREFIX + btoa(unescape(encodeURIComponent(JSON.stringify(legacyPayload))));
  }
}

async function decodePresetShareCode(code) {
  const trimmed = String(code || '').trim();

  if (trimmed.startsWith(PRESET_SHARE_CODE_PREFIX_V2)) {
    try {
      const json = await gzipBase64ToText(trimmed.slice(PRESET_SHARE_CODE_PREFIX_V2.length));
      const data = JSON.parse(json);
      if (!data || typeof data.n !== 'string' || !Array.isArray(data.ch)) return null;

      const channels = data.ch.map(fromCompactShareChannelEntry).filter(Boolean);
      if (channels.length === 0) return null;

      return { name: data.n, color: typeof data.c === 'string' ? data.c : '#FFC800', channels };
    } catch (e) {
      return null;
    }
  }

  if (trimmed.startsWith(PRESET_SHARE_CODE_PREFIX)) {
    try {
      const json = decodeURIComponent(escape(atob(trimmed.slice(PRESET_SHARE_CODE_PREFIX.length))));
      const data = JSON.parse(json);
      if (!data || typeof data.name !== 'string' || !Array.isArray(data.channels)) return null;

      const channels = data.channels
        .filter(c => c && c.platform && c.hash && c.name)
        .map(toShareChannelEntry);
      if (channels.length === 0) return null;

      return { name: data.name, color: typeof data.color === 'string' ? data.color : '#FFC800', channels };
    } catch (e) {
      return null;
    }
  }

  return null;
}

async function copyTextToClipboard(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (e) {}

  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (e) {
    return false;
  }
}

function ensurePresetShareModal() {
  let modal = document.getElementById('preset-share-modal');
  if (modal) return modal;

  return createSimpleModal('preset-share-modal', {
    windowClass: 'preset-share-window',
    titleKey: 'preset.shareTitle',
    titleFallback: '프리셋 공유',
    bodyHtml: `<ul id="preset-share-channel-list" class="preset-overwrite-channel-list preset-share-channel-list"></ul><textarea id="preset-share-code" class="preset-share-textarea" readonly></textarea>`,
    footerHtml: `<button id="preset-share-copy-btn" class="preset-modal-primary-btn" data-i18n="preset.copyCode">${t('preset.copyCode', '코드 복사')}</button>`
  });
}

async function openPresetShareModal(presetId) {
  const preset = presets.find(p => p.id === presetId);
  if (!preset) return;

  const modal = ensurePresetShareModal();
  const textarea = document.getElementById('preset-share-code');
  textarea.value = '';
  renderPresetOverwriteChannelList(document.getElementById('preset-share-channel-list'), preset.channels);

  const copyBtn = document.getElementById('preset-share-copy-btn');
  copyBtn.textContent = t('preset.copyCode', '코드 복사');
  // gzip 인코딩이 비동기라 복사 시점의 textarea 값을 읽는다.
  copyBtn.onclick = async () => {
    const ok = await copyTextToClipboard(textarea.value);
    copyBtn.textContent = ok ? t('preset.copied', '복사됨!') : t('preset.copyFailed', '복사 실패');
    setTimeout(() => { copyBtn.textContent = t('preset.copyCode', '코드 복사'); }, 1500);
  };

  modal.classList.add('active');
  textarea.focus();

  textarea.value = await encodePresetShareCode(preset);
  textarea.select();
}

function ensurePresetImportModal() {
  let modal = document.getElementById('preset-import-modal');
  if (modal) return modal;

  modal = createSimpleModal('preset-import-modal', {
    windowClass: 'preset-share-window',
    titleKey: 'preset.importTitle',
    titleFallback: '프리셋 가져오기',
    bodyHtml: `<textarea id="preset-import-code" class="preset-share-textarea" data-i18n-placeholder="preset.importPlaceholder" placeholder="${t('preset.importPlaceholder', '공유받은 코드를 붙여넣으세요')}"></textarea><ul id="preset-import-channel-list" class="preset-overwrite-channel-list preset-share-channel-list"></ul>`,
    footerHtml: `<button id="preset-import-confirm-btn" class="preset-modal-primary-btn" data-i18n="preset.importConfirm">${t('preset.importConfirm', '가져오기')}</button>`
  });

  document.getElementById('preset-import-confirm-btn').addEventListener('click', confirmImportPreset);
  // 가져오기 전 포함 채널 미리보기. 늦게 끝난 옛 입력 결과가 덮어쓰지 않게 입력값을 다시 확인한다.
  const importInput = document.getElementById('preset-import-code');
  importInput.addEventListener('input', async () => {
    const code = importInput.value;
    const decoded = code.trim() ? await decodePresetShareCode(code) : null;
    if (importInput.value !== code) return;
    renderPresetOverwriteChannelList(document.getElementById('preset-import-channel-list'), decoded ? decoded.channels : []);
  });

  return modal;
}

function openPresetImportModal() {
  const modal = ensurePresetImportModal();
  document.getElementById('preset-import-code').value = '';
  renderPresetOverwriteChannelList(document.getElementById('preset-import-channel-list'), []);
  modal.classList.add('active');
  document.getElementById('preset-import-code').focus();
}

function ensurePresetOverwriteModal() {
  let modal = document.getElementById('preset-overwrite-modal');
  if (modal) return modal;

  modal = createSimpleModal('preset-overwrite-modal', {
    windowClass: 'preset-share-window',
    titleKey: 'preset.noticeTitle',
    titleFallback: '안내',
    bodyHtml: `
      <p class="preset-notice-message" data-i18n="preset.overwriteConfirm">이 프리셋을 덮어쓰시겠습니까?</p>
      <div class="preset-overwrite-compare">
        <div class="preset-overwrite-col">
          <div class="preset-overwrite-col-title" id="preset-overwrite-old-name"></div>
          <ul class="preset-overwrite-channel-list" id="preset-overwrite-old-list"></ul>
        </div>
        <div class="preset-overwrite-arrow">→</div>
        <div class="preset-overwrite-col">
          <div class="preset-overwrite-col-title" id="preset-overwrite-new-name"></div>
          <ul class="preset-overwrite-channel-list" id="preset-overwrite-new-list"></ul>
        </div>
      </div>
    `,
    footerHtml: `
      <button id="preset-overwrite-cancel-btn" class="preset-modal-cancel-btn" data-i18n-title="preset.cancel" title="${t('preset.cancel', '취소')}">✕</button>
      <button id="preset-overwrite-confirm-btn" class="preset-modal-primary-btn" data-i18n="preset.overwriteButton">${t('preset.overwriteButton', '덮어쓰기')}</button>
    `
  });

  document.getElementById('preset-overwrite-cancel-btn').addEventListener('click', () => modal.classList.remove('active'));

  return modal;
}

// 채널 추가 모달 칩 클래스를 그대로 재사용한다.
function renderPresetOverwriteChannelList(listEl, channels) {
  listEl.innerHTML = '';
  (channels || []).forEach(ch => {
    const li = document.createElement('li');
    li.className = 'preset-selected-chip';
    li.style.setProperty('--item-color', getPlatformColor(ch.platform));
    li.textContent = ch.name || ch.hash;
    listEl.appendChild(li);
  });
}

// 기존/새 프리셋 구성을 나란히 보여주고 확인 시 덮어쓴다(같은 이름은 하나만).
function showPresetOverwriteConfirm(existingPreset, newPreset, onConfirm) {
  const modal = ensurePresetOverwriteModal();
  document.getElementById('preset-overwrite-old-name').textContent = existingPreset.name;
  document.getElementById('preset-overwrite-new-name').textContent = newPreset.name;
  renderPresetOverwriteChannelList(document.getElementById('preset-overwrite-old-list'), existingPreset.channels);
  renderPresetOverwriteChannelList(document.getElementById('preset-overwrite-new-list'), newPreset.channels);
  document.getElementById('preset-overwrite-confirm-btn').onclick = () => {
    modal.classList.remove('active');
    onConfirm();
  };
  modal.classList.add('active');
}

async function confirmImportPreset() {
  const codeInput = document.getElementById('preset-import-code');
  const decoded = await decodePresetShareCode(codeInput.value);
  if (!decoded) {
    showPresetNotice(t('preset.importFailed', '유효하지 않은 프리셋 코드입니다.'));
    return;
  }

  const existing = presets.find(p => p.name === decoded.name);
  if (existing) {
    showPresetOverwriteConfirm(existing, decoded, () => {
      existing.color = decoded.color;
      existing.channels = decoded.channels;
      savePresetsToStorage();
      renderPresets();
      document.getElementById('preset-import-modal').classList.remove('active');
      document.getElementById('preset-modal')?.classList.remove('active');
      loadPreset(existing.id);
    });
    return;
  }

  const importedPreset = { id: Date.now(), name: decoded.name, color: decoded.color, channels: decoded.channels };
  presets.push(importedPreset);
  savePresetsToStorage();
  renderPresets();

  document.getElementById('preset-import-modal').classList.remove('active');
  document.getElementById('preset-modal')?.classList.remove('active');
  loadPreset(importedPreset.id);
}

function toggleChat() {
  chatVisible = !chatVisible;
  chatSidebar?.classList.toggle('active', chatVisible);
  chatToggleBtn?.classList.toggle('active', chatVisible);
  saveChatVisibleToStorage();
  // 채팅을 닫으면 사이드 분할 빈 자리와 헤더 덮개 띠도 거둬야 해서 syncChatVisibility가 처리한다.
  syncChatVisibility();
  renderVideo();

  if (!chatVisible) {
    if (document.activeElement && typeof document.activeElement.blur === 'function') {
      document.activeElement.blur();
    }
    window.focus();
    if (document.body && typeof document.body.focus === 'function') {
      document.body.focus();
    }
  }
}

// 사이드바 너비 트랜지션이 끝난 뒤 썸네일 크기를 한 번 더 계산한다.
chatSidebar?.addEventListener('transitionend', (e) => {
  if (e.propertyName === 'width') renderVideo();
});

function saveChatVisibleToStorage() {
  saveWindowState();
  if (!isRepresentativeWindow()) return;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ my_chat_visible: chatVisible });
  } else {
    localStorage.setItem('my_chat_visible', chatVisible ? '1' : '0');
  }
}

let isMouseOverChatFrame = false;
const chatFrameContainerForShortcut = document.getElementById('chat-frame-container');
if (chatFrameContainerForShortcut) {
  chatFrameContainerForShortcut.addEventListener('mouseenter', () => { isMouseOverChatFrame = true; });
  chatFrameContainerForShortcut.addEventListener('mouseleave', () => { isMouseOverChatFrame = false; });
}

// ── 조작 키 ── mySetting.shortcutKeys(my_profile로 창 간 공유). 글자는 소문자, 그 외는 KeyboardEvent.key, ''는 해제.
// 다른 기능이 쓰는 키는 고를 수 없다. useCode: 방송 사이트 페이지용(multiview_trigger.js) — code로 저장하며 대시보드 키와 겹쳐도 됨.
const SHORTCUT_ACTIONS = [
  { id: 'trayAdd', defaultKey: 'AltLeft', useCode: true, labelKey: 'settings.shortcutTrayAdd', label: '멀티뷰 트레이' },
  { id: 'grid', defaultKey: 'z', labelKey: 'settings.shortcutGrid', label: '그리드 레이아웃' },
  { id: 'mainSub', defaultKey: 'x', labelKey: 'settings.shortcutMainSub', label: '메인-서브 레이아웃' },
  { id: 'chat', defaultKey: 'c', labelKey: 'settings.shortcutChat', label: '채팅 표시' },
  { id: 'search', defaultKey: '/', labelKey: 'settings.shortcutSearch', label: '빠른 검색' },
  { id: 'settings', defaultKey: 'v', labelKey: 'settings.shortcutSettings', label: '설정 열기' },
  { id: 'audioPanel', defaultKey: '`', labelKey: 'settings.shortcutAudioPanel', label: '오디오 패널' },
  { id: 'queue', defaultKey: '.', labelKey: 'settings.shortcutQueue', label: '대기열' },
  { id: 'following', defaultKey: 'f', labelKey: 'settings.shortcutFollowing', label: '팔로잉 목록' },
  { id: 'liveSync', defaultKey: 's', labelKey: 'settings.shortcutLiveSync', label: '라이브 싱크 맞추기' }
];
let isCapturingShortcutKey = false;

function normalizeShortcutKey(key) {
  if (typeof key !== 'string' || !key) return '';
  return key.length === 1 ? key.toLowerCase() : key;
}

function isAssignableShortcutKey(key) {
  if (key.length === 1) return key !== ' ';
  return /^F([1-9]|1[0-2])$/.test(key);
}

function getShortcutKey(actionId) {
  const saved = mySetting.shortcutKeys;
  if (saved && typeof saved[actionId] === 'string') return saved[actionId];
  const action = SHORTCUT_ACTIONS.find((a) => a.id === actionId);
  return action ? action.defaultKey : '';
}

// 수정 키 없이 눌린 키의 조작. 없으면 null.
function findShortcutAction(e) {
  if (isCapturingShortcutKey || e.ctrlKey || e.metaKey || e.altKey) return null;
  const key = normalizeShortcutKey(e.key);
  if (!key) return null;
  const action = SHORTCUT_ACTIONS.find((a) => !a.useCode && getShortcutKey(a.id) === key);
  return action ? action.id : null;
}

const SHORTCUT_CODE_LABELS = {
  AltLeft: 'Left Alt', AltRight: 'Right Alt', ControlLeft: 'Left Ctrl', ControlRight: 'Right Ctrl',
  ShiftLeft: 'Left Shift', ShiftRight: 'Right Shift', Space: 'Space', Backquote: '`'
};

function formatShortcutKey(key, useCode) {
  if (!key) return t('settings.shortcutNone', '없음');
  if (useCode) {
    if (SHORTCUT_CODE_LABELS[key]) return SHORTCUT_CODE_LABELS[key];
    const m = key.match(/^(?:Key|Digit|Numpad)(.+)$/);
    return m ? m[1] : key;
  }
  return key.length === 1 ? key.toUpperCase() : key;
}

function setShortcutKey(actionId, key) {
  const next = {};
  SHORTCUT_ACTIONS.forEach((a) => { next[a.id] = getShortcutKey(a.id); });
  // 같은 키를 쓰던 다른 조작은 해제한다(useCode 제외).
  const changed = SHORTCUT_ACTIONS.find((a) => a.id === actionId);
  if (key && !changed.useCode) {
    SHORTCUT_ACTIONS.forEach((a) => { if (a.id !== actionId && !a.useCode && next[a.id] === key) next[a.id] = ''; });
  }
  next[actionId] = key;
  mySetting.shortcutKeys = next;
  saveSetting();
  renderShortcutKeyList();
}

function renderSearchPlatformOrderList() {
  const list = document.getElementById('search-platform-order-list');
  if (!list) return;
  list.innerHTML = '';
  const order = getSearchPlatformOrder();
  order.forEach((platform, index) => {
    const row = document.createElement('div');
    row.className = 'yt-settings-row search-platform-order-row';

    const label = document.createElement('span');
    label.className = 'yt-settings-label';
    const dot = document.createElement('span');
    dot.className = 'search-platform-order-dot';
    dot.style.backgroundColor = getPlatformColor(platform);
    label.appendChild(dot);
    label.appendChild(document.createTextNode(`${index + 1}. ${getPlatformLabel(platform)}`));
    row.appendChild(label);

    const buttons = document.createElement('div');
    buttons.className = 'search-platform-order-buttons';
    [
      { delta: -1, text: '▲', disabled: index === 0, title: t('settings.searchOrderUp', '위로') },
      { delta: 1, text: '▼', disabled: index === order.length - 1, title: t('settings.searchOrderDown', '아래로') }
    ].forEach(({ delta, text, disabled, title }) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'search-platform-order-btn';
      btn.textContent = text;
      btn.title = title;
      btn.disabled = disabled;
      btn.addEventListener('click', () => {
        if (moveSearchPlatformOrder(platform, delta)) renderSearchPlatformOrderList();
      });
      buttons.appendChild(btn);
    });
    row.appendChild(buttons);
    list.appendChild(row);
  });
}

function renderShortcutKeyList() {
  const list = document.getElementById('shortcut-key-list');
  if (!list) return;
  list.innerHTML = '';
  SHORTCUT_ACTIONS.forEach((action) => {
    const row = document.createElement('div');
    row.className = 'yt-settings-row';
    const label = document.createElement('span');
    label.className = 'yt-settings-label';
    label.textContent = t(action.labelKey, action.label);
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'yt-settings-select shortcut-key-btn';
    btn.textContent = formatShortcutKey(getShortcutKey(action.id), action.useCode);
    btn.addEventListener('click', () => captureShortcutKey(action.id, btn));
    row.append(label, btn);
    list.appendChild(row);
  });
}

// 다음 키 입력을 그 조작 키로 쓴다. Esc 취소, Backspace/Delete 해제.
function captureShortcutKey(actionId, btn) {
  if (isCapturingShortcutKey) return;
  isCapturingShortcutKey = true;
  btn.classList.add('capturing');
  btn.textContent = t('settings.shortcutPressKey', '키를 누르세요');
  const finish = () => {
    isCapturingShortcutKey = false;
    window.removeEventListener('keydown', onKey, true);
    document.removeEventListener('mousedown', onMouseDown, true);
  };
  const useCode = !!SHORTCUT_ACTIONS.find((a) => a.id === actionId)?.useCode;
  const onKey = (e) => {
    // 캡처 단계에서 막아 다른 키 처리로 새지 않게 한다.
    e.preventDefault();
    e.stopPropagation();
    if (e.key === 'Escape' || e.key === 'Esc') {
      finish();
      renderShortcutKeyList();
      return;
    }
    if (e.key === 'Backspace' || e.key === 'Delete') {
      finish();
      setShortcutKey(actionId, '');
      return;
    }
    if (useCode) {
      // 방송 사이트용 키는 수정 키 하나도 받는다.
      if (!e.code || /^(Arrow|Enter|NumpadEnter|Tab|Meta|OS|CapsLock)/.test(e.code)) return;
      finish();
      setShortcutKey(actionId, e.code);
      return;
    }
    if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock'].includes(e.key)) return;
    const key = normalizeShortcutKey(e.key);
    if (e.ctrlKey || e.metaKey || e.altKey || !isAssignableShortcutKey(key)) return; // 못 쓰는 키는 무시하고 계속 기다린다
    finish();
    setShortcutKey(actionId, key);
  };
  const onMouseDown = (e) => {
    if (e.target === btn) return;
    finish();
    renderShortcutKeyList();
  };
  window.addEventListener('keydown', onKey, true);
  document.addEventListener('mousedown', onMouseDown, true);
}

function resetShortcutKeys() {
  mySetting.shortcutKeys = {};
  saveSetting();
  renderShortcutKeyList();
}

document.addEventListener('keydown', (e) => {
  if (findShortcutAction(e) !== 'chat') return;
  if (isMouseOverChatFrame) return;

  const active = document.activeElement;
  const isTyping = active && (
    active.tagName === 'INPUT' ||
    active.tagName === 'TEXTAREA' ||
    active.isContentEditable
  );
  if (isTyping) return;

  toggleChat();
});

const channelInputWrapper = document.getElementById('channel-input-wrapper');
const inputsContainer = document.querySelector('.inputs');
const addChannelBtnRef = document.getElementById('add-btn');

function openQuickSearch() {
  if (!channelInputWrapper) return;
  channelInputWrapper.classList.add('quick-search-active');
  channelInput && channelInput.focus();
}

function closeQuickSearch() {
  if (!channelInputWrapper) return;
  if (!channelInputWrapper.classList.contains('quick-search-active')) return;
  channelInputWrapper.classList.remove('quick-search-active');
  channelInput && channelInput.blur();
}

document.addEventListener('mousedown', (e) => {
  if (!channelInputWrapper || !channelInputWrapper.classList.contains('quick-search-active')) return;
  if (e.target.closest('#channel-input-wrapper')) return;
  closeQuickSearch();
});

const fsModeToolbarRef = document.getElementById('fs-mode-toolbar');

function openFsQuickSearch() {
  const appContainer = document.getElementById('app-container');
  if (!appContainer || !fsModeToolbarRef || !channelInputWrapper) return;
  if (!chatVisible) {
    toggleChat();
  }
  fsModeToolbarRef.appendChild(channelInputWrapper);
  appContainer.classList.add('fs-search-active');
  channelInput && channelInput.focus();
}

function closeFsQuickSearch() {
  const appContainer = document.getElementById('app-container');
  if (!appContainer || !appContainer.classList.contains('fs-search-active')) return;
  appContainer.classList.remove('fs-search-active');
  if (inputsContainer && addChannelBtnRef) {
    inputsContainer.insertBefore(channelInputWrapper, addChannelBtnRef);
  }
  channelInput && channelInput.blur();
  hideAutocomplete && hideAutocomplete();
}

document.addEventListener('keydown', (e) => {
  const active = document.activeElement;
  const isTyping = active && (
    active.tagName === 'INPUT' ||
    active.tagName === 'TEXTAREA' ||
    active.isContentEditable
  );

  if (e.key === 'Escape' || e.key === 'Esc') {
    if (document.getElementById('audio-settings-panel')) {
      closeAudioSettingsPanel();
      return;
    }

    const appContainerForEsc = document.getElementById('app-container');
    const isQuickSearchActive = channelInputWrapper && channelInputWrapper.classList.contains('quick-search-active');
    const isFsSearchActive = appContainerForEsc && appContainerForEsc.classList.contains('fs-search-active');

    if (isQuickSearchActive || isFsSearchActive) {
      if (isQuickSearchActive) closeQuickSearch();
      if (isFsSearchActive) closeFsQuickSearch();
    } else if (chatVisible) {
      toggleChat();
    }
    return;
  }

  const shortcutAction = findShortcutAction(e);

  if (shortcutAction === 'search') {
    if (isTyping) return;
    e.preventDefault();
    const appContainer = document.getElementById('app-container');
    if (appContainer && appContainer.classList.contains('fs-mode')) {
      openFsQuickSearch();
    } else {
      openQuickSearch();
    }
    return;
  }

  if (isTyping) return;
  if (e.ctrlKey || e.metaKey || e.altKey) return;

  if (shortcutAction === 'grid') {
    switchLayout('grid');
  } else if (shortcutAction === 'mainSub') {
    switchLayout('main_sub');
  } else if (shortcutAction === 'settings') {
    toggleSettingModal();
  } else if (shortcutAction === 'audioPanel') {
    toggleAudioSettingsPanel();
  } else if (shortcutAction === 'queue') {
    toggleQueueSidebar();
  } else if (shortcutAction === 'liveSync') {
    syncLiveChannelLatencies();
  } else if (shortcutAction === 'following') {
    const noticeModal = document.getElementById('tag-notice-modal');
    if (noticeModal && noticeModal.classList.contains('active') && currentNoticeMode === 'following') {
      closeTagNoticeModal();
    } else {
      openList('following');
    }
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight' && e.key !== 'ArrowUp' && e.key !== 'ArrowDown') return;
  if (!(e.ctrlKey || e.metaKey) || e.altKey) return;

  const active = document.activeElement;
  const isChannelInputFocused = active === channelInput;

  if (isChannelInputFocused) {
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') return;
    e.preventDefault();
    e.stopPropagation();

    // 검색창이 비어 있으면 같은 단축키로 최근 검색어 탭을 순환한다.
    if (!channelInput.value.trim()) {
      const tabOrder = ['all', ...lastRecentSearchCategoriesShown];
      const curIdx = tabOrder.indexOf(currentRecentSearchTab);
      const dir = e.key === 'ArrowRight' ? 1 : -1;
      const nextIdx = ((curIdx === -1 ? 0 : curIdx) + dir + tabOrder.length) % tabOrder.length;
      currentRecentSearchTab = tabOrder[nextIdx];
      renderRecentSearches();
      return;
    }

    const platformTabOrder = ['all', ...Object.keys(PLATFORM_META).filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p])];
    const curIdx = platformTabOrder.indexOf(currentSearchPlatformTab);
    const dir = e.key === 'ArrowRight' ? 1 : -1;
    const nextIdx = ((curIdx === -1 ? 0 : curIdx) + dir + platformTabOrder.length) % platformTabOrder.length;
    currentSearchPlatformTab = platformTabOrder[nextIdx];
    saveSearchPlatformTab();
    if (currentSearchKeyword) fetchAutocomplete(currentSearchKeyword);
    return;
  }

  const isTyping = active && (
    active.tagName === 'INPUT' ||
    active.tagName === 'TEXTAREA' ||
    active.isContentEditable
  );
  if (isTyping) return;
  if (!chatVisible) return;
  if (!displayChannels || displayChannels.length === 0) return;

  if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
    e.preventDefault();
    e.stopPropagation();

    const idx = displayChannels.findIndex(c => c.hash === activeChatChannel);
    const dir = e.key === 'ArrowRight' ? 1 : -1;
    const baseIdx = idx === -1 ? 0 : idx;
    const nextIdx = (baseIdx + dir + displayChannels.length) % displayChannels.length;
    setChatChannel(displayChannels[nextIdx].hash);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    e.stopPropagation();

    const currentChannel = getChannelObjByHash(activeChatChannel);
    if (!currentChannel) return;
    const btnEl = chatTabs ? chatTabs.querySelector(`.chat-tab[data-hash="${activeChatChannel}"] .chat-tab-refresh-btn`) : null;
    refreshChatTab(activeChatChannel, currentChannel.platform, btnEl);
  } else if (e.key === 'ArrowDown') {
    e.preventDefault();
    e.stopPropagation();

    toggleChannelVideoHidden(activeChatChannel);
  }
});

// 메인-서브에서 방향키로 메인 채널을 순환한다. setMainChannel이 swap하므로 매번 "메인 제외 서브 목록"을 새로 구해
// 누적 횟수(fsMainCycleStep)로 순회한다.
let fsMainCycleStep = 0;
document.addEventListener('keydown', (e) => {
  if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
  if (e.ctrlKey || e.metaKey || e.altKey) return;

  // 보이는 채널이 1개면 순환 대상이 아니다.
  if (currentLayout !== 'main_sub' || isMainSubTreatedAsGrid()) return;

  const active = document.activeElement;
  const isTyping = active && (
    active.tagName === 'INPUT' ||
    active.tagName === 'TEXTAREA' ||
    active.isContentEditable
  );
  if (isTyping) return;
  if (!displayChannels) return;

  const subList = displayChannels.filter(c => c.hash !== mainChannel);
  if (subList.length === 0) return;

  e.preventDefault();
  e.stopPropagation();

  fsMainCycleStep += (e.key === 'ArrowRight' ? 1 : -1);
  const len = subList.length;
  const idx = fsMainCycleStep > 0
    ? (fsMainCycleStep - 1) % len
    : (len + (fsMainCycleStep % len)) % len;
  setMainChannel(subList[idx].hash);
});

function parseDirectInput(rawToken) {
  const str = (rawToken || '').trim();
  if (!str) return null;

  const chzzkVodMatch = str.match(/chzzk\.naver\.com\/video\/(\d+)/);
  if (chzzkVodMatch) {
    return { platform: 'chzzk', id: chzzkVodMatch[1], isVod: true };
  }

  let chzzkCandidate = str;
  if (chzzkCandidate.includes('chzzk.naver.com/')) {
    const parts = chzzkCandidate.split('/');
    chzzkCandidate = parts[parts.length - 1].split('?')[0];
  }
  if (/^[a-f0-9]{32}$/i.test(chzzkCandidate)) {
    return { platform: 'chzzk', id: chzzkCandidate };
  }

  // 숲 VOD는 제3자 iframe에서 재생이 안 돼 미지원.

  if (str.includes('play.sooplive.com/') || str.includes('sooplive.co.kr/') || str.includes('bj.afreecatv.com/')) {
    const parts = str.split('?')[0].split('/').filter(Boolean);
    const domainIdx = parts.findIndex(p => p.includes('sooplive.com') || p.includes('sooplive.co.kr') || p.includes('afreecatv.com'));
    if (domainIdx !== -1 && parts[domainIdx + 1]) {
      const id = parts[domainIdx + 1];
      const maybeBroadNo = parts[domainIdx + 2];
      const broadNo = /^\d+$/.test(maybeBroadNo || '') ? maybeBroadNo : undefined;
      return { platform: 'soop', id, broadNo };
    }
    const id = parts[parts.length - 1];
    if (id) return { platform: 'soop', id };
  }

  const YT_CHANNEL_ID_RE = /^UC[a-zA-Z0-9_-]{22}$/;
  const YT_HANDLE_RE = /^@[a-zA-Z0-9._-]{3,30}$/;
  const YT_URL_VIDEO_ID_RE = /(?:youtube\.com\/(?:[^/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?/\s]{11})/;

  if (YT_HANDLE_RE.test(str)) {
    return { platform: 'youtube', id: str };
  }
  if (str.includes('youtube.com/') || str.includes('youtu.be/')) {
    const videoIdMatch = YT_URL_VIDEO_ID_RE.exec(str);
    if (videoIdMatch) return { platform: 'youtube', id: videoIdMatch[1] };

    const parts = str.split('?')[0].split('/').filter(Boolean);
    const domainIdx = parts.findIndex(p => p.includes('youtube.com'));
    if (domainIdx !== -1 && parts[domainIdx + 1]) {
      let next = parts[domainIdx + 1];
      if (next === 'channel' && parts[domainIdx + 2]) next = parts[domainIdx + 2];
      if (YT_CHANNEL_ID_RE.test(next) || next.startsWith('@')) {
        return { platform: 'youtube', id: next };
      }
    }
  }

  return null;
}

function isHashFormat(str) {
  return !!parseDirectInput(str);
}

// "r "/"ㄱ " 접두사를 떼어 돌려준다 — 키워드 파싱은 항상 뗀 나머지로 한다.
const VOD_SEARCH_PREFIX_RE = /^(r|ㄱ)\s+/i;
function splitVodSearchPrefix(value) {
  const m = VOD_SEARCH_PREFIX_RE.exec(value);
  return m ? { vodPrefix: m[0], rest: value.slice(m[0].length) } : { vodPrefix: '', rest: value };
}

// "c "/"ㅊ " — 채널을 찾아 채팅탭만 남긴다(§chatOnly). "r "과 같은 자리라 동시 사용은 없다.
const CHAT_ONLY_SEARCH_PREFIX_RE = /^(c|ㅊ)\s+/i;
function splitChatOnlySearchPrefix(value) {
  const m = CHAT_ONLY_SEARCH_PREFIX_RE.exec(value);
  return m ? { chatPrefix: m[0], rest: value.slice(m[0].length) } : { chatPrefix: '', rest: value };
}

function splitSearchPrefixes(value) {
  const { vodPrefix, rest: afterVod } = splitVodSearchPrefix(value);
  if (vodPrefix) return { vodPrefix, chatPrefix: '', rest: afterVod };
  const { chatPrefix, rest } = splitChatOnlySearchPrefix(value);
  return { vodPrefix: '', chatPrefix, rest };
}

function getLastKeywordInfo(value) {
  const { vodPrefix, chatPrefix, rest } = splitSearchPrefixes(value);
  // 구분자는 쉼표만(공백까지 쓰면 띄어쓴 채널명이 잘림).
  const parts = rest.split(',').map(p => p.trim());
  const lastPart = parts.pop() || '';
  const validPreviousParts = parts.filter(p => p.length > 0);
  // 접두사를 prefix에 다시 붙여 자동완성 선택 후에도 모드가 유지되게.
  const prefix = vodPrefix + chatPrefix + (validPreviousParts.length > 0 ? validPreviousParts.join(', ') + ', ' : '');
  return { prefix, lastKeyword: lastPart };
}

let currentFocusIndex = 1;

function handleInputChange() {
  if (isKeyNavigating) return;

  if (searchDebounceTimer) {
    clearTimeout(searchDebounceTimer);
  }

  // 빈 검색창이면 최근 검색어를 보여준다.
  if (!channelInput.value.trim()) {
    renderRecentSearches();
    return;
  }

  const { lastKeyword } = getLastKeywordInfo(channelInput.value);

  if (!lastKeyword || isHashFormat(lastKeyword)) {
    hideAutocomplete();
    return;
  }

  searchDebounceTimer = setTimeout(() => {
    fetchAutocomplete(lastKeyword);
  }, 150);
}

let isKeyNavigating = false;

if (channelInput) {
  // 포커스 시 이미 비어 있으면 바로 보여준다(input 이벤트로는 못 잡음).
  channelInput.addEventListener('focus', () => {
    if (!channelInput.value.trim()) renderRecentSearches();
  });

  channelInput.addEventListener('input', (e) => {
    if (e.data === ',' && !e.isComposing) {
      const pos = channelInput.selectionStart;
      const before = channelInput.value.slice(0, pos);
      const after = channelInput.value.slice(pos);
      if (!after.startsWith(' ')) {
        channelInput.value = before + ' ' + after;
        channelInput.setSelectionRange(pos + 1, pos + 1);
      }
    }

    if (!isKeyNavigating) {
      handleInputChange();
    }
    isKeyNavigating = false;
  });

  channelInput.addEventListener('keydown', (e) => {
    if (e.isComposing && e.key !== 'Enter') return;

    if (e.shiftKey && e.key === 'Enter') {
      e.preventDefault();
      e.stopPropagation();
      hideAutocomplete();
      openList();
      return;
    }

    const items = autocompleteList ? autocompleteList.querySelectorAll('.autocomplete-item') : [];
    const isListActive = autocompleteList && autocompleteList.classList.contains('active') && items.length > 0;

    if (isListActive) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        e.stopPropagation();
        
        if (typeof searchDebounceTimer !== 'undefined' && searchDebounceTimer) {
          clearTimeout(searchDebounceTimer);
        }
        
        if (e.isComposing) {
          channelInput.blur();
          channelInput.focus();
        }

        isMouseMoving = false;
        isKeyNavigating = true;

        if (e.key === 'ArrowDown') {
          if (currentFocusIndex < 0) {
            currentFocusIndex = 0; 
          } else if (currentFocusIndex < items.length - 1) {
            currentFocusIndex++;
          }
        } else if (e.key === 'ArrowUp') {
          if (currentFocusIndex > 0) {
            currentFocusIndex--;
          }
        }

        updateFocus(items);
        return;
      } 
      
      if (e.key === 'Enter') {
        e.preventDefault();
        if (currentFocusIndex > -1 && items[currentFocusIndex]) {
          const focusedEl = items[currentFocusIndex];
          if (focusedEl.dataset.ignoreTrigger === 'true') {
            return;
          }
          const selectedText = focusedEl.querySelector('.keyword-text')?.textContent || '';
          // 최근 검색어 항목은 원래 검색 방식(태그/VOD 등)으로 실행한다.
          const recentCategory = focusedEl.dataset.recentCategory;
          if (recentCategory && RECENT_SEARCH_CATEGORY_META[recentCategory]) {
            // VOD 항목은 원본 term을 쓴다(화면 텍스트엔 "r "가 붙어 있음).
            const recentTerm = focusedEl.dataset.recentTerm || selectedText;
            RECENT_SEARCH_CATEGORY_META[recentCategory].onSelect(recentTerm);
            return;
          }
          const selectedPlatform = focusedEl.getAttribute('data-platform') || 'chzzk';
          selectAutocompleteItem({ platform: selectedPlatform, text: selectedText });
          addChannelFromInput();
        } else {
          hideAutocomplete();
          addChannelFromInput();
        }
        return;
      }
      
      if (e.key === 'Escape') {
        hideAutocomplete();
        return;
      }
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      hideAutocomplete();
      addChannelFromInput();
      return;
    }
  });
}

async function fetchAutocompleteItems(keyword) {
  // 설정의 플랫폼 순서로 조회한다(점수 동률 시 순서).
  let enabledPlatforms = getSearchPlatformOrder();
  // "r "은 방송 중이 아닌 채널도 보여준다.
  const options = { includeOffline: !!splitVodSearchPrefix(channelInput.value).vodPrefix };

  // "c "는 방송 중인 채널만 — 유튜브 자동완성은 방송 여부와 무관해 뺀다(플랫폼 탭으로 직접 고른 경우는 유지).
  if (splitChatOnlySearchPrefix(channelInput.value).chatPrefix && currentSearchPlatformTab !== 'youtube') {
    const liveOnly = enabledPlatforms.filter((p) => p !== 'youtube');
    if (liveOnly.length > 0) enabledPlatforms = liveOnly;
  }

  if (enabledPlatforms.includes(currentSearchPlatformTab)) {
    return await PlatformAdapters[currentSearchPlatformTab].searchAutocomplete(keyword, 10, options);
  }

  // "@" 핸들 검색은 유튜브만 조회한다(다른 플랫폼 결과가 핸들 캐시 추천을 밀어내지 않게).
  if (keyword.startsWith('@') && enabledPlatforms.includes('youtube')) {
    return await PlatformAdapters.youtube.searchAutocomplete(keyword, 10);
  }

  const resultsByPlatform = await Promise.all(
    enabledPlatforms.map(p => PlatformAdapters[p].searchAutocomplete(keyword, 10, options))
  );

  return mergeAutocompleteByRelevance(keyword, resultsByPlatform);
}

async function fetchAutocomplete(keyword) {
  currentSearchKeyword = keyword;

  try {
    const items = await fetchAutocompleteItems(keyword);

    const { lastKeyword: latestKeyword } = getLastKeywordInfo(channelInput.value);
    if (keyword !== latestKeyword || keyword !== currentSearchKeyword) {
      return;
    }

    showAutocomplete(items, keyword);
  } catch (err) {
    console.error('연관 검색어 조회 실패:', err);
    showAutocomplete([], keyword);
  }
}

function updateFocus(items) {
  items.forEach((item, idx) => {
    if (idx === currentFocusIndex) {
      item.classList.add('focused'); 
      item.scrollIntoView({ block: 'nearest' }); 
    } else {
      item.classList.remove('focused');
    }
  });
}

async function checkChzzkLiveByChannelId(channelId) {
  if (!channelId) return false;
  try {
    const res = await apiFetch(`https://api.chzzk.naver.com/service/v2/channels/${channelId}/live-detail`);
    if (!res.ok) return false;

    const data = await res.json();
    return !!(data && data.content && data.content.status === 'OPEN');
  } catch (e) {
    return false;
  }
}

// ── 라이브 종료 자동 감지 ── 라이브는 'ended'가 안 오므로 플랫폼 API로 주기적으로 확인한다.
const LIVE_STATUS_POLL_INTERVAL_MS = 60000;
// 연속으로 이만큼 오프라인이어야 삭제한다.
const OFFLINE_CONFIRM_THRESHOLD = 2;
const offlineStreakByHash = {};
// 다시보기 패널을 보여준 치지직 채널 — 이후 재조회하지 않는다(docs/vod-replay-architecture.md §3).
const vodPickerShownByHash = {};
// 패널 띄운 시각 — 치지직 API가 종료를 늦게 반영해 "아직 라이브"를 돌려주는 동안 패널을 걷지 않기 위함.
const vodPickerShownAtByHash = {};
// 위 유예 상한. 이후의 "아직 라이브"는 진짜 재개로 본다.
const VOD_PICKER_RESUME_GRACE_MS = 5 * 60 * 1000;
// 디버그 방송 종료 시뮬레이션 채널 — 실제 상태를 폴링하지 않는다.
const debugForcedEndedHashes = new Set();

async function checkChannelStillLive(ch) {
  // VOD는 hash가 영상 번호라 라이브 조회를 하지 않는다('ended'로만 판단).
  if (ch.isVod) return true;
  try {
    if (ch.platform === 'chzzk') {
      return await checkChzzkLiveByChannelId(ch.hash);
    }
    if (ch.platform === 'soop') {
      const found = await PlatformAdapters.soop.searchChannelById(ch.hash);
      return !!found;
    }
    if (ch.platform === 'youtube') {
      // 특정 영상 고정 항목도 'ended'로만 판단한다.
      if (!ch.videoId || ch.isPinnedVideoSlot || ch.hash === ch.videoId) return true;
      // /live 폴백은 종료 직후에도 예전 videoId를 돌려줘서 _checkStillLive를 쓴다. null이면 지우지 않는다.
      const stillLive = await PlatformAdapters.youtube._checkStillLive(ch.hash, ch.videoId);
      return stillLive === null ? true : stillLive;
    }
  } catch (e) {
    console.error(`[CHEESE EYES] ${ch.platform}:${ch.hash} 라이브 상태 확인 실패:`, e);
  }
  return true; // 알 수 없는 플랫폼이거나 확인 자체가 실패하면 지우지 않는다.
}

async function pollLiveStatusAndAutoRemove() {
  // 이 창이 그리는 채널만 확인한다(요청 중복·이중 삭제 방지, §3.2).
  const snapshot = channels.filter((c) => isChannelOwnedByThisWindow(c.hash));
  for (const ch of snapshot) {
    if (debugForcedEndedHashes.has(ch.hash)) continue;
    const stillLive = await checkChannelStillLive(ch);
    if (stillLive) {
      delete offlineStreakByHash[ch.hash];
      // 패널을 보여준 뒤 방송이 재개되면 라이브로 되돌린다. 단 유예 기간 안의 "아직 라이브"는 무시한다.
      if (vodPickerShownByHash[ch.hash]) {
        const shownAt = vodPickerShownAtByHash[ch.hash] || 0;
        if (Date.now() - shownAt >= VOD_PICKER_RESUME_GRACE_MS) {
          hideVodPickerPanel(ch.hash);
        }
      }
      continue;
    }
    if (vodPickerShownByHash[ch.hash]) continue;
    const streak = (offlineStreakByHash[ch.hash] || 0) + 1;
    offlineStreakByHash[ch.hash] = streak;
    if (streak < OFFLINE_CONFIRM_THRESHOLD) continue;
    delete offlineStreakByHash[ch.hash];
    console.log(`[CHEESE EYES] ${ch.platform}:${ch.hash} 방송 종료 확정(연속 ${OFFLINE_CONFIRM_THRESHOLD}회 오프라인)`);
    // 치지직 라이브(VOD 제외)는 지우지 않고 다시보기 선택 패널을 띄운다 — 챗탭 보류 게이트보다 먼저 처리한다
    // (게이트를 거치면 보고 있는 채널일수록 패널이 영영 안 떴다).
    if (ch.platform === 'chzzk' && !ch.isVod) {
      console.log(`[CHEESE EYES] ${ch.platform}:${ch.hash} 방송 종료 -> 다시보기 선택 패널 표시`);
      showVodPickerForChannel(ch);
      continue;
    }
    // 챗탭이 정확히 이 채널을 보고 있으면 빼지 않는다(이 시점만 검사).
    if (chatVisible && activeChatChannel === ch.hash) {
      console.log(`[CHEESE EYES] ${ch.platform}:${ch.hash} 방송 종료 확정했지만 챗탭이 열려있어 처리 보류`);
      continue;
    }
    if (tryConsumeQueueForSlot(ch.hash)) {
      console.log(`[CHEESE EYES] ${ch.platform}:${ch.hash} 방송 종료 -> 대기열 영상으로 교체`);
      continue;
    }
    removeChannel(ch.hash);
  }
}

setInterval(() => {
  if (channels.length > 0) pollLiveStatusAndAutoRemove();
}, LIVE_STATUS_POLL_INTERVAL_MS);

// ── 방송 종료 후 다시보기 선택 패널 ── wrapper 안에 패널만 얹고, VOD를 고를 때만 replaceVodChannelInPlace로 커밋한다.

function getOrCreateVodPickerPanel(wrapper) {
  let panel = wrapper.querySelector(':scope > .vod-picker-panel');
  if (!panel) {
    panel = document.createElement('div');
    panel.className = 'vod-picker-panel';
    wrapper.appendChild(panel);
  }
  wrapper.classList.add('vod-picker-active');
  return panel;
}

// 유튜브 날짜 텍스트는 접두어가 붙거나 영어로 올 수 있어 "숫자+단위"만 뽑아 앱 언어로 다시 조합한다(절대 날짜는 그대로).
const RELATIVE_TIME_UNIT_ALIASES = {
  sec: 'second', secs: 'second', second: 'second', seconds: 'second', '초': 'second',
  min: 'minute', mins: 'minute', minute: 'minute', minutes: 'minute', '분': 'minute',
  hour: 'hour', hours: 'hour', '시간': 'hour',
  day: 'day', days: 'day', '일': 'day',
  week: 'week', weeks: 'week', '주': 'week',
  month: 'month', months: 'month', '개월': 'month', '달': 'month',
  year: 'year', years: 'year', '년': 'year'
};
const RELATIVE_TIME_UNIT_LABELS = {
  ko: { second: '초', minute: '분', hour: '시간', day: '일', week: '주', month: '개월', year: '년' },
  en: { second: 'second', minute: 'minute', hour: 'hour', day: 'day', week: 'week', month: 'month', year: 'year' }
};
function localizeRelativeTimeText(raw) {
  if (!raw) return raw;
  const lang = (typeof window !== 'undefined' && window.CHEESE_EYES_CURRENT_LANG) || 'ko';
  if (/방금|just now|moments?\s+ago/i.test(raw)) {
    return lang === 'ko' ? '방금 전' : 'Just now';
  }
  const m = raw.match(/(\d+)\s*([a-zA-Z가-힣]+)/);
  if (!m) return raw;
  const unitKey = RELATIVE_TIME_UNIT_ALIASES[m[2].toLowerCase()] || RELATIVE_TIME_UNIT_ALIASES[m[2]];
  if (!unitKey) return raw;
  const amount = m[1];
  if (lang === 'ko') return `${amount}${RELATIVE_TIME_UNIT_LABELS.ko[unitKey]} 전`;
  const unitLabel = RELATIVE_TIME_UNIT_LABELS.en[unitKey] + (amount === '1' ? '' : 's');
  return `${amount} ${unitLabel} ago`;
}

function formatVodDuration(sec) {
  if (!sec) return '';
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}:${String(m).padStart(2, '0')}` : `${m}${t('vodPicker.minuteSuffix', '분')}`;
}

// VOD 검색 모달 카드는 mm:ss(시간 있으면 h:mm:ss)로 정확히 표시한다.
function formatVodDurationClock(sec) {
  if (!sec && sec !== 0) return '';
  const total = Math.max(0, Math.floor(sec));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mmss = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return h > 0 ? `${h}:${mmss}` : mmss;
}

function renderVodPickerLoading(wrapper) {
  const panel = getOrCreateVodPickerPanel(wrapper);
  panel.innerHTML = '';

  const header = document.createElement('div');
  header.className = 'vod-picker-header';
  header.textContent = t('vodPicker.ended', '방송이 종료되었습니다');
  panel.appendChild(header);

  const loading = document.createElement('div');
  loading.className = 'vod-picker-empty';
  loading.textContent = t('vodPicker.loading', '다시보기를 확인하는 중...');
  panel.appendChild(loading);

  panel.classList.add('visible');
}

function renderVodPickerEmpty(wrapper, ch) {
  const panel = getOrCreateVodPickerPanel(wrapper);
  panel.innerHTML = '';

  const header = document.createElement('div');
  header.className = 'vod-picker-header';
  header.textContent = t('vodPicker.ended', '방송이 종료되었습니다');
  panel.appendChild(header);

  const empty = document.createElement('div');
  empty.className = 'vod-picker-empty';

  const msg = document.createElement('div');
  msg.textContent = t('vodPicker.empty', '다시보기를 찾을 수 없습니다.');
  empty.appendChild(msg);

  const refreshBtn = document.createElement('button');
  refreshBtn.type = 'button';
  refreshBtn.className = 'vod-picker-refresh-btn';
  refreshBtn.textContent = t('vodPicker.refresh', '다시 확인');
  refreshBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    showVodPickerForChannel(ch, { forceRefresh: true });
  });
  empty.appendChild(refreshBtn);

  panel.appendChild(empty);
  panel.classList.add('visible');
}

// 페이지당 12개(4열 3줄).
const VOD_PICKER_PAGE_SIZE = 12;

// 다시보기 패널 무한 스크롤 상태 — 타일마다 패널이 있으므로 hash별로.
const vodPickerPaginationByHash = new Map();

function renderVodPickerVideoRow(list, ch, video, index) {
  const row = document.createElement('div');
  row.className = 'vod-picker-row';

  if (video.thumbnail) {
    const img = document.createElement('img');
    img.className = 'vod-picker-thumb';
    img.src = video.thumbnail;
    row.appendChild(img);
  }

  const info = document.createElement('div');
  info.className = 'vod-picker-info';

  const title = document.createElement('div');
  title.className = 'vod-picker-title';
  // LATEST 정렬이라 첫 항목이 가장 최근 방송이다.
  if (index === 0) {
    const badge = document.createElement('span');
    badge.className = 'vod-picker-latest-badge';
    badge.textContent = t('vodPicker.latestBadge', '최신');
    title.appendChild(badge);
  }
  title.appendChild(document.createTextNode(video.title || ch.name));
  info.appendChild(title);

  const sub = document.createElement('div');
  sub.className = 'vod-picker-sub';
  const parts = [];
  if (video.publishDate) parts.push(localizeRelativeTimeText(video.publishDate));
  const durationText = formatVodDuration(video.duration);
  if (durationText) parts.push(durationText);
  sub.textContent = parts.join(' · ');
  info.appendChild(sub);

  row.appendChild(info);

  row.addEventListener('click', async (e) => {
    e.stopPropagation();
    const oldHash = ch.hash;
    // 프리셋 칩 날짜용으로 VOD 상세 API의 liveOpenDate를 다시 조회한다(목록 publishDate는 형식이 불확실).
    const detail = await PlatformAdapters.chzzk.getVodDetail(video.videoNo).catch(() => null);
    replaceVodChannelInPlace(oldHash, {
      platform: 'chzzk',
      hash: String(video.videoNo),
      name: ch.name,
      title: video.title || ch.name,
      isVod: true,
      // 라이브 시절 hash(채널ID)를 채널 홈 이동용으로 저장한다.
      channelId: ch.channelId || ch.hash,
      broadcastDate: detail?.liveOpenDate || null
    });
    delete vodPickerShownByHash[oldHash];
    vodPickerPaginationByHash.delete(oldHash);
  });

  list.appendChild(row);
}

// 바닥 근처(150px)에서 다음 페이지를 이어 붙인다.
function onVodPickerListScroll(list, ch) {
  if (list.scrollHeight - list.scrollTop - list.clientHeight > 150) return;
  loadMoreVodPickerResults(list, ch);
}

async function loadMoreVodPickerResults(list, ch) {
  const state = vodPickerPaginationByHash.get(ch.hash);
  if (!state || state.loading || state.exhausted) return;
  state.loading = true;

  const { items, nextCursor } = await PlatformAdapters.chzzk.getChannelVideos(ch.hash, VOD_PICKER_PAGE_SIZE, state.cursor);

  // list가 DOM에서 떨어졌으면 중단한다.
  if (!list.isConnected) return;

  state.loading = false;
  state.cursor = nextCursor;
  state.exhausted = nextCursor === null || items.length === 0;
  if (items.length === 0) return;

  items.forEach((video, i) => renderVodPickerVideoRow(list, ch, video, state.count + i));
  state.count += items.length;
}

function renderVodPickerList(wrapper, ch, videos, nextCursor) {
  const panel = getOrCreateVodPickerPanel(wrapper);
  panel.innerHTML = '';

  const header = document.createElement('div');
  header.className = 'vod-picker-header';
  header.textContent = t('vodPicker.title', '다시보기 선택');
  panel.appendChild(header);

  const list = document.createElement('div');
  list.className = 'vod-picker-list';
  // 휠을 직접 받아 목록 안에서만 스크롤한다(바깥 컨테이너로 새지 않게).
  list.addEventListener('wheel', (e) => {
    if (e.deltaY === 0) return;
    e.preventDefault();
    e.stopPropagation();
    list.scrollTop += e.deltaY;
  }, { passive: false });
  list.addEventListener('scroll', () => onVodPickerListScroll(list, ch));

  videos.forEach((video, index) => renderVodPickerVideoRow(list, ch, video, index));

  panel.appendChild(list);
  panel.classList.add('visible');

  vodPickerPaginationByHash.set(ch.hash, {
    cursor: nextCursor, exhausted: nextCursor === null, loading: false, count: videos.length
  });
}

function hideVodPickerPanel(hash) {
  delete vodPickerShownByHash[hash];
  delete vodPickerShownAtByHash[hash];
  vodPickerPaginationByHash.delete(hash);
  const wrapper = videoWrapperMap.get(hash);
  if (!wrapper) return;
  wrapper.classList.remove('vod-picker-active');
  const panel = wrapper.querySelector(':scope > .vod-picker-panel');
  if (panel) panel.remove();
}

async function showVodPickerForChannel(ch, opts = {}) {
  const wrapper = videoWrapperMap.get(ch.hash);
  if (!wrapper) { removeChannel(ch.hash); return; }
  if (vodPickerShownByHash[ch.hash] && !opts.forceRefresh) return;
  vodPickerShownByHash[ch.hash] = true;
  vodPickerShownAtByHash[ch.hash] = Date.now();

  // 숨긴 채널은 패널이 안 보이므로 강제로 다시 켠다.
  if (videoHiddenChannels.has(ch.hash)) {
    toggleChannelVideoHidden(ch.hash);
  }

  renderVodPickerLoading(wrapper);
  const { items: videos, nextCursor } = await PlatformAdapters.chzzk.getChannelVideos(ch.hash, VOD_PICKER_PAGE_SIZE);

  // 조회 중 채널이 사라졌거나 패널이 걷혔으면 중단.
  if (!channels.some(c => c.hash === ch.hash)) return;
  const currentWrapper = videoWrapperMap.get(ch.hash);
  if (!currentWrapper || !currentWrapper.classList.contains('vod-picker-active')) return;

  if (videos.length === 0) {
    renderVodPickerEmpty(currentWrapper, ch);
    return;
  }
  renderVodPickerList(currentWrapper, ch, videos, nextCursor);
}

// 디버그 방종 VOD 시뮬레이션 — 실사용과 같은 showVodPickerForChannel을 탄다.
function simulateBroadcastEnded(ch, on) {
  if (on) {
    debugForcedEndedHashes.add(ch.hash);
    if (ch.platform === 'chzzk' && !ch.isVod) {
      // wrapper가 있을 때만 호출한다(없을 때의 removeChannel 폴백은 디버그에서 원치 않음).
      if (videoWrapperMap.get(ch.hash)) {
        showVodPickerForChannel(ch, { forceRefresh: true });
      }
    }
  } else {
    debugForcedEndedHashes.delete(ch.hash);
    hideVodPickerPanel(ch.hash);
  }
}

let autocompletePlatformHints = new Map();
// "r" 검색 플랫폼 힌트 — 유튜브도 기록한다(없으면 기본값 chzzk로 잘못 검색됨).
let vodSearchPlatformHints = new Map();

function posAutocompleteList() {
  if (!channelInput || !autocompleteList) return;
  const rect = channelInput.getBoundingClientRect();
  autocompleteList.style.top = `${rect.bottom + 6}px`;
  autocompleteList.style.left = `${rect.left}px`;
  autocompleteList.style.width = `${rect.width}px`;
}

window.addEventListener('resize', () => {
  if (autocompleteList && autocompleteList.classList.contains('active')) {
    posAutocompleteList();
  }
});

window.addEventListener('scroll', () => {
  if (autocompleteList && autocompleteList.classList.contains('active')) {
    posAutocompleteList();
  }
}, true);

if (autocompleteList) {
  autocompleteList.addEventListener('wheel', (e) => {
    if (e.deltaY !== 0) {
      e.preventDefault();
      autocompleteList.scrollTop += e.deltaY;
    }
  }, { passive: false });
}

function showAutocomplete(items, searchKeyword) {
  autocompleteList.innerHTML = '';
  currentFocusIndex = -1;
  posAutocompleteList();

  autocompleteRenderToken++;
  const tabsBar = buildPlatformTabsBar(currentSearchPlatformTab, (tab) => {
    currentSearchPlatformTab = tab;
    saveSearchPlatformTab();
    if (currentSearchKeyword) fetchAutocomplete(currentSearchKeyword);
  });
  autocompleteList.appendChild(tabsBar);

  if (!items || items.length === 0) {
    autocompleteList.classList.add('active');
    return;
  }

  items.forEach((item, index) => {
    const text = (item && item.text ? String(item.text) : '').trim();
    if (!text) return;

    const li = document.createElement('li');
    li.className = 'autocomplete-item';
    li.setAttribute('data-platform', item.platform);
    li.style.setProperty('--item-color', getPlatformColor(item.platform));

    const svgIcon = `
      <svg class="search-icon" viewBox="0 0 24 24" style="width: 16px; height: 16px; flex-shrink: 0;">
        <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
      </svg>
    `;

    const textSpan = document.createElement('span');
    textSpan.className = 'keyword-text';
    textSpan.style.cssText = 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1;';

    if (searchKeyword && text.toLowerCase().includes(searchKeyword.toLowerCase())) {
      const idx = text.toLowerCase().indexOf(searchKeyword.toLowerCase());
      const before = text.substring(0, idx);
      const match = text.substring(idx, idx + searchKeyword.length);
      const after = text.substring(idx + searchKeyword.length);

      textSpan.innerHTML = `${before}<span class="highlight">${match}</span>${after}`;
    } else {
      textSpan.textContent = text;
    }

    li.dataset.ignoreTrigger = 'false';

    li.innerHTML = svgIcon;
    li.appendChild(textSpan);

    li.addEventListener('mouseenter', () => {
      currentFocusIndex = index;
      updateFocus(autocompleteList.querySelectorAll('.autocomplete-item'));
    });

    li.addEventListener('mousedown', (e) => {
      e.preventDefault();
      selectAutocompleteItem(item);
    });

    autocompleteList.appendChild(li);
  });

  autocompleteList.classList.add('active');
}

function hideAutocomplete() {
  autocompleteRenderToken++;  if (autocompleteList) {
    autocompleteList.classList.remove('active');
    autocompleteList.innerHTML = '';
  }
  currentFocusIndex = -1;
}

function selectAutocompleteItem(item) {
  const obj = typeof item === 'string' ? { platform: 'chzzk', text: item } : item;
  if (obj.ignoreTrigger) return;

  const { prefix } = getLastKeywordInfo(channelInput.value);
  channelInput.value = prefix + obj.text + ', ';
  vodSearchPlatformHints.set(obj.text.trim(), obj.platform);
  if (obj.platform !== 'youtube') {
    autocompletePlatformHints.set(obj.text.trim(), obj.platform);
  }
  hideAutocomplete();
  channelInput.focus();
}

let liveConfirmToken = 0;
let liveConfirmSections = [];
// 이번 검색이 "c "로 시작했는지(챗만 커밋 여부).
let liveConfirmChatOnly = false;

function ensureLiveConfirmModal() {
  let modal = document.getElementById('live-confirm-modal');
  if (modal) return modal;

  modal = document.createElement('div');
  modal.id = 'live-confirm-modal';
  modal.className = 'tag-notice-backdrop';
  modal.innerHTML = `
    <div class="tag-notice-window">
      <div class="tag-notice-header">
        <h3 id="live-confirm-title">${t('modal.searchResultTitle', '검색 결과')}</h3>
        <button class="tag-notice-close" id="live-confirm-close-btn">✕</button>
      </div>
      <div class="tag-notice-body" id="live-confirm-body"></div>
      <div class="tag-notice-footer" style="justify-content:flex-end;">
        <button id="live-confirm-apply-btn">${t('modal.addSelected', '선택한 채널 추가')}</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  document.getElementById('live-confirm-close-btn').addEventListener('click', closeLiveConfirmModal);
  document.getElementById('live-confirm-apply-btn').addEventListener('click', applyLiveConfirmSelection);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeLiveConfirmModal();
  });
  document.addEventListener('keydown', (e) => {
    if (!modal.classList.contains('active')) return;
    if (e.key === 'Escape' || e.key === 'Esc') closeLiveConfirmModal();
  });

  return modal;
}

function closeLiveConfirmModal() {
  liveConfirmToken++;
  const modal = document.getElementById('live-confirm-modal');
  if (modal) modal.classList.remove('active');
  liveConfirmSections = [];
}

// ── "r 채널명" 검색 ── 그 채널 다시보기 목록 모달(치지직/유튜브). 커밋 시점에만 동작이 갈린다.
let vodSearchModalToken = 0;

function ensureVodSearchModal() {
  let modal = document.getElementById('vod-search-modal');
  if (modal) return modal;

  modal = document.createElement('div');
  modal.id = 'vod-search-modal';
  modal.className = 'tag-notice-backdrop';
  modal.innerHTML = `
    <div class="tag-notice-window">
      <div class="tag-notice-header">
        <h3 id="vod-search-title">${t('vodPicker.title', '다시보기 선택')}</h3>
        <button class="tag-notice-close" id="vod-search-close-btn">✕</button>
      </div>
      <div class="tag-notice-body" id="vod-search-body"></div>
    </div>
  `;
  document.body.appendChild(modal);

  document.getElementById('vod-search-close-btn').addEventListener('click', closeVodSearchModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeVodSearchModal();
  });
  document.addEventListener('keydown', (e) => {
    if (!modal.classList.contains('active')) return;
    if (e.key === 'Escape' || e.key === 'Esc') closeVodSearchModal();
  });

  return modal;
}

function closeVodSearchModal() {
  vodSearchModalToken++;
  vodSearchModalState = null;
  const modal = document.getElementById('vod-search-modal');
  if (modal) modal.classList.remove('active');
  const body = document.getElementById('vod-search-body');
  if (body) body.removeEventListener('scroll', onVodSearchModalScroll);
}

const VOD_SEARCH_SUPPORTED_PLATFORMS = ['chzzk', 'youtube'];

const YOUTUBE_HANDLE_CACHE_KEY = 'youtube_handle_search_cache';
const YOUTUBE_HANDLE_CACHE_MAX = 30;

function readYoutubeHandleCache() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get([YOUTUBE_HANDLE_CACHE_KEY], (result) => {
        const cached = result && result[YOUTUBE_HANDLE_CACHE_KEY];
        resolve(Array.isArray(cached) ? cached : []);
      });
    } catch (e) { resolve([]); }
  });
}

// "/vod" 모달이 열릴 만큼 해석된 핸들을 기억해 다음부터 연관검색어로 추천한다. count로 정렬.
function rememberYoutubeHandle(handle, name, hash) {
  if (!handle || !hash) return;
  try {
    chrome.storage.local.get([YOUTUBE_HANDLE_CACHE_KEY], (result) => {
      const list = Array.isArray(result && result[YOUTUBE_HANDLE_CACHE_KEY]) ? result[YOUTUBE_HANDLE_CACHE_KEY] : [];
      const existing = list.find(e => e && e.handle && e.handle.toLowerCase() === handle.toLowerCase());
      const count = (existing && typeof existing.count === 'number' ? existing.count : 0) + 1;
      const filtered = list.filter(e => e && e.handle && e.handle.toLowerCase() !== handle.toLowerCase());
      filtered.unshift({ handle, name: name || handle, hash, count });
      chrome.storage.local.set({ [YOUTUBE_HANDLE_CACHE_KEY]: filtered.slice(0, YOUTUBE_HANDLE_CACHE_MAX) });
    });
  } catch (e) { console.warn('[CHEESE EYES] 유튜브 핸들 캐시 저장 실패:', e); }
}

// ── 최근 검색어 ── 빈 검색창 포커스 시 표시. 카테고리별(일반/태그/VOD/채팅만)로 따로 쌓는다. 최대 10개, 최신순, 중복 제거.
const RECENT_SEARCH_KEY = 'recent_channel_searches';
const RECENT_SEARCH_MAX = 10;
const RECENT_SEARCH_CATEGORIES = ['channel', 'tag', 'vod', 'chat'];

// 항목 { term, platform } — platform은 아이콘 색용 힌트. 예전 문자열 배열 형식도 이어받는다.
function normRecentSearchEntry(raw) {
  if (typeof raw === 'string') {
    const term = raw.trim();
    return term ? { term, platform: null, savedAt: 0 } : null;
  }
  if (raw && typeof raw === 'object' && typeof raw.term === 'string' && raw.term.trim()) {
    // savedAt 없는 옛 항목은 0(전체 탭 병합 시 맨 아래).
    return {
      term: raw.term.trim(),
      platform: raw.platform || null,
      savedAt: typeof raw.savedAt === 'number' ? raw.savedAt : 0,
    };
  }
  return null;
}

function normRecentSearchStore(raw) {
  if (Array.isArray(raw)) {
    return { channel: raw.map(normRecentSearchEntry).filter(Boolean), tag: [], vod: [] };
  }
  const obj = raw && typeof raw === 'object' ? raw : {};
  const store = {};
  RECENT_SEARCH_CATEGORIES.forEach((cat) => {
    const list = Array.isArray(obj[cat]) ? obj[cat] : [];
    store[cat] = list.map(normRecentSearchEntry).filter(Boolean);
  });
  return store;
}

function readRecentSearches() {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get([RECENT_SEARCH_KEY], (result) => {
        resolve(normRecentSearchStore(result && result[RECENT_SEARCH_KEY]));
      });
    } catch (e) { resolve(normRecentSearchStore(null)); }
  });
}

function rememberRecentSearch(term, category = 'channel', platform = null) {
  const trimmed = String(term || '').trim();
  if (!trimmed) return;
  try {
    chrome.storage.local.get([RECENT_SEARCH_KEY], (result) => {
      const store = normRecentSearchStore(result && result[RECENT_SEARCH_KEY]);
      const filtered = store[category].filter(e => e.term !== trimmed);
      filtered.unshift({ term: trimmed, platform: platform || null, savedAt: Date.now() });
      store[category] = filtered.slice(0, RECENT_SEARCH_MAX);
      chrome.storage.local.set({ [RECENT_SEARCH_KEY]: store });
    });
  } catch (e) { console.warn('[CHEESE EYES] 최근 검색어 저장 실패:', e); }
}

function removeRecentSearch(term, category) {
  try {
    chrome.storage.local.get([RECENT_SEARCH_KEY], (result) => {
      const store = normRecentSearchStore(result && result[RECENT_SEARCH_KEY]);
      store[category] = store[category].filter(e => e.term !== term);
      chrome.storage.local.set({ [RECENT_SEARCH_KEY]: store }, () => {
        renderRecentSearches();
      });
    });
  } catch (e) { console.warn('[CHEESE EYES] 최근 검색어 삭제 실패:', e); }
}

// 일반/VOD는 입력창을 채우고 연관검색어를 다시 띄우고, 태그는 바로 태그 검색 모달을 연다.
const RECENT_SEARCH_CATEGORY_META = {
  channel: {
    tabLabel: () => t('input.recentTabChannel', '일반'),
    onSelect: (term) => {
      channelInput.value = term;
      handleInputChange();
    }
  },
  tag: {
    tabLabel: () => t('input.recentTabTag', '태그'),
    onSelect: (term) => {
      channelInput.value = term;
      openList('tag');
    }
  },
  vod: {
    tabLabel: () => t('input.recentTabVod', 'VOD'),
    // VOD는 입력창만 채우지 않고 바로 다시보기 모달을 띄운다(엔터 커밋과 동일).
    onSelect: (term) => {
      channelInput.value = '';
      hideAutocomplete();
      resolveAndOpenVodSearchModal(term);
    }
  },
  chat: {
    tabLabel: () => t('input.recentTabChat', '채팅'),
    // 채팅만도 바로 커밋한다.
    onSelect: (term) => {
      channelInput.value = `c ${term}`;
      hideAutocomplete();
      addChannelFromInput();
    }
  }
};

// 탭 선택은 세션 동안만 기억한다.
let currentRecentSearchTab = 'all';
// Ctrl+좌우 순환용으로 마지막 탭 목록을 캐시한다.
let lastRecentSearchCategoriesShown = [];

// 일반 자동완성 항목과 같은 모양에 삭제 버튼만 더한다.
function appendRecentSearchItem(entry, category) {
  const meta = RECENT_SEARCH_CATEGORY_META[category];
  const term = entry.term;
  const li = document.createElement('li');
  li.className = 'autocomplete-item recent-search-item';
  // Enter 시 이 카테고리 방식으로 실행되도록 카테고리를 데이터로 남긴다.
  li.dataset.recentCategory = category;
  // 원본 term을 데이터로 남긴다(화면 텍스트엔 "r "가 붙음).
  li.dataset.recentTerm = term;
  // 태그는 강조색 고정, 나머지는 플랫폼 힌트 색(없으면 기본색). "@" 핸들은 힌트가 없어도 유튜브 색.
  const effectivePlatform = entry.platform || (term.startsWith('@') ? 'youtube' : null);
  if (category === 'tag') {
    li.style.setProperty('--item-color', '#FFC800');
  } else if (effectivePlatform) {
    li.style.setProperty('--item-color', getPlatformColor(effectivePlatform));
  }

  const svgIcon = `
    <svg class="search-icon" viewBox="0 0 24 24" style="width: 16px; height: 16px; flex-shrink: 0;">
      <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
    </svg>
  `;
  li.innerHTML = svgIcon;

  const textSpan = document.createElement('span');
  textSpan.className = 'keyword-text';
  textSpan.style.cssText = 'overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1;';
  // VOD 검색어는 표시할 때만 "r "을 다시 붙인다.
  const RECENT_SEARCH_DISPLAY_PREFIX = { vod: 'r ', chat: 'c ' };
  textSpan.textContent = `${RECENT_SEARCH_DISPLAY_PREFIX[category] || ''}${term}`;
  li.appendChild(textSpan);

  const deleteBtn = document.createElement('button');
  deleteBtn.type = 'button';
  deleteBtn.className = 'recent-search-delete-btn';
  deleteBtn.textContent = '×';
  deleteBtn.addEventListener('mousedown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    removeRecentSearch(term, category);
  });
  li.appendChild(deleteBtn);

  li.addEventListener('mousedown', (e) => {
    if (e.target === deleteBtn) return;
    e.preventDefault();
    meta.onSelect(term);
  });

  return li;
}

// 포커스를 벗어났거나 값이 채워졌으면 무시한다(비동기 레이스 가드).
async function renderRecentSearches() {
  if (!channelInput || document.activeElement !== channelInput || channelInput.value.trim()) return;
  const store = await readRecentSearches();
  if (document.activeElement !== channelInput || channelInput.value.trim()) return;

  autocompleteRenderToken++;
  autocompleteList.innerHTML = '';
  currentFocusIndex = -1;
  posAutocompleteList();

  const categoriesToShow = RECENT_SEARCH_CATEGORIES.filter((cat) => store[cat].length > 0);
  lastRecentSearchCategoriesShown = categoriesToShow;
  if (categoriesToShow.length === 0) {
    autocompleteList.classList.remove('active');
    return;
  }
  if (currentRecentSearchTab !== 'all' && !categoriesToShow.includes(currentRecentSearchTab)) {
    currentRecentSearchTab = 'all';
  }

  // 카테고리 탭은 강조색 하나로 통일(플랫폼 색과 혼동 방지).
  const tabsBar = buildTabsBar(
    [
      { key: 'all', label: t('platformTabs.all', '전체'), color: '#FFC800' },
      ...categoriesToShow.map((cat) => ({ key: cat, label: RECENT_SEARCH_CATEGORY_META[cat].tabLabel(), color: '#FFC800' }))
    ],
    currentRecentSearchTab,
    (tab) => {
      currentRecentSearchTab = tab;
      renderRecentSearches();
    }
  );
  // mousedown에서 blur를 막아야 탭 클릭이 반영된다.
  tabsBar.addEventListener('mousedown', (e) => e.preventDefault());

  autocompleteList.appendChild(tabsBar);

  if (currentRecentSearchTab === 'all') {
    // 카테고리를 가로질러 savedAt 최신순으로 병합한다.
    categoriesToShow
      .flatMap((category) => store[category].map((entry) => ({ entry, category })))
      .sort((a, b) => b.entry.savedAt - a.entry.savedAt)
      .forEach(({ entry, category }) => {
        autocompleteList.appendChild(appendRecentSearchItem(entry, category));
      });
  } else {
    store[currentRecentSearchTab].forEach((entry) => {
      autocompleteList.appendChild(appendRecentSearchItem(entry, currentRecentSearchTab));
    });
  }

  autocompleteList.classList.add('active');
}

const VOD_LIST_CACHE_KEY = 'vod_search_list_cache';
// 다시보기 목록 캐시는 짧게(수 분).
const VOD_LIST_CACHE_MAX_AGE_MS = 3 * 60 * 1000;
const VOD_LIST_CACHE_MAX_ENTRIES = 20;

function vodListCacheKeyFor(platform, channelId, tab) {
  return `${platform}:${channelId}:${tab || ''}`;
}

// 이미 불러온 채널+탭이면 누적 목록을 즉시 보여준다.
function readVodListCache(platform, channelId, tab) {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get([VOD_LIST_CACHE_KEY], (result) => {
        const store = result && result[VOD_LIST_CACHE_KEY];
        const entry = store && store[vodListCacheKeyFor(platform, channelId, tab)];
        if (!entry || !Array.isArray(entry.items) || entry.items.length === 0
          || typeof entry.cachedAt !== 'number' || Date.now() - entry.cachedAt > VOD_LIST_CACHE_MAX_AGE_MS) {
          resolve(null);
          return;
        }
        resolve(entry);
      });
    } catch (e) { resolve(null); }
  });
}

// items = 무한 스크롤로 누적된 전체 목록.
function writeVodListCache(platform, channelId, tab, items, cursor, exhausted) {
  if (!items || items.length === 0) return;
  try {
    chrome.storage.local.get([VOD_LIST_CACHE_KEY], (result) => {
      const store = (result && result[VOD_LIST_CACHE_KEY]) || {};
      const key = vodListCacheKeyFor(platform, channelId, tab);
      store[key] = { items, cursor, exhausted, cachedAt: Date.now() };
      const keys = Object.keys(store);
      if (keys.length > VOD_LIST_CACHE_MAX_ENTRIES) {
        // 가장 오래된 것부터 정리(LRU 근사).
        keys.sort((a, b) => (store[a].cachedAt || 0) - (store[b].cachedAt || 0));
        delete store[keys[0]];
      }
      chrome.storage.local.set({ [VOD_LIST_CACHE_KEY]: store });
    });
  } catch (e) { console.warn('[CHEESE EYES] 다시보기 목록 캐시 저장 실패:', e); }
}

// token 하나를 치지직/유튜브 채널로 풀어 다시보기 모달을 띄운다. 다른 플랫폼이면 미지원 안내.
async function resolveAndOpenVodSearchModal(token) {
  const direct = parseDirectInput(token);
  if (direct) {
    if (!VOD_SEARCH_SUPPORTED_PLATFORMS.includes(direct.platform)) {
      showPlatformNotice(t('vodSearch.chzzkOnlyNotice', '지금은 r(또는 ㄱ) 검색이 치지직/유튜브 채널만 지원합니다.'));
      return;
    }
    if (direct.platform === 'chzzk' && direct.isVod) {
      // 특정 다시보기 영상 URL이면 바로 추가한다.
      commitChannels([{ platform: 'chzzk', hash: direct.id, name: direct.id, isVod: true }]);
      return;
    }
    if (direct.platform === 'youtube') {
      // parseDirectInput은 유튜브 영상/채널을 같은 모양으로 돌려주므로 id 형태(UC.../@...)로 구분한다.
      const looksLikeChannelRef = /^UC[a-zA-Z0-9_-]{22}$/.test(direct.id) || direct.id.startsWith('@');
      if (!looksLikeChannelRef) {
        const meta = await PlatformAdapters.youtube._resolveVideoMeta(direct.id);
        commitChannels([{
          platform: 'youtube',
          hash: direct.id,
          videoId: direct.id,
          name: (meta && meta.channelName) || direct.id,
          title: (meta && meta.title) || '',
          channelId: (meta && meta.channelId) || null,
          isPinnedVideoSlot: true,
          isVod: true
        }]);
        return;
      }
    }
    const channelData = await getAdapter(direct.platform).getChannelById(direct.id);
    if (channelData && channelData.hash) {
      // 진짜 채널ID까지 확보된 핸들만 기억한다.
      if (direct.platform === 'youtube' && direct.id.startsWith('@') && /^UC[a-zA-Z0-9_-]{22}$/.test(channelData.hash)) {
        rememberYoutubeHandle(direct.id, channelData.name, channelData.hash);
      }
      openVodSearchModal(direct.platform, channelData.hash, channelData.name || direct.id);
    }
    return;
  }

  const hintPlatform = vodSearchPlatformHints.get(token);
  if (hintPlatform && !VOD_SEARCH_SUPPORTED_PLATFORMS.includes(hintPlatform)) {
    showPlatformNotice(t('vodSearch.chzzkOnlyNotice', '지금은 r(또는 ㄱ) 검색이 치지직/유튜브 채널만 지원합니다.'));
    return;
  }

  // '@'로 시작하는데 못 알아본 경우(한글 애칭 등)는 유튜브로 보고 alias 검색으로 먼저 푼다.
  if (!hintPlatform && token.startsWith('@')) {
    try {
      const candidates = await PlatformAdapters.youtube._searchChannelRenderers(token.slice(1).trim());
      const best = candidates[0];
      if (best && best.hash) {
        if (best.handle) rememberYoutubeHandle(best.handle, best.name, best.hash);
        openVodSearchModal('youtube', best.hash, best.name || token);
        return;
      }
    } catch (err) {
      console.error(`'${token}' 유튜브 alias 채널 검색 실패(/vod):`, err);
    }
  }

  const platform = VOD_SEARCH_SUPPORTED_PLATFORMS.includes(hintPlatform) ? hintPlatform : 'chzzk';

  try {
    const channelData = await getAdapter(platform).searchChannelByName(token);
    if (channelData && channelData.hash) {
      openVodSearchModal(platform, channelData.hash, channelData.name || token);
    } else {
      showPlatformNotice(t('vodSearch.notFoundNotice', '"{name}" 채널을 찾을 수 없습니다.', { name: token }));
    }
  } catch (err) {
    console.error(`'${token}' ${platform} 채널 검색 실패(/vod):`, err);
    showPlatformNotice(t('vodSearch.notFoundNotice', '"{name}" 채널을 찾을 수 없습니다.', { name: token }));
  }
}

// 모달 무한 스크롤 상태(열 때마다 새로).
let vodSearchModalState = null;

// 유튜브 전용 다시보기/채널 영상 탭. 기본은 streams.
const YOUTUBE_VOD_MODAL_TABS = [
  { key: 'streams', labelKey: 'vodPicker.tabStreams', labelDefault: '다시보기(VOD)' },
  { key: 'videos', labelKey: 'vodPicker.tabVideos', labelDefault: '채널 영상' }
];

async function openVodSearchModal(platform, channelId, channelName) {
  const modal = ensureVodSearchModal();
  const titleEl = document.getElementById('vod-search-title');
  const myToken = ++vodSearchModalToken;

  titleEl.textContent = `${channelName} - ${t('vodPicker.title', '다시보기 선택')}`;
  // 모달 최상단에 --tab-color를 플랫폼 색으로 지정하면 나머지는 CSS 상속으로 맞춰진다.
  modal.style.setProperty('--tab-color', getPlatformColor(platform));
  modal.classList.add('active');

  let showStreamsTab = true;
  if (platform === 'youtube') {
    showStreamsTab = await getAdapter('youtube').hasLiveTab(channelId);
    if (vodSearchModalToken !== myToken) return;
    const suffix = showStreamsTab
      ? t('vodPicker.titleBoth', 'VOD / 채널 영상 선택')
      : t('vodPicker.titleVideosOnly', '채널 영상 선택');
    titleEl.textContent = `${channelName} - ${suffix}`;
  }
  const defaultTab = platform === 'youtube' ? (showStreamsTab ? 'streams' : 'videos') : null;
  await loadVodSearchModalTab(platform, channelId, channelName, defaultTab, myToken, showStreamsTab);
}

// 탭 전환 시 목록을 새로 불러온다(무한 스크롤 상태도 새로).
async function loadVodSearchModalTab(platform, channelId, channelName, tab, myToken, showStreamsTab = true) {
  const body = document.getElementById('vod-search-body');
  body.innerHTML = '';

  if (platform === 'youtube' && showStreamsTab) {
    const tabsBar = buildTabsBar(
      YOUTUBE_VOD_MODAL_TABS.map(tb => ({ key: tb.key, label: t(tb.labelKey, tb.labelDefault) })),
      tab,
      (newTab) => {
        if (!vodSearchModalState || vodSearchModalState.tab === newTab) return;
        loadVodSearchModalTab(platform, channelId, channelName, newTab, ++vodSearchModalToken, showStreamsTab);
      },
      'vod-search-modal-tabs'
    );
    body.appendChild(tabsBar);
  }

  vodSearchModalState = {
    token: myToken, platform, channelId, channelName, tab,
    cursor: platform === 'chzzk' ? 0 : null,
    loading: true, exhausted: false, count: 0, list: null, autoFillAttempts: 0, allItems: []
  };

  // 캐시가 있으면 네트워크 없이 바로 렌더링.
  const cached = await readVodListCache(platform, channelId, tab);
  if (vodSearchModalToken !== myToken) return;
  if (cached) {
    const list = document.createElement('div');
    list.className = 'vod-search-modal-list';
    body.appendChild(list);

    vodSearchModalState.list = list;
    vodSearchModalState.loading = false;
    vodSearchModalState.cursor = cached.cursor;
    vodSearchModalState.exhausted = cached.exhausted;
    vodSearchModalState.allItems = cached.items;
    appendVodSearchModalItems(list, channelName, cached.items, channelId, platform, 0, tab);
    vodSearchModalState.count = cached.items.length;

    body.removeEventListener('scroll', onVodSearchModalScroll);
    body.addEventListener('scroll', onVodSearchModalScroll);
    maybeAutoLoadMoreVodSearchModalResults();
    return;
  }

  const loadingEl = document.createElement('div');
  loadingEl.className = 'tag-notice-empty';
  loadingEl.textContent = t('vodPicker.loading', '다시보기를 확인하는 중...');
  body.appendChild(loadingEl);

  const { items, nextCursor } = await getAdapter(platform).getChannelVideos(channelId, 20, vodSearchModalState.cursor, tab);
  if (vodSearchModalToken !== myToken) return; // 그 사이 닫혔거나 다른 검색/탭으로 넘어갔으면 중단.

  loadingEl.remove();
  if (!items || items.length === 0) {
    const emptyEl = document.createElement('div');
    emptyEl.className = 'tag-notice-empty';
    emptyEl.textContent = t('vodPicker.empty', '다시보기를 찾을 수 없습니다.');
    body.appendChild(emptyEl);
    vodSearchModalState.exhausted = true;
    return;
  }

  const list = document.createElement('div');
  list.className = 'vod-search-modal-list';
  body.appendChild(list);

  vodSearchModalState.list = list;
  vodSearchModalState.loading = false;
  vodSearchModalState.cursor = nextCursor;
  vodSearchModalState.exhausted = nextCursor === null;
  vodSearchModalState.allItems = items;
  appendVodSearchModalItems(list, channelName, items, channelId, platform, vodSearchModalState.count, tab);
  vodSearchModalState.count += items.length;
  writeVodListCache(platform, channelId, tab, items, nextCursor, nextCursor === null);

  body.removeEventListener('scroll', onVodSearchModalScroll);
  body.addEventListener('scroll', onVodSearchModalScroll);

  // 목록이 모달을 넘치지 않으면 스크롤 이벤트가 안 나므로, 넘칠 때까지(또는 끝까지) 자동으로 이어 불러온다.
  maybeAutoLoadMoreVodSearchModalResults();
}

// 바닥 근처(200px)에서 다음 페이지.
function onVodSearchModalScroll(e) {
  const body = e.target;
  if (body.scrollHeight - body.scrollTop - body.clientHeight > 200) return;
  loadMoreVodSearchModalResults();
}

function maybeAutoLoadMoreVodSearchModalResults() {
  const state = vodSearchModalState;
  if (!state || state.loading || state.exhausted || !state.list) return;
  const body = document.getElementById('vod-search-body');
  if (!body || body.scrollHeight > body.clientHeight) return; // 이미 스크롤 가능 — 자동으로 더 불러올 필요 없음.
  // 자동 이어받기 횟수 안전장치.
  if (state.autoFillAttempts >= 10) return;
  state.autoFillAttempts++;
  loadMoreVodSearchModalResults();
}

async function loadMoreVodSearchModalResults() {
  const state = vodSearchModalState;
  if (!state || state.loading || state.exhausted) return;
  state.loading = true;
  const footer = document.createElement('div');
  footer.className = 'vod-search-modal-loading-more';
  footer.textContent = t('chat.commentsLoadingMore', '더 불러오는 중...');
  state.list.parentElement.appendChild(footer);

  const myToken = state.token;
  const { items, nextCursor } = await getAdapter(state.platform).getChannelVideos(state.channelId, 20, state.cursor, state.tab);
  footer.remove();
  if (vodSearchModalToken !== myToken || vodSearchModalState !== state) return; // 그 사이 모달이 닫혔거나 다른 검색으로 넘어감.

  state.loading = false;
  state.cursor = nextCursor;
  state.exhausted = nextCursor === null || items.length === 0;
  if (items.length === 0 || !state.list) return;
  appendVodSearchModalItems(state.list, state.channelName, items, state.channelId, state.platform, state.count, state.tab);
  state.count += items.length;
  state.allItems = (state.allItems || []).concat(items);
  // 누적 목록으로 캐시를 갱신한다.
  writeVodListCache(state.platform, state.channelId, state.tab, state.allItems, state.cursor, state.exhausted);
  maybeAutoLoadMoreVodSearchModalResults();
}

function appendVodSearchModalItems(list, channelName, videos, channelId, platform, startIndex, tab) {
  videos.forEach((video, i) => {
    const index = startIndex + i;
    // 모달 전용 세로 카드 레이아웃(.vod-search-modal-row).
    const row = document.createElement('div');
    row.className = 'vod-search-modal-row';

    if (video.thumbnail) {
      const img = document.createElement('img');
      img.className = 'vod-search-modal-thumb';
      img.src = video.thumbnail;
      row.appendChild(img);
    }

    const info = document.createElement('div');
    info.className = 'vod-picker-info';

    const title = document.createElement('div');
    title.className = 'vod-picker-title';
    if (index === 0) {
      const badge = document.createElement('span');
      badge.className = 'vod-picker-latest-badge';
      badge.textContent = t('vodPicker.latestBadge', '최신');
      title.appendChild(badge);
    }
    title.appendChild(document.createTextNode(video.title || channelName));
    info.appendChild(title);

    const sub = document.createElement('div');
    sub.className = 'vod-picker-sub';
    const parts = [];
    if (video.publishDate) parts.push(localizeRelativeTimeText(video.publishDate));
    const durationText = formatVodDurationClock(video.duration);
    if (durationText) parts.push(durationText);
    sub.textContent = parts.join(' · ');
    info.appendChild(sub);

    row.appendChild(info);

    row.addEventListener('click', async () => {
      const videoIdentifier = String(video.videoNo ?? video.videoId);
      // 프리셋 칩 날짜용으로 liveOpenDate를 다시 조회한다.
      const broadcastDate = platform === 'chzzk'
        ? (await PlatformAdapters.chzzk.getVodDetail(videoIdentifier).catch(() => null))?.liveOpenDate || null
        : null;
      commitChannels([platform === 'youtube' ? {
        platform: 'youtube',
        hash: videoIdentifier,
        videoId: videoIdentifier,
        name: channelName,
        title: video.title || channelName,
        channelId,
        isPinnedVideoSlot: true,
        isVod: true
      } : {
        platform: 'chzzk',
        hash: videoIdentifier,
        name: channelName,
        title: video.title || channelName,
        isVod: true,
        channelId,
        broadcastDate
      }]);
      closeVodSearchModal();
    });

    list.appendChild(row);
  });
}

// opts.chatOnly — "c " 검색이면 고른 채널도 챗만으로 커밋한다.
function openLiveConfirmModal(keywords, opts) {
  const list = (keywords || []).map(k => String(k || '').trim()).filter(Boolean);
  if (list.length === 0) return;

  liveConfirmChatOnly = !!(opts && opts.chatOnly);

  hideAutocomplete();

  const modal = ensureLiveConfirmModal();
  const titleEl = document.getElementById('live-confirm-title');
  const myToken = ++liveConfirmToken;
  currentLiveConfirmPlatformTab = 'all';
  currentLiveConfirmKeywordTab = 'all';

  titleEl.textContent = `${list.join(', ')} - ${t('modal.searchResultTitle', '검색 결과')}`;
  modal.classList.add('active');

  liveConfirmSections = list.map(keyword => ({ keyword, groups: [], selected: new Set() }));
  renderLiveConfirmSections();

  liveConfirmSections.forEach((section, sectionIdx) => {
    loadKeywordCandidatesProgressively(sectionIdx, section.keyword, myToken);
  });
}

function loadKeywordCandidatesProgressively(sectionIdx, keyword, myToken) {
  const isHandleMode = keyword.startsWith('@');
  const enabledPlatforms = Object.keys(PLATFORM_META).filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p]);

  const platformFetchers = {
    youtube: () => isHandleMode
      ? PlatformAdapters.youtube._resolveHandleCandidatesForStageB(keyword)
      : PlatformAdapters.youtube._resolveKeywordCandidatesForStageB(keyword),
    chzzk: () => fetchChzzkLiveCandidatesByName(keyword),
    soop: () => fetchSoopLiveCandidatesByName(keyword)
  };

  const platformsToQuery = isHandleMode ? ['youtube'] : enabledPlatforms.filter(p => platformFetchers[p]);

  const targetSection = liveConfirmSections[sectionIdx];
  if (targetSection) {
    targetSection.expectedCount = platformsToQuery.length;
    targetSection.allPlatforms = platformsToQuery;
  }

  platformsToQuery.forEach(platform => {
    platformFetchers[platform]()
      .catch(err => {
        console.error(`'${keyword}' ${platform} 라이브 후보 조회 실패:`, err);
        return [];
      })
      .then(candidates => {
        if (liveConfirmToken !== myToken) return;
        const section = liveConfirmSections[sectionIdx];
        if (!section) return;
        section.groups.push({ platform, candidates: candidates || [] });
        renderLiveConfirmSections();
      });
  });
}

// minViewers — 합방 멤버 제안은 0을 넘긴다.
async function fetchChzzkLiveCandidatesByName(keyword, minViewers = getMinViewers('chzzk')) {
  const queries = [keyword];
  const dataLists = await Promise.all(queries.map(async (q) => {
    try {
      const res = await apiFetch(`https://api.chzzk.naver.com/service/v1/search/channels?keyword=${encodeURIComponent(q)}&offset=0&size=20&withFirstChannelContent=true`);
      if (!res.ok) return [];
      const data = await res.json();
      return data.content && data.content.data ? data.content.data : [];
    } catch (e) { return []; }
  }));

  const seenChannelId = new Set();
  const rawChannels = [];
  dataLists.forEach(list => {
    list.forEach(entry => {
      const c = entry.channel;
      if (!c || !c.channelId || !c.channelName || seenChannelId.has(c.channelId)) return;
      seenChannelId.add(c.channelId);
      rawChannels.push(c);
    });
  });

  const checked = await Promise.all(rawChannels.map(async (c) => {
    try {
      const detailRes = await apiFetch(`https://api.chzzk.naver.com/service/v2/channels/${c.channelId}/live-detail`);
      if (!detailRes.ok) return null;
      const detail = await detailRes.json();
      const content = detail && detail.content;
      if (!content || content.status !== 'OPEN') return null;
      const viewersNum = typeof content.concurrentUserCount === 'number' ? content.concurrentUserCount : null;
      if (viewersNum != null && viewersNum < minViewers) return null;
      return {
        platform: 'chzzk',
        hash: c.channelId,
        name: c.channelName,
        title: content.liveTitle || '',
        thumbnail: content.liveImageUrl ? content.liveImageUrl.replace('{type}', '270') : '',
        viewersText: viewersNum != null ? viewersNum.toLocaleString() : ''
      };
    } catch (e) { return null; }
  }));

  return checked.filter(Boolean);
}

async function fetchSoopLiveCandidatesByName(keyword, minViewers = getMinViewers('soop')) {
  const queries = [keyword];
  const seenId = new Set();
  const results = [];
  for (const q of queries) {
    const list = await PlatformAdapters.soop._liveSearch(q, { count: 20 });
    const kw = String(q || '').trim().toLowerCase();
    list.forEach(raw => {
      const ch = PlatformAdapters.soop._toChannelData(raw);
      if (!ch || seenId.has(ch.hash)) return;
      if (kw && !String(ch.name || '').toLowerCase().includes(kw)) return;
      const viewers = raw.total_view_cnt ?? raw.view_cnt ?? raw.m_current_view_cnt;
      const viewersNum = viewers != null ? Number(viewers) : null;
      if (viewersNum != null && !isNaN(viewersNum) && viewersNum < minViewers) return;
      seenId.add(ch.hash);
      results.push({
        ...ch,
        title: raw.broad_title || raw.title || '',
        thumbnail: raw.broad_img || raw.thumbnail || '',
        viewersText: viewersNum != null ? viewersNum.toLocaleString() : ''
      });
    });
  }
  return results;
}

function createLiveResultRow(ch, isSelected, onToggle) {
  const row = document.createElement('div');
  row.className = 'live-confirm-row selectable-channel-item';
  row.style.setProperty('--item-color', getPlatformColor(ch.platform));
  row.setAttribute('data-hash', ch.hash);
  row.setAttribute('data-platform', ch.platform);
  if (isSelected) row.classList.add('selected');

  if (ch.thumbnail) {
    const img = document.createElement('img');
    img.src = ch.thumbnail;
    img.className = 'live-confirm-thumb';
    // 썸네일 <img>의 네이티브 드래그를 꺼야 커스텀 드래그 선택이 동작한다.
    img.draggable = false;
    row.appendChild(img);
  }

  const info = document.createElement('div');
  info.className = 'live-confirm-info';

  const isKnownLive = ch.platform !== 'youtube' || !!ch.videoId;

  const nameEl = document.createElement('div');
  nameEl.className = 'live-confirm-name';
  nameEl.textContent = ch.name;
  info.appendChild(nameEl);

  const titleEl = document.createElement('div');
  titleEl.className = 'live-confirm-title';
  const titleText = ch.title || ch.name;
  titleEl.textContent = titleText;
  titleEl.title = titleText;
  info.appendChild(titleEl);

  const sub = document.createElement('div');
  sub.className = 'live-confirm-sub';
  if (isKnownLive) {
    sub.textContent = ch.viewersText ? `● LIVE · ${ch.viewersText}` : '● LIVE';
    sub.classList.add('is-live');
  } else {
    sub.textContent = t('following.empty', '라이브 중인 채널이 없습니다.');
    sub.classList.add('is-offline');
  }
  info.appendChild(sub);

  row.appendChild(info);
  row.addEventListener('click', () => {
    if (row.parentElement && row.parentElement.classList.contains('has-dragged')) return;
    onToggle(row);
  });

  return row;
}

let currentLiveConfirmPlatformTab = 'all';
let currentLiveConfirmKeywordTab = 'all';

function buildKeywordTabsBar(activeTab, onSelect) {
  const tabs = [
    { key: 'all', label: t('platformTabs.all', '전체') },
    ...liveConfirmSections.map(section => ({ key: section.keyword, label: section.keyword }))
  ];
  return buildTabsBar(tabs, activeTab, onSelect, 'search-keyword-tabs');
}

function renderLiveConfirmSections() {
  const bodyEl = document.getElementById('live-confirm-body');
  bodyEl.innerHTML = '';

  const tabsBar = buildPlatformTabsBar(currentLiveConfirmPlatformTab, (tab) => {
    currentLiveConfirmPlatformTab = tab;
    renderLiveConfirmSections();
  });
  bodyEl.appendChild(tabsBar);

  if (liveConfirmSections.length > 1) {
    const keywordTabsBar = buildKeywordTabsBar(currentLiveConfirmKeywordTab, (tab) => {
      currentLiveConfirmKeywordTab = tab;
      renderLiveConfirmSections();
    });
    bodyEl.appendChild(keywordTabsBar);
  }

  const sectionsToRender = liveConfirmSections.filter(section => (
    currentLiveConfirmKeywordTab === 'all' || section.keyword === currentLiveConfirmKeywordTab
  ));

  sectionsToRender.forEach(section => {
    const sectionEl = document.createElement('div');
    sectionEl.className = 'live-confirm-section';

    if (currentLiveConfirmKeywordTab === 'all' && liveConfirmSections.length > 1) {
      const heading = document.createElement('div');
      heading.className = 'live-confirm-section-heading';
      heading.textContent = section.keyword;
      sectionEl.appendChild(heading);
    }

    const allPlatforms = section.allPlatforms || [];
    const allResponded = section.expectedCount != null && section.groups.length >= section.expectedCount;

    const visibleCandidates = [];
    section.groups.forEach(group => {
      if (currentLiveConfirmPlatformTab !== 'all' && group.platform !== currentLiveConfirmPlatformTab) return;
      group.candidates.forEach(ch => visibleCandidates.push({ platform: group.platform, ch }));
    });

    if (allPlatforms.length === 0) {
      const loading = document.createElement('div');
      loading.className = 'tag-notice-empty';
      loading.textContent = t('modal.liveConfirmLoading', '라이브 여부를 확인하는 중...');
      sectionEl.appendChild(loading);
    } else if (visibleCandidates.length === 0 && allResponded) {
      const empty = document.createElement('div');
      empty.className = 'tag-notice-empty';
      empty.textContent = t('following.empty', '라이브 중인 채널이 없습니다.');
      sectionEl.appendChild(empty);
    } else {
      const listWrap = document.createElement('div');
      listWrap.className = 'live-confirm-rows';

      visibleCandidates.forEach(({ platform, ch }) => {
        const uid = `${platform}:${ch.hash}`;
        const row = createLiveResultRow(ch, section.selected.has(uid), () => {
          if (section.selected.has(uid)) {
            section.selected.delete(uid);
            row.classList.remove('selected');
          } else {
            section.selected.add(uid);
            row.classList.add('selected');
          }
        });
        listWrap.appendChild(row);
      });

      sectionEl.appendChild(listWrap);

      if (!allResponded) {
        const loadingMore = document.createElement('div');
        loadingMore.className = 'live-confirm-platform-loading';
        loadingMore.textContent = t('modal.liveConfirmLoading', '라이브 여부를 확인하는 중...');
        sectionEl.appendChild(loadingMore);
      }
    }

    bodyEl.appendChild(sectionEl);
  });
}

function applyLiveConfirmSelection() {
  const selectedChannels = [];
  liveConfirmSections.forEach(section => {
    section.groups.forEach(group => {
      group.candidates.forEach(ch => {
        const uid = `${group.platform}:${ch.hash}`;
        if (section.selected.has(uid)) selectedChannels.push(ch);
      });
    });
  });

  closeLiveConfirmModal();
  if (selectedChannels.length > 0) {
    if (liveConfirmChatOnly) selectedChannels.forEach((ch) => { if (ch) ch.chatOnly = true; });
    commitChannels(selectedChannels);
  }
  liveConfirmChatOnly = false;
}

// ── 합방 멤버 추가 제안 ── 채팅 "!멤버" 목록(content.js)을 받아 없는 멤버 중 라이브만 이름별 탭으로 보여준다.
// 같은 채널의 같은 목록은 한 번만 띄운다.
const collabMemberSuggestSeen = new Set();

function normalizeCollabMemberName(name) {
  return String(name || '').replace(/\s+/g, '').toLowerCase();
}

window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'COLLAB_MEMBER_LIST' || !Array.isArray(event.data.names)) return;
  const hash = findChatHashByWindow(event.source);
  if (hash) handleCollabMemberList(hash, event.data.names.map(String));
});

async function handleCollabMemberList(sourceHash, names) {
  const source = getChannelObjByHash(sourceHash);
  if (!source) return;
  const key = `${sourceHash}|${names.map(normalizeCollabMemberName).sort().join(',')}`;
  if (collabMemberSuggestSeen.has(key)) return;
  collabMemberSuggestSeen.add(key);

  const existingNames = new Set(channels.map((c) => normalizeCollabMemberName(c.name)));
  const wanted = names.filter((n) => !existingNames.has(normalizeCollabMemberName(n)));
  console.log('[CHEESE EYES][합방 멤버]', source.name, '채팅 목록:', names, '조회 대상:', wanted);
  if (wanted.length === 0) return;

  // 라이브 채널만, 시청자 수 하한 없음.
  const fetchers = { chzzk: fetchChzzkLiveCandidatesByName, soop: fetchSoopLiveCandidatesByName };
  const platforms = Object.keys(fetchers).filter((p) => PLATFORM_META[p] && PLATFORM_META[p].enabled && PlatformAdapters[p]);
  const sections = await Promise.all(wanted.map(async (name) => {
    const lists = await Promise.all(platforms.map((p) => fetchers[p](name, 0).catch(() => [])));
    const target = normalizeCollabMemberName(name);
    const results = dedupeChannels(lists.flat())
      .filter((ch) => ch && !channels.some((c) => sameChannel(c, ch)))
      .filter((ch) => normalizeCollabMemberName(ch.name).includes(target))
      // !멤버가 올라온 채널과 같은 플랫폼 → 이름 정확히 일치 순.
      .map((ch, i) => ({ ch, i, rank: (ch.platform === source.platform ? 0 : 2) + (normalizeCollabMemberName(ch.name) === target ? 0 : 1) }))
      .sort((a, b) => a.rank - b.rank || a.i - b.i)
      .map((entry) => entry.ch);
    return { keyword: name, results };
  }));
  const found = sections.filter((section) => section.results.length > 0);
  const notLive = sections.filter((section) => section.results.length === 0).map((section) => section.keyword);
  console.log('[CHEESE EYES][합방 멤버] 찾은 라이브 채널:', found.map((section) => `${section.keyword}(${section.results.length})`), '라이브 없음:', notLive);
  if (found.length === 0) return;
  openCollabMemberSuggestModal(source, found, notLive);
}

let collabMemberSuggestSections = [];
let collabMemberSuggestSourcePlatform = null;
let currentCollabMemberSuggestTab = 'all';

function ensureCollabMemberSuggestModal() {
  let modal = document.getElementById('collab-member-suggest-modal');
  if (modal) return modal;
  modal = document.createElement('div');
  modal.id = 'collab-member-suggest-modal';
  modal.className = 'tag-notice-backdrop';
  modal.innerHTML = `
    <div class="tag-notice-window">
      <div class="tag-notice-header">
        <h3 id="collab-member-suggest-title"></h3>
        <button class="tag-notice-close" id="collab-member-suggest-close-btn">✕</button>
      </div>
      <div class="tag-notice-body">
        <div id="collab-member-suggest-hint" class="collab-member-suggest-hint"></div>
        <div id="collab-member-suggest-results"></div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);
  const close = () => modal.classList.remove('active');
  document.getElementById('collab-member-suggest-close-btn').addEventListener('click', close);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) close();
  });
  document.addEventListener('keydown', (e) => {
    if (modal.classList.contains('active') && (e.key === 'Escape' || e.key === 'Esc')) close();
  });
  return modal;
}

function openCollabMemberSuggestModal(source, sections, notLive) {
  const modal = ensureCollabMemberSuggestModal();
  collabMemberSuggestSections = sections;
  collabMemberSuggestSourcePlatform = source.platform;
  currentCollabMemberSuggestTab = 'all';
  document.getElementById('collab-member-suggest-title').textContent =
    t('modal.collabMemberSuggestTitle', '{name} 합방 멤버').replace('{name}', source.name || '');
  let hint = t('modal.collabMemberSuggestHint', '채팅의 !멤버 목록에서 찾은 라이브 채널입니다.');
  if (notLive.length > 0) {
    hint += ' ' + t('modal.collabMemberSuggestNotLive', '라이브 아님: {names}').replace('{names}', notLive.join(', '));
  }
  document.getElementById('collab-member-suggest-hint').textContent = hint;
  renderCollabMemberSuggestResults();
  modal.classList.add('active');
}

// 디버그 "띄우기" — 지금 그리드 라이브 이름으로 창 모양을 확인한다.
async function openCollabMemberSuggestExample() {
  const liveChannels = (displayChannels || []).filter((ch) => !ch.isVod && (ch.platform === 'chzzk' || ch.platform === 'soop')).slice(0, 4);
  const source = getChannelObjByHash(mainChannel) || liveChannels[0] || { name: 'CHEESE EYES', platform: 'chzzk' };
  const fetchers = { chzzk: fetchChzzkLiveCandidatesByName, soop: fetchSoopLiveCandidatesByName };
  const sections = (await Promise.all(liveChannels.map(async (ch) => {
    const results = (await fetchers[ch.platform](ch.name, 0).catch(() => [])).slice(0, 3);
    return { keyword: ch.name, results };
  }))).filter((section) => section.results.length > 0);
  openCollabMemberSuggestModal(source, sections, [t('settings.debugMemberSuggestNotLiveSample', '예시')]);
}

function renderCollabMemberSuggestResults() {
  const resultsEl = document.getElementById('collab-member-suggest-results');
  if (!resultsEl) return;
  resultsEl.innerHTML = '';

  if (collabMemberSuggestSections.length > 1) {
    const tabs = [
      { key: 'all', label: t('platformTabs.all', '전체') },
      ...collabMemberSuggestSections.map((section) => ({ key: section.keyword, label: section.keyword }))
    ];
    resultsEl.appendChild(buildTabsBar(tabs, currentCollabMemberSuggestTab, (tab) => {
      currentCollabMemberSuggestTab = tab;
      renderCollabMemberSuggestResults();
    }, 'search-keyword-tabs'));
  }

  // 전체 탭에서도 같은 플랫폼을 다시 앞으로 모은다.
  const items = currentCollabMemberSuggestTab === 'all'
    ? dedupeChannels(collabMemberSuggestSections.flatMap((section) => section.results))
      .map((ch, i) => ({ ch, i, rank: ch.platform === collabMemberSuggestSourcePlatform ? 0 : 1 }))
      .sort((a, b) => a.rank - b.rank || a.i - b.i)
      .map((entry) => entry.ch)
    : ((collabMemberSuggestSections.find((section) => section.keyword === currentCollabMemberSuggestTab) || {}).results || []);

  const listWrap = document.createElement('div');
  listWrap.className = 'live-confirm-rows';
  items.forEach((ch) => {
    const addBtn = document.createElement('button');
    addBtn.type = 'button';
    addBtn.className = 'collab-member-suggest-add-btn';
    const markAdded = () => {
      addBtn.textContent = t('modal.collabMemberSuggestAdded', '추가됨');
      addBtn.disabled = true;
      row.classList.add('selected');
    };
    const add = () => {
      if (addBtn.disabled) return;
      if (!channels.some((c) => sameChannel(c, ch))) commitChannels([ch]);
      markAdded();
    };
    const row = createLiveResultRow(ch, false, add);
    addBtn.textContent = t('modal.collabMemberSuggestAdd', '추가');
    if (channels.some((c) => sameChannel(c, ch))) markAdded();
    addBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      add();
    });
    row.appendChild(addBtn);
    listWrap.appendChild(row);
  });
  resultsEl.appendChild(listWrap);
}

// iframe만 새로 불러오게 videoWrapperMap에서만 지운다(위치 유지).
function refreshChannelVideoWrapper(hash) {
  const wrapper = videoWrapperMap.get(hash);
  if (!wrapper) return;
  const iframe = wrapper.querySelector('iframe');
  if (iframe) iframe.src = 'about:blank';
  wrapper.remove();
  videoWrapperMap.delete(hash);
}

function commitChannels(channelDataList) {
  let hasAdded = false;
  let hasRefreshed = false;
  let limitReached = false;
  const newHashes = [];
  const newOwnerSlots = []; // newHashes와 같은 순서 — 따로 정해진 소유 창(없으면 이 창)
  const movedChannels = []; // 다른 창에 있던 기존 채널 { channel, slotId }
  channelDataList.forEach(ch => {
    if (!ch || !ch.hash) return;

    const existingChannel = channels.find(c => c.platform === ch.platform && c.hash === ch.hash);
    if (existingChannel) {
      // 다른 창에 있는 채널이면 소유 창을 옮긴다(§3.3).
      const targetSlot = ch.__ownerSlotId || windowSlotId;
      if (isWindowRegistered() && targetSlot && resolveChannelOwnerSlot(existingChannel.hash) !== targetSlot) {
        movedChannels.push({ channel: existingChannel, slotId: targetSlot });
      }
      // 이미 있는 채널은 최신 값만 반영하고 그 채널 화면만 다시 불러온다(유튜브 videoId 무효화 대비).
      let needsRefresh = false;
      if (ch.platform === 'youtube' && ch.videoId && ch.videoId !== existingChannel.videoId) {
        existingChannel.videoId = ch.videoId;
        needsRefresh = true;
      }
      if (ch.platform === 'soop' && ch.broadNo && ch.broadNo !== existingChannel.broadNo) {
        existingChannel.broadNo = ch.broadNo;
        needsRefresh = true;
      }
      const displayChannel = displayChannels.find(c => c.platform === ch.platform && c.hash === ch.hash);
      if (displayChannel && displayChannel !== existingChannel) {
        displayChannel.videoId = existingChannel.videoId;
        displayChannel.broadNo = existingChannel.broadNo;
      }
      if (needsRefresh) {
        refreshChannelVideoWrapper(existingChannel.hash);
        hasRefreshed = true;
      }
      return;
    }

    // 기존 채널 갱신은 상한과 무관하게 허용한다.
    if (isChannelLimitReached()) {
      limitReached = true;
      return;
    }

    const channelData = { platform: ch.platform, hash: ch.hash, name: ch.name };
    if (ch.broadNo) channelData.broadNo = ch.broadNo;
    if (ch.videoId) channelData.videoId = ch.videoId;
    if (ch.isVod) channelData.isVod = true;
    if (ch.title) channelData.title = ch.title;
    if (ch.channelId) channelData.channelId = ch.channelId;
    if (typeof ch.hasLiveChat === 'boolean') channelData.hasLiveChat = ch.hasLiveChat;
    if (ch.isPinnedVideoSlot) channelData.isPinnedVideoSlot = true;
    // "c "로 추가했거나 숨김인 채로 저장된 채널 — 채팅탭만 남는다. 챗탭이 없는 채널(숲 VOD)은 제외.
    if (ch.chatOnly && channelSupportsChatTab(channelData)) {
      channelData.chatOnly = true;
      // "c "로 추가된 채널 표시 — chatOnly는 눈 아이콘 한 번에 지워지므로 따로 남긴다.
      channelData.chatOnlyAdded = true;
      videoHiddenChannels.add(channelData.hash);
    }
    // broadcastDate도 화이트리스트에 넣어야 남는다.
    if (ch.broadcastDate) channelData.broadcastDate = ch.broadcastDate;
    if (ch.platform === 'youtube') {
      console.log(`[CHEESE EYES][YT-DEBUG] commitChannels: ${ch.name}(${ch.hash}) videoId=${ch.videoId || '(없음)'}`);
    }

    channels.push(channelData);
    displayChannels.push(channelData);
    channelAddOrder.push(channelData.hash);
    newHashes.push(channelData.hash);
    newOwnerSlots.push(ch.__ownerSlotId || null);
    hasAdded = true;
  });

  if (limitReached) notifyChannelLimitReached();
  movedChannels.forEach(({ channel, slotId }) => {
    claimChannelOwnership([channel.hash], slotId);
    if (slotId === windowSlotId) notifyChannelMovedHere(channel);
  });
  if (!hasAdded && !hasRefreshed) {
    if (movedChannels.length > 0) renderAll();
    return;
  }

  if (hasAdded) {
    if (!mainChannel) mainChannel = getFirstVideoChannelHash();
    if (!activeChatChannel) activeChatChannel = displayChannels[0].hash;
    if (isWindowRegistered()) {
      const hashesBySlot = new Map();
      newHashes.forEach((hash, i) => {
        const slotId = newOwnerSlots[i] || windowSlotId;
        if (!hashesBySlot.has(slotId)) hashesBySlot.set(slotId, []);
        hashesBySlot.get(slotId).push(hash);
      });
      Promise.all([...hashesBySlot].map(([slotId, hashes]) => claimChannelOwnership(hashes, slotId)))
        .then(() => saveChannelsToStorage());
    } else {
      saveChannelsToStorage();
    }
  }

  renderAll();
}

// ── 사이드바 "멀티뷰로 보내기" ── pending_multiview_add 목록을 getChannelById로 해석해 commitChannels로 반영한다.
async function processPendingMultiviewAdd() {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.session) return;
  // 모든 창이 알림을 받으므로 대표 창만 처리한다(§3.3).
  await windowRegistrationReady;
  if (!isRepresentativeWindow()) return;

  let data;
  try {
    data = await chrome.storage.session.get('pending_multiview_add');
  } catch (e) {
    return;
  }
  const items = data && data.pending_multiview_add;
  if (!items || items.length === 0) return;

  await chrome.storage.session.remove('pending_multiview_add');

  const resolved = [];
  // 담아 둔 사이 방송이 끝났을 수 있다.
  const offlineChzzkOnAdd = [];
  for (const item of items) {
    try {
      let channelData = null;
      if (item.isVod) {
        // VOD는 라이브 조회 없이 채널 데이터를 직접 구성한다.
        channelData = { platform: item.platform, hash: item.id, name: item.title || item.id, isVod: true };
      } else if (item.platform === 'soop' && item.broadNo) {
        channelData = { platform: 'soop', hash: item.id, broadNo: item.broadNo, name: item.title || item.id };
      } else {
        channelData = await getAdapter(item.platform).getChannelById(item.id);
        if (channelData && channelData.hash && item.platform === 'chzzk') {
          const isLive = await checkChzzkLiveByChannelId(channelData.hash);
          if (!isLive) offlineChzzkOnAdd.push(channelData);
        }
      }
      if (channelData && channelData.hash) {
        if (typeof item.ownerSlotId === 'string' && item.ownerSlotId) channelData.__ownerSlotId = item.ownerSlotId;
        resolved.push(channelData);
      }
    } catch (err) {
      console.error('[CHEESE EYES] 사이드바에서 추가된 채널 처리 실패:', item, err);
    }
  }

  if (resolved.length > 0) {
    commitChannels(resolved);
    offlineChzzkOnAdd.forEach((ch) => showVodPickerForChannel(ch));
  }
}

// ── 사이드바 "대기열에 추가" ── pending_queue_add(유튜브만)를 getChannelById로 해석해 enqueueYoutubeVideo로 넘긴다.
async function processPendingQueueAdd() {
  if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.session) return;
  // 대표 창만 대기열에 넣는다(§3.5).
  await windowRegistrationReady;
  if (!isRepresentativeWindow()) return;

  let data;
  try {
    data = await chrome.storage.session.get('pending_queue_add');
  } catch (e) {
    return;
  }
  const items = data && data.pending_queue_add;
  if (!items || items.length === 0) return;

  await chrome.storage.session.remove('pending_queue_add');

  for (const item of items) {
    try {
      const channelData = await getAdapter('youtube').getChannelById(item.id);
      if (channelData && channelData.videoId) {
        // 이미 알아낸 채널명/제목을 미리 넘긴다.
        await enqueueYoutubeVideo(null, channelData.videoId, channelData.title, channelData.name);
      }
    } catch (err) {
      console.error('[CHEESE EYES] 사이드바에서 대기열로 추가된 항목 처리 실패:', item, err);
    }
  }
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === 'MULTIVIEW_PENDING_ADD_READY') {
      processPendingMultiviewAdd();
    } else if (message && message.type === 'QUEUE_PENDING_ADD_READY') {
      processPendingQueueAdd();
    } else if (message && message.type === 'CHEESE_YT_NEWTAB_SUGGESTION' && message.videoId) {
      // background의 새 탭 차단이 잡은 추천 영상도 대기열에 담는다.
      enqueueYoutubeVideo(null, message.videoId, undefined, undefined, true);
    }
  });
}

function levenshteinDistance(a, b) {
  const m = a.length, n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;

  const dp = new Array(n + 1);
  for (let j = 0; j <= n; j++) dp[j] = j;

  for (let i = 1; i <= m; i++) {
    let prevDiag = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const temp = dp[j];
      dp[j] = a[i - 1] === b[j - 1]
        ? prevDiag
        : Math.min(prevDiag, dp[j], dp[j - 1]) + 1;
      prevDiag = temp;
    }
  }
  return dp[n];
}

function computeRelevanceScore(query, candidateName) {
  if (!candidateName) return -1;
  const q = String(query).trim().toLowerCase();
  const c = String(candidateName).trim().toLowerCase();
  if (!q || !c) return -1;

  if (q === c) return 1;
  if (c.includes(q) || q.includes(c)) {
    const lenDiff = Math.abs(c.length - q.length);
    return Math.max(0.7, 0.95 - lenDiff * 0.02);
  }

  const dist = levenshteinDistance(q, c);
  const maxLen = Math.max(q.length, c.length);
  return maxLen === 0 ? 0 : 1 - dist / maxLen;
}

function mergeTagChannelsByRelevance(query, listsByPlatform) {
  const maxLen = Math.max(0, ...listsByPlatform.map(list => list.length));
  const merged = [];

  for (let i = 0; i < maxLen; i++) {
    const candidates = listsByPlatform
      .map(list => list[i])
      .filter(Boolean)
      .sort((a, b) => computeRelevanceScore(query, b.name) - computeRelevanceScore(query, a.name));

    merged.push(...candidates);
  }

  return merged;
}

function mergeAutocompleteByRelevance(keyword, listsByPlatform) {
  const maxLen = Math.max(0, ...listsByPlatform.map(list => list.length));
  const merged = [];

  for (let i = 0; i < maxLen; i++) {
    const candidates = listsByPlatform
      .map(list => list[i])
      .filter(Boolean)
      .sort((a, b) => computeRelevanceScore(keyword, b.text) - computeRelevanceScore(keyword, a.text));

    merged.push(...candidates);
  }

  return merged;
}

async function addChannelFromInput() {
  const value = channelInput.value.trim();
  if (!value) {
    if (channelInput) channelInput.focus();
    return;
  }

  hideAutocomplete();

  // "r 채널명" — 다시보기 목록 모달(치지직/유튜브). 커밋 시점에만 동작이 갈린다.
  const { vodPrefix, rest: vodStripped } = splitVodSearchPrefix(value);
  if (vodPrefix) {
    const vodTokens = vodStripped.split(',').map(t => t.trim()).filter(t => t.length > 0);
    channelInput.value = '';
    for (const token of vodTokens) {
      rememberRecentSearch(token, 'vod', vodSearchPlatformHints.get(token) || null);
      await resolveAndOpenVodSearchModal(token);
    }
    return;
  }

  // "c 채널명" — 같은 해석 경로로 챗만 상태로 커밋한다.
  const { chatPrefix, rest: chatStripped } = splitChatOnlySearchPrefix(value);
  const chatOnlyAdd = !!chatPrefix;

  // 구분자는 쉼표만(공백으로 나누면 띄어쓴 채널명이 쪼개짐).
  const rawTokens = chatStripped.split(',').map(t => t.trim()).filter(t => t.length > 0);

  const directChannels = [];
  const pendingKeywords = [];
  // 직접 붙여넣은 치지직 라이브가 오프라인이면 추가 후 다시보기 선택 패널을 띄운다.
  const offlineChzzkOnAdd = [];

  for (const token of rawTokens) {
    const direct = parseDirectInput(token);

    if (direct) {
      let channelData = null;
      if (direct.isVod) {
        // VOD는 라이브 조회 API로 넘기지 않는다.
        channelData = { platform: direct.platform, hash: direct.id, name: direct.id, isVod: true };
      } else if (direct.platform === 'soop' && direct.broadNo) {
        channelData = { platform: 'soop', hash: direct.id, broadNo: direct.broadNo, name: direct.id };
      } else {
        channelData = await getAdapter(direct.platform).getChannelById(direct.id);
        if (channelData && channelData.hash && direct.platform === 'chzzk') {
          const isLive = await checkChzzkLiveByChannelId(channelData.hash);
          if (!isLive) offlineChzzkOnAdd.push(channelData);
        }
      }
      if (channelData && channelData.hash) directChannels.push(channelData);
      continue;
    }

    // 직접 붙여넣기는 최근 검색어에 남기지 않는다. 자동완성 플랫폼 힌트를 같이 남긴다.
    const hintPlatform = autocompletePlatformHints.get(token);
    // 아이콘 색용으로 vodSearchPlatformHints로 보강한다(autocompletePlatformHints는 유튜브를 뺌).
    rememberRecentSearch(token, chatOnlyAdd ? 'chat' : 'channel', hintPlatform || vodSearchPlatformHints.get(token) || null);
    let resolvedDirectly = false;

    if (hintPlatform) {
      try {
        const channelData = await getAdapter(hintPlatform).searchChannelByName(token);
        if (channelData && channelData.hash) {
          const isLive = channelData.platform === 'chzzk'
            ? await checkChzzkLiveByChannelId(channelData.hash)
            : true;
          if (isLive) {
            directChannels.push(channelData);
            resolvedDirectly = true;
          }
        }
      } catch (err) {
        console.error(`'${token}' 채널 확인 실패:`, err);
      }
    }

    if (!resolvedDirectly) pendingKeywords.push(token);
  }

  if (directChannels.length > 0) {
    if (chatOnlyAdd) directChannels.forEach((ch) => { if (ch) ch.chatOnly = true; });
    commitChannels(directChannels);
    // commitChannels가 동기적으로 렌더링까지 끝내므로 wrapper가 이미 있다.
    offlineChzzkOnAdd.forEach((ch) => showVodPickerForChannel(ch));
  }

  channelInput.value = '';

  if (pendingKeywords.length > 0) {
    openLiveConfirmModal(pendingKeywords, { chatOnly: chatOnlyAdd });
  }
}

function switchLayout(mode) {
  if (currentLayout === mode) return;

  currentLayout = mode;
  saveLayoutToStorage();
  document.getElementById('mode-grid')?.classList.toggle('active', mode === 'grid');
  document.getElementById('mode-main_sub')?.classList.toggle('active', mode === 'main_sub');
  suppressVolumeEchoReports(2000);
  renderVideo();
  // 레이아웃 전환은 여러 채널 기준 음량이 한꺼번에 바뀌므로 부드럽게 넘긴다.
  applyVolumeToAllChannels(true);
  renderAudioSettingsList();
  renderCollabSettingsSection();
  refreshExtendedMainSubState();
}

function swapChannels(hash1, hash2) {
  const paIdx1 = channels.findIndex(c => c.hash === hash1);
  const paIdx2 = channels.findIndex(c => c.hash === hash2);

  if (paIdx1 !== -1 && paIdx2 !== -1) {
    const tempPa = channels[paIdx1];
    channels[paIdx1] = channels[paIdx2];
    channels[paIdx2] = tempPa;
  }
  const daIdx1 = displayChannels.findIndex(c => c.hash === hash1);
  const daIdx2 = displayChannels.findIndex(c => c.hash === hash2);

  if (daIdx1 !== -1 && daIdx2 !== -1) {
    const tempDa = displayChannels[daIdx1];
    displayChannels[daIdx1] = displayChannels[daIdx2];
    displayChannels[daIdx2] = tempDa;
  }
  // mainChannel은 hash로 추적하므로 자리 교환으로 바꾸지 않는다.

  saveChannelsToStorage();
  renderAll();
}

function setMainChannel(hash) {
  if (!hash || mainChannel === hash) return;

  // 직접 메인을 지정했으니 숨김 자동 복귀 약속을 취소한다.
  if (pendingMainRestoreHash && hash !== pendingMainRestoreHash && !suppressPendingMainInvalidate) {
    pendingMainRestoreHash = null;
  }

  const prevMainHash = mainChannel;

  // main_sub에서만 이전/새 메인 두 자리를 swap한다(서브 목록 순서 유지). 그리드는 타일 순서를 바꾸지 않는다.
  if (prevMainHash && currentLayout === 'main_sub') {
    const swapPositions = (arr) => {
      const idxOld = arr.findIndex(c => c.hash === prevMainHash);
      const idxNew = arr.findIndex(c => c.hash === hash);
      if (idxOld !== -1 && idxNew !== -1 && idxOld !== idxNew) {
        const temp = arr[idxOld];
        arr[idxOld] = arr[idxNew];
        arr[idxNew] = temp;
      }
    };
    swapPositions(channels);
    swapPositions(displayChannels);
  }

  mainChannel = hash;
  suppressVolumeEchoReports(2000);
  if (extendedMainSubActive && prevMainHash) beginCollabMovePause([prevMainHash, hash]);

  // 메인 = 합방 대표라 항상 재판정한다. 영향받는 그룹은 Stage2 재확인까지 keeper를 즉시 뒤집지 않게 표시한다.
  if (isCollabSettingEnabled()) {
    getEffectiveCollabGroups().forEach((group) => {
      if (group.memberHashes.includes(prevMainHash) || group.memberHashes.includes(hash)) {
        leaderChangedAtByGroupId[group.id] = Date.now();
        // vod-sync면 멤버 전원의 마지막 재생/정지 명령 기록을 지운다 — 역할이 바뀐 채널의 낡은 값 때문에 명령이 생략됐다.
        if (isVodSyncGroup(group)) {
          group.memberHashes.forEach((h) => { delete vodSyncLastCommandedPlaying[h]; });
        }
      }
    });
    recomputeCollabMuting();
    applyVolumeToAllChannels();
    renderCollabSettingsSection();
  }

  if (currentLayout === 'main_sub') {
    applyScreenChangeChatChannel(mainChannel);
    updateChatSession();
    renderAudioSettingsList();
  }

  saveChannelsToStorage();
  renderAll();
}

function setChatChannel(hash) {
  if (!hash) return;
  // 챗탭이 없는 채널(치지직/숲 VOD)은 채팅 패널을 건드리지 않는다.
  const ch = getChannelObjByHash(hash);
  if (ch && !channelSupportsChatTab(ch)) return;
  // 실제로 바뀔 때만 애니메이션을 건다.
  const chatChanged = activeChatChannel !== hash;
  // 두 번째 칸 채널을 첫 칸으로 올리면 두 번째 칸을 비운다.
  if (secondaryChatChannel === hash) secondaryChatChannel = null;
  activeChatChannel = hash;
  ensureSecondaryChatChannel();
  saveWindowState();
  refreshChatTabActiveClass();
  ensureChatIframeCreated(hash);
  updateChatTabPaneMarks();
  syncChatVisibility();
  if (chatChanged) playChatPaneEnterAnimation(hash);
}
let iframeLoadQueue = [];
let isProcessingQueue = false;
const QUEUE_CONFIG = {
  initialDelay: 0,     
  stepDelay: 50,       
  maxDelayCap: 2000,   
  maxRetries: 3        
};

function createIframeReadyPromise(iframe, hash, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let isResolved = false;

    try {
      const videoElem = iframe.contentDocument?.querySelector('video');
      if (videoElem) {
        if (videoElem.readyState >= 3) {
          videoElem.pause();
          return resolve({ iframe, hash, success: true });
        }
        const onReady = () => {
          videoElem.pause();
          cleanup();
          if (!isResolved) { isResolved = true; resolve({ iframe, hash, success: true }); }
        };
        videoElem.addEventListener('canplaythrough', onReady, { once: true });
        videoElem.addEventListener('canplay', onReady, { once: true });
      }
    } catch (e) {
    
    }
    const handleMessage = (event) => {
      if (!event.origin.includes('naver.com') && !event.origin.includes('chzzk')) return;

      const data = event.data;
      if (!data) return;

      const isReady = 
        data.type === 'PLAYER_READY' ||
        data.type === 'BUFFERING_END' ||
        data.type === 'PLAYBACK_STATE_CHANGED' ||
        data.cmd === 'ready' ||
        (typeof data === 'string' && (data.includes('ready') || data.includes('canplay')));

      if (isReady) {
        iframe.contentWindow?.postMessage(JSON.stringify({ cmd: 'pause', type: 'command' }), '*');
        cleanup();
        if (!isResolved) { isResolved = true; resolve({ iframe, hash, success: true }); }
      }
    };

    const iframeLoadHandler = () => {
      setTimeout(() => {
        if (!isResolved) {
          console.log(`⚡ [FAST FALLBACK] [${hash}] Iframe 로드 후 안정화 완료 (조기 동기화)`);
          cleanup();
          isResolved = true;
          resolve({ iframe, hash, success: true });
        }
      }, 1500); 
    };

    if (iframe.contentDocument && iframe.contentDocument.readyState === 'complete') {
      iframeLoadHandler();
    } else {
      iframe.addEventListener('load', iframeLoadHandler, { once: true });
    }

    const timer = setTimeout(() => {
      console.warn(`⏰ [READY TIMEOUT] [${hash}] 최종 시간 초과 (강제 포함)`);
      cleanup();
      if (!isResolved) { isResolved = true; resolve({ iframe, hash, success: false }); }
    }, timeoutMs);

    function cleanup() {
      clearTimeout(timer);
      window.removeEventListener('message', handleMessage);
      iframe.removeEventListener('load', iframeLoadHandler);
    }

    window.addEventListener('message', handleMessage);
    iframe.contentWindow?.postMessage(JSON.stringify({ cmd: 'pause', type: 'command' }), '*');
  });
}

async function processIframeQueue() {
  if (isProcessingQueue || isReloadingAll) return;
  isProcessingQueue = true;

  try {
    // 큐가 실제로 빌 때까지 바깥 루프를 돈다 — 처리 중 늦게 추가된 유튜브 항목이 처리되지 않고 검은 화면으로 남았다.
    while (true) {
      let currentDelay = QUEUE_CONFIG.initialDelay;
      const loadingPromises = [];

      while (iframeLoadQueue.length > 0) {
        const task = iframeLoadQueue.shift();
        if (!task || !task.iframe || !task.url) continue;

        const targetHash = task.hash || task.url.split('/').pop();
        const isStillExist = channels.some(c => c.hash === targetHash);
        if (!isStillExist) {
          console.warn(`🛑 [QUEUE SKIP] 이미 삭제된 채널입니다. (Skip): ${targetHash}`);
          continue;
        }

        console.log(`⏳ [QUEUE LOAD] Iframe 생성/URL 할당 -> 타겟 Hash: ${targetHash}`);
        const isSuccess = await loadIframeWithBackoff(task.iframe, task.url, targetHash);

        if (isSuccess) {
          loadingPromises.push(createIframeReadyPromise(task.iframe, targetHash, 10000));
        } else {
          console.error(`❌ [QUEUE FAIL] 최종 로드 실패: ${targetHash}`);
        }

        await new Promise(resolve => setTimeout(resolve, currentDelay));
        currentDelay = Math.min(currentDelay + QUEUE_CONFIG.stepDelay, QUEUE_CONFIG.maxDelayCap);
      }

      if (loadingPromises.length > 0) {
        console.log(`⏳ [SYNC WAIT] 총 ${loadingPromises.length}개 채널의 버퍼링 완결을 비동기로 동시에 대기합니다...`);

        const results = await Promise.all(loadingPromises);
        const readyIframes = results.filter(res => res.iframe);
        const startTime = performance.now();
        const clockTime = new Date().toISOString().split('T')[1].slice(0, -1);

        console.log(`▶️ [ALL SYNC PLAY] [${clockTime}] 모든 채널 버퍼링 완전 완료! 총 ${readyIframes.length}개 비디오 동시 재생 실행`);

        unpauseAllIframesSimultaneously(readyIframes, startTime);
      }

      if (iframeLoadQueue.length === 0) break;
    }

  } catch (error) {
    console.error(`💥 [QUEUE ERROR] 큐 내부 예외 발생:`, error);
  } finally {
    isProcessingQueue = false;
    loadAllChatsSequential();
  }
}

function unpauseAllIframesSimultaneously(iframeList, baseTime) {
  const len = iframeList.length;
  if (len === 0) return;

  const targets = new Array(len);
  for (let i = 0; i < len; i++) {
    const item = iframeList[i];
    const iframe = item.iframe || item;
    targets[i] = {
      win: iframe.contentWindow,
      hash: item.hash || iframe.getAttribute('data-hash') || `채널 #${i + 1}`,
      isYoutube: iframe.closest('.video-wrapper')?.getAttribute('data-platform') === 'youtube'
    };
  }

  requestAnimationFrame(() => {
    const triggerStart = performance.now();
    const clockTime = new Date().toISOString().split('T')[1].slice(0, -1);

    for (let i = 0; i < len; i++) {
      const target = targets[i];
      if (!target || !target.win) continue;

      target.win.postMessage({ action: 'SYNC_PLAY', type: 'SET_VOLUME', value: 100 }, '*');
      // 유튜브는 SET_VOLUME이 이미 재생을 시도하므로(사용자 일시정지 가드 포함) PLAY를 따로 보내지 않는다.
      if (!target.isYoutube) {
        target.win.postMessage({ type: 'PLAY' }, '*');
      }

      const now = performance.now();
      const diffFromStart = (now - triggerStart).toFixed(3);

      console.log(`🔊 [ALL PLAY TRIGGER] [${clockTime}] [${target.hash}] 트리거 완료 (+${diffFromStart}ms)`);
    }
  });
}

async function loadIframeWithBackoff(iframe, url, hash) {
  let attempt = 0;

  while (attempt <= QUEUE_CONFIG.maxRetries) {
    try {
      if (attempt > 0) {
        const backoffDelay = 100 * Math.pow(2, attempt);
        console.warn(`⚠️ [RETRY ${attempt}/${QUEUE_CONFIG.maxRetries}] ${hash} - ${backoffDelay}ms 후 재시도`);
        await new Promise(resolve => setTimeout(resolve, backoffDelay));
      }

      iframe.src = url;
      return true;

    } catch (error) {
      console.error(`❌ [LOAD ERROR] (${attempt + 1}회차) ${hash}:`, error);
      attempt++;
    }
  }

  return false;
}
async function loadAllChatsSequential() {
  if (!displayChannels || displayChannels.length === 0) return;
  if (activeChatChannel) {
    ensureChatIframeCreated(activeChatChannel);
  }
  for (const item of displayChannels) {
    if (item.hash === activeChatChannel) continue;

    ensureChatIframeCreated(item.hash);
  }
}

function getOrCreateVideoWrapper(item) {
  if (videoWrapperMap.has(item.hash)) {
    return videoWrapperMap.get(item.hash);
  }

  const wrapper = document.createElement('div');
  wrapper.setAttribute('data-hash', item.hash);
  wrapper.setAttribute('data-platform', item.platform);
  wrapper.style.setProperty('--tab-color', getPlatformColor(item.platform));
  wrapper.style.setProperty('--tab-color-rgb', getPlatformColorRGB(item.platform));

  const iframe = document.createElement('iframe');
  iframe.src = 'about:blank';
  iframe.setAttribute("allow", IFRAME_ALLOW);

  if (item.platform === 'soop') {
    iframe.name = isNaN(Number(item.hash)) ? item.hash : `#${item.hash}`;
  }

  iframe.style.width = '100%';
  iframe.style.height = '100%';
  iframe.style.border = 'none';
  
  iframe.addEventListener('load', () => {
  if (iframe.src !== 'about:blank' && iframe.contentWindow) {
      // 다시 불러온 페이지는 캡처가 꺼진 채 시작하므로 켜짐 기록을 지운다.
      const loadedHash = wrapper.getAttribute('data-hash') || item.hash;
      collabCaptureHashes.delete(loadedHash);
      delete collabCaptureWindowSecByHash[loadedHash];
      markLiveSyncNewPlayer(loadedHash); // 새로 뜬 플레이어는 지연이 안정되면 메인 채널에 한 번 맞춘다

      setTimeout(() => {
        iframe.contentWindow?.postMessage({ type: 'APPLY_WIDE_MODE' }, '*'); // 그 사이 채널이 지워지면 contentWindow가 null
        const initVol = getDisplayVolumeForChannel(item.hash);
        const realInitVol = getEffectiveVolumeForChannel(item.hash);
        lastAppliedDisplayVolume[item.hash] = initVol;
        lastAppliedRealVolume[item.hash] = realInitVol;
        postVolumeMsg(item.hash, realInitVol);
      }, 1000);
      // 플랫폼이 뒤늦게 음소거할 수 있어 같은 값을 한 번 더 보낸다(중복 억제 캐시 우회).
      setTimeout(() => {
        const reVol = getDisplayVolumeForChannel(item.hash);
        const realReVol = getEffectiveVolumeForChannel(item.hash);
        lastAppliedDisplayVolume[item.hash] = reVol;
        lastAppliedRealVolume[item.hash] = realReVol;
        delete lastSentVolumeMessage[item.hash];
        postVolumeMsg(item.hash, realReVol);
      }, 3000);
      if (item.platform === 'soop') {
        setTimeout(() => markSoopVideoReady(item.hash), 6000);
      }
    }
  });

  wrapper.appendChild(iframe);

  // 대기열 항목을 타일에 드롭하면 그 채널 전용으로 예약한다. hash는 매번 data-hash에서 다시 읽는다.
  wrapper.addEventListener('dragover', (e) => {
    if (!e.dataTransfer) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    wrapper.classList.add('queue-drop-target');
  });
  wrapper.addEventListener('dragleave', () => {
    wrapper.classList.remove('queue-drop-target');
  });
  wrapper.addEventListener('drop', (e) => {
    e.preventDefault();
    wrapper.classList.remove('queue-drop-target');
    const raw = e.dataTransfer && e.dataTransfer.getData('text/plain');
    const index = raw ? parseInt(raw, 10) : NaN;
    if (Number.isNaN(index)) return;
    const currentHash = wrapper.getAttribute('data-hash') || item.hash;
    setQueueItemTarget(index, currentHash);
  });

  // 교차 출처 iframe 클릭은 부모로 안 오므로 카드 전체를 덮는 투명 레이어로 클릭을 받는다.
  const selectCatcher = document.createElement('div');
  selectCatcher.className = 'video-select-catcher';
  selectCatcher.addEventListener('click', () => {
    const currentHash = wrapper.getAttribute('data-hash') || item.hash;

    // 다른 채널의 조작 가능 상태를 다시 잠근다(여기 왔다면 항상 이 채널의 첫 클릭).
    if (controlUnlockedHash && controlUnlockedHash !== currentHash) {
      lockChannelControl(controlUnlockedHash);
    }

    if (wrapper.classList.contains('sub-session')) {
      setMainChannel(currentHash);
    } else if (wrapper.classList.contains('grid-item')) {
      setChatChannel(currentHash);
      // 첫 클릭에서도 setMainChannel을 불러 그리드 대표 전환이 한 번에 되게 한다.
      setMainChannel(currentHash);
    }

    // 처리 직후 캐처를 꺼서 다음 클릭부터 iframe으로 직접 전달한다.
    unlockChannelControl(currentHash);
  });
  wrapper.appendChild(selectCatcher);

  const edgeSensor = document.createElement('div');
  edgeSensor.className = 'video-edge-sensor';
  wrapper.appendChild(edgeSensor);

  (async () => {
    // URL을 만들기 직전에 최신 videoId로 갱신한다(저장된 옛 videoId는 무효일 수 있음).
    if (item.platform === 'youtube') {
      await refreshYoutubeVideoId(item.hash);
    }
    iframeLoadQueue.push({
      iframe: iframe,
      url: getAdapter(item.platform).getVideoEmbedUrl(item.hash),
      hash: item.hash
    });
    processIframeQueue();
  })();
  const isMain = (mainChannel === item.hash);
  const overlay = document.createElement('div');
  overlay.className = 'video-overlay';
  overlay.style.pointerEvents = 'none';
  // 삭제/드래그/홈 버튼은 우측 세로 묶음(유튜브 우상단 컨트롤 아래). 숨김 버튼은 채팅탭에 있다.
  // channelId를 모르는 치지직 VOD(URL 직접 추가)는 홈 버튼을 렌더링하지 않는다.
  const platformAdapter = getAdapter(item.platform);
  const canShowChannelHome = !(item.platform === 'chzzk' && item.isVod && !item.channelId);
  const channelHomeBtnHtml = canShowChannelHome ? `
      <button type="button" class="channel-home-btn" data-i18n-title="video.channelHome" title="${t('video.channelHome', '채널 홈으로 이동')}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <line x1="7" y1="17" x2="17" y2="7"></line>
          <polyline points="8 7 17 7 17 16"></polyline>
        </svg>
      </button>` : '';
  // VOD 현재 시점을 네이티브 플레이어 새 탭으로 여는 버튼(getVodUrlAtTime 지원 플랫폼만).
  const canShowVodTimeLink = !!(item.isVod && typeof platformAdapter.getVodUrlAtTime === 'function');
  const vodTimeBtnHtml = canShowVodTimeLink ? `
      <button type="button" class="vod-open-time-btn" data-i18n-title="video.openAtCurrentTime" title="${t('video.openAtCurrentTime', '이 시점으로 새 탭에서 열기')}">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="9"></circle>
          <polyline points="12 7 12 12 15.5 14"></polyline>
        </svg>
      </button>` : '';
  overlay.innerHTML = `
    <div class="channel-badge-group">
      <button type="button" class="remove-card-btn" data-i18n-title="video.removeChannel" title="${t('video.removeChannel', '채널 삭제')}">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
      <button type="button" class="drag-handle-btn" data-i18n-title="video.dragHandle" title="${t('video.dragHandle', '드래그하여 위치 이동')}" draggable="true">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <circle cx="9" cy="5" r="1.5" fill="currentColor"/><circle cx="15" cy="5" r="1.5" fill="currentColor"/>
          <circle cx="9" cy="12" r="1.5" fill="currentColor"/><circle cx="15" cy="12" r="1.5" fill="currentColor"/>
          <circle cx="9" cy="19" r="1.5" fill="currentColor"/><circle cx="15" cy="19" r="1.5" fill="currentColor"/>
        </svg>
      </button>
      ${channelHomeBtnHtml}
      ${vodTimeBtnHtml}
    </div>
  `;

  const removeBtn = overlay.querySelector('.remove-card-btn');
  if (removeBtn) {
    removeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const currentHash = wrapper.getAttribute('data-hash') || item.hash;
      removeChannel(currentHash);
    });
  }
  const dragHandle = overlay.querySelector('.drag-handle-btn');
  if (dragHandle) {
    dragHandle.addEventListener('dragstart', (e) => {
      const currentHash = wrapper.getAttribute('data-hash') || item.hash;
      e.dataTransfer.setData('text/plain', currentHash);
      const sec = lastKnownPlaybackTimeSec[currentHash];
      e.dataTransfer.setData(CHANNEL_DRAG_MIME, JSON.stringify({ hash: currentHash, sec: typeof sec === 'number' ? sec : null }));
      e.dataTransfer.effectAllowed = 'move';
      wrapper.classList.add('dragging');
      document.body.classList.add('is-dragging-card');
    });

    dragHandle.addEventListener('dragend', () => {
      wrapper.classList.remove('dragging');
      document.body.classList.remove('is-dragging-card');
      document.querySelectorAll('.video-wrapper').forEach(w => w.classList.remove('drag-over'));
    });
  }

  const homeBtn = overlay.querySelector('.channel-home-btn');
  if (homeBtn) {
    homeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const currentHash = wrapper.getAttribute('data-hash') || item.hash;
      const platform = wrapper.getAttribute('data-platform') || item.platform;
      const adapter = getAdapter(platform);
      if (typeof adapter.getChannelHomeUrl === 'function') {
        window.open(adapter.getChannelHomeUrl(currentHash), '_blank');
      }
    });
  }

  const vodTimeBtn = overlay.querySelector('.vod-open-time-btn');
  if (vodTimeBtn) {
    vodTimeBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const currentHash = wrapper.getAttribute('data-hash') || item.hash;
      const platform = wrapper.getAttribute('data-platform') || item.platform;
      const adapter = getAdapter(platform);
      if (typeof adapter.getVodUrlAtTime === 'function') {
        const sec = lastKnownPlaybackTimeSec[currentHash] || 0;
        window.open(adapter.getVodUrlAtTime(currentHash, sec), '_blank');
      }
    });
  }

  wrapper.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (!wrapper.classList.contains('drag-over')) {
      wrapper.classList.add('drag-over');
    }
  });

  wrapper.addEventListener('dragleave', (e) => {
    if (!wrapper.contains(e.relatedTarget)) {
      wrapper.classList.remove('drag-over');
    }
  });

  wrapper.addEventListener('drop', (e) => {
    e.preventDefault();
    e.stopPropagation();
    wrapper.classList.remove('drag-over');

    const targetHash = wrapper.getAttribute('data-hash') || item.hash;
    handleChannelTileDrop(readChannelDragData(e.dataTransfer), targetHash);
  });

  wrapper.appendChild(overlay);
  videoGrid.appendChild(wrapper);
  videoWrapperMap.set(item.hash, wrapper);
  return wrapper;
}

// 모듈 스코프에서 한 번만 등록한다(타일마다 등록하던 누수 수정).
setInterval(() => {
  videoWrapperMap.forEach((wrapper, hash) => {
    if (hash !== mainChannel) {
      const iframe = wrapper.querySelector('iframe');
      if (iframe && iframe.contentWindow) {
        iframe.contentWindow.postMessage({ type: 'SEEK_TO_LIVE' }, '*');
      }
    }
  });
}, 300000);

function calcBestFit(total, width, height, maxCols = Infinity) {
  let bestWidth = 0;
  let bestHeight = 0;
  if (total <= 0 || width <= 0 || height <= 0) return { bestWidth: 0, bestHeight: 0 };

  const colLimit = Math.min(total, maxCols);
  for (let cols = 1; cols <= colLimit; cols++) {
    const rows = Math.ceil(total / cols);
    let maxWidth = Math.floor(width / cols);
    let maxHeight = Math.floor(height / rows);
    if ((maxWidth * 9) / 16 < maxHeight) {
      maxHeight = Math.floor((maxWidth * 9) / 16);
    } else {
      maxWidth = Math.floor((maxHeight * 16) / 9);
    }
    if (maxWidth > bestWidth) {
      bestWidth = maxWidth;
      bestHeight = maxHeight;
    }
  }
  return { bestWidth, bestHeight };
}

// 메인-서브 메인 화면 높이(vh) — 우하단 손잡이로 조절, mySetting.mainSessionVh에 저장. 풀스크린은 +6vh.
// 드래그 중엔 실제 메인 크기만 바꾸고 서브 재배치는 놓을 때 한 번.
const MAIN_SESSION_VH_DEFAULT = 72;
const MAIN_SESSION_VH_FS_OFFSET = 6;
const MAIN_SESSION_VH_MIN = 25;
const MAIN_SESSION_VH_MAX = 88;
let mainSessionResizeState = null;
let mainSessionBlockerEl = null;

function applyMainSessionSizeVar(vh) {
  const root = document.documentElement;
  if (typeof vh === 'number' && !isNaN(vh)) {
    const clamped = Math.min(MAIN_SESSION_VH_MAX, Math.max(MAIN_SESSION_VH_MIN, vh));
    root.style.setProperty('--main-session-vh', clamped);
    root.style.setProperty('--main-session-vh-fs', clamped + MAIN_SESSION_VH_FS_OFFSET);
    return clamped;
  }
  root.style.removeProperty('--main-session-vh');
  root.style.removeProperty('--main-session-vh-fs');
  return MAIN_SESSION_VH_DEFAULT;
}

function resetMainSessionSize() {
  mySetting.mainSessionVh = null;
  saveSetting();
  applyMainSessionSizeVar(null);
  renderVideo();
}

// 드래그 중엔 투명 레이어로 포인터 이벤트를 가로챈다(iframe 위에서 이벤트가 끊김).
function getMainSessionBlockerEl() {
  if (!mainSessionBlockerEl) {
    mainSessionBlockerEl = document.createElement('div');
    mainSessionBlockerEl.className = 'main-session-resize-blocker';
    document.body.appendChild(mainSessionBlockerEl);
  }
  return mainSessionBlockerEl;
}

function startMainSessionResize(e) {
  if (e.button !== 0) return;
  e.preventDefault();
  e.stopPropagation();

  const mainWrapper = e.currentTarget.closest('.video-wrapper.main-session');
  if (!mainWrapper) return;

  const rect = mainWrapper.getBoundingClientRect();
  // 지금 실제 높이에서 되짚어 계산한다(캐시값 기준이면 죽은 구간이 생김). 풀스크린이면 +6을 미리 뺀다(중복 적용 방지).
  const isFsMode = document.getElementById('app-container')?.classList.contains('fs-mode');
  const baseVh = (rect.height / window.innerHeight) * 100 - (isFsMode ? MAIN_SESSION_VH_FS_OFFSET : 0);
  mainSessionResizeState = {
    startX: e.clientX,
    startY: e.clientY,
    baseVh,
    finalVh: null,
  };
  mainWrapper.classList.add('resizing');
  document.body.classList.add('main-session-resizing');

  // 드래그 중 iframe 크기를 고정해(!important 필요) 리플로우는 놓을 때 한 번만.
  const iframe = mainWrapper.querySelector('iframe');
  if (iframe) {
    iframe.style.setProperty('width', `${rect.width}px`, 'important');
    iframe.style.setProperty('height', `${rect.height}px`, 'important');
  }

  const blocker = getMainSessionBlockerEl();
  blocker.classList.add('active');

  window.addEventListener('mousemove', onMainSessionResizeMove);
  window.addEventListener('mouseup', onMainSessionResizeUp);
}

// 매 이벤트마다 바로 반영한다(rAF 지연은 오히려 튀어 보였다).
function onMainSessionResizeMove(e) {
  const state = mainSessionResizeState;
  if (!state) return;

  // 가로 이동량도 16:9로 환산해 더 큰 쪽을 따른다(대각선 드래그 대응).
  const dy = e.clientY - state.startY;
  const dx = e.clientX - state.startX;
  const deltaVhFromY = (dy / window.innerHeight) * 100;
  const deltaVhFromX = ((dx * 9) / 16 / window.innerHeight) * 100;
  const deltaVh = Math.abs(deltaVhFromX) > Math.abs(deltaVhFromY) ? deltaVhFromX : deltaVhFromY;

  state.finalVh = applyMainSessionSizeVar(state.baseVh + deltaVh);
}

function onMainSessionResizeUp() {
  if (!mainSessionResizeState) return;
  const { baseVh, finalVh } = mainSessionResizeState;

  window.removeEventListener('mousemove', onMainSessionResizeMove);
  window.removeEventListener('mouseup', onMainSessionResizeUp);
  document.body.classList.remove('main-session-resizing');
  document.querySelectorAll('.video-wrapper.main-session.resizing').forEach(el => {
    el.classList.remove('resizing');
    // 고정한 iframe 크기를 풀어 한 번만 리플로우.
    const iframe = el.querySelector('iframe');
    if (iframe) {
      iframe.style.removeProperty('width');
      iframe.style.removeProperty('height');
    }
  });
  if (mainSessionBlockerEl) mainSessionBlockerEl.classList.remove('active');
  mainSessionResizeState = null;

  if (finalVh == null || finalVh === baseVh) return;

  mySetting.mainSessionVh = finalVh;
  saveSetting();
  renderVideo();
}

function renderVideo() {
  if (!videoGrid) return;

  // 이 창에 그릴 채널만 고르고 매번 프루닝한다(남은 래퍼가 중복으로 보임). 채팅만 채널은 아예 그리지 않는다(숨기기만 하면 계속 받음).
  const windowChannels = getChannelsShownInThisWindow(displayChannels).filter((c) => !c.chatOnly);
  const assignedHashes = new Set(windowChannels.map((c) => c.hash));
  videoWrapperMap.forEach((wrapper, hash) => {
    if (!assignedHashes.has(hash) && displayChannels.some((c) => c.hash === hash)) {
      wrapper.remove();
      videoWrapperMap.delete(hash);
    }
  });

  if (windowChannels.length === 0) {
    videoGrid.innerHTML = '';
    videoWrapperMap.clear();
    return;
  }

  videoGrid.className = '';
  document.getElementById('main-sub-row-break')?.remove();

  // 메인-서브라도 보이는 채널이 1개면 그리드 경로로 그린다. 메인-서브 확장 중엔 양쪽 창 모두 그리드처럼 채운다.
  if (currentLayout === 'grid' || isMainSubTreatedAsGrid() || extendedMainSubActive) {
    const total = windowChannels.length;
    // 숨긴 채널은 작은 썸네일 고정 — 보이는 채널 수 기준으로 계산(전부 숨겨졌으면 전체 수).
    const visibleCount = windowChannels.filter(c => !videoHiddenChannels.has(c.hash)).length || total;

    videoGrid.classList.add('grid-mode');

    const width = videoGrid.clientWidth;
    const height = videoGrid.clientHeight;

    const { bestWidth, bestHeight } = calcBestFit(visibleCount, width, height);

    videoGrid.style.display = 'flex';
    videoGrid.style.flexWrap = 'wrap';
    videoGrid.style.justifyContent = 'center';
    videoGrid.style.alignItems = 'center';
    videoGrid.style.alignContent = 'center';
    videoGrid.style.gridTemplateColumns = '';
    videoGrid.style.gridTemplateRows = '';

    windowChannels.forEach((item, index) => {
      const wrapper = getOrCreateVideoWrapper(item);
      if (!wrapper.parentNode) {
        videoGrid.appendChild(wrapper);
      }

      wrapper.style.display = 'block';
      wrapper.style.visibility = 'visible';
      wrapper.style.overflow = '';
      wrapper.style.pointerEvents = '';
      wrapper.style.position = '';

      wrapper.className = 'video-wrapper grid-item';
      wrapper.querySelector('.main-session-resize-handle')?.remove();
      wrapper.classList.toggle('video-hidden-item', videoHiddenChannels.has(item.hash));
      wrapper.style.flexGrow = '0';
      wrapper.style.width = `${bestWidth}px`;
      wrapper.style.height = `${bestHeight}px`;
      wrapper.style.gridRow = '';
      wrapper.style.gridColumn = '';
      wrapper.style.justifySelf = '';
      wrapper.style.transform = '';
      wrapper.style.order = index;
    });

    return;
  }
  videoGrid.style.display = '';
  videoGrid.style.flexWrap = '';
  videoGrid.style.justifyContent = '';
  videoGrid.style.alignItems = '';
  videoGrid.style.alignContent = '';
  videoGrid.style.gridTemplateColumns = '';
  videoGrid.style.gridTemplateRows = '';
  videoGrid.classList.add('main_sub-mode');

  const mainItem = windowChannels.find(item => item.hash === mainChannel) || windowChannels[0];
  const subItemList = windowChannels.filter(item => item.hash !== mainItem.hash);
  const mainWrapper = getOrCreateVideoWrapper(mainItem);
  if (!mainWrapper.parentNode) {
    videoGrid.appendChild(mainWrapper);
  }

  mainWrapper.style.display = 'block';
  mainWrapper.style.visibility = 'visible';
  mainWrapper.style.width = '';
  mainWrapper.style.height = '';
  mainWrapper.style.overflow = '';
  mainWrapper.style.pointerEvents = '';
  mainWrapper.style.position = '';
  mainWrapper.style.gridRow = '';
  mainWrapper.style.gridColumn = '';
  mainWrapper.style.justifySelf = '';
  mainWrapper.style.transform = '';
  mainWrapper.className = 'video-wrapper main-session';
  mainWrapper.classList.toggle('video-hidden-item', videoHiddenChannels.has(mainItem.hash));
  mainWrapper.style.order = 0;
  if (!mainWrapper.querySelector('.main-session-resize-handle')) {
    const resizeHandle = document.createElement('div');
    resizeHandle.className = 'main-session-resize-handle';
    resizeHandle.addEventListener('mousedown', startMainSessionResize);
    mainWrapper.appendChild(resizeHandle);
  }

  if (subItemList.length > 0) {
    const rowBreak = document.createElement('div');
    rowBreak.id = 'main-sub-row-break';
    rowBreak.className = 'main-sub-row-break';
    videoGrid.appendChild(rowBreak);

    void mainWrapper.offsetHeight;

    const gridStyle = window.getComputedStyle(videoGrid);
    const paddingX = parseFloat(gridStyle.paddingLeft || 0) + parseFloat(gridStyle.paddingRight || 0);
    const paddingY = parseFloat(gridStyle.paddingTop || 0) + parseFloat(gridStyle.paddingBottom || 0);

    const availableWidth = Math.max(videoGrid.clientWidth - paddingX, 0);
    const mainRect = mainWrapper.getBoundingClientRect();
    const availableHeight = Math.max(videoGrid.clientHeight - paddingY - mainRect.height, 60);
    const visibleSubCount = subItemList.filter(c => !videoHiddenChannels.has(c.hash)).length || subItemList.length;
    const MAX_SUB_COLS = 5;
    const subCols = Math.min(visibleSubCount, MAX_SUB_COLS);

    let bestWidth;
    let bestHeight;

    if (visibleSubCount <= MAX_SUB_COLS) {
      ({ bestWidth, bestHeight } = calcBestFit(visibleSubCount, availableWidth, availableHeight, subCols));
    } else {
      bestWidth = Math.floor(availableWidth / MAX_SUB_COLS);
      bestHeight = Math.floor((bestWidth * 9) / 16);
    }

    let subOrder = 1;
    subItemList.forEach(item => {
      const wrapper = getOrCreateVideoWrapper(item);
      if (!wrapper.parentNode) {
        videoGrid.appendChild(wrapper);
      }

      wrapper.style.display = 'block';
      wrapper.style.visibility = 'visible';
      wrapper.style.overflow = '';
      wrapper.style.pointerEvents = '';
      wrapper.style.position = '';
      wrapper.style.gridRow = '';
      wrapper.style.gridColumn = '';
      wrapper.style.justifySelf = '';
      wrapper.style.transform = '';

      wrapper.className = 'video-wrapper sub-session';
      wrapper.querySelector('.main-session-resize-handle')?.remove();
      wrapper.classList.toggle('video-hidden-item', videoHiddenChannels.has(item.hash));
      wrapper.style.order = subOrder++;

      if (bestWidth > 0 && bestHeight > 0) {
        wrapper.style.width = `${bestWidth}px`;
        wrapper.style.height = `${bestHeight}px`;
      } else {
        wrapper.style.width = '';
        wrapper.style.height = '';
      }
    });
  }
}

// 채팅 탭 아이콘·타일 배지가 함께 쓰는 합방 표시 상태(자동 클러스터 또는 VOD 싱크 그룹일 때만).
// 음소거된 채널은 듣는 채널(keeper)과 묶인 채널을 알려준다.
function getCollabDisplayState(hash) {
  if (!isCollabSettingEnabled()) return null;
  const cluster = getCollabLiveClusterForHash(hash);
  if (cluster) {
    const isKeeper = cluster.keeper === hash;
    const muted = !isKeeper && isChannelCollabMuted(hash);
    // 같은 소리로 묶인 다른 채널(둘뿐이면 괄호 생략).
    const others = cluster.members.filter((h) => h !== hash && h !== cluster.keeper).map(getChannelNameByHash);
    const keeperName = getChannelNameByHash(cluster.keeper);
    const title = muted
      ? (others.length > 0
        ? t('audio.collabListeningToTemplate', '{keeper} 방송으로 듣는 중 (같은 소리: {members})', { keeper: keeperName, members: others.join(', ') })
        : t('audio.collabListeningToSimpleTemplate', '{keeper} 방송으로 듣는 중', { keeper: keeperName }))
      : t('audio.collabKeeperTemplate', '{name} — 이 채널 소리로 듣는 중', { name: getCollabClusterName(cluster) });
    return { cluster, isKeeper, muted, color: cluster.color, title };
  }
  const group = findCollabGroupForChannel(hash);
  if (!isVodSyncGroup(group)) return null;
  const isKeeper = getCollabLeaderHash(group) === hash;
  const muted = !isKeeper && isChannelCollabMuted(hash);
  const title = muted
    ? t('audio.collabMutedLabel', '음소거')
    : (isKeeper ? t('audio.collabLeaderLabel', '대표') : t('audio.collabInGroupHint', '합방 그룹 소속'));
  return { cluster: null, isKeeper, muted, color: null, title };
}

function updateChatTabCollabIcons() {
  updateTileCollabBadges();
  if (!chatTabs) return;
  chatTabs.querySelectorAll('.chat-tab').forEach((tab) => {
    const icon = tab.querySelector('.chat-tab-collab-icon');
    if (!icon) return;
    const state = getCollabDisplayState(tab.getAttribute('data-hash'));
    if (!state) {
      icon.hidden = true;
      icon.className = 'chat-tab-collab-icon';
      icon.textContent = '';
      icon.style.removeProperty('--collab-color');
      icon.removeAttribute('title');
      return;
    }
    icon.hidden = false;
    icon.className = 'chat-tab-collab-icon' + (state.muted ? ' muted' : (state.isKeeper ? ' leader' : '')) + (state.color ? ' clustered' : '');
    if (state.color) icon.style.setProperty('--collab-color', state.color);
    else icon.style.removeProperty('--collab-color');
    icon.textContent = state.muted ? '🔇' : (state.isKeeper ? '★' : '🔗');
    icon.title = state.title;
  });
}

// 타일 합방 표시 — 그룹 색 테두리와 좌상단 배지(호버 시 이유와 "합방 해제" 버튼).
function updateTileCollabBadges() {
  videoWrapperMap.forEach((wrapper, hash) => {
    const state = getCollabDisplayState(hash);
    let outline = wrapper.querySelector(':scope > .collab-tile-outline');
    let badge = wrapper.querySelector(':scope > .collab-tile-badge');
    if (!state || !state.cluster) {
      if (outline) outline.remove();
      if (badge) badge.remove();
      wrapper.style.removeProperty('--collab-color');
      return;
    }
    wrapper.style.setProperty('--collab-color', state.color);
    if (!outline) {
      outline = document.createElement('div');
      outline.className = 'collab-tile-outline';
      wrapper.appendChild(outline);
    }
    if (!badge) {
      badge = document.createElement('div');
      badge.className = 'collab-tile-badge';
      badge.innerHTML = '<span class="collab-tile-badge-icon"></span><span class="collab-tile-badge-text"></span><button type="button" class="collab-tile-split-btn"></button>';
      badge.querySelector('.collab-tile-split-btn').addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        splitCollabChannel(wrapper.getAttribute('data-hash') || hash);
      });
      wrapper.appendChild(badge);
    }
    badge.classList.toggle('muted', state.muted);
    badge.querySelector('.collab-tile-badge-icon').textContent = state.muted ? '🔇' : '★';
    badge.querySelector('.collab-tile-badge-text').textContent = state.title;
    const splitBtn = badge.querySelector('.collab-tile-split-btn');
    splitBtn.textContent = t('audio.collabSplitButton', '합방 해제');
    const groupOfCluster = state.cluster.groupId ? audioState.collabGroups.find((g) => g.id === state.cluster.groupId) : null;
    splitBtn.title = isVodSyncGroup(groupOfCluster)
      ? t('audio.collabVodRemoveMemberHint', '이 채널을 VOD 싱크 그룹에서 뺍니다')
      : state.cluster.groupId
      ? t('audio.collabManualRemoveMemberHint', '이 채널을 수동 합방 그룹에서 뺍니다')
      : t('audio.collabChannelSplitHint', '이 채널만 그룹에서 빼고, 다른 소리로 확인될 때까지 다시 묶지 않습니다');
  });
}

// 숲 VOD는 챗탭을 만들지 않는다. 유튜브는 댓글 패널, 치지직 VOD는 VOD 페이지 자체로 챗탭을 지원한다.
function channelSupportsChatTab(item) {
  return item.platform === 'youtube' || item.platform === 'chzzk' || !item.isVod;
}

// ── 채팅 2분할 ── 채널별 iframe은 그대로 두고 보여줄 두 개를 .chat-pane-1 / .chat-pane-2 자리에 앉힌다.
function isChatSplitEnabled() {
  return !!mySetting.chatSplitEnabled;
}

// 'vertical' 위아래 · 'horizontal' 사이드바 안 좌우 · 'side' 영상 양옆(2번 칸만 사이드바 밖).
function getChatSplitDir() {
  const v = mySetting.chatSplitDir;
  return (v === 'horizontal' || v === 'side') ? v : 'vertical';
}

function getChatSide() {
  return mySetting.chatSide === 'left' ? 'left' : 'right';
}

// 왼쪽 배치는 order로만 바꾼다(DOM 이동은 iframe을 다시 로드함).
function applyChatSidePosition() {
  const mainContent = document.getElementById('main-content');
  if (!mainContent) return;
  mainContent.classList.toggle('chat-left', getChatSide() === 'left');
}

// 화면 전환 시 2번 칸 — 'keep' 그대로 · 'inherit' 1번 채팅을 2번으로 내림.
function getChatSecondPaneMode() {
  return mySetting.chatSecondPaneMode === 'inherit' ? 'inherit' : 'keep';
}

function refreshChatTabActiveClass() {
  if (!chatTabs) return;
  chatTabs.querySelectorAll('.chat-tab').forEach((tab) => {
    tab.classList.toggle('active', tab.getAttribute('data-hash') === activeChatChannel);
  });
}

function setChatPanes(first, second, enterDelayMs = 0) {
  activeChatChannel = first;
  refreshChatTabActiveClass();
  ensureChatIframeCreated(first);
  setSecondaryChatChannel(second);
  playChatPaneEnterAnimation(first, enterDelayMs);
}

// 이어받기 시 두 칸을 함께 한 칸씩 내린다. 둘 다 translateY(-100%) → 0(칸 높이 = 컨테이너 절반).
// 위아래 분할에서만, transform으로만 옮긴다(top은 iframe 재배치로 버벅임).
const CHAT_PANE_ANIM_EASING = 'cubic-bezier(0.33, 1, 0.68, 1)';
const CHAT_PANE_ENTER_MS = 260;    // 1번 칸에 새 채팅이 오른쪽에서 들어오는 시간
const CHAT_PANE_DESCEND_MS = 280;  // 1번 채팅이 2번 자리로 내려가는 시간
// 내려가는 칸이 먼저 비우고 새 채팅이 이만큼 늦게 따라온다(이어받기일 때만).
const CHAT_PANE_ENTER_DELAY_MS = 90;
// 재생 중인 애니메이션 — 연달아 전환하면 이전 걸 끊는다.
const chatPaneAnims = new WeakMap();

// Web Animations를 쓴다(클래스 방식은 매번 강제 리플로우가 필요했다).
function runChatPaneAnimation(hash, paneClass, keyframes, duration, delay) {
  if (!chatContainer || !hash) return;
  if (typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  chatContainer.querySelectorAll(`[data-hash="${hash}"]`).forEach((el) => {
    if (!el.classList.contains(paneClass) || typeof el.animate !== 'function') return;
    const prev = chatPaneAnims.get(el);
    if (prev) prev.cancel();
    const anim = el.animate(keyframes, {
      duration,
      delay,
      easing: CHAT_PANE_ANIM_EASING,
      // 늦게 출발하는 쪽은 기다리는 동안 출발 위치에 머문다.
      fill: delay > 0 ? 'backwards' : 'none'
    });
    chatPaneAnims.set(el, anim);
    anim.finished
      .then(() => { if (chatPaneAnims.get(el) === anim) chatPaneAnims.delete(el); })
      .catch(() => {}); // cancel()이면 reject된다 — 무시한다.
  });
}

// 1번 칸에 새 채팅이 오른쪽에서 밀려 들어온다(탭 전환·화면 전환 공통). 2번 칸은 제외.
// 두 칸일 때만 — 한 칸에선 화면 전체가 흔들려 보인다.
function playChatPaneEnterAnimation(hash, delay = 0) {
  if (!getEffectiveSecondaryChatChannel()) return;
  runChatPaneAnimation(
    hash, 'chat-pane-1',
    [{ transform: 'translateX(100%)' }, { transform: 'translateX(0)' }],
    CHAT_PANE_ENTER_MS, delay
  );
}

// 이어받기로 1번 채팅이 2번 자리로 내려간다(위아래 분할에서만).
function playChatPaneDescendAnimation(hash) {
  if (getChatSplitDir() !== 'vertical') return;
  if (!getEffectiveSecondaryChatChannel()) return;
  runChatPaneAnimation(
    hash, 'chat-pane-2',
    [{ transform: 'translateY(-100%)' }, { transform: 'translateY(0)' }],
    CHAT_PANE_DESCEND_MS, 0
  );
}

// 메인 채널 전환 시 채팅을 따라가게 한다. 반대 칸에 이미 그 채팅이 있으면 맞바꾼다.
function applyScreenChangeChatChannel(hash) {
  if (!hash) return;
  const ch = getChannelObjByHash(hash);
  if (ch && !channelSupportsChatTab(ch)) return;
  if (hash === activeChatChannel) return; // 이미 1번 칸에 떠 있다.

  // 이어받기: 1번 → 2번, 새 메인 → 1번. 원래 2번은 밀려난다.
  if (isChatSplitEnabled() && getChatSecondPaneMode() === 'inherit') {
    const descending = activeChatChannel; // setChatPanes가 덮어쓰기 전에 붙잡는다
    setChatPanes(hash, descending, CHAT_PANE_ENTER_DELAY_MS);
    playChatPaneDescendAnimation(descending);
    return;
  }

  // 고정: 2번은 그대로. 새 메인이 2번에 있을 때만 맞바꾼다.
  if (getEffectiveSecondaryChatChannel() === hash) {
    setChatPanes(hash, activeChatChannel);
    return;
  }
  if (secondaryChatChannel === hash) secondaryChatChannel = null;
  activeChatChannel = hash;
  ensureSecondaryChatChannel();
  // 애니메이션 전에 칸 클래스를 입힌다 — runChatPaneAnimation은 .chat-pane-1로 요소를 찾는다.
  refreshChatTabActiveClass();
  ensureChatIframeCreated(hash);
  updateChatTabPaneMarks();
  syncChatVisibility();
  playChatPaneEnterAnimation(hash);
}

// 두 번째 칸에 실제로 띄울 채널(분할 꺼짐·첫 칸과 같음·이 창에 없음이면 null).
function getEffectiveSecondaryChatChannel() {
  if (!isChatSplitEnabled()) return null;
  if (!secondaryChatChannel || secondaryChatChannel === activeChatChannel) return null;
  const ch = getChannelObjByHash(secondaryChatChannel);
  if (!ch || !channelSupportsChatTab(ch) || !isChannelShownInThisWindow(secondaryChatChannel)) return null;
  return secondaryChatChannel;
}

// 분할이 켜졌는데 두 번째 칸이 비면 채널 하나를 앉힌다(비우면 분할이 화면에 적용되지 않음). 바꿨으면 true.
function ensureSecondaryChatChannel() {
  if (!isChatSplitEnabled()) return false;
  if (getEffectiveSecondaryChatChannel()) return false;
  const candidate = getChannelsShownInThisWindow(displayChannels)
    .filter(channelSupportsChatTab)
    .find((c) => c.hash !== activeChatChannel);
  const next = candidate ? candidate.hash : null;
  if (secondaryChatChannel === next) return false;
  secondaryChatChannel = next;
  saveWindowState();
  if (next) ensureChatIframeCreated(next);
  return true;
}

function setSecondaryChatChannel(hash) {
  secondaryChatChannel = (hash && hash !== activeChatChannel) ? hash : null;
  saveWindowState();
  if (secondaryChatChannel) ensureChatIframeCreated(secondaryChatChannel);
  updateChatTabPaneMarks();
  syncChatVisibility();
}

function applyChatSplitLayout() {
  if (!chatContainer) return;
  const on = isChatSplitEnabled() && !!getEffectiveSecondaryChatChannel();
  const dir = on ? getChatSplitDir() : 'vertical';
  const horizontal = dir === 'horizontal';
  // 사이드 분할은 채팅이 열려 있을 때만 쓴다.
  const side = dir === 'side' && chatVisible;
  chatContainer.classList.toggle('split', on);
  chatContainer.classList.toggle('split-h', horizontal);
  chatContainer.classList.toggle('split-side', side);
  // 좌우 분할은 사이드바를 한 칸 폭만큼 넓히고, 사이드 분할은 반대쪽에 자리를 비운다. 둘 다 타일 크기를 다시 계산한다.
  const mainContent = document.getElementById('main-content');
  let widthChanged = false;
  if (chatSidebar) {
    widthChanged = chatSidebar.classList.contains('split-h') !== horizontal;
    chatSidebar.classList.toggle('split-h', horizontal);
  }
  if (mainContent) {
    if (mainContent.classList.contains('chat-side-split') !== side) widthChanged = true;
    mainContent.classList.toggle('chat-side-split', side);
  }
  // 폭 트랜지션이 끝난 뒤 다시 그린다.
  if (widthChanged && chatVisible) {
    renderVideo();
    setTimeout(() => renderVideo(), 200);
  }
}

// 설정 > 채팅 UI를 현재 설정에 맞춘다.
function updateChatSplitSettingsUI() {
  const enabled = isChatSplitEnabled();
  const dir = getChatSplitDir();
  const toggle = document.getElementById('chat-split-toggle');
  if (toggle) toggle.checked = enabled;
  const dirSelect = document.getElementById('chat-split-dir-select');
  if (dirSelect) {
    dirSelect.value = dir;
    dirSelect.disabled = !enabled;
  }
  const secondPaneSelect = document.getElementById('chat-second-pane-select');
  if (secondPaneSelect) {
    secondPaneSelect.value = getChatSecondPaneMode();
    secondPaneSelect.disabled = !enabled;
  }
  const sideSelect = document.getElementById('chat-side-select');
  if (sideSelect) sideSelect.value = getChatSide();
  const preview = document.getElementById('chat-split-preview');
  if (preview) {
    preview.classList.toggle('split', enabled);
    preview.classList.toggle('split-h', enabled && dir === 'horizontal');
    preview.classList.toggle('split-side', enabled && dir === 'side');
    preview.classList.toggle('chat-left', getChatSide() === 'left');
  }
}

function updateChatTabPaneMarks() {
  if (!chatTabs) return;
  // 실제로 두 칸이 떠 있을 때만 표시한다.
  const second = getEffectiveSecondaryChatChannel();
  const split = isChatSplitEnabled() && !!second;
  chatTabs.querySelectorAll('.chat-tab').forEach((tab) => {
    const hash = tab.getAttribute('data-hash');
    tab.classList.toggle('pane-1', split && hash === activeChatChannel);
    tab.classList.toggle('pane-2', split && hash === second);
  });
}

// ── 채팅탭 오른쪽 클릭 메뉴 ── 한 번에 하나, 바깥 클릭·Esc·리사이즈·탭 재생성 때 닫힌다.
let chatTabContextMenuEl = null;

function closeChatTabContextMenu() {
  if (!chatTabContextMenuEl) return;
  chatTabContextMenuEl.remove();
  chatTabContextMenuEl = null;
  document.removeEventListener('mousedown', onChatTabContextMenuOutside, true);
  document.removeEventListener('keydown', onChatTabContextMenuKey, true);
  window.removeEventListener('resize', closeChatTabContextMenu);
}

function onChatTabContextMenuOutside(e) {
  if (chatTabContextMenuEl && chatTabContextMenuEl.contains(e.target)) return;
  closeChatTabContextMenu();
}

function onChatTabContextMenuKey(e) {
  if (e.key === 'Escape') closeChatTabContextMenu();
}

function openChatTabContextMenu(x, y, hash) {
  closeChatTabContextMenu();
  if (!hash) return;

  const menu = document.createElement('div');
  menu.className = 'chat-tab-context-menu';

  // 분할이 켜져 있을 때만 두 번째 칸에 올리기를 제공한다("비우기"는 없음 — 분할을 끄면 된다).
  const alreadyShown = hash === activeChatChannel || getEffectiveSecondaryChatChannel() === hash;
  if (isChatSplitEnabled() && !alreadyShown) {
    // 방향마다 2번 칸 위치가 달라 문구도 바꾼다(사이드는 항상 오른쪽).
    const dir = getChatSplitDir();
    const paneItem = document.createElement('button');
    paneItem.type = 'button';
    paneItem.className = 'chat-tab-context-item';
    paneItem.textContent = (dir === 'horizontal' || dir === 'side')
      ? t('chat.splitPaneRight', '오른쪽 칸에 표시')
      : t('chat.splitPaneBottom', '아래 칸에 표시');
    paneItem.addEventListener('click', () => {
      closeChatTabContextMenu();
      setSecondaryChatChannel(hash);
    });
    menu.appendChild(paneItem);
  }

  const removeItem = document.createElement('button');
  removeItem.type = 'button';
  removeItem.className = 'chat-tab-context-item danger';
  removeItem.textContent = t('video.removeChannel', '채널 삭제');
  removeItem.setAttribute('data-i18n', 'video.removeChannel');
  removeItem.addEventListener('click', () => {
    closeChatTabContextMenu();
    removeChannel(hash);
  });
  menu.appendChild(removeItem);

  document.body.appendChild(menu);
  const rect = menu.getBoundingClientRect();
  const left = Math.max(4, Math.min(x, window.innerWidth - rect.width - 4));
  const top = Math.max(4, Math.min(y, window.innerHeight - rect.height - 4));
  menu.style.left = `${left}px`;
  menu.style.top = `${top}px`;

  chatTabContextMenuEl = menu;
  document.addEventListener('mousedown', onChatTabContextMenuOutside, true);
  document.addEventListener('keydown', onChatTabContextMenuKey, true);
  window.addEventListener('resize', closeChatTabContextMenu);
}

function updateChatSession() {
  closeChatTabContextMenu();
  if (!chatTabs || !chatContainer) return;
  const chatCapableChannels = getChannelsShownInThisWindow(displayChannels).filter(channelSupportsChatTab);
  if (chatCapableChannels.length === 0) {
    chatTabs.innerHTML = '';
    chatContainer.innerHTML = `<div class="chat-placeholder">${t('app.chatPlaceholder', '채널을 추가하면 채팅이 동기화됩니다.')}</div>`;
    chatContainer.classList.remove('split', 'split-h');
    activeChatChannel = null;
    secondaryChatChannel = null;
    return;
  }
  const isValidActive = chatCapableChannels.some(c => c.hash === activeChatChannel);
  if (!activeChatChannel || !isValidActive) {
    activeChatChannel = chatCapableChannels[0].hash;
  }
  // 두 번째 칸 채널이 없어졌으면 비우고 다시 채운다.
  if (secondaryChatChannel
    && (secondaryChatChannel === activeChatChannel
      || !chatCapableChannels.some(c => c.hash === secondaryChatChannel))) {
    secondaryChatChannel = null;
  }
  ensureSecondaryChatChannel();
  const placeholder = chatContainer.querySelector('.chat-placeholder');
  if (placeholder) placeholder.remove();
  chatTabs.innerHTML = '';
  const fragment = document.createDocumentFragment();

  chatCapableChannels.forEach(item => {
    const tab = document.createElement('div');
    const isActive = (item.hash === activeChatChannel);
    tab.className = `chat-tab ${isActive ? 'active' : ''}`;
    tab.setAttribute('data-hash', item.hash);
    tab.setAttribute('data-platform', item.platform);
    tab.style.setProperty('--tab-color', getPlatformColor(item.platform));

    // 합방 상태 아이콘 자리 — 내용은 updateChatTabCollabIcons()가 채운다(탭 재생성 없이 갱신).
    const collabIcon = document.createElement('span');
    collabIcon.className = 'chat-tab-collab-icon';
    collabIcon.hidden = true;
    tab.appendChild(collabIcon);

    const tabName = document.createElement('span');
    tabName.className = 'chat-tab-name';
    tabName.innerText = item.name;
    tab.addEventListener('click', () => {
      setChatChannel(item.hash);
    });

    // 화면 숨김 토글은 항상 보이는 채팅탭에 둔다(숨긴 카드는 호버할 수 없음). 상태는 updateChatTabVideoToggleIcons()가 채운다.
    const videoToggleBtn = document.createElement('button');
    videoToggleBtn.type = 'button';
    videoToggleBtn.className = 'chat-tab-video-toggle-btn';
    videoToggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleChannelVideoHidden(item.hash);
    });

    const refreshBtn = document.createElement('button');
    refreshBtn.className = 'chat-tab-refresh-btn';
    refreshBtn.innerHTML = '⟳';
    refreshBtn.title = t('chat.refreshTooltip', '채팅 새로고침');
    refreshBtn.setAttribute('data-i18n-title', 'chat.refreshTooltip');
    refreshBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      refreshChatTab(item.hash, item.platform, refreshBtn);
    });

    // 오른쪽 클릭 메뉴 — 타일이 없는 채널(챗만·숨김)도 채팅탭에서 지울 수 있게.
    tab.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      openChatTabContextMenu(e.clientX, e.clientY, item.hash);
    });

    tab.appendChild(tabName);
    tab.appendChild(videoToggleBtn);
    tab.appendChild(refreshBtn);
    fragment.appendChild(tab);
  });

  chatTabs.appendChild(fragment);
  updateChatTabCollabIcons();
  updateChatTabVideoToggleIcons();
  const existingIframes = chatContainer.querySelectorAll('iframe.chat-iframe');
  existingIframes.forEach(iframe => {
    const hash = iframe.getAttribute('data-hash');
    if (!chatCapableChannels.some(c => c.hash === hash)) {
      iframe.src = 'about:blank';
      iframe.remove();
      reinitPendingHashes.delete(hash);
      const overlay = chatReinitOverlays.get(hash);
      if (overlay) { overlay.remove(); chatReinitOverlays.delete(hash); }
      removeYoutubeCommentsPanel(hash);
      youtubeChatSubView.delete(hash);
    }
  });
  ensureChatIframeCreated(activeChatChannel);
  const secondHash = getEffectiveSecondaryChatChannel();
  if (secondHash) ensureChatIframeCreated(secondHash);
  updateChatTabPaneMarks();
  syncChatVisibility();
}

// 유튜브 VOD 챗탭은 댓글 패널 — 맵은 syncChatVisibility가 표시 판단에 쓴다.
const youtubeChatSubView = new Map();
function getYoutubeChatSubView(hash) {
  return youtubeChatSubView.get(hash) || 'comments';
}

// ── 유튜브 댓글 패널 ── 댓글을 embed할 공식 방법이 없어 InnerTube 데이터로 직접 그린다(작성·답글 포함, 로그인 필요).
// hash -> { videoId, items, nextToken, loading, loadingMore, exhausted, errored, composerParams, composerBusy, composerError }
const youtubeCommentsState = new Map();

function getYoutubeCommentsPanel(hash) {
  return chatContainer ? chatContainer.querySelector(`.chat-comments-panel[data-hash="${hash}"]`) : null;
}

function ensureYoutubeCommentsPanel(hash) {
  if (!chatContainer) return null;
  let panel = getYoutubeCommentsPanel(hash);
  if (panel) return panel;
  panel = document.createElement('div');
  panel.className = 'chat-comments-panel';
  panel.setAttribute('data-hash', hash);

  const composer = buildYoutubeCommentComposer(hash, {
    placeholder: t('chat.commentPlaceholder', '댓글 추가...'),
    onSubmit: (text) => submitYoutubeComment(hash, text)
  });
  composer.classList.add('chat-comment-composer-root');
  panel.appendChild(composer);

  const list = document.createElement('div');
  list.className = 'chat-comments-list';
  panel.appendChild(list);
  panel.addEventListener('scroll', () => onYoutubeCommentsScroll(hash));
  chatContainer.appendChild(panel);
  // 패널이 비동기로 늦게 만들어질 수 있어 생성 직후 한 번 더 표시를 동기화한다.
  syncChatVisibility();
  return panel;
}

function removeYoutubeCommentsPanel(hash) {
  const panel = getYoutubeCommentsPanel(hash);
  if (panel) panel.remove();
  youtubeCommentsState.delete(hash);
}

// 댓글 작성창(공용). onSubmit이 true면 비우고, false면 에러 표시.
function buildYoutubeCommentComposer(hash, { placeholder, onSubmit, submitLabel, autofocus, draftKey, initialText } = {}) {
  const wrap = document.createElement('div');
  wrap.className = 'chat-comment-composer';

  const textarea = document.createElement('textarea');
  textarea.className = 'chat-comment-composer-input';
  textarea.placeholder = placeholder || '';
  textarea.rows = 1;
  if (initialText) textarea.value = initialText;
  if (draftKey) textarea.setAttribute('data-draft-key', draftKey);
  wrap.appendChild(textarea);

  const row = document.createElement('div');
  row.className = 'chat-comment-composer-row';
  const status = document.createElement('span');
  status.className = 'chat-comment-composer-status';
  row.appendChild(status);
  const submitBtn = document.createElement('button');
  submitBtn.type = 'button';
  submitBtn.className = 'chat-comment-composer-submit';
  submitBtn.textContent = submitLabel || t('chat.commentSubmit', '등록');
  row.appendChild(submitBtn);
  wrap.appendChild(row);

  const doSubmit = async () => {
    const text = textarea.value.trim();
    if (!text || submitBtn.disabled) return;
    submitBtn.disabled = true;
    status.textContent = t('chat.commentPosting', '작성 중...');
    status.classList.remove('chat-comments-error');
    const ok = await onSubmit(text);
    submitBtn.disabled = false;
    if (ok) {
      textarea.value = '';
      status.textContent = '';
    } else {
      status.textContent = t('chat.commentPostFailed', '작성에 실패했습니다. 로그인 상태를 확인해주세요.');
      status.classList.add('chat-comments-error');
    }
  };
  submitBtn.addEventListener('click', doSubmit);
  textarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); doSubmit(); }
  });
  if (autofocus) setTimeout(() => textarea.focus(), 0);

  return wrap;
}

// "1:57" 같은 타임스탬프만 클릭 링크로 바꾼다(innerHTML 미사용 — XSS 방지).
const YOUTUBE_COMMENT_TIMESTAMP_RE = /\b((?:\d{1,2}:)?\d{1,2}:\d{2})\b/g;
function youtubeTsToSeconds(str) {
  const parts = str.split(':').map(Number);
  if (parts.some(n => Number.isNaN(n))) return null;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}
function renderYoutubeCommentTextWithTs(container, text, hash) {
  const re = new RegExp(YOUTUBE_COMMENT_TIMESTAMP_RE);
  let lastIndex = 0;
  let match;
  while ((match = re.exec(text))) {
    if (match.index > lastIndex) {
      container.appendChild(document.createTextNode(text.slice(lastIndex, match.index)));
    }
    const seconds = youtubeTsToSeconds(match[1]);
    if (seconds === null) {
      container.appendChild(document.createTextNode(match[0]));
    } else {
      const link = document.createElement('a');
      link.href = '#';
      link.className = 'chat-comment-timestamp';
      link.textContent = match[1];
      link.addEventListener('click', (e) => {
        e.preventDefault();
        seekChannelToTime(hash, seconds);
      });
      container.appendChild(link);
    }
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < text.length) {
    container.appendChild(document.createTextNode(text.slice(lastIndex)));
  }
}

function renderYoutubeCommentRow(hash, c, depth, parentComment) {
  if (c.repliesExpanded === undefined) {
    c.repliesExpanded = false;
    c.repliesLoaded = [];
    c.repliesNextToken = c.repliesToken;
    c.repliesExhausted = !c.repliesToken;
    c.repliesLoading = false;
    c.repliesErrored = false;
    c.replyComposerOpen = false;
  }

  const row = document.createElement('div');
  row.className = 'chat-comment-row' + (c.isPinned ? ' pinned' : '') + (c.isOwner ? ' owner-reply' : '') + (depth > 0 ? ' reply' : '');

  const avatar = document.createElement('img');
  avatar.className = 'chat-comment-avatar';
  avatar.src = c.avatarUrl || '';
  avatar.alt = '';
  avatar.loading = 'lazy';
  row.appendChild(avatar);

  const body = document.createElement('div');
  body.className = 'chat-comment-body';

  const head = document.createElement('div');
  head.className = 'chat-comment-head';
  const nameEl = document.createElement('span');
  nameEl.className = 'chat-comment-author';
  nameEl.textContent = c.author;
  head.appendChild(nameEl);
  if (c.publishedTime) {
    const timeEl = document.createElement('span');
    timeEl.className = 'chat-comment-time';
    timeEl.textContent = c.publishedTime;
    head.appendChild(timeEl);
  }
  body.appendChild(head);

  const textEl = document.createElement('div');
  textEl.className = 'chat-comment-text';
  renderYoutubeCommentTextWithTs(textEl, c.text, hash);
  body.appendChild(textEl);

  let translationEl = null;
  if (c.translationOpen && c.translatedText) {
    translationEl = document.createElement('div');
    translationEl.className = 'chat-comment-translation';
    translationEl.textContent = c.translatedText;
    body.appendChild(translationEl);
  }

  if (c.likeCount) {
    const likeEl = document.createElement('div');
    likeEl.className = 'chat-comment-likes';
    likeEl.textContent = `👍 ${c.likeCount}`;
    body.appendChild(likeEl);
  }

  // 답글 보기는 최상위 댓글에만. 답글에 다는 답글은 같은 목록에 @멘션으로 추가된다(유튜브와 동일).
  const actions = document.createElement('div');
  actions.className = 'chat-comment-actions';

  if (depth === 0 && (c.replyCount > 0 || c.repliesLoaded.length > 0)) {
    const toggleBtn = document.createElement('button');
    toggleBtn.type = 'button';
    toggleBtn.className = 'chat-comment-action-btn chat-comment-view-replies';
    const setToggleLabel = () => {
      toggleBtn.textContent = c.repliesExpanded
        ? t('chat.hideReplies', '답글 숨기기')
        : t('chat.viewRepliesTemplate', '답글 {count}개 보기', { count: c.replyCount || c.repliesLoaded.length });
    };
    setToggleLabel();
    toggleBtn.addEventListener('click', async () => {
      if (!c.repliesExpanded && c.repliesLoaded.length === 0 && !c.repliesLoading) {
        await fetchMoreYoutubeReplies(hash, c);
      }
      c.repliesExpanded = !c.repliesExpanded;
      renderYoutubeCommentsList(hash);
    });
    actions.appendChild(toggleBtn);
  }

  const replyBtn = document.createElement('button');
  replyBtn.type = 'button';
  replyBtn.className = 'chat-comment-action-btn';
  replyBtn.textContent = t('chat.writeReply', '답글 달기');
  replyBtn.addEventListener('click', () => {
    c.replyComposerOpen = !c.replyComposerOpen;
    renderYoutubeCommentsList(hash);
  });
  actions.appendChild(replyBtn);

  const translateBtn = document.createElement('button');
  translateBtn.type = 'button';
  translateBtn.className = 'chat-comment-action-btn';
  translateBtn.textContent = c.translationOpen
    ? t('chat.hideTranslation', '번역 숨기기')
    : t('chat.viewTranslation', '번역 보기');
  translateBtn.addEventListener('click', async () => {
    if (c.translationOpen) {
      c.translationOpen = false;
      if (translationEl) { translationEl.remove(); translationEl = null; }
      translateBtn.textContent = t('chat.viewTranslation', '번역 보기');
      return;
    }
    // 번역은 한 번만 호출해 캐시한다. 이미 대상 언어로 보이거나 detectedLang이 같으면 번역 없음(null).
    if (c.translatedText === undefined) {
      const targetLang = window.CHEESE_EYES_CURRENT_LANG || 'ko';
      if (looksLikeAlreadyInLang(c.text, targetLang)) {
        c.translatedText = null;
      } else {
        // 로딩 중엔 이 버튼과 결과 칸만 로컬 갱신한다(전체 재렌더링은 다른 초안을 깜빡이게 함).
        translateBtn.disabled = true;
        translateBtn.textContent = t('chat.translationLoading', '번역 준비 중...');
        const loadingEl = document.createElement('div');
        loadingEl.className = 'chat-comment-translation chat-comment-translation-loading';
        loadingEl.textContent = t('chat.translationLoading', '번역 준비 중...');
        textEl.insertAdjacentElement('afterend', loadingEl);
        const { translated, detectedLang } = await translateChatMsgText(c.text, targetLang);
        loadingEl.remove();
        translateBtn.disabled = false;
        c.translatedText = (detectedLang && detectedLang === targetLang) ? null : (translated || null);
      }
    }
    if (!c.translatedText) {
      translateBtn.textContent = t('chat.viewTranslation', '번역 보기');
      return;
    }
    translationEl = document.createElement('div');
    translationEl.className = 'chat-comment-translation';
    translationEl.textContent = c.translatedText;
    textEl.insertAdjacentElement('afterend', translationEl);
    c.translationOpen = true;
    translateBtn.textContent = t('chat.hideTranslation', '번역 숨기기');
  });
  actions.appendChild(translateBtn);

  body.appendChild(actions);

  if (c.replyComposerOpen) {
    // 답글이면 그 답글이 속한 최상위 댓글이 실제 대상이다.
    const target = depth === 0 ? c : parentComment;
    const replyComposer = buildYoutubeCommentComposer(hash, {
      placeholder: t('chat.replyPlaceholder', '답글 추가...'),
      submitLabel: t('chat.commentSubmit', '등록'),
      autofocus: true,
      draftKey: `reply:${c.id}`,
      initialText: depth > 0 ? `@${c.author} ` : '',
      onSubmit: async (text) => {
        const params = await PlatformAdapters.youtube._getReplyComposerParams(target);
        if (!params) return false;
        const ok = await PlatformAdapters.youtube._postComment(params, text);
        if (!ok) return false;
        target.repliesLoaded.push({
          id: `local-${Date.now()}`,
          text,
          author: getYoutubeSelfLabel(),
          avatarUrl: '',
          publishedTime: t('chat.commentsJustNow', '방금 전'),
          likeCount: '',
          isOwner: false,
          isPinned: false,
          replyCount: 0,
          repliesToken: null,
          _raw: null
        });
        target.replyCount = (target.replyCount || 0) + 1;
        target.repliesExpanded = true;
        c.replyComposerOpen = false;
        renderYoutubeCommentsList(hash);
        return true;
      }
    });
    body.appendChild(replyComposer);
  }

  if (depth === 0 && c.repliesExpanded) {
    const repliesWrap = document.createElement('div');
    repliesWrap.className = 'chat-comment-replies';
    c.repliesLoaded.forEach(r => repliesWrap.appendChild(renderYoutubeCommentRow(hash, r, depth + 1, c)));
    if (c.repliesLoading) {
      const loadingEl = document.createElement('div');
      loadingEl.className = 'chat-comments-status chat-comments-loading-more';
      loadingEl.textContent = t('chat.commentsLoadingMore', '더 불러오는 중...');
      repliesWrap.appendChild(loadingEl);
    } else if (c.repliesErrored && c.repliesLoaded.length === 0) {
      const errEl = document.createElement('div');
      errEl.className = 'chat-comments-status chat-comments-error chat-comments-loading-more';
      errEl.textContent = t('chat.repliesLoadFailed', '답글을 불러오지 못했습니다.');
      repliesWrap.appendChild(errEl);
    } else if (!c.repliesExhausted && c.repliesLoaded.length > 0) {
      const moreBtn = document.createElement('button');
      moreBtn.type = 'button';
      moreBtn.className = 'chat-comment-action-btn chat-comment-more-replies';
      moreBtn.textContent = t('chat.loadMoreReplies', '답글 더보기');
      moreBtn.addEventListener('click', () => fetchMoreYoutubeReplies(hash, c));
      repliesWrap.appendChild(moreBtn);
    }
    body.appendChild(repliesWrap);
  }

  row.appendChild(body);
  return row;
}

function getYoutubeSelfLabel() {
  const info = (cachedAccountInfo || []).find(a => a.platform === 'youtube');
  return (info && info.label) || t('chat.commentsYou', '나');
}

async function fetchMoreYoutubeReplies(hash, comment) {
  if (comment.repliesLoading || comment.repliesExhausted) return;
  if (!comment.repliesNextToken) {
    // 답글 토큰을 못 찾으면 눈에 보이는 에러로 표시한다.
    console.warn(`[CHEESE EYES] 유튜브 답글 토큰을 찾지 못함 (commentId=${comment.id}, replyCount=${comment.replyCount})`);
    comment.repliesErrored = true;
    comment.repliesExhausted = true;
    return;
  }
  comment.repliesLoading = true;
  comment.repliesErrored = false;
  renderYoutubeCommentsList(hash);
  const page = await PlatformAdapters.youtube._fetchComments(null, comment.repliesNextToken);
  comment.repliesLoading = false;
  if (!page || page.parseFailed) {
    // 요청 실패나 파싱 실패는 빈 목록이 아니라 에러로 표시한다(다음 토큰도 믿지 않음).
    comment.repliesExhausted = true;
    comment.repliesErrored = comment.repliesLoaded.length === 0;
  } else {
    comment.repliesLoaded.push(...page.items);
    comment.repliesNextToken = page.nextToken;
    comment.repliesExhausted = !page.nextToken;
  }
  renderYoutubeCommentsList(hash);
}

async function submitYoutubeComment(hash, text) {
  const state = youtubeCommentsState.get(hash);
  if (!state) return false;
  if (state.composerParams === undefined) {
    state.composerParams = await PlatformAdapters.youtube._getCommentComposerParams(state.videoId);
  }
  if (!state.composerParams) return false;
  const ok = await PlatformAdapters.youtube._postComment(state.composerParams, text);
  if (!ok) return false;
  // 방금 작성한 댓글은 입력 내용 그대로 맨 위에 낙관적으로 얹는다.
  state.items.unshift({
    id: `local-${Date.now()}`,
    text,
    author: getYoutubeSelfLabel(),
    avatarUrl: '',
    publishedTime: t('chat.commentsJustNow', '방금 전'),
    likeCount: '',
    isOwner: false,
    isPinned: false,
    replyCount: 0,
    repliesToken: null,
    _raw: null
  });
  renderYoutubeCommentsList(hash);
  return true;
}

function renderYoutubeCommentsList(hash) {
  const state = youtubeCommentsState.get(hash);
  const panel = getYoutubeCommentsPanel(hash);
  if (!state || !panel) return;
  const list = panel.querySelector('.chat-comments-list');
  if (!list) return;

  // 목록 재렌더링 전 답글 초안을 걷어 뒀다가 같은 draftKey 입력창에 되돌린다.
  const drafts = new Map();
  list.querySelectorAll('[data-draft-key]').forEach((el) => {
    if (el.value) drafts.set(el.getAttribute('data-draft-key'), el.value);
  });

  list.innerHTML = '';

  if (state.errored) {
    list.innerHTML = `<div class="chat-comments-status chat-comments-error">${t('chat.commentsLoadFailed', '댓글을 불러오지 못했습니다.')}</div>`;
    return;
  }
  if (state.items.length === 0) {
    list.innerHTML = `<div class="chat-comments-status">${state.loading ? t('chat.commentsLoading', '댓글을 불러오는 중...') : t('chat.commentsEmpty', '댓글이 없습니다.')}</div>`;
    return;
  }

  const fragment = document.createDocumentFragment();
  state.items.forEach(c => fragment.appendChild(renderYoutubeCommentRow(hash, c, 0)));
  list.appendChild(fragment);

  if (state.loadingMore) {
    const moreEl = document.createElement('div');
    moreEl.className = 'chat-comments-status chat-comments-loading-more';
    moreEl.textContent = t('chat.commentsLoadingMore', '더 불러오는 중...');
    list.appendChild(moreEl);
  }

  if (drafts.size > 0) {
    list.querySelectorAll('[data-draft-key]').forEach((el) => {
      const draft = drafts.get(el.getAttribute('data-draft-key'));
      if (draft) el.value = draft;
    });
  }
}

async function loadYoutubeComments(hash, videoId) {
  ensureYoutubeCommentsPanel(hash);
  const state = { videoId, items: [], nextToken: null, loading: true, loadingMore: false, exhausted: false, errored: false, composerParams: undefined };
  youtubeCommentsState.set(hash, state);
  renderYoutubeCommentsList(hash);

  const page = await PlatformAdapters.youtube._fetchComments(videoId);
  // 그 사이 state가 교체됐으면 낡은 응답은 버린다.
  if (youtubeCommentsState.get(hash) !== state) return;
  state.loading = false;
  if (!page || page.parseFailed) {
    state.errored = true;
  } else {
    state.items = page.items;
    state.nextToken = page.nextToken;
    state.exhausted = !page.nextToken;
  }
  renderYoutubeCommentsList(hash);
}

async function fetchMoreYoutubeComments(hash) {
  const state = youtubeCommentsState.get(hash);
  if (!state || state.loading || state.loadingMore || state.exhausted || !state.nextToken) return;
  state.loadingMore = true;
  renderYoutubeCommentsList(hash);

  const page = await PlatformAdapters.youtube._fetchComments(state.videoId, state.nextToken);
  if (youtubeCommentsState.get(hash) !== state) return;
  state.loadingMore = false;
  if (!page || page.parseFailed) {
    state.exhausted = true;
  } else {
    state.items.push(...page.items);
    state.nextToken = page.nextToken;
    state.exhausted = !page.nextToken;
  }
  renderYoutubeCommentsList(hash);
}

function onYoutubeCommentsScroll(hash) {
  const panel = getYoutubeCommentsPanel(hash);
  if (!panel) return;
  const remaining = panel.scrollHeight - panel.scrollTop - panel.clientHeight;
  if (remaining > 200) return;
  fetchMoreYoutubeComments(hash);
}

// 치지직 VOD 채팅은 VOD 시청 페이지에 cheeseChatEmbed를 붙여 일반 iframe 경로로 띄운다(content.js가 #vod-aside만 띄움).

async function loadChatIframe(iframe, hash, platform) {
  const adapter = getAdapter(platform);

  if (platform === 'youtube') {
    await refreshYoutubeVideoId(hash);
    const ch = getChannelObjByHash(hash);
    const videoId = ch && ch.videoId;
    if (!videoId) {
      iframe.src = 'about:blank';
      removeYoutubeCommentsPanel(hash);
      youtubeChatSubView.delete(hash);
      return;
    }

    // 라이브는 live_chat iframe, VOD/일반 영상은 댓글 패널. getChatEmbedUrl이 live/replay를 구분한 URL을 준다.
    if (ch.isVod) {
      iframe.src = 'about:blank';
      youtubeChatSubView.set(hash, 'comments');
      loadYoutubeComments(hash, videoId);
    } else {
      iframe.src = adapter.getChatEmbedUrl(hash);
      youtubeChatSubView.set(hash, 'chat');
      removeYoutubeCommentsPanel(hash);
    }
    syncChatVisibility();
    return;
  }

  if (platform !== 'soop') {
    iframe.src = adapter.getChatEmbedUrl(hash);
    return;
  }

  const readyEntry = getSoopVideoReadyEntry(hash);
  const readyPromise = Promise.race([readyEntry.promise, new Promise((res) => setTimeout(res, 8000))]);
  const broadNoPromise = refreshSoopBroadNo(hash);
  const videoLoadPromise = new Promise((resolve) => {
    const onLoad = () => { iframe.removeEventListener('load', onLoad); resolve(); };
    iframe.addEventListener('load', onLoad);
  });
  iframe.src = adapter.getVideoEmbedUrl(hash);

  await Promise.all([readyPromise, broadNoPromise, videoLoadPromise]);

  const chatUrl = adapter.getChatEmbedUrl(hash);
  try {
    iframe.contentWindow.location.href = chatUrl;
  } catch (e) {
    iframe.src = chatUrl;  }
}

function refreshChatTab(hash, platform, btnEl) {
  if (!hash || !chatContainer) return;

  if (btnEl) {
    btnEl.classList.remove('is-spinning');
    void btnEl.offsetWidth;
    btnEl.classList.add('is-spinning');
    setTimeout(() => btnEl.classList.remove('is-spinning'), 700);
  }

  const iframe = chatContainer.querySelector(`iframe[data-hash="${hash}"]`);
  if (!iframe) {
    ensureChatIframeCreated(hash);
    return;
  }

  const wasVisible = chatVisible && hash === activeChatChannel;

  if (platform === 'soop') {
    soopVideoReadyMap.delete(hash);
    if (wasVisible) showChatReinitOverlay(hash);
    loadChatIframe(iframe, hash, 'soop').finally(() => { if (wasVisible) hideChatReinitOverlay(hash); });
  } else {
    // iframe을 새로 만들어 교체한다(chrome-error 상태의 프레임은 재탐색이 거부될 수 있음).
    recreateChatIframe(iframe, hash, platform);
  }
}

// 치지직 VOD 채팅탭은 무거운 VOD 페이지를 통째로 불러와 메인 타일과 자원을 다툰다.
function isChzzkVodChatChannel(hash) {
  const ch = getChannelObjByHash(hash);
  return !!(ch && ch.platform === 'chzzk' && ch.isVod);
}

const CHZZK_VOD_CHAT_LOAD_TIMEOUT_MS = 20000;
const CHZZK_VOD_CHAT_STAGGER_MS = 600;

// hash -> 대기 중 감시 해제 함수. load가 아니라 content.js의 CHZZK_CHAT_EMBED_READY(#vod-aside 등장)를 기다린다
// (load는 SPA 로딩 화면에 갇혀도 온다).
const chzzkVodChatWatchdogs = new Map();
window.addEventListener('message', (event) => {
  if (!event.data || event.data.type !== 'CHZZK_CHAT_EMBED_READY') return;
  const hash = findChatHashByWindow(event.source);
  const settle = hash && chzzkVodChatWatchdogs.get(hash);
  if (settle) settle();
});

// 준비 신호 전에 타임아웃이면 iframe을 새로 만들어 재시도한다.
function attachChzzkVodChatWatchdog(iframe, hash) {
  if (!isChzzkVodChatChannel(hash)) return;
  const wasVisible = chatVisible && hash === activeChatChannel;
  if (wasVisible) showChatReinitOverlay(hash);

  let settled = false;
  const finish = () => {
    if (settled) return;
    settled = true;
    clearTimeout(timeoutId);
    chzzkVodChatWatchdogs.delete(hash);
    if (wasVisible) hideChatReinitOverlay(hash);
  };
  chzzkVodChatWatchdogs.set(hash, finish);

  const timeoutId = setTimeout(() => {
    if (settled) return;
    settled = true;
    chzzkVodChatWatchdogs.delete(hash);
    console.warn('[CHEESE EYES] 치지직 VOD 채팅탭 로딩이 오래 걸려 다시 시도합니다:', hash);
    if (wasVisible) hideChatReinitOverlay(hash);
    const current = chatContainer && chatContainer.querySelector(`iframe[data-hash="${hash}"]`);
    if (current === iframe) {
      recreateChatIframe(iframe, hash, 'chzzk');
    }
  }, CHZZK_VOD_CHAT_LOAD_TIMEOUT_MS);
}

function createChatIframe(hash, platform) {
  const iframe = document.createElement('iframe');
  iframe.className = 'chat-iframe';
  iframe.setAttribute('data-hash', hash);
  iframe.setAttribute('allow', IFRAME_ALLOW);
  // 크기는 CSS(.chat-iframe)가 잡는다(인라인이면 2분할 칸 크기를 덮어씀).
  chatContainer.appendChild(iframe);
  attachChzzkVodChatWatchdog(iframe, hash);
  if (isChzzkVodChatChannel(hash)) {
    // 메인 타일과 동시에 요청하지 않도록 살짝 늦춘다.
    setTimeout(() => loadChatIframe(iframe, hash, platform), CHZZK_VOD_CHAT_STAGGER_MS);
  } else {
    loadChatIframe(iframe, hash, platform);
  }
  return iframe;
}

function recreateChatIframe(oldIframe, hash, platform) {
  const parent = oldIframe.parentNode;
  if (!parent) return oldIframe;
  const fresh = document.createElement('iframe');
  fresh.className = oldIframe.className || 'chat-iframe';
  fresh.setAttribute('data-hash', hash);
  fresh.setAttribute('allow', IFRAME_ALLOW);
  fresh.style.display = oldIframe.style.display || '';
  parent.replaceChild(fresh, oldIframe);
  attachChzzkVodChatWatchdog(fresh, hash);
  loadChatIframe(fresh, hash, platform);
  return fresh;
}

function ensureChatIframeCreated(hash) {
  if (!hash || !chatContainer) return;

  let iframe = chatContainer.querySelector(`iframe[data-hash="${hash}"]`);
  if (!iframe) {
    const chObj = getChannelObjByHash(hash);
    const platform = chObj ? chObj.platform : 'chzzk';
    createChatIframe(hash, platform);
  }
}
// 유튜브는 채널뿐 아니라 서브뷰(채팅/댓글)까지 맞는지 본다.
function shouldShowYoutubeSubView(hash, view) {
  const ch = getChannelObjByHash(hash);
  if (!ch || ch.platform !== 'youtube' || !ch.videoId) return true;
  return getYoutubeChatSubView(hash) === view;
}

function syncChatVisibility() {
  if (!chatContainer) return;

  applyChatSplitLayout();
  const secondHash = getEffectiveSecondaryChatChannel();
  // 분할이 꺼져 있으면 .chat-pane-1은 효과가 없다.
  const paneOf = (hash) => {
    if (hash === activeChatChannel) return 1;
    if (secondHash && hash === secondHash) return 2;
    return 0;
  };
  const applyPaneClass = (el, pane) => {
    el.classList.toggle('chat-pane-1', pane === 1);
    el.classList.toggle('chat-pane-2', pane === 2);
  };

  const iframes = chatContainer.querySelectorAll('iframe.chat-iframe');
  iframes.forEach(iframe => {
    const hash = iframe.getAttribute('data-hash');
    const pane = paneOf(hash);
    const isActive = pane > 0 && shouldShowYoutubeSubView(hash, 'chat');
    iframe.style.display = isActive ? 'block' : 'none';
    applyPaneClass(iframe, isActive ? pane : 0);
  });
  const commentsPanels = chatContainer.querySelectorAll('.chat-comments-panel');
  commentsPanels.forEach(panel => {
    const hash = panel.getAttribute('data-hash');
    const pane = paneOf(hash);
    const isActive = pane > 0 && shouldShowYoutubeSubView(hash, 'comments');
    panel.style.display = isActive ? 'flex' : 'none';
    applyPaneClass(panel, isActive ? pane : 0);
  });
  reinitPendingHashes.forEach(h => updateChatReinitOverlayVisibility(h));
  updateChatPaneNameBands(secondHash);
}

// ── 채팅 헤더 덮개 띠 ── 플랫폼 채팅 헤더 왼쪽을 덮어 채널명을 보여준다(iframe 위에 올리므로 마크업 변경에 안 깨짐).
// 오른쪽 버튼 영역은 남기고, 덮은 자리도 pointer-events: none. 높이·폭·배경색은 눈대중 값이라 다르면 여기만 고친다.
const CHAT_HEADER_COVER = {
  chzzk: { height: 40, reserveRight: 124, background: '#141517' },  // − 100% + 와 ⋮
  soop: { height: 44, reserveRight: 76, background: '#1b1b20' },    // 참여자·설정 아이콘
  youtube: { height: 40, reserveRight: 88, background: '#0f0f0f' }  // XP 배지와 ⋮ ("주요 채팅" 드롭다운은 덮는다)
};

function getChatHeaderCover(platform) {
  return CHAT_HEADER_COVER[platform] || CHAT_HEADER_COVER.chzzk;
}

// 칸과 같은 클래스(.chat-pane-1/2)를 달아 위치는 기존 규칙에 맡기고 높이만 덮어쓴다. data-hash로 전환 애니메이션에 같이 실린다.
function ensureChatPaneNameBand(pane) {
  const id = `chat-pane-name-${pane}`;
  let band = chatContainer.querySelector(`#${id}`);
  if (band) return band;
  band = document.createElement('div');
  band.id = id;
  band.className = 'chat-pane-name';
  band.innerHTML = '<div class="chat-pane-name-inner">'
    + '<span class="chat-pane-name-badge"></span>'
    + '<span class="chat-pane-name-dot"></span>'
    + '<span class="chat-pane-name-text"></span>'
    + '</div>';
  chatContainer.appendChild(band);
  return band;
}

function updateChatPaneNameBands(secondHash) {
  if (!chatContainer) return;
  const split = isChatSplitEnabled() && !!secondHash;
  [
    { pane: 1, hash: activeChatChannel },
    { pane: 2, hash: split ? secondHash : null }
  ].forEach(({ pane, hash }) => {
    const existing = chatContainer.querySelector(`#chat-pane-name-${pane}`);
    const ch = hash ? getChannelObjByHash(hash) : null;
    if (!ch || !chatVisible) {
      if (existing) existing.remove();
      return;
    }
    const band = existing || ensureChatPaneNameBand(pane);
    const cover = getChatHeaderCover(ch.platform);
    band.setAttribute('data-hash', hash);
    band.classList.toggle('chat-pane-1', pane === 1);
    band.classList.toggle('chat-pane-2', pane === 2);
    band.style.setProperty('--chat-cover-h', `${cover.height}px`);
    band.style.setProperty('--chat-cover-reserve', `${cover.reserveRight}px`);
    band.style.setProperty('--chat-cover-bg', cover.background);
    band.style.setProperty('--chat-cover-accent', pane === 2 ? 'var(--chat-pane-2)' : 'var(--chat-pane-1)');
    // 칸 번호는 두 칸일 때만.
    const badge = band.querySelector('.chat-pane-name-badge');
    badge.textContent = split ? String(pane) : '';
    badge.hidden = !split;
    band.querySelector('.chat-pane-name-dot').style.backgroundColor = getPlatformColor(ch.platform);
    band.querySelector('.chat-pane-name-text').textContent = ch.name || '';
  });
}

function ensureChatIframeLoaded(hash) {
  if (!chatContainer || !hash) return;

  let iframe = chatContainer.querySelector(`iframe[data-hash="${hash}"]`);
  if (!iframe) {
    const chObj = getChannelObjByHash(hash);
    const platform = chObj ? chObj.platform : 'chzzk';
    iframe = createChatIframe(hash, platform);
  }

  // 표시는 syncChatVisibility에 맡긴다(유튜브 서브뷰 때문에).
  syncChatVisibility();
}
function loadChatForChannel(hash) {
  if (!chatContainer || !channels.some(c => c.hash === hash)) return;

  let iframe = chatContainer.querySelector(`iframe[data-hash="${hash}"]`);

  if (!iframe) {
    const chObj = getChannelObjByHash(hash);
    const platform = chObj ? chObj.platform : 'chzzk';
    createChatIframe(hash, platform);
  }

  syncChatVisibility();
}

function renderAll() {
  renderVideo();
  updateChatSession();
  renderAudioSettingsList();
  renderCollabSettingsSection();
}

// 채널별 런타임 기록을 지운다(저장되는 audioState는 유지). 삭제와 다른 창 삭제 반영에 쓴다.
function forgetChannelRuntimeState(hash) {
  delete channelAudioLevels[hash];
  delete channelAudioLevelHistory[hash];
  delete channelLevelingDbHistory[hash];
  delete debugDbHistory[hash];
  delete collabDbSmoothBuffer[hash];
  delete collabVadDebugByHash[hash];
  delete lastAppliedDisplayVolume[hash];
  delete lastAppliedRealVolume[hash];
  delete lastSentVolumeMessage[hash];
  ['grid', 'sub'].forEach((groupKey) => {
    if (groupReferenceHash[groupKey] === hash) delete groupReferenceHash[groupKey];
    const challenger = groupReferenceChallengerSince[groupKey];
    if (challenger && challenger.hash === hash) delete groupReferenceChallengerSince[groupKey];
  });
  delete offlineStreakByHash[hash];
  delete vodPickerShownByHash[hash];
  delete vodPickerShownAtByHash[hash];
  vodPickerPaginationByHash.delete(hash);
  debugForcedEndedHashes.delete(hash);
  delete channelLatencySecByHash[hash];
  delete lastKnownPlaybackTimeSec[hash];
  delete channelStallTracker[hash];
  delete channelStallRecoveryCount[hash];
  delete vodSyncLastCommandedPlaying[hash];
  vodAutoAlignPendingHashes.delete(hash);
  delete vodAutoAlignErrorByHash[hash];
  delete vodSyncRefineHistoryByMemberHash[hash];
  delete collabResetHoldUntilByHash[hash];
  delete channelDurationSecByHash[hash];
  delete collabLatencySmoothBuffer[hash];
  collabMutedHashes.delete(hash);
  deletePairEntriesForHash(hash);
  collabCaptureHashes.delete(hash);
  collabWaveformUnavailableHashes.delete(hash);
  videoHiddenChannels.delete(hash);
}

function removeChannel(hash, opts) {
  if (!hash) {
    console.error('❌ [ERROR] removeChannel: 전달된 hash 값이 없습니다.');
    return;
  }

  const dataTargetIndex = displayChannels.findIndex(c => c.hash === hash || c.name === hash);
  if (dataTargetIndex === -1) {
    console.warn(`⚠️ [REMOVE] displayChannels 목록에서 삭제 대상을 찾을 수 없습니다: ${hash}`);
    return;
  }
  const targetChannel = displayChannels[dataTargetIndex];
  const deleteHash = targetChannel.hash;
  const isMainTarget = (mainChannel === deleteHash || mainChannel === hash);
  const firstChzzkHash = getFirstChzzkHash();
  const isFirstChzzkDeleted = targetChannel.platform === 'chzzk' && deleteHash === firstChzzkHash;
  const shouldReloadAll = isFirstChzzkDeleted;

  console.log(`🗑️ [REMOVE] 삭제 요청 - Target: ${targetChannel.name} (${deleteHash}) | IsFirstChzzkDeleted: ${isFirstChzzkDeleted} | IsMain: ${isMainTarget}`);

  channels = channels.filter(c => c.hash !== deleteHash && c.name !== deleteHash);
  displayChannels = displayChannels.filter(c => c.hash !== deleteHash && c.name !== deleteHash);
  channelAddOrder = channelAddOrder.filter(h => h !== deleteHash && h !== hash);
  if (audioState.channelVolumeOverrides) {
    ['grid', 'sub'].forEach((role) => {
      const group = audioState.channelVolumeOverrides[role];
      if (!group) return;
      delete group[deleteHash];
      delete group[hash];
    });
    saveAudioState();
  }
  if (audioState.mainVolumeByChannel) {
    delete audioState.mainVolumeByChannel[deleteHash];
    delete audioState.mainVolumeByChannel[hash];
  }
  delete audioState.vodStartTimeMsByHash[deleteHash];
  delete audioState.vodStartTimeMsByHash[hash];
  forgetChannelRuntimeState(deleteHash);
  if (hash !== deleteHash) forgetChannelRuntimeState(hash);
  if (pendingMainRestoreHash === deleteHash || pendingMainRestoreHash === hash) pendingMainRestoreHash = null;
  if (pruneCollabGroups()) saveAudioState();

  if (displayChannels.length > 0) {
    // 삭제된 게 메인이었거나 메인이 없을 때만 새로 배정한다.
    if (isMainTarget || !mainChannel) {
      mainChannel = getFirstVideoChannelHash();
    }
  } else {
    mainChannel = null;
  }

  if (activeChatChannel === deleteHash || activeChatChannel === hash) {
    activeChatChannel = mainChannel;
  }

  if (controlUnlockedHash === deleteHash || controlUnlockedHash === hash) controlUnlockedHash = null;

  videoWrapperMap.forEach((wrapper, key) => {
    const wrapperDataHash = wrapper.getAttribute('data-hash');
    if (key === deleteHash || key === hash || wrapperDataHash === deleteHash || wrapperDataHash === hash) {
      const iframe = wrapper.querySelector('iframe');
      if (iframe) iframe.src = 'about:blank';
      wrapper.remove();
      videoWrapperMap.delete(key);
    }
  });

  if (chatContainer) {
    const chatIframe = chatContainer.querySelector(`iframe[data-hash="${deleteHash}"], iframe[data-hash="${hash}"]`);
    if (chatIframe) {
      chatIframe.src = 'about:blank';
      chatIframe.remove();
    }
  }
  // 유튜브 댓글 패널 DOM과 state도 정리한다.
  removeYoutubeCommentsPanel(deleteHash);
  removeYoutubeCommentsPanel(hash);
  youtubeChatSubView.delete(deleteHash);
  youtubeChatSubView.delete(hash);

  saveChannelsToStorage();
  renderQueueSidebar();

  if (shouldReloadAll && !(opts && opts.skipFullReload)) {
    console.log('🔄 [RELOAD] 가장 먼저 추가된 치지직 채널 삭제(메인/서브 무관) ➔ 플레이어 전체 재할당!');
    if (typeof reloadAllVideoPlayers === 'function') {
      reloadAllVideoPlayers();
    }
  } else {
    console.log('✨ [NO RELOAD] 일반 채널 삭제 처리 완료');
    if (typeof renderVideo === 'function') {
      renderVideo();
    }
  }

  if (typeof updateChatSession === 'function') {
    updateChatSession();
  }
}

// 치지직 VOD 영상 교체 — hash가 영상 식별자라 removeChannel로 정리한 뒤 같은 자리에 새 채널을 끼운다
// (전체 재로드는 건너뜀). 이전 영상 상태는 사라지고 기본값으로 시작한다.
function replaceVodChannelInPlace(oldHash, newChannelData) {
  if (!oldHash || !newChannelData || !newChannelData.hash) return;
  if (channels.some(c => c.hash === newChannelData.hash) || displayChannels.some(c => c.hash === newChannelData.hash)) {
    // 같은 영상이 이미 있으면 기존 슬롯만 지운다(hash 충돌 방지).
    removeChannel(oldHash);
    return;
  }

  const chIdx = channels.findIndex(c => c.hash === oldHash);
  const dispIdx = displayChannels.findIndex(c => c.hash === oldHash);
  const orderIdx = channelAddOrder.indexOf(oldHash);
  const wasMain = (mainChannel === oldHash);
  const wasActiveChat = (activeChatChannel === oldHash);

  removeChannel(oldHash, { skipFullReload: true });

  channels.splice(Math.min(Math.max(chIdx, 0), channels.length), 0, newChannelData);
  displayChannels.splice(Math.min(Math.max(dispIdx, 0), displayChannels.length), 0, newChannelData);
  channelAddOrder.splice(Math.min(Math.max(orderIdx, 0), channelAddOrder.length), 0, newChannelData.hash);
  if (wasMain) mainChannel = newChannelData.hash;
  if (wasActiveChat) activeChatChannel = newChannelData.hash;

  // 새 hash는 소유 기록이 없어 이 창 몫으로 먼저 올린다.
  saveChannelsAfterClaim([newChannelData.hash]);
  renderAll();
}

function saveActiveChatState() {
  const activeChatWrapper = document.querySelector('.chat-wrapper.active, [data-chat-active="true"]');
  if (activeChatWrapper) {
    const activeIndex = activeChatWrapper.getAttribute('data-channel-index') || '0';
    sessionStorage.setItem('LAST_ACTIVE_CHAT_INDEX', activeIndex);
  } else {
    sessionStorage.setItem('LAST_ACTIVE_CHAT_INDEX', '');
  }
}

function restoreActiveChatState() {
  const savedIndex = sessionStorage.getItem('LAST_ACTIVE_CHAT_INDEX');
  let targetIdx = 0;

  if (savedIndex !== null && savedIndex !== '') {
    targetIdx = parseInt(savedIndex, 10);
  }

  if (typeof displayChannels !== 'undefined' && displayChannels[targetIdx]) {
    setChatChannel(displayChannels[targetIdx].hash);
  }
}

function reloadAllVideoPlayers() {
  saveActiveChatState();
  // 다시 불러오는 동안의 정지는 정상 — 정지 기록을 비우고 쿨다운을 건다.
  Object.keys(channelStallTracker).forEach((h) => { delete channelStallTracker[h]; });
  lastPlayerReloadAt = Date.now();

  clearVideoGrid();

  if (typeof renderVideo === 'function') {
    renderVideo();
  }

  setTimeout(() => {
    restoreActiveChatState();
  }, 100);
}

const mainRefreshBtn = document.getElementById('refresh-btn');
if (mainRefreshBtn) {
  const cleanMainBtn = mainRefreshBtn.cloneNode(true);
  mainRefreshBtn.parentNode.replaceChild(cleanMainBtn, mainRefreshBtn);

  cleanMainBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    reloadAllVideoPlayers();
  });
}

window.addEventListener('beforeunload', () => {
  saveActiveChatState();
});

document.addEventListener('DOMContentLoaded', () => {
  restoreActiveChatState();
});

document.getElementById('logo')?.addEventListener('click', () => {
  channels = [];
  displayChannels = [];
  channelAddOrder = [];
  mainChannel = null;
  activeChatChannel = null;
  isFirstZeroRemoved = false;
  controlUnlockedHash = null;

  if (typeof channelInput !== 'undefined' && channelInput) {
    channelInput.value = '';
  } else {
    const inputElem = document.getElementById('channel-input'); 
    if (inputElem) inputElem.value = '';
  }

  clearVideoGrid();
  if (chatContainer) chatContainer.innerHTML = '';

  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.remove(['my_channels'], () => {
      renderAll();
    });
  } else {
    localStorage.removeItem('my_channels');
    renderAll();
  }
});

let isReloadingAll = false;

let mySetting = {
  name: '내 프로필', avatar: '', connections: { chzzk: false, soop: false },
  minViewers: { ...DEFAULT_MIN_VIEWERS }, gridVolume: DEFAULT_CHANNEL_VOLUME, subVolume: DEFAULT_SUB_VOLUME,
  mainSessionVh: null, maxChannels: DEFAULT_MAX_CHANNELS, mainSubSpan: 'normal',
  collabAutoEnabled: false, collabManualEnabled: false,
  dynamicsCompressorEnabled: false,
  // 디버그 하위 스위치는 기본 꺼짐 — vodDebugEnabled는 그리드 전체를 실제로 방종 시뮬레이션하는 스위치라 위험하다.
  audioDebugEnabled: false, vodDebugEnabled: false,
  // 채팅 2분할(설정 > 채팅).
  chatSplitEnabled: false, chatSplitDir: 'vertical', chatSecondPaneMode: 'keep',
  chatSide: 'right',
  // 검색 "전체" 탭 플랫폼 순서. 빈 배열이면 PLATFORM_META 순서.
  searchPlatformOrder: []
};
let profileConnectionChanged = false;

function loadSetting(callback) {
  const migrate = () => {
    if (!mySetting.connections) {
      mySetting.connections = { chzzk: !!mySetting.chzzkConnected, soop: false };
      delete mySetting.chzzkConnected;
    }
    mySetting.minViewers = { ...DEFAULT_MIN_VIEWERS, ...(mySetting.minViewers || {}) };
    if (typeof mySetting.gridVolume !== 'number' || isNaN(mySetting.gridVolume)) mySetting.gridVolume = DEFAULT_CHANNEL_VOLUME;
    if (typeof mySetting.subVolume !== 'number' || isNaN(mySetting.subVolume)) mySetting.subVolume = DEFAULT_SUB_VOLUME;
    if (!Number.isInteger(mySetting.maxChannels) || mySetting.maxChannels < MAX_CHANNELS_INPUT_MIN) mySetting.maxChannels = DEFAULT_MAX_CHANNELS;
    // 예전 "실험적 기능" 총 스위치가 꺼진 채 저장된 프로필은 합방 설정도 끈다.
    if (mySetting.experimentalEnabled === false) mySetting.collabSettingEnabled = false;
    delete mySetting.experimentalEnabled;
    delete mySetting.audioOptimizationEnabled;
    // 기본값은 전부 꺼짐. 예전 단일 합방 스위치 값은 자동·수동 둘 다에 옮긴다.
    if (typeof mySetting.collabSettingEnabled === 'boolean') {
      if (typeof mySetting.collabAutoEnabled !== 'boolean') mySetting.collabAutoEnabled = mySetting.collabSettingEnabled;
      if (typeof mySetting.collabManualEnabled !== 'boolean') mySetting.collabManualEnabled = mySetting.collabSettingEnabled;
    }
    delete mySetting.collabSettingEnabled;
    mySetting.collabAutoEnabled = !!mySetting.collabAutoEnabled;
    mySetting.collabManualEnabled = !!mySetting.collabManualEnabled;
    if (mySetting.collabVadModel !== 'pyannote') mySetting.collabVadModel = 'silero';
    mySetting.dynamicsCompressorEnabled = !!mySetting.dynamicsCompressorEnabled;
    if (typeof mySetting.audioDebugEnabled !== 'boolean') mySetting.audioDebugEnabled = false;
    if (typeof mySetting.vodDebugEnabled !== 'boolean') mySetting.vodDebugEnabled = false;
    // 메인-서브 확장은 제거됨 — 일반으로 되돌린다.
    mySetting.mainSubSpan = 'normal';
    if (!mySetting.shortcutKeys || typeof mySetting.shortcutKeys !== 'object') mySetting.shortcutKeys = {};
  };
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['my_profile'], (result) => {
      if (result.my_profile) mySetting = result.my_profile;
      migrate();
      callback && callback();
    });
  } else {
    const saved = localStorage.getItem('my_profile');
    if (saved) mySetting = JSON.parse(saved);
    migrate();
    callback && callback();
  }
}

function saveSetting() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    profileWriteEchoes.remember(JSON.stringify(mySetting));
    chrome.storage.local.set({ my_profile: mySetting });
  } else {
    localStorage.setItem('my_profile', JSON.stringify(mySetting));
  }
}

async function syncPlatformLoginStatus(platform) {
  const loggedIn = await getAdapter(platform).checkLoginStatus();
  if (!mySetting.connections) mySetting.connections = {};
  if (mySetting.connections[platform] !== loggedIn) {
    mySetting.connections[platform] = loggedIn;
    saveSetting();
    profileConnectionChanged = true;
  }
  return loggedIn;
}

async function syncAllLoginStatus() {
  const enabledPlatforms = Object.keys(PLATFORM_META).filter(p => PLATFORM_META[p].enabled && PlatformAdapters[p]);
  const statuses = await Promise.all(enabledPlatforms.map(p => syncPlatformLoginStatus(p)));
  return Object.fromEntries(enabledPlatforms.map((p, i) => [p, statuses[i]]));
}

// 설정 화면을 열 때마다 계정 정보를 새로 조회한다.
async function getAccountLabelForPlatform(platform) {
  try {
    let info = null;
    if (platform === 'chzzk') info = await getChzzkAccountKey();
    else if (platform === 'soop') info = await getSoopAccountKey();
    else if (platform === 'youtube') info = await getYoutubeAccountKey();
    return info ? info.label : null;
  } catch (err) {
    return null;
  }
}

function renderPlatformRow(container, key) {
  const meta = PLATFORM_META[key];
  const connected = mySetting.connections ? !!mySetting.connections[key] : false;

  const row = document.createElement('div');
  row.className = 'platform-row' + (meta.enabled ? '' : ' disabled');

  const dot = document.createElement('div');
  dot.className = 'platform-dot';
  dot.style.backgroundColor = meta.color;
  row.appendChild(dot);

  const name = document.createElement('div');
  name.className = 'platform-name';
  name.textContent = getPlatformLabel(key);
  row.appendChild(name);

  if (meta.enabled && connected) {
    const accountIdEl = document.createElement('span');
    accountIdEl.className = 'platform-account-id';
    accountIdEl.style.cssText = 'margin-left:6px; font-size:12px; color:#999;';
    row.appendChild(accountIdEl);
    getAccountLabelForPlatform(key).then((label) => {
      if (label) accountIdEl.textContent = `(${label})`;
    });
  }

  if (!meta.enabled) {
    const btn = document.createElement('button');
    btn.className = 'platform-login-btn';
    btn.style.color = meta.color;
    btn.textContent = t('settings.platformPreparing', '준비중');
    btn.disabled = true;
    row.appendChild(btn);
  } else if (connected) {
    const status = document.createElement('span');
    status.className = 'platform-login-btn';
    status.style.color = meta.color;
    status.textContent = t('settings.platformConnected', '연동됨');
    row.appendChild(status);

    const logoutBtn = document.createElement('button');
    logoutBtn.className = 'platform-logout-btn';
    logoutBtn.style.borderColor = meta.color;
    logoutBtn.style.color = meta.color;
    logoutBtn.textContent = t('settings.platformLogout', '로그아웃');
    logoutBtn.addEventListener('click', async () => {
      logoutBtn.disabled = true;
      logoutBtn.classList.add('is-loading');
      logoutBtn.textContent = t('settings.platformLoggingOut', '로그아웃 중...');
      status.textContent = t('settings.platformLoggingOut', '로그아웃 중...');
      status.classList.add('is-loading');

      const adapter = getAdapter(key);
      if (typeof adapter.logout === 'function') {
        await adapter.logout();
      } else {
        window.open(adapter.getLogoutUrl(), '_blank');
      }
      setTimeout(() => syncPlatformLoginStatus(key).then(() => refreshSettingModal()), 1500);
    });
    row.appendChild(logoutBtn);
  } else {
    const btn = document.createElement('button');
    btn.className = 'platform-login-btn';
    btn.style.color = meta.color;
    btn.textContent = t('settings.platformLogin', '로그인');
    btn.addEventListener('click', () => {
      openLoginPopup(getAdapter(key).getLoginUrl()).then(() => {
        syncPlatformLoginStatus(key).then(() => refreshSettingModal());
      });
      pollPlatformLogin(key);
    });
    row.appendChild(btn);
  }

  container.appendChild(row);
}

function openLoginPopup(url, { width = 500, height = 650 } = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'OPEN_LOGIN_POPUP', url, width, height }, (response) => {
      if (chrome.runtime.lastError || !response || !response.ok) {
        window.open(url, '_blank');
        resolve();
        return;
      }

      const targetWindowId = response.windowId;
      function onClosedMessage(message) {
        if (!message || message.type !== 'LOGIN_POPUP_CLOSED') return;
        if (message.windowId !== targetWindowId) return;
        chrome.runtime.onMessage.removeListener(onClosedMessage);
        resolve();
      }
      chrome.runtime.onMessage.addListener(onClosedMessage);
    });
  });
}

function pollPlatformLogin(platform) {
  let attempts = 0;
  const interval = setInterval(async () => {
    attempts++;
    const loggedIn = await syncPlatformLoginStatus(platform);
    if (loggedIn || attempts >= 15) {
      clearInterval(interval);
      const modal = document.getElementById('setting-modal');
      if (modal && modal.classList.contains('active')) refreshSettingModal();
    }
  }, 2000);
}

function closeSettingModal() {
  const modal = document.getElementById('setting-modal');
  if (modal) modal.classList.remove('active');

  const settingsBtn = document.getElementById('settings-btn');
  if (settingsBtn) settingsBtn.classList.remove('active');

  if (profileConnectionChanged) {
    profileConnectionChanged = false;
    window.location.reload();
  }
}

function toggleSettingModal() {
  const modal = document.getElementById('setting-modal');
  if (modal && modal.classList.contains('active')) {
    closeSettingModal();
  } else {
    openSettingModal();
  }
}

function bindVolumeSettingInput(inputId, settingKey) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('change', () => {
    let value = parseInt(input.value, 10);
    if (isNaN(value) || value < 0) value = 0;
    if (value > 100) value = 100;
    input.value = value;
    mySetting[settingKey] = value;
    saveSetting();
    applyVolumeToAllChannels(true);
    renderAudioSettingsList();
  });
}

async function openSettingModal() {
  profileConnectionChanged = false;
  let modal = document.getElementById('setting-modal');

  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'setting-modal';
    modal.className = 'setting-modal-backdrop';
    modal.innerHTML = `
      <div class="setting-modal-content">
        <h3 data-i18n="settings.title">설정</h3>
        <div class="settings-tab-nav">
          <button type="button" class="settings-tab-btn active" data-tab="settings" data-i18n="settings.tabSettings">설정</button>
          <button type="button" class="settings-tab-btn" data-tab="lab" data-i18n="settings.tabLab">실험실</button>
          <button type="button" class="settings-tab-btn" data-tab="info" data-i18n="settings.tabInfo">안내</button>
        </div>

        <div class="settings-tab-panel" data-panel="settings">
          <div class="settings-subtab-nav">
            <button type="button" class="settings-subtab-btn active" data-subtab="general" data-i18n="settings.tabGeneral">일반</button>
            <button type="button" class="settings-subtab-btn" data-subtab="controls" data-i18n="settings.tabControls">조작</button>
            <button type="button" class="settings-subtab-btn" data-subtab="video" data-i18n="settings.tabVideo">비디오</button>
            <button type="button" class="settings-subtab-btn" data-subtab="audio" data-i18n="settings.tabAudio">오디오</button>
            <button type="button" class="settings-subtab-btn" data-subtab="chat" data-i18n="settings.tabChat">채팅</button>
            <button type="button" class="settings-subtab-btn" data-subtab="debug" data-i18n="settings.tabDebug">디버그</button>
          </div>

          <div class="settings-subtab-panel" data-subpanel="general">
            <div class="setting-section-title" data-i18n="settings.uiLanguageSection">언어</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="ui-language-select" data-i18n="settings.uiLanguageLabel">언어</label>
              <select id="ui-language-select" class="yt-settings-select"></select>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.uiLanguageHint">화면에 표시되는 언어를 바꿉니다.</div>

            <div class="setting-section-title" data-i18n="settings.accountSection">연동 계정</div>
            <div id="platform-list"></div>

            <div class="setting-section-title" data-i18n="settings.searchOrderSection">검색 결과 순서</div>
            <div id="search-platform-order-list" class="search-platform-order-list"></div>
            <div class="yt-settings-hint" data-i18n="settings.searchOrderHint">검색 "전체" 탭에서 결과를 섞는 순서입니다. 연관도가 비슷하면 위에 있는 플랫폼이 먼저 나옵니다.</div>

            <div class="setting-section-title" data-i18n="settings.minViewersSection">최소 시청자 수</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="min-viewer-platform-select" data-i18n="settings.minViewersPlatformLabel">플랫폼</label>
              <select id="min-viewer-platform-select" class="yt-settings-select"></select>
            </div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="min-viewer-input" data-i18n="settings.minViewersValueLabel">최소 시청자수</label>
              <input type="number" id="min-viewer-input" class="yt-settings-select" min="0" step="1" />
            </div>
            <div class="yt-settings-hint" data-i18n="settings.minViewersHint">이 수 미만인 라이브는 검색에서 숨깁니다.</div>

            <div class="setting-section-title" data-i18n="settings.maxChannelsSection">최대 채널 수</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="max-channels-input" data-i18n="settings.maxChannelsLabel">최대 채널 수</label>
              <input type="number" id="max-channels-input" class="yt-settings-select" min="1" max="50" step="1" />
            </div>
            <div class="yt-settings-hint" data-i18n="settings.maxChannelsHint">기본 12개. 줄여도 이미 추가한 채널은 유지됩니다.</div>
            <div id="max-channels-warning" class="info-notice" data-i18n="settings.maxChannelsWarning" hidden>12개를 넘으면 끊김이 생기거나 합방 자동 음소거가 잘못 걸릴 수 있습니다.</div>
          </div>

          <div class="settings-subtab-panel" data-subpanel="controls" hidden>
            <div class="setting-section-title" data-i18n="settings.shortcutSection">조작 키</div>
            <div id="shortcut-key-list"></div>
            <div class="yt-settings-row">
              <span class="yt-settings-label"></span>
              <button id="shortcut-key-reset-btn" type="button" class="yt-settings-select" data-i18n="settings.shortcutReset">기본값으로</button>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.shortcutHint">버튼을 누른 뒤 바꿀 키를 누르세요. Backspace는 해제, Esc는 취소입니다.</div>
          </div>

          <div class="settings-subtab-panel" data-subpanel="video" hidden>
            <div class="setting-section-title" data-i18n="settings.representativeWindowSection">대표 창</div>
            <div id="representative-window-list"></div>
            <div class="yt-settings-hint" data-i18n="settings.representativeWindowHint">창이 여러 개일 때 계정 확인·보내기·합방 판정을 맡습니다. 닫으면 가장 먼저 연 창이 이어받습니다.</div>

            <div class="setting-section-title" data-i18n="settings.mainSessionSizeSection">메인 화면 크기</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" data-i18n="settings.mainSessionSizeLabel">메인 화면 크기</label>
              <button id="main-session-size-reset-btn" type="button" class="yt-settings-select" data-i18n="settings.mainSessionSizeResetButton">초기화</button>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.mainSessionSizeHint">메인 화면 우하단 모서리를 드래그해 크기를 조절합니다. 초기화하면 기본 크기로 돌아갑니다.</div>

            <div class="setting-section-title" data-i18n="settings.liveSyncSection">라이브 싱크</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="live-sync-toggle" data-i18n="settings.liveSyncLabel">라이브 싱크 자동 맞춤</label>
              <label class="setting-toggle">
                <input type="checkbox" id="live-sync-toggle" />
                <span class="setting-toggle-track"></span>
              </label>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.liveSyncHint">채널을 추가하면 메인 채널의 지연에 한 번 맞추고, 그 뒤로 벌어지면 재생 속도를 살짝(최대 5%) 바꿔 끊김 없이 맞춥니다(치지직·숲). 3초 넘게 벌어지면 한 번 옮깁니다. 모든 채널을 지금 맞추려면 조작 키(기본 S)를 누르세요. 방송마다 송출 지연이 달라 소리가 완전히 맞지 않을 수 있습니다.</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="live-sync-target-input" data-i18n="settings.liveSyncTargetLabel">기준 지연(초)</label>
              <input type="number" id="live-sync-target-input" class="yt-settings-select" min="0.5" max="10" step="0.1" />
            </div>
            <div class="yt-settings-hint" data-i18n="settings.liveSyncTargetHint">메인 채널을 맞추는 지연입니다. 나머지 채널은 메인 채널에 맞춥니다. 작을수록 실시간에 가깝지만 버퍼링이 잦아질 수 있습니다(기본 1.5초).</div>
          </div>

          <div class="settings-subtab-panel" data-subpanel="audio" hidden>
            <div class="setting-section-title" data-i18n="settings.audioOptimizationSection">오디오 최적화</div>
            <div class="yt-settings-hint" data-i18n="settings.audioOptimizationHint">채널 체감 음량을 자동으로 맞춥니다. 음량은 플레이어가 아닌 여기서 조절하세요.</div>

            <div id="audio-optimization-detail">
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="grid-volume-input" data-i18n="settings.gridVolumeLabel">그리드 레이아웃 최대 음량</label>
                <input type="number" id="grid-volume-input" class="yt-settings-select" min="0" max="100" step="1" />
              </div>
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="sub-volume-input" data-i18n="settings.subVolumeLabel">메인-서브 레이아웃 최대 음량</label>
                <input type="number" id="sub-volume-input" class="yt-settings-select" min="0" max="100" step="1" />
              </div>
              <div class="yt-settings-hint" data-i18n="settings.audioHint">그리드/서브 채널의 최대 음량입니다. 이 안에서 채널 음량을 자동으로 맞춥니다(거의 무음인 채널 제외).</div>
            </div>

            <div class="setting-section-title" data-i18n="settings.collabSettingSection">합방 설정</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="collab-auto-toggle" data-i18n="settings.collabAutoLabel">자동 합방 사용</label>
              <label class="setting-toggle">
                <input type="checkbox" id="collab-auto-toggle" />
                <span class="setting-toggle-track"></span>
              </label>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.collabAutoHint">같은 소리가 겹치는 채널끼리 자동으로 묶어 하나만 남기고 음소거합니다. AI 음성 감지로 말하는 구간을 비교하며, 처음 켤 때 약 15MB를 받고 CPU를 더 씁니다.</div>
            <div id="collab-auto-detail">
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="collab-vad-model-select" data-i18n="settings.collabVadModelLabel">AI 음성 감지 모델</label>
                <select id="collab-vad-model-select" class="yt-settings-select">
                  <option value="silero" data-i18n="settings.collabVadModelBasic">기본 (Silero)</option>
                  <option value="pyannote" data-i18n="settings.collabVadModelPrecise">정밀 (pyannote)</option>
                </select>
              </div>
              <div class="yt-settings-hint" data-i18n="settings.collabVadModelHint">정밀은 더 큰 모델로 말소리를 더 정확히 가려내고, 겹친 말소리도 구분합니다. CPU를 조금 더 씁니다(처음 한 번 약 6MB를 더 불러옴).</div>
              <div id="collab-vad-status" class="yt-settings-hint collab-vad-status"></div>
            </div>

            <div class="yt-settings-row">
              <label class="yt-settings-label" for="collab-manual-toggle" data-i18n="settings.collabManualLabel">수동 합방 사용</label>
              <label class="setting-toggle">
                <input type="checkbox" id="collab-manual-toggle" />
                <span class="setting-toggle-track"></span>
              </label>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.collabManualHint">오디오 패널에서 직접 묶은 합방 그룹은 소리를 비교하지 않고 항상 하나만 남기고 음소거합니다. 방송 싱크가 크게 어긋나 자동으로 안 묶이는 합방에 씁니다.</div>

            <div id="collab-manual-detail">
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="vod-sync-toggle" data-i18n="settings.vodSyncLabel">VOD 합방 싱크 동기화 사용</label>
                <label class="setting-toggle">
                  <input type="checkbox" id="vod-sync-toggle" />
                  <span class="setting-toggle-track"></span>
                </label>
              </div>
              <div class="yt-settings-hint" data-i18n="settings.vodSyncHint">VOD 싱크 그룹은 지정한 오프셋으로 재생 위치를 맞추고 대표 채널 외 음소거합니다.</div>
            </div>
          </div>

          <div class="settings-subtab-panel" data-subpanel="chat" hidden>
            <div class="setting-section-title" data-i18n="settings.chatSideSection">채팅 위치</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="chat-side-select" data-i18n="settings.chatSideLabel">채팅 표시 위치</label>
              <select id="chat-side-select" class="yt-settings-select">
                <option value="right" data-i18n="settings.chatSideRight">영상 우측</option>
                <option value="left" data-i18n="settings.chatSideLeft">영상 좌측</option>
              </select>
            </div>
            <div class="setting-section-title" data-i18n="settings.chatSplitSection">채팅 2분할</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="chat-split-toggle" data-i18n="settings.chatSplitLabel">채팅창 2개 보기</label>
              <label class="setting-toggle">
                <input type="checkbox" id="chat-split-toggle" />
                <span class="setting-toggle-track"></span>
              </label>
            </div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="chat-split-dir-select" data-i18n="settings.chatSplitDirLabel">나누는 방향</label>
              <select id="chat-split-dir-select" class="yt-settings-select">
                <option value="vertical" data-i18n="settings.chatSplitDirVertical">위아래</option>
                <option value="horizontal" data-i18n="settings.chatSplitDirHorizontal">좌우</option>
                <option value="side" data-i18n="settings.chatSplitDirSide">사이드 (채팅 - 영상 - 채팅)</option>
              </select>
            </div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="chat-second-pane-select" data-i18n="settings.chatSecondPaneLabel">화면 전환 시 2번 칸</label>
              <select id="chat-second-pane-select" class="yt-settings-select">
                <option value="keep" data-i18n="settings.chatSecondPaneKeep">고정 (직접 고른 채팅 유지)</option>
                <option value="inherit" data-i18n="settings.chatSecondPaneInherit">이어받기 (1번 칸 채팅이 내려옴)</option>
              </select>
            </div>
            <div class="chat-split-preview" id="chat-split-preview">
              <div class="chat-split-preview-video"></div>
              <div class="chat-split-preview-side">
                <div class="chat-split-preview-tabs"><span></span><span></span><span></span></div>
                <div class="chat-split-preview-panes">
                  <div class="chat-split-preview-pane" data-pane="1">1</div>
                  <div class="chat-split-preview-pane" data-pane="2">2</div>
                </div>
              </div>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.chatSplitHint">채팅 사이드바를 두 칸으로 나눠 서로 다른 채널의 채팅을 같이 봅니다. 1번 칸은 채팅 탭을 왼쪽 클릭으로, 2번 칸은 탭을 오른쪽 클릭해 메뉴에서 고릅니다.</div>
          </div>

          <div class="settings-subtab-panel" data-subpanel="debug" hidden>
            <div class="setting-section-title" data-i18n="settings.debugSection">디버그</div>
            <div class="yt-settings-row">
              <label class="yt-settings-label" for="debug-mode-toggle" data-i18n="settings.debugModeLabel">디버그 모드</label>
              <label class="setting-toggle">
                <input type="checkbox" id="debug-mode-toggle" />
                <span class="setting-toggle-track"></span>
              </label>
            </div>
            <div class="yt-settings-hint" data-i18n="settings.debugModeHint">켜면 아래 디버그 기능을 쓸 수 있습니다.</div>

            <div id="debug-feature-list" class="experimental-feature-list" hidden>
              <div class="setting-section-title" data-i18n="settings.debugAudioSectionTitle">오디오 디버그</div>
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="audio-debug-toggle" data-i18n="settings.debugAudioToggleLabel">오디오 디버그 표시</label>
                <label class="setting-toggle">
                  <input type="checkbox" id="audio-debug-toggle" />
                  <span class="setting-toggle-track"></span>
                </label>
              </div>
              <div class="yt-settings-hint" data-i18n="settings.debugAudioToggleHint">오디오 패널에 dB 파형과 합방 분석값을 표시합니다.</div>

              <div class="setting-section-title" data-i18n="settings.debugVodSectionTitle">방종 VOD 시뮬레이션</div>
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="vod-debug-toggle" data-i18n="settings.debugVodToggleLabel">방종 VOD 디버그 표시</label>
                <label class="setting-toggle">
                  <input type="checkbox" id="vod-debug-toggle" />
                  <span class="setting-toggle-track"></span>
                </label>
              </div>
              <div class="yt-settings-hint" data-i18n="settings.debugVodToggleHint">그리드의 치지직 라이브를 모두 방송 종료 상태로 만들어 다시보기 패널을 테스트합니다.</div>

              <div class="setting-section-title" data-i18n="settings.debugSyncSectionTitle">라이브 싱크 디버그</div>
              <div class="yt-settings-row">
                <label class="yt-settings-label" for="sync-debug-toggle" data-i18n="settings.debugSyncToggleLabel">싱크 표시</label>
                <label class="setting-toggle">
                  <input type="checkbox" id="sync-debug-toggle" />
                  <span class="setting-toggle-track"></span>
                </label>
              </div>
              <div class="yt-settings-hint" data-i18n="settings.debugSyncToggleHint">각 타일에 라이브 지연, 맞출 기준과의 차이, 최근에 당긴 양을 표시합니다.</div>

              <div class="setting-section-title" data-i18n="settings.debugMemberSuggestSectionTitle">합방 멤버 추가 제안</div>
              <div class="yt-settings-row">
                <label class="yt-settings-label" data-i18n="settings.debugMemberSuggestLabel">예시 창 띄우기</label>
                <button type="button" id="debug-member-suggest-btn" class="debug-action-btn" data-i18n="settings.debugMemberSuggestButton">띄우기</button>
              </div>
              <div class="yt-settings-hint" data-i18n="settings.debugMemberSuggestHint">지금 그리드의 채널 이름으로 조회해 제안 창을 띄웁니다(크기 확인용).</div>
            </div>
          </div>
        </div>

        <div class="settings-tab-panel" data-panel="lab" hidden></div>

        <div class="settings-tab-panel" data-panel="info" hidden>
          <div class="setting-section-title">CHEESE EYES</div>
          <div class="info-row"><span class="info-row-label" data-i18n="settings.versionLabel">버전</span><span id="info-version" class="info-row-value"></span></div>
          <div class="setting-section-title" data-i18n="settings.platformsSection">지원 플랫폼</div>
          <div class="info-platform-list" data-i18n="settings.platformsList">치지직(CHZZK) · 숲(SOOP) · 유튜브(YOUTUBE)</div>
          <div class="info-notice" data-i18n="settings.noticeStructure">플랫폼 구조 변경 시 정상 동작 하지 않을 수 있습니다.</div>
          <div class="info-notice" data-i18n="settings.noticeYoutubeTag">유튜브는 별도의 태그 검색을 지원하지 않습니다.</div>
          <div class="info-notice" data-i18n="settings.noticeKoreanSearch">치지직 / 숲은 한글 검색만을 지원합니다.</div>
          <div class="setting-section-title" data-i18n="settings.contactSection">문의 / 링크</div>
          <div class="info-link-row"><a href="mailto:seoldam82@gmail.com">seoldam82@gmail.com</a></div>
          <div class="info-link-row"><a href="https://github.com/seoldam82/CHEESE-EYES" target="_blank" rel="noopener" data-i18n="settings.githubRepo">GitHub 저장소</a></div>
          <div class="info-link-row"><a href="https://github.com/seoldam82/CHEESE-EYES/blob/main/PRIVACY_POLICY.md" target="_blank" rel="noopener" data-i18n="settings.privacyPolicy">개인정보처리방침</a></div>
        </div>

        <div class="setting-modal-actions">
          <button id="setting-close-btn" data-i18n="settings.closeButton">닫기</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    if (typeof window.applyStaticTranslations === 'function') window.applyStaticTranslations();

    document.getElementById('setting-close-btn').addEventListener('click', closeSettingModal);

    // 대표 창 목록은 자주 다시 그리므로 클릭은 컨테이너에서 받는다.
    document.getElementById('representative-window-list')?.addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-slot-action]');
      if (!btn || btn.disabled) return;
      const type = btn.dataset.slotAction === 'focus' ? 'FOCUS_DASHBOARD_WINDOW' : 'SET_REPRESENTATIVE';
      chrome.runtime.sendMessage({ type, slotId: btn.dataset.slotId }).catch(() => {});
    });

    modal.querySelectorAll('.settings-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.tab;
        modal.querySelectorAll('.settings-tab-btn').forEach(b => b.classList.toggle('active', b === btn));
        modal.querySelectorAll('.settings-tab-panel').forEach(p => {
          p.hidden = p.dataset.panel !== target;
        });
      });
    });

    modal.querySelectorAll('.settings-subtab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.subtab;
        modal.querySelectorAll('.settings-subtab-btn').forEach(b => b.classList.toggle('active', b === btn));
        modal.querySelectorAll('.settings-subtab-panel').forEach(p => {
          p.hidden = p.dataset.subpanel !== target;
        });
      });
    });

    const uiLanguageSelect = document.getElementById('ui-language-select');
    getUiLanguageOptions().forEach(opt => {
      const el = document.createElement('option');
      el.value = opt.value;
      el.textContent = opt.label;
      uiLanguageSelect.appendChild(el);
    });
    uiLanguageSelect.addEventListener('change', () => {
      if (typeof window.setUiLanguage === 'function') window.setUiLanguage(uiLanguageSelect.value);
    });

    const infoVersion = document.getElementById('info-version');
    if (infoVersion) {
      try { infoVersion.textContent = `v${chrome.runtime.getManifest().version}`; }
      catch (e) { infoVersion.textContent = ''; }
    }

    const minViewerPlatformSelect = document.getElementById('min-viewer-platform-select');
    const minViewerInput = document.getElementById('min-viewer-input');
    if (minViewerPlatformSelect) {
      Object.keys(PLATFORM_META)
        .filter(key => PLATFORM_META[key].enabled)
        .forEach(key => {
          const el = document.createElement('option');
          el.value = key;
          el.textContent = getPlatformBrand(key);
          minViewerPlatformSelect.appendChild(el);
        });
    }
    if (minViewerPlatformSelect && minViewerInput) {
      minViewerPlatformSelect.addEventListener('change', () => {
        minViewerInput.value = getMinViewers(minViewerPlatformSelect.value);
      });
      minViewerInput.addEventListener('change', () => {
        const platform = minViewerPlatformSelect.value;
        let value = parseInt(minViewerInput.value, 10);
        if (isNaN(value) || value < 0) value = 0;
        minViewerInput.value = value;
        if (!mySetting.minViewers) mySetting.minViewers = { ...DEFAULT_MIN_VIEWERS };
        mySetting.minViewers[platform] = value;
        saveSetting();
      });
    }

    bindVolumeSettingInput('grid-volume-input', 'gridVolume');
    bindVolumeSettingInput('sub-volume-input', 'subVolume');

    const maxChannelsInput = document.getElementById('max-channels-input');
    if (maxChannelsInput) {
      maxChannelsInput.addEventListener('input', () => {
        updateMaxChannelsWarning(parseInt(maxChannelsInput.value, 10));
      });
      maxChannelsInput.addEventListener('change', () => {
        let value = parseInt(maxChannelsInput.value, 10);
        if (isNaN(value)) value = DEFAULT_MAX_CHANNELS;
        value = Math.min(MAX_CHANNELS_INPUT_MAX, Math.max(MAX_CHANNELS_INPUT_MIN, value));
        maxChannelsInput.value = value;
        mySetting.maxChannels = value;
        saveSetting();
        updateMaxChannelsWarning(value);
      });
    }

    document.getElementById('main-session-size-reset-btn')?.addEventListener('click', resetMainSessionSize);
    document.getElementById('shortcut-key-reset-btn')?.addEventListener('click', resetShortcutKeys);
    document.getElementById('sync-debug-toggle')?.addEventListener('change', (e) => {
      mySetting.syncDebugEnabled = e.target.checked;
      saveSetting();
      renderSyncDebugOverlays();
    });
    const liveSyncTargetInput = document.getElementById('live-sync-target-input');
    liveSyncTargetInput?.addEventListener('change', () => {
      let value = parseFloat(liveSyncTargetInput.value);
      if (!isFinite(value)) value = LIVE_SYNC_DEFAULT_TARGET_SEC;
      value = Math.round(Math.min(LIVE_SYNC_TARGET_MAX_SEC, Math.max(LIVE_SYNC_TARGET_MIN_SEC, value)) * 10) / 10;
      liveSyncTargetInput.value = value;
      mySetting.liveSyncTargetSec = value;
      saveSetting();
    });
    document.getElementById('live-sync-toggle')?.addEventListener('change', (e) => {
      mySetting.liveSyncEnabled = e.target.checked;
      saveSetting();
    });

    const applyChatSplitSettingChange = () => {
      saveSetting();
      updateChatSplitSettingsUI();
      updateChatSession();
    };
    document.getElementById('chat-split-toggle')?.addEventListener('change', (e) => {
      mySetting.chatSplitEnabled = e.target.checked;
      applyChatSplitSettingChange();
    });
    document.getElementById('chat-split-dir-select')?.addEventListener('change', (e) => {
      // 값 검증은 getChatSplitDir 한 곳에서만(여기서 좁히면 새 방향이 조용히 버려진다).
      mySetting.chatSplitDir = e.target.value;
      applyChatSplitSettingChange();
    });
    document.getElementById('chat-second-pane-select')?.addEventListener('change', (e) => {
      mySetting.chatSecondPaneMode = e.target.value === 'inherit' ? 'inherit' : 'keep';
      saveSetting();
      updateChatSplitSettingsUI();
    });
    // 좌/우 위치는 영상 폭이 안 바뀌어 클래스만 바꾼다.
    document.getElementById('chat-side-select')?.addEventListener('change', (e) => {
      mySetting.chatSide = e.target.value === 'left' ? 'left' : 'right';
      saveSetting();
      applyChatSidePosition();
      updateChatSplitSettingsUI();
    });

    const onCollabToggleChanged = () => {
      // AI 음성 감지는 자동 합방과 함께 켜진다 — 즉시 모델 로딩.
      if (isCollabVadNeededInThisWindow()) ensureVadWorker();
      recomputeCollabMuting();
      applyVolumeToAllChannels(true);
      refreshAudioSettingsListIfSafe();
      renderCollabSettingsSection();
    };
    const collabAutoToggle = document.getElementById('collab-auto-toggle');
    const collabAutoDetail = document.getElementById('collab-auto-detail');
    collabAutoToggle?.addEventListener('change', () => {
      mySetting.collabAutoEnabled = collabAutoToggle.checked;
      saveSetting();
      if (collabAutoDetail) collabAutoDetail.hidden = !collabAutoToggle.checked;
      onCollabToggleChanged();
    });
    document.getElementById('collab-vad-model-select')?.addEventListener('change', (e) => {
      mySetting.collabVadModel = e.target.value === 'pyannote' ? 'pyannote' : 'silero';
      saveSetting();
      resetVadWorker();
      if (isCollabVadNeededInThisWindow()) ensureVadWorker();
    });
    const collabManualToggle = document.getElementById('collab-manual-toggle');
    const collabManualDetail = document.getElementById('collab-manual-detail');
    collabManualToggle?.addEventListener('change', () => {
      mySetting.collabManualEnabled = collabManualToggle.checked;
      saveSetting();
      if (collabManualDetail) collabManualDetail.hidden = !collabManualToggle.checked;
      onCollabToggleChanged();
    });

    const vodSyncToggle = document.getElementById('vod-sync-toggle');
    if (vodSyncToggle) {
      vodSyncToggle.addEventListener('change', () => {
        mySetting.vodSyncEnabled = vodSyncToggle.checked;
        saveSetting();
        if (isCollabVadNeededInThisWindow()) ensureVadWorker();
        recomputeCollabMuting();
        renderCollabSettingsSection();
      });
    }

    const debugMemberSuggestBtn = document.getElementById('debug-member-suggest-btn');
    if (debugMemberSuggestBtn) {
      debugMemberSuggestBtn.addEventListener('click', () => {
        toggleSettingModal();
        openCollabMemberSuggestExample();
      });
    }

    const debugModeToggle = document.getElementById('debug-mode-toggle');
    const debugFeatureList = document.getElementById('debug-feature-list');
    if (debugModeToggle) {
      debugModeToggle.addEventListener('change', () => {
        mySetting.debugMode = debugModeToggle.checked;
        if (debugFeatureList) debugFeatureList.hidden = !debugModeToggle.checked;
        if (debugModeToggle.checked) {
          // 디버그 모드를 다시 켜면 ×로 닫은 창 상태를 리셋한다.
          debugPanelManuallyClosed = false;
        } else {
          // 상위 스위치를 끄면 하위 기능도 실제로 끈다(숨기기만 하면 부작용이 남음).
          mySetting.audioDebugEnabled = false;
          mySetting.vodDebugEnabled = false;
          const audioDebugToggleEl = document.getElementById('audio-debug-toggle');
          if (audioDebugToggleEl) audioDebugToggleEl.checked = false;
          const vodDebugToggleEl = document.getElementById('vod-debug-toggle');
          if (vodDebugToggleEl) vodDebugToggleEl.checked = false;
          mySetting.syncDebugEnabled = false;
          const syncDebugToggleEl = document.getElementById('sync-debug-toggle');
          if (syncDebugToggleEl) syncDebugToggleEl.checked = false;
          renderSyncDebugOverlays();
          [...debugForcedEndedHashes].forEach(hash => {
            debugForcedEndedHashes.delete(hash);
            hideVodPickerPanel(hash);
          });
        }
        saveSetting();
        updateDebugPanelVisibility();
        // needsGraph가 디버그 상태도 보므로 로드된 채널에 다시 보낸다.
        applyVolumeToAllChannels(true);
      });
    }

    const audioDebugToggle = document.getElementById('audio-debug-toggle');
    if (audioDebugToggle) {
      audioDebugToggle.addEventListener('change', () => {
        mySetting.audioDebugEnabled = audioDebugToggle.checked;
        saveSetting();
        applyVolumeToAllChannels(true); // needsGraph 갱신(위와 같은 이유)
        updateDebugPanelVisibility();
      });
    }

    const vodDebugToggle = document.getElementById('vod-debug-toggle');
    if (vodDebugToggle) {
      vodDebugToggle.addEventListener('change', () => {
        mySetting.vodDebugEnabled = vodDebugToggle.checked;
        saveSetting();
        // 이 마스터 토글 하나로 그리드 전체를 켜고 끈다.
        (displayChannels || []).forEach(ch => simulateBroadcastEnded(ch, vodDebugToggle.checked));
      });
    }

    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeSettingModal();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        const m = document.getElementById('setting-modal');
        if (m && m.classList.contains('active')) {
          closeSettingModal();
        }
      }
    });

  }

  await refreshSettingModal();
  modal.classList.add('active');

  const settingsBtn = document.getElementById('settings-btn');
  if (settingsBtn) settingsBtn.classList.add('active');
}

async function refreshSettingModal() {
  await syncAllLoginStatus();

  const platformList = document.getElementById('platform-list');
  platformList.innerHTML = '';
  // 준비 중 플랫폼은 연동 계정 목록에 노출하지 않는다.
  Object.keys(PLATFORM_META)
    .filter(key => PLATFORM_META[key].enabled)
    .forEach(key => renderPlatformRow(platformList, key));

  const uiLanguageSelect = document.getElementById('ui-language-select');
  if (uiLanguageSelect) {
    uiLanguageSelect.value = window.CHEESE_EYES_CURRENT_LANG
      || (typeof window.CHEESE_EYES_SUPPORTED_LANGS !== 'undefined' && window.CHEESE_EYES_SUPPORTED_LANGS[0])
      || 'ko';
  }

  const minViewerPlatformSelect = document.getElementById('min-viewer-platform-select');
  const minViewerInput = document.getElementById('min-viewer-input');
  if (minViewerPlatformSelect && minViewerInput) {
    if (!minViewerPlatformSelect.value && minViewerPlatformSelect.options.length > 0) {
      minViewerPlatformSelect.selectedIndex = 0;
    }
    minViewerInput.value = getMinViewers(minViewerPlatformSelect.value);
  }

  const populateVolumeInput = (id, getter) => {
    const el = document.getElementById(id);
    if (el) el.value = getter();
  };
  populateVolumeInput('grid-volume-input', getGridDefaultVolume);
  populateVolumeInput('sub-volume-input', getSubDefaultVolume);
  const maxChannelsInput = document.getElementById('max-channels-input');
  if (maxChannelsInput) maxChannelsInput.value = getMaxChannels();
  updateMaxChannelsWarning(getMaxChannels());
  renderShortcutKeyList();
  renderSearchPlatformOrderList();
  updateChatSplitSettingsUI();
  const liveSyncToggle = document.getElementById('live-sync-toggle');
  if (liveSyncToggle) liveSyncToggle.checked = isLiveSyncEnabled();
  const liveSyncTargetInput = document.getElementById('live-sync-target-input');
  if (liveSyncTargetInput) liveSyncTargetInput.value = getLiveSyncTargetSetting();

  const collabAutoToggle = document.getElementById('collab-auto-toggle');
  if (collabAutoToggle) collabAutoToggle.checked = isCollabAutoEnabled();
  const collabAutoDetail = document.getElementById('collab-auto-detail');
  if (collabAutoDetail) collabAutoDetail.hidden = !isCollabAutoEnabled();
  const collabVadModelSelect = document.getElementById('collab-vad-model-select');
  if (collabVadModelSelect) collabVadModelSelect.value = getCollabVadModelSetting();
  const collabManualToggle = document.getElementById('collab-manual-toggle');
  if (collabManualToggle) collabManualToggle.checked = isCollabManualEnabled();
  const collabManualDetail = document.getElementById('collab-manual-detail');
  if (collabManualDetail) collabManualDetail.hidden = !isCollabManualEnabled();
  updateVadStatusUI();
  const vodSyncToggle = document.getElementById('vod-sync-toggle');
  if (vodSyncToggle) vodSyncToggle.checked = !!mySetting.vodSyncEnabled;

  const debugModeToggle = document.getElementById('debug-mode-toggle');
  if (debugModeToggle) debugModeToggle.checked = !!mySetting.debugMode;
  const debugFeatureList = document.getElementById('debug-feature-list');
  if (debugFeatureList) debugFeatureList.hidden = !mySetting.debugMode;
  const audioDebugToggle = document.getElementById('audio-debug-toggle');
  if (audioDebugToggle) audioDebugToggle.checked = !!mySetting.audioDebugEnabled;
  const vodDebugToggle = document.getElementById('vod-debug-toggle');
  if (vodDebugToggle) vodDebugToggle.checked = !!mySetting.vodDebugEnabled;
  const syncDebugToggle = document.getElementById('sync-debug-toggle');
  if (syncDebugToggle) syncDebugToggle.checked = !!mySetting.syncDebugEnabled;

  renderRepresentativeWindowList();
}

loadSetting(() => {
  syncAllLoginStatus();
  applyChatSidePosition();
  refreshExtendedMainSubState();
  applyVolumeToAllChannels();
  updateDebugPanelVisibility();
  if (typeof mySetting.mainSessionVh === 'number' && !isNaN(mySetting.mainSessionVh)) {
    applyMainSessionSizeVar(mySetting.mainSessionVh);
    renderVideo();
  }
  // AI 음성 감지가 켜진 채 저장됐으면 로딩과 동시에 모델을 불러온다.
  if (isCollabVadNeededInThisWindow()) ensureVadWorker();
});

setInterval(syncAllLoginStatus, 30000);

const profileBtn = document.getElementById('settings-btn');
if (profileBtn) {
  profileBtn.addEventListener('click', openSettingModal);
}

document.addEventListener('cheeseeyes:i18n-ready', () => {
  const modal = document.getElementById('setting-modal');
  if (modal && modal.classList.contains('active')) refreshSettingModal();

  if (chatContainer && chatContainer.querySelector('.chat-placeholder')) {
    updateChatSession();
  }

  // 언어가 바뀌면 상태별 타이틀을 다시 맞춘다(정적 번역이 덮어썼을 수 있음).
  updateChatTabVideoToggleIcons();
  updateWindowRoleTitle();
});

(function setupFullscreenModeToolbar() {
  const appContainer = document.getElementById('app-container');
  const controlPanel = document.getElementById('control-panel');
  const modeButtons = document.getElementById('mode-buttons');
  const fsToolbar = document.getElementById('fs-mode-toolbar');
  if (!appContainer || !controlPanel || !modeButtons || !fsToolbar) return;

  // 정보 표시줄이 있으면 크기 비교로 F11을 못 잡아 display-mode를 먼저 본다.
  const fullscreenDisplayMode = window.matchMedia('(display-mode: fullscreen)');

  function isNativeFullscreen() {
    if (document.fullscreenElement) return true;
    if (fullscreenDisplayMode.matches) return true;
    const heightGap = Math.abs(window.screen.height - window.innerHeight);
    const widthGap = Math.abs(window.screen.width - window.innerWidth);
    return heightGap <= 2 && widthGap <= 2;
  }

  function syncFullscreenState() {
    const isFs = isNativeFullscreen();
    const alreadyFs = appContainer.classList.contains('fs-mode');
    if (isFs === alreadyFs) return;
    appContainer.classList.toggle('fs-mode', isFs);
    if (!isFs) {
      if (typeof closeFsQuickSearch === 'function') closeFsQuickSearch();
    }
    requestAnimationFrame(() => {
      if (typeof renderVideo === 'function') renderVideo();
    });
  }

  window.addEventListener('resize', syncFullscreenState);
  document.addEventListener('fullscreenchange', syncFullscreenState);
  fullscreenDisplayMode.addEventListener('change', syncFullscreenState);
  syncFullscreenState();
})();