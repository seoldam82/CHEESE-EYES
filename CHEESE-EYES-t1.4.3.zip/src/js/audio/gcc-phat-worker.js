// GCC-PHAT 계산 전용 워커(메인 스레드 보호, docs/collab-architecture.md §8.6).
importScripts('gcc-phat.js');

self.onmessage = (event) => {
  const { requestId, bufA, rateA, bufB, rateB, maxLagSec, centerLagSec } = event.data || {};
  let result = null;
  try {
    result = computeGccPhat(bufA, rateA, bufB, rateB, maxLagSec, undefined, centerLagSec);
  } catch (err) {
    result = null;
  }
  self.postMessage({ requestId, result });
};
