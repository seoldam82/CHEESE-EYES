// ITU-R BS.1770-4 K-weighting 계수를 임의 샘플레이트로 재도출한다(48kHz 표준 계수와 일치 확인).

// 스테이지 1 — 셸빙(약 1.7kHz 위 +4dB)
const STAGE1_F0 = 1681.9744509555319;
const STAGE1_G = 3.99984385397;
const STAGE1_Q = 0.7071752369554193;

// 스테이지 2 — RLB 하이패스
const STAGE2_F0 = 38.13547087602444;
const STAGE2_Q = 0.5003270373238773;

function computeStage1(sampleRate) {
  const K = Math.tan(Math.PI * STAGE1_F0 / sampleRate);
  const Vh = Math.pow(10, STAGE1_G / 20);
  const Vb = Math.pow(Vh, 0.499666774155);
  const a0 = 1.0 + K / STAGE1_Q + K * K;
  return {
    b0: (Vh + (Vb * K) / STAGE1_Q + K * K) / a0,
    b1: (2.0 * (K * K - Vh)) / a0,
    b2: (Vh - (Vb * K) / STAGE1_Q + K * K) / a0,
    a1: (2.0 * (K * K - 1.0)) / a0,
    a2: (1.0 - K / STAGE1_Q + K * K) / a0,
  };
}

function computeStage2(sampleRate) {
  const K = Math.tan(Math.PI * STAGE2_F0 / sampleRate);
  const a0 = 1.0 + K / STAGE2_Q + K * K;
  return {
    b0: 1.0,
    b1: -2.0,
    b2: 1.0,
    a1: (2.0 * (K * K - 1.0)) / a0,
    a2: (1.0 - K / STAGE2_Q + K * K) / a0,
  };
}

// { stage1, stage2 } — a0=1로 정규화된 Direct Form I 계수.
export function computeKWeightingCoefficients(sampleRate) {
  return {
    stage1: computeStage1(sampleRate),
    stage2: computeStage2(sampleRate),
  };
}

// ── 음성대역 필터 ── RBJ Cookbook 2차 하이패스/로우패스(Q=1/√2), 300~3400Hz.
const VOICE_BAND_HIGHPASS_HZ = 300;
const VOICE_BAND_LOWPASS_HZ = 3400;
const VOICE_BAND_Q = Math.SQRT1_2; // 1/√2, Butterworth

function computeRbjBiquad(type, f0, Q, sampleRate) {
  const w0 = 2 * Math.PI * f0 / sampleRate;
  const cosw0 = Math.cos(w0);
  const sinw0 = Math.sin(w0);
  const alpha = sinw0 / (2 * Q);
  let b0, b1, b2;
  if (type === 'highpass') {
    b0 = (1 + cosw0) / 2;
    b1 = -(1 + cosw0);
    b2 = (1 + cosw0) / 2;
  } else {
    b0 = (1 - cosw0) / 2;
    b1 = 1 - cosw0;
    b2 = (1 - cosw0) / 2;
  }
  const a0 = 1 + alpha;
  const a1 = -2 * cosw0;
  const a2 = 1 - alpha;
  return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
}

// 하이패스 → 로우패스 캐스케이드 = 300~3400Hz 밴드패스.
export function computeVoiceBandCoefficients(sampleRate) {
  return {
    highpass: computeRbjBiquad('highpass', VOICE_BAND_HIGHPASS_HZ, VOICE_BAND_Q, sampleRate),
    lowpass: computeRbjBiquad('lowpass', VOICE_BAND_LOWPASS_HZ, VOICE_BAND_Q, sampleRate),
  };
}
