// Silero VAD 워커(onnxruntime-web). 모델/런타임 URL은 부모가 'init'으로 넘긴다(워커엔 chrome.runtime 없음).

let session = null;
let initPromise = null;

// 8kHz 모델 기준(캡처 레이트가 항상 8kHz 근방).
const SR = 8000;
const FRAME_SAMPLES = 256;
const CONTEXT_SAMPLES = 32;
const STATE_SHAPE = [2, 1, 128];

// gcc-phat.js resampleLinear 복제 — 반드시 8000Hz로 맞춘 뒤 추론한다.
function resampleLinear(buf, fromRate, toRate) {
  if (fromRate === toRate) return buf;
  const ratio = toRate / fromRate;
  const outLen = Math.max(1, Math.round(buf.length * ratio));
  const out = new Float32Array(outLen);
  const lastIdx = buf.length - 1;
  for (let i = 0; i < outLen; i++) {
    const srcPos = i / ratio;
    const i0 = Math.min(lastIdx, Math.floor(srcPos));
    const i1 = Math.min(lastIdx, i0 + 1);
    const frac = srcPos - i0;
    out[i] = buf[i0] * (1 - frac) + buf[i1] * frac;
  }
  return out;
}

async function ensureSession(modelUrl, wasmBaseUrl) {
  if (session) return session;
  if (initPromise) return initPromise;
  initPromise = (async () => {
    importScripts('ort.wasm.min.js');
    // COOP/COEP가 없어 단일 스레드로 고정.
    ort.env.wasm.numThreads = 1;
    ort.env.wasm.wasmPaths = wasmBaseUrl;
    ort.env.wasm.proxy = false; // 이미 워커 안이라 추가 프록시 워커가 필요 없다.
    session = await ort.InferenceSession.create(modelUrl, {
      executionProviders: ['wasm'],
      graphOptimizationLevel: 'all',
    });
    return session;
  })().catch((err) => {
    initPromise = null;
    throw err;
  });
  return initPromise;
}

// 8kHz 리샘플 후 256샘플 프레임별 발화 확률. 컨텍스트와 LSTM state는 스니펫 안에서만 잇는다.
async function runVad(samples, sampleRate) {
  const resampled = resampleLinear(samples, sampleRate, SR);
  const frameCount = Math.max(1, Math.ceil(resampled.length / FRAME_SAMPLES));

  let state = new Float32Array(STATE_SHAPE[0] * STATE_SHAPE[1] * STATE_SHAPE[2]);
  let context = new Float32Array(CONTEXT_SAMPLES);
  const srTensor = new ort.Tensor('int64', BigInt64Array.from([BigInt(SR)]), []);

  const probs = new Float32Array(frameCount);
  for (let f = 0; f < frameCount; f++) {
    const frame = new Float32Array(FRAME_SAMPLES);
    const start = f * FRAME_SAMPLES;
    const avail = Math.min(FRAME_SAMPLES, resampled.length - start);
    if (avail > 0) frame.set(resampled.subarray(start, start + avail));

    const modelInput = new Float32Array(CONTEXT_SAMPLES + FRAME_SAMPLES);
    modelInput.set(context, 0);
    modelInput.set(frame, CONTEXT_SAMPLES);

    const inputTensor = new ort.Tensor('float32', modelInput, [1, CONTEXT_SAMPLES + FRAME_SAMPLES]);
    const stateTensor = new ort.Tensor('float32', state, STATE_SHAPE);

    // eslint-disable-next-line no-await-in-loop
    const result = await session.run({ input: inputTensor, state: stateTensor, sr: srTensor });
    probs[f] = result.output.data[0];
    state = result.stateN.data;
    context = frame.subarray(FRAME_SAMPLES - CONTEXT_SAMPLES);
  }

  return { probs, frameSamplesAtOutputRate: FRAME_SAMPLES, outputSampleRate: SR };
}

self.onmessage = async (event) => {
  const msg = event.data || {};
  if (msg.cmd === 'init') {
    try {
      await ensureSession(msg.modelUrl, msg.wasmBaseUrl);
      self.postMessage({ type: 'init-result', ok: true });
    } catch (err) {
      self.postMessage({ type: 'init-result', ok: false, error: String(err && err.message || err) });
    }
    return;
  }
  if (msg.cmd === 'infer') {
    const { requestId, samples, sampleRate } = msg;
    try {
      await ensureSession(msg.modelUrl, msg.wasmBaseUrl);
      const { probs, frameSamplesAtOutputRate, outputSampleRate } = await runVad(samples, sampleRate);
      self.postMessage({
        type: 'infer-result',
        requestId,
        probs,
        frameSamplesAtOutputRate,
        outputSampleRate,
      });
    } catch (err) {
      self.postMessage({ type: 'infer-result', requestId, error: String(err && err.message || err) });
    }
  }
};
