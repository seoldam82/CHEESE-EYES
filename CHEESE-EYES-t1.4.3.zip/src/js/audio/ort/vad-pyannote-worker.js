// 정밀 AI 음성 감지 워커 — pyannote segmentation-3.0(onnxruntime-web WASM). 실패하면 dashboard.js가 기본 워커로 바꾼다.
// WebGPU는 내장 GPU에서 CPU보다 10배 느려 CPU로 돌린다. "말소리 없음" 확률의 여집합을 발화 확률로 쓰고,
// 8kHz 캡처를 16kHz 입력으로 늘려 넣는다. 결과 형식은 vad-worker.js와 같다.

let session = null;
let initPromise = null;
// 세션 하나에 run을 겹치지 않게 차례로 돌린다.
let runChain = Promise.resolve();

const SR = 16000;
const NON_SPEECH_CLASS = 0;
const CLASS_COUNT = 7;

// vad-worker.js resampleLinear 복제.
function resampleLinear(buf, fromRate, toRate) {
  if (fromRate === toRate) return buf;
  const ratio = toRate / fromRate;
  const outLen = Math.max(1, Math.round(buf.length * ratio));
  const out = new Float32Array(outLen);
  const lastIdx = buf.length - 1;
  for (let i = 0; i < outLen; i++) {
    const srcPos = i / ratio;
    const i0 = Math.min(lastIdx, Math.floor(srcPos));
    const i1 = Math.min(lastIdx, i0 + 1);
    const frac = srcPos - i0;
    out[i] = buf[i0] * (1 - frac) + buf[i1] * frac;
  }
  return out;
}

async function ensureSession(modelUrl, wasmBaseUrl) {
  if (session) return session;
  if (initPromise) return initPromise;
  initPromise = (async () => {
    importScripts('ort.wasm.min.js');
    ort.env.wasm.numThreads = 1; // vad-worker.js와 같은 이유(COOP/COEP 없음)
    ort.env.wasm.wasmPaths = wasmBaseUrl;
    ort.env.wasm.proxy = false;
    session = await ort.InferenceSession.create(modelUrl, {
      executionProviders: ['wasm'],
      graphOptimizationLevel: 'all',
    });
    return session;
  })().catch((err) => {
    initPromise = null;
    throw err;
  });
  return initPromise;
}

async function runVad(samples, sampleRate) {
  const resampled = resampleLinear(samples, sampleRate, SR);
  const input = new ort.Tensor('float32', resampled, [1, 1, resampled.length]);
  const result = await session.run({ input_values: input });
  const logits = result.logits;
  const frameCount = logits.dims[1];
  const data = logits.data;
  const probs = new Float32Array(frameCount);
  for (let f = 0; f < frameCount; f++) {
    probs[f] = 1 - Math.exp(data[f * CLASS_COUNT + NON_SPEECH_CLASS]);
  }
  return { probs, frameSamplesAtOutputRate: resampled.length / Math.max(1, frameCount), outputSampleRate: SR };
}

self.onmessage = async (event) => {
  const msg = event.data || {};
  if (msg.cmd === 'init') {
    try {
      await ensureSession(msg.modelUrl, msg.wasmBaseUrl);
      self.postMessage({ type: 'init-result', ok: true });
    } catch (err) {
      self.postMessage({ type: 'init-result', ok: false, error: String(err && err.message || err) });
    }
    return;
  }
  if (msg.cmd === 'infer') {
    const { requestId, samples, sampleRate } = msg;
    try {
      await ensureSession(msg.modelUrl, msg.wasmBaseUrl);
      const job = runChain.then(() => runVad(samples, sampleRate));
      runChain = job.catch(() => {});
      const { probs, frameSamplesAtOutputRate, outputSampleRate } = await job;
      self.postMessage({ type: 'infer-result', requestId, probs, frameSamplesAtOutputRate, outputSampleRate }, [probs.buffer]);
    } catch (err) {
      self.postMessage({ type: 'infer-result', requestId, error: String(err && err.message || err) });
    }
  }
};
