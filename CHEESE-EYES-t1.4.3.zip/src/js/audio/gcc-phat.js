// 두 스니펫이 같은 신호의 지연된 복사본(마이크 크로스토크)인지 판정한다(docs/collab-architecture.md §8).
// 이름과 달리 기본은 PHAT이 아닌 진폭 유지 정규화 교차상관(exponent=0) — PHAT은 조용한 잡음도 같게 취급했다.
// 작은 radix-2 FFT를 직접 구현하고 전역 함수(computeGccPhat)로 노출한다.

(function () {
  function nextPow2(n) {
    let p = 1;
    while (p < n) p *= 2;
    return p;
  }

  // in-place radix-2 FFT(re/im 길이 2의 거듭제곱). inverse면 N으로 나눈다.
  function fft(re, im, inverse) {
    const n = re.length;
    for (let i = 1, j = 0; i < n; i++) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) {
        let tmp = re[i]; re[i] = re[j]; re[j] = tmp;
        tmp = im[i]; im[i] = im[j]; im[j] = tmp;
      }
    }
    for (let len = 2; len <= n; len <<= 1) {
      const ang = (inverse ? 2 : -2) * Math.PI / len;
      const wlenRe = Math.cos(ang), wlenIm = Math.sin(ang);
      for (let i = 0; i < n; i += len) {
        let curRe = 1, curIm = 0;
        const half = len / 2;
        for (let k = 0; k < half; k++) {
          const uRe = re[i + k], uIm = im[i + k];
          const t2Re = re[i + k + half], t2Im = im[i + k + half];
          const vRe = t2Re * curRe - t2Im * curIm;
          const vIm = t2Re * curIm + t2Im * curRe;
          re[i + k] = uRe + vRe;
          im[i + k] = uIm + vIm;
          re[i + k + half] = uRe - vRe;
          im[i + k + half] = uIm - vIm;
          const nextRe = curRe * wlenRe - curIm * wlenIm;
          const nextIm = curRe * wlenIm + curIm * wlenRe;
          curRe = nextRe; curIm = nextIm;
        }
      }
    }
    if (inverse) {
      for (let i = 0; i < n; i++) { re[i] /= n; im[i] /= n; }
    }
  }

  function removeMean(buf) {
    let sum = 0;
    for (let i = 0; i < buf.length; i++) sum += buf[i];
    const mean = sum / buf.length;
    const out = new Float64Array(buf.length);
    for (let i = 0; i < buf.length; i++) out[i] = buf[i] - mean;
    return out;
  }

  // 선형보간 리샘플 — iframe마다 캡처 레이트가 달라 낮은 쪽으로 맞춘다.
  function resampleLinear(buf, fromRate, toRate) {
    if (fromRate === toRate) return buf;
    const ratio = toRate / fromRate;
    const outLen = Math.max(1, Math.round(buf.length * ratio));
    const out = new Float64Array(outLen);
    const lastIdx = buf.length - 1;
    for (let i = 0; i < outLen; i++) {
      const srcPos = i / ratio;
      const i0 = Math.min(lastIdx, Math.floor(srcPos));
      const i1 = Math.min(lastIdx, i0 + 1);
      const frac = srcPos - i0;
      out[i] = buf[i0] * (1 - frac) + buf[i1] * frac;
    }
    return out;
  }

  // centerLagSamples 중심 ±maxLagSamples에서 정규화 교차상관 최댓값과 지연을 찾는다.
  // whiteningExponent: 0(기본) ~ 1(완전 PHAT).
  function generalizedCrossCorrelate(bufA, bufB, maxLagSamples, whiteningExponent, centerLagSamples) {
    const n = bufA.length + bufB.length - 1;
    const N = nextPow2(n);

    const reA = new Float64Array(N), imA = new Float64Array(N);
    const reB = new Float64Array(N), imB = new Float64Array(N);
    reA.set(bufA);
    reB.set(bufB);

    fft(reA, imA, false);
    fft(reB, imB, false);

    const reG = new Float64Array(N), imG = new Float64Array(N);
    const EPS = 1e-12;
    const exponent = whiteningExponent || 0;
    for (let i = 0; i < N; i++) {
      const gr = reA[i] * reB[i] + imA[i] * imB[i];
      const gi = imA[i] * reB[i] - reA[i] * imB[i];
      if (exponent > 0) {
        const mag = Math.sqrt(gr * gr + gi * gi) + EPS;
        const w = exponent >= 1 ? mag : Math.pow(mag, exponent);
        reG[i] = gr / w;
        imG[i] = gi / w;
      } else {
        reG[i] = gr;
        imG[i] = gi;
      }
    }

    fft(reG, imG, true);

    // 순환 상관 인덱스 해석: 0=lag 0, 1..N/2-1 양수, 나머지 음수. 에너지로 나눠 -1~1로 정규화.
    let energyA = 0, energyB = 0;
    for (let i = 0; i < bufA.length; i++) energyA += bufA[i] * bufA[i];
    for (let i = 0; i < bufB.length; i++) energyB += bufB[i] * bufB[i];
    const norm = Math.sqrt(energyA * energyB) + EPS;

    const half = Math.floor(N / 2) - 1;
    const margin = Math.max(0, Math.min(maxLagSamples, half));
    const center = Math.max(-half, Math.min(half, Math.round(centerLagSamples || 0)));
    const lo = Math.max(-half, center - margin);
    const hi = Math.min(half, center + margin);
    let bestVal = -Infinity, bestLag = 0;
    for (let lag = lo; lag <= hi; lag++) {
      const idx = lag >= 0 ? lag : N + lag;
      const val = reG[idx] / norm;
      if (val > bestVal) { bestVal = val; bestLag = lag; }
    }
    return { peak: bestVal, lagSamples: bestLag };
  }

  // 반환 { score, lagSec } | null. lagSec는 "A[m] ≈ B[m-lag]" 정의라 Stage1과 부호가 반대 — centerLagSec엔 LA - LB를 넘긴다.
  function computeGccPhat(bufA, rateA, bufB, rateB, maxLagSec, whiteningExponent, centerLagSec) {
    if (!bufA || !bufB || bufA.length < 8 || bufB.length < 8) return null;
    const targetRate = Math.min(rateA, rateB);
    const a = removeMean(rateA === targetRate ? bufA : resampleLinear(bufA, rateA, targetRate));
    const b = removeMean(rateB === targetRate ? bufB : resampleLinear(bufB, rateB, targetRate));
    const maxLagSamples = Math.max(1, Math.round(maxLagSec * targetRate));
    const limit = Math.min(maxLagSamples, a.length - 1, b.length - 1);
    const centerLagSamples = Math.round((centerLagSec || 0) * targetRate);
    const { peak, lagSamples } = generalizedCrossCorrelate(a, b, limit, whiteningExponent, centerLagSamples);
    return { score: peak, lagSec: lagSamples / targetRate };
  }

  // gcc-phat-worker.js에서도 importScripts로 쓴다.
  (typeof window !== 'undefined' ? window : self).computeGccPhat = computeGccPhat;
})();
