// K-weighted momentary LUFS를 오디오 스레드에서 계산해 보고하는 측정 전용 워클릿(출력은 항상 무음).
// content.js가 무음 gain을 거쳐 destination에 연결해야 process()가 불린다(docs/audio-architecture.md §5.3).

import { computeKWeightingCoefficients, computeVoiceBandCoefficients } from './lufs-coefficients.js';

const MOMENTARY_WINDOW_SEC = 0.4;
// 보고 주기 — content.js 피크 추적 폴링(50ms)과 맞춘다.
const REPORT_INTERVAL_SEC = 0.05;

// ── 합방용 파형 캡처(기본 꺼짐) ── LUFS 측정 지점에서 다운샘플해 링 버퍼에 담고 요청 시 스냅샷을 준다.
const CAPTURE_TARGET_SAMPLE_RATE = 8000;
const CAPTURE_WINDOW_SEC = 3;

class BiquadState {
  constructor() {
    this.x1 = 0; this.x2 = 0; this.y1 = 0; this.y2 = 0;
  }
}

function processBiquad(coeffs, state, x) {
  const y = coeffs.b0 * x + coeffs.b1 * state.x1 + coeffs.b2 * state.x2
    - coeffs.a1 * state.y1 - coeffs.a2 * state.y2;
  state.x2 = state.x1;
  state.x1 = x;
  state.y2 = state.y1;
  state.y1 = y;
  return y;
}

class LufsMeterProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    // 실제 컨텍스트 샘플레이트에 맞춰 계수를 계산한다.
    this.coeffs = computeKWeightingCoefficients(sampleRate);
    this.stage1States = [];
    this.stage2States = [];

    // ── 음성대역(300~3400Hz) 필터 ── 모노 믹스다운 하나에만 적용.
    this.voiceCoeffs = computeVoiceBandCoefficients(sampleRate);
    this.voiceHighpassState = new BiquadState();
    this.voiceLowpassState = new BiquadState();

    this.windowSamples = Math.max(1, Math.round(MOMENTARY_WINDOW_SEC * sampleRate));
    // 최근 400ms 제곱합을 O(1)로 유지하는 링 버퍼(채널 합산해도 mean-square는 동일).
    this.ringBuffer = new Float32Array(this.windowSamples);
    this.ringIndex = 0;
    this.runningSum = 0;

    // 음성대역 이동합 — 같은 400ms 창.
    this.voiceRingBuffer = new Float32Array(this.windowSamples);
    this.voiceRingIndex = 0;
    this.voiceRunningSum = 0;

    this.reportIntervalFrames = Math.max(1, Math.round(REPORT_INTERVAL_SEC * sampleRate));
    this.framesSinceReport = 0;

    // 다운샘플 비율은 정수 — 실제 캡처 레이트를 함께 보고해 gcc-phat에서 리샘플한다.
    this.captureRatio = Math.max(1, Math.round(sampleRate / CAPTURE_TARGET_SAMPLE_RATE));
    this.captureSampleRate = sampleRate / this.captureRatio;
    this.captureWindowSec = CAPTURE_WINDOW_SEC;
    this.captureBufferLength = Math.max(1, Math.round(this.captureWindowSec * this.captureSampleRate));
    this.captureBuffer = new Float32Array(this.captureBufferLength);
    this.captureIndex = 0;
    this.captureFilled = 0;
    this.captureEnabled = false;
    this.decimateAccum = 0;
    this.decimateCount = 0;

    this.port.onmessage = (event) => this.handleControlMessage(event.data);
  }

  handleControlMessage(msg) {
    if (!msg || typeof msg !== 'object') return;
    if (msg.cmd === 'setCapture') {
      this.captureEnabled = !!msg.enabled;
      // windowSec — VOD 싱크용 넓은 캡처 창. 길이가 바뀔 때만 버퍼를 다시 만든다(매번 만들면 캡처가 리셋됨).
      const windowSec = (typeof msg.windowSec === 'number' && msg.windowSec > 0) ? msg.windowSec : CAPTURE_WINDOW_SEC;
      const windowChanged = windowSec !== this.captureWindowSec;
      if (windowChanged) {
        this.captureWindowSec = windowSec;
        this.captureBufferLength = Math.max(1, Math.round(this.captureWindowSec * this.captureSampleRate));
        this.captureBuffer = new Float32Array(this.captureBufferLength);
        this.captureIndex = 0;
        this.captureFilled = 0;
        this.decimateAccum = 0;
        this.decimateCount = 0;
      }
      // forceReset — 시크 직후 버퍼를 비워 시크 전/후 오디오가 섞이지 않게 한다.
      if (!this.captureEnabled || windowChanged || msg.forceReset) {
        // 꺼질 때·창 변경·강제 리셋 시 버퍼를 비운다.
        this.captureBuffer.fill(0);
        this.captureIndex = 0;
        this.captureFilled = 0;
        this.decimateAccum = 0;
        this.decimateCount = 0;
      }
    } else if (msg.cmd === 'getSnippet') {
      // recentSec — 최근 N초만 잘라 보내 IPC 비용을 줄인다. filled는 항상 전체 창 기준.
      const recentSamples = (typeof msg.recentSec === 'number' && msg.recentSec > 0)
        ? Math.max(1, Math.round(msg.recentSec * this.captureSampleRate))
        : undefined;
      this.port.postMessage({
        type: 'snippet',
        requestId: msg.requestId,
        samples: this.readCaptureSnapshot(recentSamples),
        sampleRate: this.captureSampleRate,
        filled: this.captureFilled >= this.captureBufferLength,
        capturedAtMs: Date.now()
      });
    }
  }

  // 링 버퍼를 오래된→최신 순 배열로 만든다. maxSamples면 최근 그만큼만.
  readCaptureSnapshot(maxSamples) {
    const fullLen = this.captureBufferLength;
    const len = (typeof maxSamples === 'number' && maxSamples > 0 && maxSamples < fullLen)
      ? maxSamples
      : fullLen;
    const skip = fullLen - len;
    const out = new Float32Array(len);
    for (let i = 0; i < len; i++) {
      out[i] = this.captureBuffer[(this.captureIndex + skip + i) % fullLen];
    }
    return out;
  }

  ensureChannelStates(channelCount) {
    while (this.stage1States.length < channelCount) {
      this.stage1States.push(new BiquadState());
      this.stage2States.push(new BiquadState());
    }
  }

  process(inputs) {
    const input = inputs[0];
    if (!input || input.length === 0 || !input[0] || input[0].length === 0) {
      return true;
    }

    const channelCount = input.length;
    this.ensureChannelStates(channelCount);
    const frameCount = input[0].length;

    for (let i = 0; i < frameCount; i++) {
      let combinedSquared = 0;
      let monoSum = 0;
      for (let c = 0; c < channelCount; c++) {
        const x = input[c][i];
        monoSum += x;
        const afterStage1 = processBiquad(this.coeffs.stage1, this.stage1States[c], x);
        const kWeighted = processBiquad(this.coeffs.stage2, this.stage2States[c], afterStage1);
        combinedSquared += kWeighted * kWeighted;
      }
      const monoAvg = monoSum / channelCount;

      // 합방 판정용 음성대역 모노 신호(LUFS는 원음 그대로).
      const afterVoiceHp = processBiquad(this.voiceCoeffs.highpass, this.voiceHighpassState, monoAvg);
      const voiceSample = processBiquad(this.voiceCoeffs.lowpass, this.voiceLowpassState, afterVoiceHp);

      this.runningSum += combinedSquared - this.ringBuffer[this.ringIndex];
      this.ringBuffer[this.ringIndex] = combinedSquared;
      // % 대신 분기로 감싼다(렌더 스레드 루프라 더 싸다).
      this.ringIndex++;
      if (this.ringIndex >= this.windowSamples) this.ringIndex = 0;

      const voiceSquared = voiceSample * voiceSample;
      this.voiceRunningSum += voiceSquared - this.voiceRingBuffer[this.voiceRingIndex];
      this.voiceRingBuffer[this.voiceRingIndex] = voiceSquared;
      this.voiceRingIndex++;
      if (this.voiceRingIndex >= this.windowSamples) this.voiceRingIndex = 0;

      this.framesSinceReport++;
      if (this.framesSinceReport >= this.reportIntervalFrames) {
        this.framesSinceReport = 0;
        const meanSquare = this.runningSum / this.windowSamples;
        const lufs = meanSquare > 0 ? -0.691 + 10 * Math.log10(meanSquare) : -100;
        // voiceDb는 캘리브레이션 없는 평균제곱 dB(상대 비교용).
        const voiceMeanSquare = this.voiceRunningSum / this.windowSamples;
        const voiceDb = voiceMeanSquare > 0 ? 10 * Math.log10(voiceMeanSquare) : -100;
        this.port.postMessage({ lufs, voiceDb });
      }

      if (this.captureEnabled) {
        // 음성대역 신호를 담는다 — 원본 믹스다운은 배경음 저음이 상관을 오염시켰다.
        this.decimateAccum += voiceSample;
        this.decimateCount++;
        if (this.decimateCount >= this.captureRatio) {
          this.captureBuffer[this.captureIndex] = this.decimateAccum / this.decimateCount;
          this.captureIndex++;
          if (this.captureIndex >= this.captureBufferLength) this.captureIndex = 0;
          if (this.captureFilled < this.captureBufferLength) this.captureFilled++;
          this.decimateAccum = 0;
          this.decimateCount = 0;
        }
      }
    }

    return true;
  }
}

registerProcessor('lufs-meter-processor', LufsMeterProcessor);
