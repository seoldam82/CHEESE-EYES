if (window.self === window.top) {
  const topStyle = document.createElement('style');
  topStyle.textContent = `
    .ext-theatre-iframe-active {
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100vw !important;
      height: 100vh !important;
      z-index: 2147483647 !important;
      border: none !important;
    }
    body.ext-theatre-body-active {
      overflow: hidden !important;
    }
  `;
  (document.head || document.documentElement).appendChild(topStyle);

  window.addEventListener('message', (event) => {
    if (!event.data) return;

    if (event.data.type === 'TOGGLE_PARENT_THEATRE') {
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach((iframe) => {
        if (iframe.contentWindow === event.source) {
          const isFull = iframe.classList.toggle('ext-theatre-iframe-active');
          document.body.classList.toggle('ext-theatre-body-active', isFull);
        }
      });
    }
  });

} else {
  const host = window.location.hostname;
  const isSoopHost = host.includes('play.sooplive.com') || host.includes('vod.sooplive.com') || host.includes('sooplive.co.kr') || host.includes('afreecatv.com');
  const isChzzkHost = host.includes('chzzk.naver.com');
  const isYoutubeHost = host.endsWith('youtube.com');
  const isYoutubeChatFrame = isYoutubeHost && window.location.pathname.startsWith('/live_chat');
  const isYoutubeVideoFrame = isYoutubeHost && window.location.pathname.startsWith('/embed/');

  const isChatFrame = isYoutubeHost
    ? isYoutubeChatFrame
    : isSoopHost
      ? new URLSearchParams(window.location.search).get('vtype') === 'chat'
      : window.location.href.includes('/chat');
  // 채팅 다시보기가 재생 위치를 쓰므로 위치 보고 대상에 넣는다.
  const isChzzkVodFrame = isChzzkHost && !isChatFrame && window.location.pathname.startsWith('/video/');
  // 숲 VOD도 위치 보고 대상(VOD 싱크 드리프트 보정용).
  const isSoopVodFrame = host.includes('vod.sooplive.com');

  // 채팅 다시보기 전용 보조 임베드 마커 — 메인 타일 전용 로직을 끄고 영상은 강제 음소거한다.
  const isCheeseChatEmbed = isChzzkHost && new URLSearchParams(window.location.search).get('cheeseChatEmbed') === '1';
  // 라이브도 위치 보고 대상(대시보드의 정지 감지·재로드용).
  const isChzzkLiveFrame = isChzzkHost && !isChatFrame && !isCheeseChatEmbed && window.location.pathname.startsWith('/live/');
  const isSoopLiveFrame = host.includes('play.sooplive.com');

  if (isCheeseChatEmbed) {
    // #vod-aside를 <body> 바로 아래로 옮긴다 — 조상에 transform 등이 있으면 fixed가 뷰포트 기준이 아니게 된다.
    // 준비 신호는 role="log" 안에 실제 메시지(닉네임 버튼)가 나타날 때만 보낸다(틀만 뜬 상태로 보고하면 재시도가 취소됨).
    let readyReported = false;
    const promoteVodAside = () => {
      const aside = document.getElementById('vod-aside');
      if (aside && aside.parentElement !== document.body) {
        document.body.appendChild(aside);
      }
      if (aside && !readyReported) {
        const log = aside.querySelector('[role="log"]');
        const hasChatContent = log && (log.querySelector('button[aria-haspopup]') || log.children.length > 1);
        if (hasChatContent) {
          readyReported = true;
          window.parent.postMessage({ type: 'CHZZK_CHAT_EMBED_READY' }, '*');
        }
      }
    };

    // 메인 타일의 위치/정지 상태를 대시보드가 릴레이한다. 받기 전엔 재생만 유지.
    let syncedPaused = false;
    let syncedCurrentTime = null;
    window.addEventListener('message', (event) => {
      if (!event.data || event.data.type !== 'CHZZK_VOD_CHAT_SYNC') return;
      syncedPaused = !!event.data.paused;
      syncedCurrentTime = (typeof event.data.currentTime === 'number' && isFinite(event.data.currentTime))
        ? event.data.currentTime : null;
    });

    const forceMutedAndPlaying = () => {
      promoteVodAside();
      document.querySelectorAll('video').forEach((video) => {
        video.muted = true;
        video.volume = 0;
        // 2초 넘게 어긋날 때만 맞춘다.
        if (syncedCurrentTime !== null && Math.abs(video.currentTime - syncedCurrentTime) > 2) {
          video.currentTime = syncedCurrentTime;
        }
        if (syncedPaused) {
          if (!video.paused) video.pause();
        } else if (video.paused && video.readyState >= 2) {
          // 메인이 재생 중이면 음소거된 채로 재생 상태를 유지한다(자동재생 차단 대비 재시도).
          video.play().catch(() => {});
        }
      });
    };
    forceMutedAndPlaying();
    setInterval(forceMutedAndPlaying, 1000);
  }

  // VOD 엔딩화면 클릭으로 URL(/video/{ID})이 바뀌면 대시보드에 알려 슬롯을 교체한다(채팅 전용 임베드 제외).
  if (isChzzkHost && !isChatFrame && !isCheeseChatEmbed) {
    const VOD_PATH_RE = /^\/video\/(\d+)/;
    let lastVodId = (VOD_PATH_RE.exec(window.location.pathname) || [])[1] || null;
    setInterval(() => {
      const m = VOD_PATH_RE.exec(window.location.pathname);
      const currentId = m ? m[1] : null;
      if (currentId && currentId !== lastVodId) {
        lastVodId = currentId;
        window.parent.postMessage({ type: 'CHANNEL_VIDEO_CHANGED', videoId: currentId }, '*');
      }
    }, 1000);
  }

  // 치지직 방종 추천 화면("다음 라이브를 기대해주세요")을 DOM에서 감지해 바로 알린다 — API는 종료 반영이 몇 분 늦다.
  // 클래스 접두어(_recommended_/_wrapper_) + 문구 이중 확인. 못 찾으면 API 폴링이 폴백.
  if (isChzzkHost && !isChatFrame && !isCheeseChatEmbed && window.location.pathname.startsWith('/live/')) {
    let endScreenNotified = false;
    const ENDED_SCREEN_TEXT = '다음 라이브를 기대해주세요';
    const endScreenCheckId = setInterval(() => {
      if (endScreenNotified) { clearInterval(endScreenCheckId); return; }
      const el = document.querySelector('[class*="_recommended_"][class*="_wrapper_"]');
      if (el && el.textContent && el.textContent.includes(ENDED_SCREEN_TEXT)) {
        endScreenNotified = true;
        clearInterval(endScreenCheckId);
        window.parent.postMessage({ type: 'CHZZK_LIVE_ENDED_SCREEN_DETECTED' }, '*');
      }
    }, 1500);
  }

  // 플레이어 위 상품 알림 카드를 숨긴다 — 문구에서 위로 올라가며 영상을 품지 않고 타일 높이 절반 이하인 가장 바깥 박스(폭은 기준 아님).
  if (isChzzkHost && !isChatFrame && !isCheeseChatEmbed) {
    const PRODUCT_PROMO_TEXT_RE = /상품\s*확인하기/;
    const hideProductPromoCard = (textEl) => {
      let card = null;
      for (let node = textEl, depth = 0; node && node !== document.body && depth < 8; node = node.parentElement, depth++) {
        if (node.querySelector('video')) break;
        if (node.getBoundingClientRect().height > window.innerHeight * 0.5) break;
        card = node;
      }
      if (card && card.style.display !== 'none') card.style.setProperty('display', 'none', 'important');
    };
    const scanForProductPromo = (root) => {
      if (!root || !PRODUCT_PROMO_TEXT_RE.test(root.textContent || '')) return;
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      while (walker.nextNode()) {
        const textNode = walker.currentNode;
        if (textNode.parentElement && PRODUCT_PROMO_TEXT_RE.test(textNode.textContent || '')) {
          hideProductPromoCard(textNode.parentElement);
        }
      }
    };
    const startProductPromoObserver = () => {
      if (!document.body) return;
      scanForProductPromo(document.body);
      new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((added) => {
            if (added.nodeType === Node.ELEMENT_NODE) scanForProductPromo(added);
            else if (added.nodeType === Node.TEXT_NODE) scanForProductPromo(added.parentElement);
          });
        });
      }).observe(document.body, { childList: true, subtree: true });
    };
    if (document.body) startProductPromoObserver();
    else document.addEventListener('DOMContentLoaded', startProductPromoObserver, { once: true });
  }

  // 유튜브 추천 클릭 가로채기는 youtube_endscreen_guard.js가 document_start에서 먼저 선점한다.

  let extensionOrigin = null;
  try { extensionOrigin = chrome.runtime.getURL('').replace(/\/$/, ''); } catch (e) {}

  window.addEventListener('message', (event) => {
    if (!event.data || event.data.type !== 'CHEESE_API_PROXY') return;
    // 같은 URL을 다른 사이트가 iframe으로 심을 수 있으니 우리 확장 페이지에서 온 메시지인지 확인한다.
    if (!extensionOrigin || event.origin !== extensionOrigin) return;
    const { requestId, url, init } = event.data;
    (async () => {
      try {
        const res = await fetch(url, { ...(init || {}), credentials: 'include' });
        const body = await res.text();
        event.source && event.source.postMessage({
          type: 'CHEESE_API_PROXY_RESULT', requestId, ok: res.ok, status: res.status, body
        }, extensionOrigin);
      } catch (err) {
        event.source && event.source.postMessage({
          type: 'CHEESE_API_PROXY_RESULT', requestId, ok: false, status: 0, body: '', error: String((err && err.message) || err)
        }, extensionOrigin);
      }
    })();
  });

  if (isChatFrame) {
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' || e.key === 'Esc') {
        e.stopImmediatePropagation();
        e.stopPropagation();
        e.preventDefault();
      }
    }, true);
  }

  // 치지직 통나무 파워 자동 받기 — iframe 안에선 다른 확장이 안 돌아 "받기" 버튼을 1초마다 찾아 누른다.
  if (isChzzkHost && window.location.pathname.startsWith('/live/')) {
    const isPowerButton = (b) => {
      const cls = typeof b.className === 'string' ? b.className : '';
      if (cls.includes('power_button')) return true;
      const text = b.textContent || '';
      return text.includes('받기') && (text.includes('통나무') || text.includes('파워') || text.includes('1시간'));
    };
    setInterval(() => {
      const btn = Array.from(document.querySelectorAll('button')).find(isPowerButton);
      if (btn && !btn.disabled) btn.click();
    }, 1000);

    // 버튼 없는 보상(팔로우 등)은 API로 받는다 — 영상 타일에서만, 채널당 한 번.
    const powerChannelId = (window.location.pathname.match(/^\/live\/([0-9a-f]{32})\/?$/) || [])[1];
    if (powerChannelId) {
      const powerApi = `https://api.chzzk.naver.com/service/v1/channels/${powerChannelId}/log-power`;
      const claimPendingPower = async () => {
        try {
          const res = await fetch(powerApi, { credentials: 'include' });
          if (!res.ok) return;
          const data = await res.json();
          const claims = (data && data.content && data.content.claims) || [];
          await Promise.all(claims
            .filter((claim) => claim && claim.claimId && claim.claimType !== 'WATCH_1_HOUR')
            .map((claim) => fetch(`${powerApi}/claims/${claim.claimId}`, { method: 'PUT', credentials: 'include' }).catch(() => {})));
        } catch (_) {}
      };
      setTimeout(claimPendingPower, 5000);
      setInterval(claimPendingPower, 30000);
    }
  }

  const style = document.createElement('style');

  if (isChzzkHost) {
    if (isChatFrame) {
      style.textContent = `
        * {
          -ms-overflow-style: none !important;
          scrollbar-width: none !important;
        }
        *::-webkit-scrollbar {
          display: none !important;
          width: 0 !important;
          height: 0 !important;
        }
        html, body, #root, main, [class*="chatting_container__"], [class*="live_chatting_area__"] {
          width: 100% !important;
          height: 100% !important;
          margin: 0 !important;
          padding: 0 !important;
          overflow: hidden !important;
          background-color: #181823 !important;
        }
      `;
    } else if (isCheeseChatEmbed) {
      // #vod-aside만 뷰포트 전체로 끌어올린다(해시 클래스명과 무관하게 동작).
      style.textContent = `
        * {
          -ms-overflow-style: none !important;
          scrollbar-width: none !important;
        }
        *::-webkit-scrollbar {
          display: none !important;
          width: 0 !important;
          height: 0 !important;
        }
        html, body {
          margin: 0 !important;
          padding: 0 !important;
          width: 100% !important;
          height: 100% !important;
          overflow: hidden !important;
          background: #0f0f0f !important;
        }
        #vod-aside {
          position: fixed !important;
          inset: 0 !important;
          width: 100vw !important;
          height: 100vh !important;
          margin: 0 !important;
          z-index: 2147483000 !important;
          display: block !important;
          visibility: visible !important;
          opacity: 1 !important;
          pointer-events: auto !important;
        }
        /* 닫기(X)를 누르면 되살릴 수 없어 클릭만 막는다. */
        #vod-aside [class*="_close_button_"] {
          pointer-events: none !important;
        }
      `;
    } else {
      style.textContent = `
        * {
          -ms-overflow-style: none !important;
          scrollbar-width: none !important;
        }
        *::-webkit-scrollbar {
          display: none !important;
          width: 0 !important;
          height: 0 !important;
        }
        [class*="header_container__"], 
        [class*="live_information_container__"], 
        [class*="sidebar_container__"], 
        [class*="live_chatting_container__"],
        [class*="live_stage_chatting__"],
        [class*="chatting_container__"],
        [class*="live_chatting_area__"],
        aside, header, footer { 
          display: none !important; 
          visibility: hidden !important;
          pointer-events: none !important;
        }
        html, body, main, [class*="content_container__"], [class*="live_content__"], [class*="live_stage_layout__"], [class*="live_stage_container__"], [class*="live_stage_player__"] {
          padding: 0 !important;
          margin: 0 !important;
          width: 100% !important;
          max-width: 100% !important;
          height: 100% !important;
          min-height: 100% !important;
          overflow: hidden !important;
          background: #000 !important;
        }
        [class*="player_container__"], [class*="video_container__"], [class*="webplayer_"] {
          width: 100% !important;
          height: 100% !important;
          max-width: 100% !important;
          max-height: 100% !important;
          padding: 0 !important;
          margin: 0 !important;
        }
        video {
          width: 100% !important;
          height: 100% !important;
          object-fit: contain !important;
        }
        /* 개편 후 위 클래스는 해시명이라 안 맞는다 — 고정 id 플레이어를 화면 전체로 덮고 조상 transform을 푼다. */
        html, body { overflow: hidden !important; background: #000 !important; }
        body :has(#live_player_layout), body :has(#player_layout) {
          transform: none !important; filter: none !important; contain: none !important; will-change: auto !important;
        }
        #live_player_layout, #player_layout {
          position: fixed !important; inset: 0 !important; width: 100vw !important; height: 100vh !important;
          max-width: none !important; max-height: none !important; margin: 0 !important; z-index: 2147483000 !important;
        }
      `;
    }
  } else if (isSoopHost) {
    const soopChatBg = '#181823';

    style.textContent = `
      * {
        -ms-overflow-style: none !important;
        scrollbar-width: none !important;
      }
      *::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      html, body, #player_area, .player_wrap, #webplayer, #videoLayer {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        height: 100% !important;
        min-width: 0 !important;
        min-height: 0 !important;
        overflow: hidden !important;
        background: ${isChatFrame ? soopChatBg : '#000'} !important;
      }
      /* SOOP 내부 min-width를 풀어 좁은 프레임에 맞춘다. */
      ${isChatFrame ? '' : `
      #player_area, #player_area *, .player_wrap, .player_wrap *, #webplayer, #webplayer *, #videoLayer, #videoLayer * {
        min-width: 0 !important;
      }
      `}
      video {
        width: 100% !important;
        height: 100% !important;
        min-width: 0 !important;
        object-fit: contain !important;
      }
      .embeded_mode #webplayer.chat_open #chatting_area {
        display: none !important;
      }
      .embeded_mode #webplayer #player div.quality_box {
        display: block !important;
      }
      .popout_chat #chatting_area {
        min-width: auto !important;
      }
      #webplayer #player_area {
        max-width: 100% !important;
      }
    `;
  } else if (isYoutubeHost) {
    style.textContent = `
      * {
        -ms-overflow-style: none !important;
        scrollbar-width: none !important;
      }
      *::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
      html, body {
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        height: 100% !important;
        overflow: hidden !important;
        background: #0f0f0f !important;
      }
      ${isYoutubeVideoFrame ? `
      ` : ''}
    `;
  }

  (document.head || document.documentElement).appendChild(style);

  if (!isChatFrame && isSoopHost) {
    function isolateSoopPlayer() {
      // #videoLayer는 숲 VOD 플레이어 컨테이너.
      const player = document.querySelector('#player_area') || document.querySelector('.player_wrap')
        || document.querySelector('#webplayer') || document.querySelector('#videoLayer');
      if (!player) return false;

      // VOD는 조상 형제 강제 숨김을 건너뛴다(필요한 요소를 숨겨 까맣게 될 수 있음).
      if (player.id === 'videoLayer') return true;

      // 이미 적용돼 있으면 스타일 쓰기를 건너뛴다(폴링은 유지).
      let el = player;
      while (el && el.parentElement && el !== document.body) {
        const parent = el.parentElement;
        Array.from(parent.children).forEach((sibling) => {
          if (sibling !== el && sibling.style.display !== 'none') {
            sibling.style.setProperty('display', 'none', 'important');
          }
        });
        if (parent.style.overflow !== 'hidden') {
          parent.style.setProperty('margin', '0', 'important');
          parent.style.setProperty('padding', '0', 'important');
          parent.style.setProperty('width', '100%', 'important');
          parent.style.setProperty('max-width', '100%', 'important');
          parent.style.setProperty('min-width', '0', 'important');
          parent.style.setProperty('height', '100%', 'important');
          parent.style.setProperty('overflow', 'hidden', 'important');
        }
        el = parent;
      }

      const video = document.querySelector('video');
      if (video && player.contains(video)) {
        let inner = video;
        let guard = 0;
        while (inner && inner.parentElement && inner !== player && guard < 20) {
          guard++;
          const parent = inner.parentElement;
          Array.from(parent.children).forEach((sibling) => {
            if (sibling === inner) return;
            if (sibling.tagName === 'VIDEO') return;
            if (sibling.style.display === 'none') return;
            const hasControl = sibling.querySelector && sibling.querySelector('button, input, [role="slider"], [role="button"]');
            if (hasControl) return;
            sibling.style.setProperty('display', 'none', 'important');
          });
          inner = parent;
        }
      }

      return true;
    }

    isolateSoopPlayer();
    setInterval(isolateSoopPlayer, 1000);
  }

  // 오래된 채팅 행을 직접 지우던 정리는 제거했다 — 리액트 가상 리스트와 어긋나 빈 공간이 생겼다.

  // ── 채팅 메시지 클릭 번역 ── 클릭한 메시지만 대시보드에 번역을 요청한다(무료 엔드포인트 호출 최소화).
  // 치지직 VOD 채팅 임베드도 같은 릴레이로 동작한다.
  if ((isChatFrame && (isChzzkHost || isYoutubeChatFrame || isSoopHost)) || isCheeseChatEmbed) {
    const pendingChatTranslateRequests = new Map();

    // 대상 언어를 대시보드에 물어 캐시한다 — 언어 변경을 반영하려고 몇 초마다 다시 묻는다.
    let cachedTargetLang = null;
    window.addEventListener('message', (event) => {
      if (!event.data || event.data.type !== 'UI_LANGUAGE_RESULT') return;
      cachedTargetLang = event.data.lang;
    });
    window.parent.postMessage({ type: 'REQUEST_UI_LANGUAGE' }, '*');
    setInterval(() => {
      window.parent.postMessage({ type: 'REQUEST_UI_LANGUAGE' }, '*');
    }, 3000);

    // ko/en 단순 문자 구성 휴리스틱 — 확신이 없으면 false(API에 맡김). 이 프레임엔 i18n이 없어 문구는 cachedTargetLang으로 고른다.
    const CHAT_TRANSLATE_STRINGS = {
      ko: { loading: '번역 준비 중...', failed: '(번역 실패)' },
      en: { loading: 'Translating...', failed: '(translation failed)' }
    };
    function chatTranslateText(key) {
      const strings = CHAT_TRANSLATE_STRINGS[cachedTargetLang] || CHAT_TRANSLATE_STRINGS.ko;
      return strings[key];
    }

    function looksLikeAlreadyInLang(text, targetLang) {
      const s = String(text || '');
      if (!s.trim()) return false;
      const hangul = (s.match(/[가-힣]/g) || []).length;
      const latin = (s.match(/[A-Za-z]/g) || []).length;
      if (targetLang === 'ko') return hangul > 0 && hangul >= latin;
      if (targetLang === 'en') {
        const otherScript = (s.match(/[가-힣぀-ヿ一-鿿]/g) || []).length;
        return latin > 0 && otherScript === 0;
      }
      return false;
    }

    window.addEventListener('message', (event) => {
      if (!event.data || event.data.type !== 'TRANSLATE_CHAT_RESULT') return;
      const onResult = pendingChatTranslateRequests.get(event.data.requestId);
      if (!onResult) return;
      pendingChatTranslateRequests.delete(event.data.requestId);
      onResult(event.data.translated, event.data.detectedLang, event.data.targetLang);
    });

    function requestChatTranslation(text, onResult) {
      const requestId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
      // 응답이 없으면 8초 뒤 실패로 풀어 준다(응답/타임아웃 중 먼저 오는 쪽만 처리).
      let settled = false;
      const settle = (translated, detectedLang, targetLang) => {
        if (settled) return;
        settled = true;
        pendingChatTranslateRequests.delete(requestId);
        onResult(translated, detectedLang, targetLang);
      };
      pendingChatTranslateRequests.set(requestId, settle);
      setTimeout(() => settle('', '', ''), 8000);
      // 유튜브는 relay.html이 한 번 더 중계한다.
      window.parent.postMessage({ type: 'TRANSLATE_CHAT_MESSAGE', requestId, text }, '*');
    }

    // 플랫폼이 호버 하이라이트하는 행을 클릭하면 번역(다시 클릭하면 지움). 기존 클릭 동작은 막지 않는다.
    // getResultContainer: 결과 붙일 위치 — 숲은 flex 행이라 .message-text에 붙인다.
    function ensureChatTranslateClickable(row, getMessageText, getResultContainer) {
      if (!row || row.classList.contains('cheese-chat-translate-bound')) return;
      row.classList.add('cheese-chat-translate-bound');
      row.style.setProperty('cursor', 'pointer', 'important');
      row.addEventListener('click', (e) => {
        // 닉네임 클릭은 무시한다(프로필 팝업 리렌더로 결과가 날아갈 수 있음).
        if (e.target.closest('[class*="_nickname_"], button[aria-haspopup]')) return;
        const container = (getResultContainer && getResultContainer(row)) || row;
        const existing = container.querySelector('.cheese-chat-translate-result');
        if (existing) {
          existing.remove();
          return;
        }
        const text = getMessageText();
        if (!text) return;
        // 이미 대상 언어로 보이면 요청하지 않는다.
        if (cachedTargetLang && looksLikeAlreadyInLang(text, cachedTargetLang)) return;
        const resultEl = document.createElement('div');
        resultEl.className = 'cheese-chat-translate-result cheese-chat-translate-loading';
        resultEl.textContent = chatTranslateText('loading');
        container.appendChild(resultEl);
        requestChatTranslation(text, (translated, detectedLang, targetLang) => {
          if (!resultEl.isConnected) return;
          resultEl.classList.remove('cheese-chat-translate-loading');
          // 원문이 대상 언어면 결과를 지운다.
          if (detectedLang && targetLang && detectedLang === targetLang) {
            resultEl.remove();
            return;
          }
          resultEl.textContent = translated || chatTranslateText('failed');
        });
      });
    }

    const chatTranslateStyle = document.createElement('style');
    chatTranslateStyle.textContent = `
      .cheese-chat-translate-result {
        font-size: 12px;
        color: #8ec9ff;
        padding: 2px 4px 4px;
        white-space: normal;
        word-break: break-word;
      }
      .cheese-chat-translate-loading {
        color: #9a9aa8;
        font-style: italic;
      }
    `;
    (document.head || document.documentElement).appendChild(chatTranslateStyle);

    // rowFilter: 번역할 메시지 행만. 채팅 컨테이너가 통째로 리마운트될 수 있어 document.body 전체를 감시하고
    // 추가된 노드의 하위 트리까지 검사한다.
    function collectMatchingRows(node, rowFilter, results) {
      if (!node || node.nodeType !== 1) return;
      if (rowFilter(node)) results.push(node);
      const children = node.children;
      if (children) {
        for (let i = 0; i < children.length; i++) collectMatchingRows(children[i], rowFilter, results);
      }
    }

    // 합방 멤버 알림 — 사용자가 직접 "!멤버"를 보낸 뒤 채팅 3개 안에 올라온 멤버 목록을 대시보드에 넘긴다(치지직/숲 라이브).
    const COLLAB_MEMBER_COMMAND_RE = /!\s*멤버/;
    const COLLAB_MEMBER_WAIT_MS = 30000;
    const COLLAB_MEMBER_WAIT_ROWS = 3;
    const COLLAB_MEMBER_TRIM_RE = /^[\s()[\]{}（）【】「」<>"'`·•\-~]+|[\s()[\]{}（）【】「」<>"'`·•\-~]+$/g;
    let collabMemberArmedUntil = 0;
    let collabMemberRowsLeft = 0;

    function parseCollabMemberList(text) {
      let s = String(text || '').trim();
      // 괄호 하나 안이면 그 안만, 아니면 마지막 콜론 뒤. 쉼표가 있으면 쉼표로, 메시지 전체가 괄호면 띄어쓰기로 나눈다.
      const inner = s.match(/[([{（【「]([^()[\]{}（）【】「」]+)[)\]}）】」]/);
      let separator = /[,，、]/;
      if (inner && separator.test(inner[1])) s = inner[1];
      else if (inner && inner[0] === s && inner[1].trim().split(/\s+/).length >= 2) {
        s = inner[1];
        separator = /\s+/;
      } else if (s.lastIndexOf(':') >= 0) s = s.slice(s.lastIndexOf(':') + 1);
      if (!separator.test(s)) return [];
      const names = s.split(separator)
        .map((n) => n.replace(COLLAB_MEMBER_TRIM_RE, '').trim())
        .filter((n) => n && n.length <= 20 && !n.startsWith('!') && !/https?:/i.test(n));
      const unique = Array.from(new Set(names)).slice(0, 12);
      return unique.length >= 2 ? unique : [];
    }

    function armCollabMemberWatch() {
      collabMemberArmedUntil = Date.now() + COLLAB_MEMBER_WAIT_MS;
      collabMemberRowsLeft = COLLAB_MEMBER_WAIT_ROWS;
      console.log('[CHEESE EYES][합방 멤버] 내가 보낸 !멤버 — 다음 채팅 3개에서 멤버 목록을 찾습니다');
    }

    function readChatInputText(el) {
      if (!el) return '';
      if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return el.value || '';
      return el.isContentEditable ? (el.textContent || '') : '';
    }

    if (isChatFrame && (isChzzkHost || isSoopHost)) {
      document.addEventListener('keydown', (e) => {
        if (e.key !== 'Enter' || e.shiftKey) return;
        if (COLLAB_MEMBER_COMMAND_RE.test(readChatInputText(e.target))) armCollabMemberWatch();
      }, true);
      // 보내기 버튼 — 치지직은 "채팅" 버튼, 숲은 #btn_send.
      document.addEventListener('click', (e) => {
        const btn = e.target && e.target.closest && e.target.closest('button');
        if (!btn) return;
        const isSend = btn.id === 'btn_send' || /send/i.test(String(btn.className)) || (btn.textContent || '').trim() === '채팅';
        if (!isSend) return;
        const input = document.querySelector('textarea[placeholder], #write_area, [contenteditable="true"]');
        if (COLLAB_MEMBER_COMMAND_RE.test(readChatInputText(input))) armCollabMemberWatch();
      }, true);
    }

    function watchCollabMemberText(text) {
      if (!text) return;
      if (COLLAB_MEMBER_COMMAND_RE.test(text)) return; // 내가 보낸 "!멤버"가 채팅에 뜬 줄 등은 세지 않는다
      if (Date.now() > collabMemberArmedUntil || collabMemberRowsLeft <= 0) return;
      collabMemberRowsLeft--;
      const names = parseCollabMemberList(text);
      if (names.length === 0) {
        console.log('[CHEESE EYES][합방 멤버] 목록 아님:', text);
        return;
      }
      collabMemberArmedUntil = 0;
      console.log('[CHEESE EYES][합방 멤버] 멤버 목록:', names);
      window.parent.postMessage({ type: 'COLLAB_MEMBER_LIST', names }, '*');
    }
    const shouldWatchCollabMembers = isChatFrame && (isChzzkHost || isSoopHost);

    function watchChatMessages(label, rowFilter, getMessageText, getResultContainer) {
      const attach = (root) => {
        const matches = [];
        collectMatchingRows(root, rowFilter, matches);
        matches.forEach((row) => ensureChatTranslateClickable(row, () => getMessageText(row), getResultContainer));
        if (shouldWatchCollabMembers) matches.forEach((row) => watchCollabMemberText(getMessageText(row)));
        return matches.length;
      };
      const initialCount = attach(document.body);
      console.log(`[CHEESE EYES][채팅번역] ${label} 초기 메시지 ${initialCount}개에 클릭 번역 바인딩`);

      const observer = new MutationObserver((mutations) => {
        mutations.forEach((m) => {
          m.addedNodes.forEach((node) => attach(node));
        });
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }

    if (isChzzkHost && (isChatFrame || isCheeseChatEmbed)) {
      // 치지직 메시지 행 `_chatting_message_*` — 행을 복제해 닉네임(`_nickname_*`) 서브트리를 잘라낸 나머지를 텍스트로 쓴다.
      // VOD 채팅 다시보기도 같은 컴포넌트를 쓴다.
      watchChatMessages(
        '치지직',
        (n) => n.className && typeof n.className === 'string' && n.className.includes('_chatting_message_'),
        (row) => {
          const clone = row.cloneNode(true);
          const nickEl = clone.querySelector('[class*="_nickname_"]');
          if (nickEl) nickEl.remove();
          return clone.textContent.trim();
        }
      );
    }

    if (isSoopHost) {
      // 숲: .message-container 안 .text-original만 읽는다. 자체 번역 요소와 클래스명이 겹치지 않게 한다.
      watchChatMessages(
        '숲',
        (n) => n.classList && n.classList.contains('message-container'),
        (row) => {
          const el = row.querySelector('.text-original');
          return el ? el.textContent.trim() : '';
        },
        (row) => row.querySelector('.message-text') || row
      );
    }

    if (isYoutubeChatFrame) {
      // 유튜브: yt-live-chat-text-message-renderer의 #message(라이트 DOM).
      watchChatMessages(
        '유튜브',
        (n) => n.tagName === 'YT-LIVE-CHAT-TEXT-MESSAGE-RENDERER',
        (row) => {
          const msgEl = row.querySelector('#message');
          return msgEl ? msgEl.textContent.trim() : '';
        }
      );
    }
  }

  if (!isChatFrame && !isCheeseChatEmbed && (isChzzkHost || isSoopHost || isYoutubeVideoFrame)) {
    console.log('🚀 [ScreenMode Inject] 스크립트 주입됨');

    let activeScreenIntervals = [];
    let screenModeAppliedSuccess = false;

    function clearAllScreenIntervals() {
      activeScreenIntervals.forEach((id) => clearInterval(id));
      activeScreenIntervals = [];
    }

    document.addEventListener('click', (e) => {
      if (e.isTrusted) {
        window.top.postMessage({
          type: 'FRAME_CLICKED',
          url: window.location.href
        }, '*');
      }
    }, true);

    const CHEESE_FORWARD_KEYS = new Set(['z', 'Z', 'x', 'X', 'c', 'C', 'v', 'V', '`', '/', 'Escape', 'Esc']);
    document.addEventListener('keydown', (e) => {
      if (!CHEESE_FORWARD_KEYS.has(e.key)) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const active = document.activeElement;
      const isTyping = active && (
        active.tagName === 'INPUT' ||
        active.tagName === 'TEXTAREA' ||
        active.isContentEditable
      );
      if (isTyping) return;

      window.top.postMessage({ type: 'CHEESE_FORWARD_SHORTCUT', key: e.key }, '*');
    }, true);

    // 라이브 플레이어 포커스 시 좌우 방향키 — 대시보드가 이 채널 지연을 조절한다(합방 아닌 채널만).
    if (isChzzkLiveFrame || isSoopLiveFrame) {
      document.addEventListener('keydown', (e) => {
        if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
        if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
        const active = document.activeElement;
        if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable)) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        window.top.postMessage({ type: 'LIVE_LATENCY_KEY', dir: e.key === 'ArrowRight' ? 1 : -1 }, '*');
      }, true);
    }


  if (isChzzkHost || isSoopHost) {
    function checkWideModeDOM() {
      if (isSoopHost) {
        const bodyClass = document.body.className;
        const webplayer = document.querySelector('#webplayer');
        const webplayerClass = webplayer ? webplayer.className : '';
        
        return bodyClass.includes('screen_mode') || 
               bodyClass.includes('wide_mode') || 
               bodyClass.includes('web_fullscreen') ||
               webplayerClass.includes('screen') ||
               webplayerClass.includes('wide');
      }
      if (isChzzkHost) {
        const player = document.querySelector('[class*="live_player_video"], [class*="player_container"]');
        return player ? player.className.includes('theater') : false;
      }
      return false;
    }

    function isAlreadyWideMode() {
      if (screenModeAppliedSuccess) return true;
      return checkWideModeDOM();
    }

    function triggerScreenMode() {
      if (isAlreadyWideMode()) {
        return true;
      }

      let btn = null;
      if (isChzzkHost) {
        btn = document.querySelector('[class*="btn_theater"], [class*="p2p_theater_button"], [aria-label*="넓은"], [aria-label*="극장"]');
      } else if (isSoopHost) {
        btn = document.querySelector('button.btn_screen_mode, #screen_mode, .btn_screen, [tip="스크린모드"], [data-title="스크린모드"]');
      }

      if (btn) {
        console.log('🎯 [ScreenMode] 버튼 클릭 실행:', btn);
        btn.click();
        return true;
      }

      return false;
    }

    function applyScreenModePersistent() {
      if (screenModeAppliedSuccess || isAlreadyWideMode()) {
        screenModeAppliedSuccess = true;
        clearAllScreenIntervals();
        return;
      }

      let attempts = 0;
      const maxAttempts = 30;

      function attemptOnce() {
        if (screenModeAppliedSuccess || isAlreadyWideMode()) {
          screenModeAppliedSuccess = true;
          clearAllScreenIntervals();
          return true;
        }

        attempts++;

        const video = document.querySelector('video');
        const isVideoReady = isChzzkHost || (video && video.readyState >= 2);

        if (isVideoReady) {
          triggerScreenMode();

          if (isAlreadyWideMode()) {
            console.log('🎉 [ScreenMode] 적용 확인 완료!');
            screenModeAppliedSuccess = true;
            clearAllScreenIntervals();
            return true;
          }
        } else {
          console.log(`⏳ [ScreenMode Loop ${attempts}/${maxAttempts}] 비디오 로딩 대기 중...`);
        }

        return false;
      }

      if (attemptOnce()) return;

      const intervalId = setInterval(() => {
        if (attemptOnce()) return;

        if (attempts >= maxAttempts) {
          console.log('🏁 [ScreenMode Loop] 최대 시도 횟수 초과로 타이머 정지');
          clearInterval(intervalId);
          activeScreenIntervals = activeScreenIntervals.filter((id) => id !== intervalId);
        }
      }, 150);
      activeScreenIntervals.push(intervalId);
    }

    let isMouseInsideFrame = false;

    function reapplyScreenModeIfDropped() {
      if (!isMouseInsideFrame) return;
      if (checkWideModeDOM()) return;
      if (activeScreenIntervals.length > 0) return;
      console.log('🔄 [ScreenMode Watch] 스크린모드 해제 감지 -> 재적용 시도');
      screenModeAppliedSuccess = false;
      applyScreenModePersistent();
    }

    document.addEventListener('mouseenter', () => {
      isMouseInsideFrame = true;
      reapplyScreenModeIfDropped();
    });
    document.addEventListener('mouseleave', () => {
      isMouseInsideFrame = false;
    });

    function getWideModeWatchTargets() {
      const targets = [document.body];
      if (isSoopHost) {
        const webplayer = document.querySelector('#webplayer');
        if (webplayer) targets.push(webplayer);
      }
      if (isChzzkHost) {
        const player = document.querySelector('[class*="live_player_video"], [class*="player_container"]');
        if (player) targets.push(player);
      }
      return targets;
    }

    const screenModeObserver = new MutationObserver(() => {
      reapplyScreenModeIfDropped();
    });
    getWideModeWatchTargets().forEach((el) => {
      screenModeObserver.observe(el, { attributes: true, attributeFilter: ['class'] });
    });

    const watchedTargets = new WeakSet(getWideModeWatchTargets());
    setInterval(() => {
      if (!isMouseInsideFrame) return;
      getWideModeWatchTargets().forEach((el) => {
        if (!watchedTargets.has(el)) {
          watchedTargets.add(el);
          screenModeObserver.observe(el, { attributes: true, attributeFilter: ['class'] });
        }
      });
      reapplyScreenModeIfDropped();
    }, 200);
  }
  // ↑ 스크린모드 감시(치지직/숲 전용) 블록을 여기서 닫는다. 아래는 모든 플랫폼에서 실행돼야 한다.

    // 우리가 넣은 값 — volumechange 에코를 사용자 조작과 구분한다.
    let lastAppliedVolumeFromParent = null;
    // 대시보드에서 첫 값을 받기 전의 volumechange는 무시한다(유튜브 자동재생 협상 등이 오보고됐다).
    let hasReceivedVolumeFromParent = false;
    // 첫 값 수신 후 INITIAL_TRUST_DELAY_MS 동안도 무시한다(유튜브 저장 볼륨 재적용 대비).
    const INITIAL_TRUST_DELAY_MS = 9000;
    let firstAppliedFromParentAt = null;
    function markAppliedFromParent(percent) {
      lastAppliedVolumeFromParent = percent;
      hasReceivedVolumeFromParent = true;
      if (firstAppliedFromParentAt === null) firstAppliedFromParentAt = Date.now();
    }
    function isWithinInitialTrustDelay() {
      return firstAppliedFromParentAt !== null
        && (Date.now() - firstAppliedFromParentAt) < INITIAL_TRUST_DELAY_MS;
    }
    // 마지막 목표 볼륨(%) — SPA로 video가 새로 생기면 곧바로 재적용한다.
    let lastKnownTargetPercent = 100;
    // USER_VOLUME_CHANGE 보고 세대 번호.
    let pendingUserVolumeReportToken = 0;
    // 메인/레이아웃 전환 직후엔 플레이어가 volume을 순간 건드릴 수 있어, SUPPRESS_VOLUME_ECHO 수신 후 잠깐 보고를 억제한다.
    let volumeReportSuppressedUntil = 0;

    // ── 채널 dB 측정 + video.volume 볼륨 제어 ── AudioContext가 running일 때만 그래프를 연결한다(suspended면 소리가 끊김).
    // video.volume이 유일한 음량 조절점이고 GainNode는 1 고정(조절점이 둘이면 이중 감쇠·진동). 그래프는 측정/컴프레서용.
    let needsGraphPending = false;
    // 컴프레서 토글 최신 상태(SET_CHANNEL_VOLUME마다 갱신).
    let compressorEnabledPending = false;
    // 합방 음소거 여부 — 그래프 active면 gainNode, 아니면 video.muted로 건다(docs/collab-architecture.md §13).
    let collabMutedPending = false;
    const pendingAudioContexts = new Set();
    // 측정 그래프가 붙은 <video>(프레임당 하나).
    let audioGraphVideo = null;

    // smooth 볼륨 램프 시간.
    const SMOOTH_RAMP_MS = 1200;

    // 값이 바뀐 뒤 이 시간 유지돼야 사용자 조작으로 보고한다(광고 전환 등 스쳐가는 변화 거름).
    const USER_VOLUME_REPORT_CONFIRM_MS = 800;

    // ── 레벨 측정 오케스트레이션(피크 추적 + 어택/릴리즈) ── 측정 원본(RMS/LUFS)과 무관하게 재사용한다.
    // readInstantVoiceDb는 워클릿만(없으면 dashboard.js가 db로 폴백). 보고 간격은 dashboard.js 디버그 상수와 맞춘다.
    const LEVEL_REPORT_INTERVAL_MS = 200;

    function startLevelSamplingLoop(graph, readInstantDb, readInstantVoiceDb) {
      let smoothedDb = null;
      let smoothedVoiceDb = null;
      // 50ms마다 측정해 구간 최댓값을 추적하고 보고는 간격대로.
      let peakSinceReport = -100;
      let peakVoiceSinceReport = -100;

      graph.peakSampleInterval = setInterval(() => {
        const instantDb = readInstantDb();
        if (instantDb > peakSinceReport) peakSinceReport = instantDb;
        if (readInstantVoiceDb) {
          const instantVoiceDb = readInstantVoiceDb();
          if (instantVoiceDb > peakVoiceSinceReport) peakVoiceSinceReport = instantVoiceDb;
        }
      }, 50);

      graph.sampleInterval = setInterval(() => {
        const peakDb = peakSinceReport;
        peakSinceReport = -100;
        // 커질 땐 빠르게, 작아질 땐 천천히.
        if (smoothedDb === null) {
          smoothedDb = peakDb;
        } else if (peakDb > smoothedDb) {
          smoothedDb = smoothedDb * 0.4 + peakDb * 0.6;
        } else {
          smoothedDb = smoothedDb * 0.85 + peakDb * 0.15;
        }

        const message = { type: 'CHANNEL_AUDIO_LEVEL', db: smoothedDb };

        if (readInstantVoiceDb) {
          const peakVoiceDb = peakVoiceSinceReport;
          peakVoiceSinceReport = -100;
          if (smoothedVoiceDb === null) {
            smoothedVoiceDb = peakVoiceDb;
          } else if (peakVoiceDb > smoothedVoiceDb) {
            smoothedVoiceDb = smoothedVoiceDb * 0.4 + peakVoiceDb * 0.6;
          } else {
            smoothedVoiceDb = smoothedVoiceDb * 0.85 + peakVoiceDb * 0.15;
          }
          message.voiceDb = smoothedVoiceDb;
        }

        // window.parent로 보낸다 — 유튜브는 relay.html을 거쳐야 event.source가 직계 iframe과 일치한다.
        window.parent.postMessage(message, '*');
      }, LEVEL_REPORT_INTERVAL_MS);
    }

    // 폴백: AudioWorklet을 못 쓰면 RMS dBFS 측정.
    function startLegacyAudioLevelSampling(graph) {
      const analyser = graph.analyser;
      const buffer = new Float32Array(analyser.fftSize);
      const readInstantDb = () => {
        analyser.getFloatTimeDomainData(buffer);
        let sumSquares = 0;
        for (let i = 0; i < buffer.length; i++) sumSquares += buffer[i] * buffer[i];
        const rms = Math.sqrt(sumSquares / buffer.length);
        return rms > 0 ? 20 * Math.log10(rms) : -100;
      };
      startLevelSamplingLoop(graph, readInstantDb);
    }

    // 워클릿이 계산한 K-weighted momentary LUFS를 순간값으로 쓴다(50ms 보고).
    function startWorkletAudioLevelSampling(graph) {
      let latestLufs = -100;
      let latestVoiceDb = -100;
      graph.workletNode.port.onmessage = (event) => {
        const data = event.data;
        // 워클릿 { lufs, voiceDb } — voiceDb는 합방용 음성대역 값.
        if (data && typeof data === 'object' && typeof data.lufs === 'number' && isFinite(data.lufs)) {
          latestLufs = data.lufs;
          if (typeof data.voiceDb === 'number' && isFinite(data.voiceDb)) latestVoiceDb = data.voiceDb;
        } else if (data && data.type === 'snippet') {
          // 파형 스니펫 응답을 그대로 올린다(Float32Array 구조화 복제).
          window.parent.postMessage({
            type: 'CHANNEL_AUDIO_SNIPPET',
            requestId: data.requestId,
            samples: data.samples,
            sampleRate: data.sampleRate,
            filled: data.filled
          }, '*');
        }
      };
      startLevelSamplingLoop(graph, () => latestLufs, () => latestVoiceDb);
    }

    // ── 합방 파형 캡처/스니펫 릴레이 ── 워클릿이 없으면 즉시 samples:null로 응답한다.
    // 워클릿 준비 전 도착한 SET_CHANNEL_CAPTURE는 기억했다가 붙는 시점에 적용한다.
    let captureEnabledPending = false;
    // VOD 싱크가 요청하는 넓은 캡처 창(undefined면 워클릿 기본값).
    let captureWindowSecPending = undefined;

    function handleSetChannelCapture(enabled, windowSec, forceReset) {
      captureEnabledPending = !!enabled;
      captureWindowSecPending = windowSec;
      const video = document.querySelector('video');
      const graph = video && video.__cheeseAudioGraph;
      if (graph && graph.state === 'active' && graph.workletNode) {
        graph.workletNode.port.postMessage({ cmd: 'setCapture', enabled: captureEnabledPending, windowSec: captureWindowSecPending, forceReset: !!forceReset });
      }
    }

    function handleRequestAudioSnippet(requestId, recentSec) {
      const video = document.querySelector('video');
      const graph = video && video.__cheeseAudioGraph;
      if (graph && graph.state === 'active' && graph.workletNode) {
        graph.workletNode.port.postMessage({ cmd: 'getSnippet', requestId, recentSec });
      } else {
        // unavailable은 "영구 불가"일 때만 true — 대시보드가 영구 등록하므로 그래프 생성 전/연결 중은 false로 둔다.
        const definitelyUnavailable = (!!graph && graph.state === 'unavailable')
          || (!!graph && graph.state === 'active' && graph.measurementMode !== 'worklet');
        window.parent.postMessage({
          type: 'CHANNEL_AUDIO_SNIPPET',
          requestId,
          samples: null,
          unavailable: definitelyUnavailable
        }, '*');
      }
    }

    // ── 레이턴시(라이브 엣지까지 거리) 보고 ── video만 있으면 측정 가능.
    function estimateLiveLatencySec(video) {
      if (!video || !video.seekable || video.seekable.length === 0) return null;
      const edge = video.seekable.end(video.seekable.length - 1);
      const behind = edge - video.currentTime;
      return behind >= 0 ? behind : null; // 음수면 측정 이상치 — 무시
    }

    const LIVE_LATENCY_REPORT_INTERVAL_MS = 1500;
    // 싱크 맞춤용 평균 지연 — seekable.end가 계단식이라 250ms마다 재서 최근 3초 평균을 함께 보고한다.
    const LIVE_LATENCY_SAMPLE_INTERVAL_MS = 250;
    const LIVE_LATENCY_AVG_SAMPLES = 12;
    let liveLatencySamples = [];
    function sampleLiveLatency() {
      if (document.hidden) return;
      const video = document.querySelector('video');
      if (!video || video.paused) {
        liveLatencySamples = [];
        return;
      }
      const latencySec = estimateLiveLatencySec(video);
      if (latencySec === null) return;
      liveLatencySamples.push(latencySec);
      if (liveLatencySamples.length > LIVE_LATENCY_AVG_SAMPLES) liveLatencySamples.shift();
    }
    function reportLiveLatency() {
      // 탭이 숨겨져 있으면 보고를 건너뛴다(백그라운드 디코딩 지연이 레이턴시로 잘못 잡힘).
      if (document.hidden) return;
      const video = document.querySelector('video');
      const latencySec = estimateLiveLatencySec(video);
      if (latencySec === null) return;
      // 평균은 8개(2초) 이상 쌓였을 때만.
      const avgLatencySec = liveLatencySamples.length >= 8
        ? liveLatencySamples.reduce((sum, v) => sum + v, 0) / liveLatencySamples.length
        : null;
      window.parent.postMessage({ type: 'CHANNEL_LIVE_LATENCY', latencySec, avgLatencySec, playbackRate: video.playbackRate }, '*');
    }
    // 치지직/숲 VOD는 레이턴시를 보고하지 않는다(남은 재생 시간이 들어가 탐색 중심이 어긋남).
    if (!isChzzkVodFrame && !isSoopVodFrame) {
      setInterval(reportLiveLatency, LIVE_LATENCY_REPORT_INTERVAL_MS);
      setInterval(sampleLiveLatency, LIVE_LATENCY_SAMPLE_INTERVAL_MS);
    }

    // ── 재생 위치 주기 보고 ── 유튜브 이어보기, 치지직 VOD 채팅 다시보기, 숲 VOD 싱크용.
    // duration도 보낸다(vod-sync 교집합 판정). NaN/Infinity는 거른다.
    if (isYoutubeVideoFrame || isChzzkVodFrame || isSoopVodFrame || isChzzkLiveFrame || isSoopLiveFrame) {
      const PLAYBACK_TIME_REPORT_INTERVAL_MS = 1000;
      function reportPlaybackTime() {
        const video = document.querySelector('video');
        if (!video || !isFinite(video.currentTime)) return;
        const duration = isFinite(video.duration) ? video.duration : null;
        // diag: 정지 원인 진단값(AudioContext 상태, readyState, 버퍼 여유).
        const graph = video.__cheeseAudioGraph;
        let bufAhead = null;
        try {
          const b = video.buffered;
          if (b && b.length) bufAhead = +(b.end(b.length - 1) - video.currentTime).toFixed(2);
        } catch (e) {}
        let ranges = 0;
        let inRange = false;
        let rangeAhead = null; // 재생 위치가 든 구간이 앞으로 몇 초 남았는지(구멍 전까지)
        try {
          const b = video.buffered;
          ranges = b.length;
          for (let i = 0; i < b.length; i++) {
            if (video.currentTime >= b.start(i) - 0.05 && video.currentTime <= b.end(i)) {
              inRange = true;
              rangeAhead = +(b.end(i) - video.currentTime).toFixed(2);
            }
          }
        } catch (e) {}
        let q = null;
        try { q = video.getVideoPlaybackQuality(); } catch (e) {}
        const diag = {
          ctx: graph && graph.ctx ? graph.ctx.state : (graph ? graph.state : 'none'),
          rs: video.readyState,
          ns: video.networkState,
          buf: bufAhead,
          ranges,
          inRange,
          rangeAhead,
          size: `${video.videoWidth}x${video.videoHeight}`,
          drop: q ? q.droppedVideoFrames : null,
          tot: q ? q.totalVideoFrames : null,
          rate: video.playbackRate,
          vis: document.visibilityState
        };
        window.parent.postMessage({ type: 'CHANNEL_PLAYBACK_TIME', currentTime: video.currentTime, paused: video.paused, duration, diag }, '*');
      }
      // 재생/정지는 play/pause 이벤트 즉시 보고한다(위치는 1초 폴링). video가 교체되면 매 틱 확인해 리스너를 다시 붙인다.
      let listenedVideo = null;
      function ensurePlayPauseListeners() {
        const video = document.querySelector('video');
        if (!video || video === listenedVideo) return;
        listenedVideo = video;
        video.addEventListener('play', reportPlaybackTime);
        video.addEventListener('pause', reportPlaybackTime);
        video.addEventListener('ratechange', reportPlaybackTime);
      }
      ensurePlayPauseListeners();
      setInterval(() => {
        ensurePlayPauseListeners();
        reportPlaybackTime();
      }, PLAYBACK_TIME_REPORT_INTERVAL_MS);
    }

    // ── 다이나믹 컴프레서 ── 노드는 항상 넣고, 꺼지면 threshold=0dB·ratio=1로 우회한다.
    const COMPRESSOR_ACTIVE_PARAMS = { threshold: -20, knee: 6, ratio: 3, attack: 0.01, release: 0.25 };
    const COMPRESSOR_NEUTRAL_PARAMS = { threshold: 0, knee: 0, ratio: 1, attack: 0.003, release: 0.25 };

    // 메이크업 게인 튜닝 — 100% 즉시 보정은 고음 잡음이 나서 70% 보정 + 0.15초 반응 + 절대 상한.
    const MAKEUP_GAIN_TIME_CONSTANT_SEC = 0.15;
    const MAKEUP_GAIN_COMPENSATION_RATIO = 0.7;
    const MAKEUP_GAIN_MAX_DB = 10;

    // 과보정 클리핑 방지 안전 리미터(-1dB, attack 1ms).
    const SAFETY_LIMITER_PARAMS = { threshold: -1, knee: 0, ratio: 20, attack: 0.001, release: 0.1 };

    function applyCompressorSetting(compressorNode, enabled) {
      const params = enabled ? COMPRESSOR_ACTIVE_PARAMS : COMPRESSOR_NEUTRAL_PARAMS;
      const ctx = compressorNode.context;
      compressorNode.threshold.setValueAtTime(params.threshold, ctx.currentTime);
      compressorNode.knee.setValueAtTime(params.knee, ctx.currentTime);
      compressorNode.ratio.setValueAtTime(params.ratio, ctx.currentTime);
      compressorNode.attack.setValueAtTime(params.attack, ctx.currentTime);
      compressorNode.release.setValueAtTime(params.release, ctx.currentTime);
    }

    // 합방 음소거 전용 — gainNode는 0 또는 1만.
    function applyCollabGain(graph, muted, smooth) {
      const gainNode = graph && graph.gainNode;
      if (!gainNode) return;
      const ctx = gainNode.context;
      const target = muted ? 0 : 1;
      gainNode.gain.cancelScheduledValues(ctx.currentTime);
      gainNode.gain.setValueAtTime(gainNode.gain.value, ctx.currentTime);
      if (!smooth) {
        gainNode.gain.setValueAtTime(target, ctx.currentTime);
        return;
      }
      gainNode.gain.linearRampToValueAtTime(target, ctx.currentTime + SMOOTH_RAMP_MS / 1000);
    }

    // 워클릿 그래프 연결. 실패하면 false(노드를 남기지 않음 — 호출부가 레거시로 폴백).
    async function tryStartWorkletSampling(ctx, tapSourceNode, graph) {
      if (!ctx.audioWorklet || typeof ctx.audioWorklet.addModule !== 'function') return false;
      try {
        const workletUrl = chrome.runtime.getURL('src/js/audio/lufs-worklet-processor.js');
        await ctx.audioWorklet.addModule(workletUrl);
        if (graph.state !== 'active') return false; // 그 사이 그래프가 정리됐으면 포기.

        const workletNode = new AudioWorkletNode(ctx, 'lufs-meter-processor');
        // 측정 전용 노드도 gain=0 싱크로 destination에 연결해야 process()가 불린다.
        const silentSink = ctx.createGain();
        silentSink.gain.value = 0;
        tapSourceNode.connect(workletNode);
        workletNode.connect(silentSink);
        silentSink.connect(ctx.destination);

        graph.workletNode = workletNode;
        graph.silentSink = silentSink;
        graph.measurementMode = 'worklet';
        startWorkletAudioLevelSampling(graph);
        // 워클릿 준비 전에 온 캡처 요청을 지금 적용한다.
        if (captureEnabledPending) {
          workletNode.port.postMessage({ cmd: 'setCapture', enabled: true, windowSec: captureWindowSecPending });
        }
        return true;
      } catch (e) {
        return false;
      }
    }

    function ensureAudioGraph(video) {
      if (!video || video.__cheeseAudioGraph) return;
      // 미디어 없는 숨은 <video>에는 붙이지 않고, 붙일 때 다른 video의 그래프는 먼저 정리해 항상 하나만 남긴다
      // (숨은 video 그래프가 -100dB를 섞어 보고해 합방 판정에서 빠졌다).
      if (video.readyState === 0) return;
      if (audioGraphVideo && audioGraphVideo !== video) teardownAudioGraph(audioGraphVideo);
      audioGraphVideo = video;
      const graph = { state: 'pending' };
      video.__cheeseAudioGraph = graph;

      let ctx;
      try {
        const AudioContextCtor = window.AudioContext || window.webkitAudioContext;
        ctx = new AudioContextCtor();
      } catch (e) {
        graph.state = 'unavailable';
        return;
      }
      // graph.ctx는 생성 직후 채운다 — pending 중 video가 교체돼도 닫을 수 있게(누수 방지).
      graph.ctx = ctx;

      const tryConnect = () => {
        if (graph.state !== 'pending' || ctx.state !== 'running') return;
        try {
          const source = ctx.createMediaElementSource(video);
          const gainNode = ctx.createGain();
          const compressorNode = ctx.createDynamicsCompressor();
          const makeupGainNode = ctx.createGain();
          const limiterNode = ctx.createDynamicsCompressor();
          applyCompressorSetting(compressorNode, compressorEnabledPending);
          // GainNode는 1 고정, 합방 음소거 중에만 0.
          gainNode.gain.value = collabMutedPending ? 0 : 1;
          makeupGainNode.gain.value = 1;
          limiterNode.threshold.setValueAtTime(SAFETY_LIMITER_PARAMS.threshold, ctx.currentTime);
          limiterNode.knee.setValueAtTime(SAFETY_LIMITER_PARAMS.knee, ctx.currentTime);
          limiterNode.ratio.setValueAtTime(SAFETY_LIMITER_PARAMS.ratio, ctx.currentTime);
          limiterNode.attack.setValueAtTime(SAFETY_LIMITER_PARAMS.attack, ctx.currentTime);
          limiterNode.release.setValueAtTime(SAFETY_LIMITER_PARAMS.release, ctx.currentTime);

          // source → compressor → makeupGain → [측정 탭] → gainNode → limiter → destination. 측정은 gain 이전 신호.
          source.connect(compressorNode);
          compressorNode.connect(makeupGainNode);
          makeupGainNode.connect(gainNode);
          gainNode.connect(limiterNode);
          limiterNode.connect(ctx.destination);

          // 메이크업 게인 — 압축만 하면 시끄러운 채널이 같은 볼륨에서도 작게 들려 reduction의 70%만 되돌린다(상한 있음).
          graph.makeupGainInterval = setInterval(() => {
            const reductionDb = compressorNode.reduction || 0;
            const compensationDb = Math.min(MAKEUP_GAIN_MAX_DB, -reductionDb * MAKEUP_GAIN_COMPENSATION_RATIO);
            const target = Math.pow(10, compensationDb / 20);
            makeupGainNode.gain.setTargetAtTime(target, ctx.currentTime, MAKEUP_GAIN_TIME_CONSTANT_SEC);
          }, 50);

          // statechange 재진입을 막으려 연결 직후 state를 확정한다.
          graph.state = 'active';
          graph.gainNode = gainNode;
          graph.compressorNode = compressorNode;
          graph.makeupGainNode = makeupGainNode;
          graph.limiterNode = limiterNode;
          pendingAudioContexts.delete(ctx);
          // active가 되면 setFallbackVolume으로 다시 계산한다 — 합방 폴백 음소거만 걷고 진짜 0%는 유지. 유튜브는 relay.html 전담.
          if (!isYoutubeVideoFrame) {
            setFallbackVolume(video, lastKnownTargetPercent, false, 0);
          }

          tryStartWorkletSampling(ctx, makeupGainNode, graph).then((workletOk) => {
            if (workletOk || graph.state !== 'active') return;
            const analyser = ctx.createAnalyser();
            analyser.fftSize = 1024;
            makeupGainNode.connect(analyser);
            graph.analyser = analyser;
            graph.measurementMode = 'legacy';
            startLegacyAudioLevelSampling(graph);
          });
        } catch (e) {
          // createMediaElementSource 예외 — video.volume 방식만 쓴다.
          graph.state = 'unavailable';
          pendingAudioContexts.delete(ctx);
        }
      };

      ctx.resume().catch(() => {});
      tryConnect();
      if (graph.state === 'pending') {
        pendingAudioContexts.add(ctx);
        ctx.addEventListener('statechange', tryConnect);
      }
    }

    // video가 교체되면 옛 그래프(AudioContext·루프)를 완전히 정리한다(이중 보고 방지).
    function teardownAudioGraph(video) {
      const graph = video && video.__cheeseAudioGraph;
      if (audioGraphVideo === video) audioGraphVideo = null;
      if (!graph) return;
      graph.state = 'unavailable';
      clearInterval(graph.peakSampleInterval);
      clearInterval(graph.sampleInterval);
      clearInterval(graph.makeupGainInterval);
      if (graph.ctx) {
        // pending 그래프도 정리하고 pendingAudioContexts에서 먼저 뺀다.
        pendingAudioContexts.delete(graph.ctx);
        try { graph.ctx.close(); } catch (e) {}
      }
      video.__cheeseAudioGraph = null;
    }

    // 자동재생 정책으로 막힌 resume()은 첫 사용자 제스처에서 다시 시도한다.
    function retryPendingAudioContexts() {
      pendingAudioContexts.forEach((ctx) => { ctx.resume().catch(() => {}); });
    }
    document.addEventListener('click', retryPendingAudioContexts, { capture: true, passive: true });
    document.addEventListener('keydown', retryPendingAudioContexts, { capture: true, passive: true });

    // smooth면 지정 시간 동안 변한다. 볼륨은 video.volume 하나로만 조절하므로 상한은 100%.

    // 합방 폴백으로 건 video.muted 상태 — 볼륨 재적용이 풀거나 사용자 조작으로 보고하면 안 된다.
    function isCollabFallbackMuteActive(video) {
      const graph = video.__cheeseAudioGraph;
      return collabMutedPending && (!graph || graph.state !== 'active');
    }

    function setFallbackVolume(video, targetPercent, smooth, durationMs) {
      // video.volume은 0~1만 허용 — 1로 캡.
      const target = Math.min(1, Math.max(0, targetPercent / 100));
      if (!smooth) {
        if (video.__cheeseVolumeRampTimer) {
          clearInterval(video.__cheeseVolumeRampTimer);
          video.__cheeseVolumeRampTimer = null;
        }
        video.__cheeseRampInProgress = false;
        video.__cheeseRampTargetPercent = null;
        markAppliedFromParent(targetPercent);
        video.volume = target;
        video.muted = target <= 0 || isCollabFallbackMuteActive(video);
        return;
      }
      // 같은 목표면 새 램프를 걸지 않는다(반복 램프가 사용자 조작을 계속 무시하게 만들었다).
      const alreadyRampingToSameTarget = video.__cheeseRampInProgress
        && video.__cheeseRampTargetPercent === targetPercent;
      const alreadySettledAtTarget = !video.__cheeseRampInProgress
        && Math.round(((video.muted && !isCollabFallbackMuteActive(video)) ? 0 : video.volume) * 100) === targetPercent;
      if (alreadyRampingToSameTarget || alreadySettledAtTarget) {
        markAppliedFromParent(targetPercent);
        return;
      }
      if (video.__cheeseVolumeRampTimer) {
        clearInterval(video.__cheeseVolumeRampTimer);
        video.__cheeseVolumeRampTimer = null;
      }
      const startVolume = video.volume;
      const stepMs = 50;
      const steps = Math.max(1, Math.round(durationMs / stepMs));
      let step = 0;
      video.__cheeseRampInProgress = true;
      video.__cheeseRampTargetPercent = targetPercent;
      video.__cheeseVolumeRampTimer = setInterval(() => {
        step++;
        const t = Math.min(1, step / steps);
        video.volume = startVolume + (target - startVolume) * t;
        video.muted = video.volume <= 0 || isCollabFallbackMuteActive(video);
        if (t >= 1) {
          clearInterval(video.__cheeseVolumeRampTimer);
          video.__cheeseVolumeRampTimer = null;
          // 마지막 스텝 volumechange가 비동기로 올 수 있어 에코 값을 먼저 남긴다.
          markAppliedFromParent(targetPercent);
          video.__cheeseRampInProgress = false;
          video.__cheeseRampTargetPercent = null;
        }
      }, stepMs);
    }

    const LIVE_SYNC_BUFFER_MARGIN_SEC = 1.0;

    // 예전 화질 자동 조절이 남긴 360p/720p 기억을 한 번만 1080p로 되돌린다(대시보드 안 프레임만).
    if (isChzzkHost && !isChatFrame && window.top !== window) {
      try {
        if (localStorage.getItem('__cheeseTileQualityReverted') !== '1') {
          localStorage.setItem('live-player-video-track', JSON.stringify({ label: '1080p', width: 1920, height: 1080 }));
          localStorage.setItem('__cheeseTileQualityReverted', '1');
        }
      } catch (e) {}
    }

    // 대시보드가 정한 속도와 시각 — 3초 넘게 명령이 없으면 1배로 되돌린다.
    let liveSyncAppliedRate = null;
    let liveSyncRateCommandAt = 0;
    setInterval(() => {
      if (liveSyncAppliedRate === null || Date.now() - liveSyncRateCommandAt < 3000) return;
      const video = document.querySelector('video');
      if (video && Math.abs(video.playbackRate - liveSyncAppliedRate) < 0.001) video.playbackRate = 1;
      liveSyncAppliedRate = null;
    }, 1000);

    window.addEventListener('message', (event) => {
      if (!event.data) return;

      const { type } = event.data;

      if (
        type === 'APPLY_SCREEN_MODE' ||
        type === 'APPLY_WIDE_MODE' ||
        type === 'REAPPLY_ALL'
      ) {
        if (!screenModeAppliedSuccess) {
          console.log('📩 [ScreenMode Message] 적용 신호 수신');
          applyScreenModePersistent();
        }
      } else if (type === 'RELOAD_PLAYER') {
        window.location.reload();
      } else if (type === 'DESTROY_PLAYER') {
        screenModeAppliedSuccess = false;
        clearAllScreenIntervals();
        const video = document.querySelector('video');
        if (video) {
          video.pause();
          video.removeAttribute('src');
          video.load();
        }
      } else if (type === 'CHEESE_EXPECT_VOLUME_ECHO') {
        // 유튜브 relay.html이 공식 API로 음소거를 풀 때 미리 알려 주면 그 volumechange를 에코로 처리한다.
        markAppliedFromParent(Math.round(Number(event.data.volume) || 0));
      } else if (type === 'SUPPRESS_VOLUME_ECHO') {
        const durationMs = Number(event.data.durationMs) || 2000;
        volumeReportSuppressedUntil = Date.now() + durationMs;
      } else if (type === 'SET_CHANNEL_VOLUME') {
        const video = document.querySelector('video');
        // video.volume 물리적 상한은 100%. 합방 음소거는 이 값을 0으로 접지 않는다.
        const vol = Math.min(100, Math.max(0, Number(event.data.volume) || 0));
        const smooth = !!event.data.smooth;
        needsGraphPending = !!event.data.needsGraph;
        compressorEnabledPending = !!event.data.compressorEnabled;
        collabMutedPending = !!event.data.collabMuted;
        lastKnownTargetPercent = vol;
        if (video) {
          const graph = video.__cheeseAudioGraph;
          // 유튜브는 IFrame Player API가 별도 볼륨 상태를 가져 video.volume을 되돌리므로 relay.html이 공식 API로 전담하고 여기선 건너뛴다.
          if (!isYoutubeVideoFrame) {
            // smooth 램프 시간. 볼륨은 video.volume, GainNode는 합방 음소거만.
            setFallbackVolume(video, vol, smooth, SMOOTH_RAMP_MS);
            // 그래프가 없거나 영구 불가면 video.muted로 음소거한다(되돌리는 건 setFallbackVolume이 매번 처리).
            if (collabMutedPending && (!graph || graph.state !== 'active')) {
              video.muted = true;
            }
          }
          if (graph && graph.state === 'active') {
            if (graph.compressorNode) applyCompressorSetting(graph.compressorNode, compressorEnabledPending);
            applyCollabGain(graph, collabMutedPending, smooth);
          }
          if (needsGraphPending) ensureAudioGraph(video);
        }
      } else if (type === 'SET_CHANNEL_CAPTURE') {
        handleSetChannelCapture(event.data.enabled, event.data.windowSec, event.data.forceReset);
      } else if (type === 'REQUEST_AUDIO_SNIPPET') {
        handleRequestAudioSnippet(event.data.requestId, event.data.recentSec);
      } else if (type === 'PAUSE') {
        // 화면 숨김 시 <video>를 직접 멈춘다(유튜브는 relay.html).
        const video = document.querySelector('video');
        if (video) video.pause();
      } else if (type === 'PLAY') {
        const video = document.querySelector('video');
        if (video) video.play().catch(() => {});
      } else if (type === 'SEEK_TO_TIME') {
        // 치지직/숲 VOD 시크(유튜브는 relay.html의 seekTo).
        const video = document.querySelector('video');
        const seconds = Number(event.data.seconds);
        if (video && isFinite(seconds)) video.currentTime = Math.max(0, seconds);
      } else if (type === 'SET_PLAYBACK_RATE') {
        if (!isChzzkVodFrame && !isSoopVodFrame) return;
        const video = document.querySelector('video');
        const rate = Number(event.data.rate);
        if (!video || !isFinite(rate) || rate < 0.25 || rate > 4) return;
        if (Math.abs(video.playbackRate - rate) >= 0.001) video.playbackRate = rate;
      } else if (type === 'LIVE_SYNC_RATE') {
        // 라이브 싱크 속도 — 1초마다 다시 받고, 끊기면 아래 감시가 1배로 되돌린다.
        if (!isChzzkLiveFrame && !isSoopLiveFrame) return;
        const video = document.querySelector('video');
        const rate = Number(event.data.rate);
        if (!video || !isFinite(rate) || rate < 0.9 || rate > 1.1) return;
        liveSyncRateCommandAt = Date.now();
        if (Math.abs(rate - 1) < 0.001) {
          // 우리가 바꾼 속도일 때만 1배로 돌린다.
          if (liveSyncAppliedRate !== null && Math.abs(video.playbackRate - liveSyncAppliedRate) < 0.001) video.playbackRate = 1;
          liveSyncAppliedRate = null;
          return;
        }
        video.preservesPitch = true;
        video.playbackRate = rate;
        liveSyncAppliedRate = rate;
      } else if (type === 'LIVE_SYNC_SEEK_BY') {
        // 라이브 싱크 맞춤 시크 — 양수 당김, 음수 늦춤. 버퍼 양 끝에서 조금 떨어진 곳까지만 옮긴다.
        if (!isChzzkLiveFrame && !isSoopLiveFrame) return;
        const video = document.querySelector('video');
        const deltaSec = Number(event.data.deltaSec);
        if (!video || video.paused || !isFinite(deltaSec) || deltaSec === 0) return;
        const buffered = video.buffered;
        if (!buffered || buffered.length === 0) return;
        const maxTime = buffered.end(buffered.length - 1) - LIVE_SYNC_BUFFER_MARGIN_SEC;
        const minTime = buffered.start(0) + LIVE_SYNC_BUFFER_MARGIN_SEC;
        const target = Math.max(minTime, Math.min(video.currentTime + deltaSec, maxTime));
        if (Math.abs(target - video.currentTime) >= 0.15 && Math.sign(target - video.currentTime) === Math.sign(deltaSec)) {
          video.currentTime = target;
          liveLatencySamples = []; // 옮기기 전 표본이 평균에 섞이지 않게
        }
      }
    });

    // ── 사용자 플레이어 직접 조작 보고 ── SPA video 교체 판단용으로 마지막 엘리먼트를 기억한다.
    let lastWatchedVideo = null;
    function attachVolumeChangeWatcher() {
      const video = document.querySelector('video');
      if (!video) return;
      if (lastWatchedVideo && lastWatchedVideo !== video) {
        teardownAudioGraph(lastWatchedVideo);
      }
      lastWatchedVideo = video;
      // 그래프가 필요할 때만(needsGraphPending) 새 video에 그래프를 만든다.
      if (needsGraphPending) ensureAudioGraph(video);
      if (video.__cheeseVolumeWatched) return;
      video.__cheeseVolumeWatched = true;
      // 새 video는 사이트 기본값에서 시작하므로 신뢰 상태를 리셋하고 마지막 목표 볼륨을 재적용한다(유튜브 제외).
      lastAppliedVolumeFromParent = null;
      hasReceivedVolumeFromParent = false;
      firstAppliedFromParentAt = null;
      if (!isYoutubeVideoFrame) {
        setFallbackVolume(video, lastKnownTargetPercent, false, 0);
      }
      video.addEventListener('volumechange', () => {
        // 첫 값 수신 전·신뢰 지연 중의 volumechange는 무시한다.
        if (!hasReceivedVolumeFromParent || isWithinInitialTrustDelay()) return;
        if (Date.now() < volumeReportSuppressedUntil) return;
        if (video.muted && isCollabFallbackMuteActive(video)) return;
        // smooth 전환 중 이벤트는 무시한다.
        if (video.__cheeseRampInProgress) return;
        const currentPercent = Math.round((video.muted ? 0 : video.volume) * 100);
        // 마지막 목표와 같은 값이면 몇 번째든 에코로 본다(플레이어가 같은 값을 한 번 더 쓰면 오보고됐다).
        if (hasReceivedVolumeFromParent && currentPercent === lastKnownTargetPercent) return;
        if (lastAppliedVolumeFromParent !== null && currentPercent === lastAppliedVolumeFromParent) {
          // volume/muted가 같이 바뀌면 이벤트가 두 번 올 수 있어 마커는 이번 턴이 끝난 뒤 지운다.
          setTimeout(() => {
            if (lastAppliedVolumeFromParent === currentPercent) lastAppliedVolumeFromParent = null;
          }, 0);
          return;
        }
        lastAppliedVolumeFromParent = null;
        // USER_VOLUME_REPORT_CONFIRM_MS 동안 유지되는지 확인한 뒤 보고한다.
        const reportToken = ++pendingUserVolumeReportToken;
        setTimeout(() => {
          if (reportToken !== pendingUserVolumeReportToken) return; // 그 사이 또 바뀜 — 최신 것에 맡긴다
          if (video.__cheeseRampInProgress) return;
          if (Date.now() < volumeReportSuppressedUntil) return; // 대기 중 억제 구간에 들어옴
          if (video.muted && isCollabFallbackMuteActive(video)) return; // 그 사이 합방 음소거 폴백이 걸림
          const stillPercent = Math.round((video.muted ? 0 : video.volume) * 100);
          if (stillPercent !== currentPercent) return; // 확인 시간 동안 값이 또 바뀜 — 아직 불안정
          if (stillPercent === lastKnownTargetPercent) return; // 그 사이 대시보드 목표가 이 값이 됨 — 에코
          window.parent.postMessage({ type: 'USER_VOLUME_CHANGE', volume: stillPercent }, '*');
        }, USER_VOLUME_REPORT_CONFIRM_MS);
      });
      // VOD 끝 — 대시보드가 자동으로 뺀다(라이브 종료는 별도 주기 확인).
      video.addEventListener('ended', () => {
        window.parent.postMessage({ type: 'CHANNEL_VIDEO_ENDED' }, '*');
      });
    }
    attachVolumeChangeWatcher();
    // SPA라 video가 바뀔 수 있어 주기적으로 재확인한다.
    setInterval(attachVolumeChangeWatcher, 1000);

    setTimeout(() => {
      if (!screenModeAppliedSuccess && !isAlreadyWideMode()) {
        console.log('⏰ [ScreenMode Init] 레이아웃 안정화 후 최초 시도');
        applyScreenModePersistent();
      }
    }, 3500);

  }
}