// 유튜브 임베드 추천 영상 클릭의 새 탭을 막고 영상ID를 relay.html에 알려 대기열에 담는다.
// 링크가 닫힌 shadow DOM에 있어 attachShadow를 감싸 모든 shadow root에도 클릭 캡처를 심는다.
(function () {
  const host = window.location.hostname;
  const isYoutubeVideoFrame = host.endsWith('youtube.com') && window.location.pathname.startsWith('/embed/');
  if (!isYoutubeVideoFrame) return;

  const YT_WATCH_ID_RE = /[?&]v=([a-zA-Z0-9_-]{11})/;
  const YT_SHORT_ID_RE = /youtu\.be\/([a-zA-Z0-9_-]{11})/;

  // 엔딩화면/카드 컨테이너 안의 링크 클릭만 가로챈다(전체를 막으면 플레이어 UI 버튼도 씹혔다).
  const SUGGESTION_CONTAINER_CLASSES = [
    'html5-endscreen', 'ytp-ce-element', 'ytp-ce-covering-overlay',
    'ytp-videowall-still', 'ytp-suggestion-set', 'ytp-cards-teaser'
  ];
  function isSuggestionContainer(el) {
    if (!el || !el.classList) return false;
    return SUGGESTION_CONTAINER_CLASSES.some((c) => el.classList.contains(c));
  }

  const nativeWindowOpen = window.open.bind(window);
  window.open = function (url) {
    if (typeof url === 'string' && (url.includes('youtube.com') || url.includes('youtu.be'))) {
      const m = YT_WATCH_ID_RE.exec(url) || YT_SHORT_ID_RE.exec(url);
      // window.open은 영역을 가릴 수 없지만 일반 UI는 이를 부르지 않아 그대로 둔다.
      if (m) {
        window.parent.postMessage({ type: 'CHEESE_YT_SUGGESTION_CLICKED', videoId: m[1] }, '*');
        return null;
      }
    }
    return nativeWindowOpen.apply(window, arguments);
  };

  function findYoutubeLink(e) {
    const path = typeof e.composedPath === 'function' ? e.composedPath() : [];
    let link = null;
    let inSuggestionUI = false;
    for (const el of path) {
      if (!link && el && el.tagName === 'A' && el.href) link = el;
      if (!inSuggestionUI && isSuggestionContainer(el)) inSuggestionUI = true;
    }
    if (!link && e.target && e.target.closest) {
      const viaClosest = e.target.closest('a');
      if (viaClosest && viaClosest.href) link = viaClosest;
    }
    if (!inSuggestionUI && e.target && e.target.closest) {
      inSuggestionUI = SUGGESTION_CONTAINER_CLASSES.some((c) => e.target.closest(`.${c}`));
    }
    return inSuggestionUI ? link : null;
  }

  function handleClick(e) {
    const link = findYoutubeLink(e);
    if (!link || !link.href) return;
    const m = YT_WATCH_ID_RE.exec(link.href) || YT_SHORT_ID_RE.exec(link.href);
    if (!m) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    window.parent.postMessage({ type: 'CHEESE_YT_SUGGESTION_CLICKED', videoId: m[1] }, '*');
  }

  document.addEventListener('click', handleClick, true);

  // detached <a target=_blank>.click() 트릭은 전파되지 않으므로 HTMLAnchorElement.prototype.click을 감싼다.
  const nativeAnchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    try {
      const href = this.href;
      if (typeof href === 'string' && (href.includes('youtube.com') || href.includes('youtu.be'))) {
        const m = YT_WATCH_ID_RE.exec(href) || YT_SHORT_ID_RE.exec(href);
        if (m) {
          window.parent.postMessage({ type: 'CHEESE_YT_SUGGESTION_CLICKED', videoId: m[1] }, '*');
          return;
        }
      }
    } catch (err) {}
    return nativeAnchorClick.apply(this, arguments);
  };

  try {
    const nativeAttachShadow = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function (init) {
      const root = nativeAttachShadow.call(this, init);
      try {
        root.addEventListener('click', handleClick, true);
      } catch (err) {}
      return root;
    };
  } catch (err) {
    console.warn('[CHEESE EYES] attachShadow 오버라이드 실패:', err);
  }
})();
