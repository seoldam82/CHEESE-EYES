// 시청 페이지에서 트레이 키/가운데 클릭으로 "멀티뷰에 추가"를 트리거한다(최상위 탭에서만).
// document_start — 페이지의 capture 리스너보다 먼저 등록해야 stopPropagation에 막히지 않는다.
(function () {
  function findVideoUnderPoint(x, y) {
    const stack = typeof document.elementsFromPoint === 'function'
      ? document.elementsFromPoint(x, y)
      : [document.elementFromPoint(x, y)];
    // 오버레이가 덮어도 찾도록 클릭 지점 엘리먼트 스택 전체에서 video를 찾는다.
    return (stack || []).find((el) => el && el.tagName === 'VIDEO') || null;
  }

  // 미리보기 카드면 video를 감싼 가장 가까운 <a href>가 실제 대상이다.
  function findNearestChannelLink(el) {
    let node = el;
    let depth = 0;
    while (node && depth < 12) {
      if (node.tagName === 'A' && node.href) return node;
      node = node.parentElement;
      depth++;
    }
    return null;
  }

  // 유튜브 라이브는 videoId 대신 채널 URL로 담는다(videoId는 무효화될 수 있음). VOD는 그대로.
  function isLikelyLiveVideo(video) {
    return !isFinite(video.duration);
  }

  // 호버 미리보기 클립도 라이브처럼 보일 수 있어 실제 시청 페이지에서만 채널 URL로 승격한다.
  function isOnYoutubeWatchPage() {
    return location.pathname === '/watch' || /^\/live\//.test(location.pathname);
  }

  // video가 없는 카드는 클릭 지점 아래 시청/VOD 링크 모양의 <a>를 대신 찾는다.
  function looksLikeWatchLink(href) {
    if (!href) return false;
    return /chzzk\.naver\.com\/(live|video)\//.test(href)
      || /(?:^|\/\/)(?:www\.)?youtube\.com\/(watch\?|channel\/|@|live\/)/.test(href)
      || /play\.sooplive\.com\//.test(href);
  }

  function findNearestWatchLink(x, y) {
    const stack = typeof document.elementsFromPoint === 'function'
      ? document.elementsFromPoint(x, y)
      : [document.elementFromPoint(x, y)];
    for (const startEl of (stack || [])) {
      let node = startEl;
      let depth = 0;
      while (node && depth < 12) {
        if (node.tagName === 'A' && looksLikeWatchLink(node.href)) return node;
        node = node.parentElement;
        depth++;
      }
    }
    return null;
  }

  function findYoutubeChannelUrl() {
    const metaLink = document.querySelector('link[itemprop="channelId"]');
    const metaId = metaLink && metaLink.getAttribute('content');
    if (metaId && /^UC[a-zA-Z0-9_-]{22}$/.test(metaId)) {
      return `https://www.youtube.com/channel/${metaId}`;
    }
    // /@handle 링크도 찾되 소유자 영역(#owner)으로 좁힌다. 못 찾으면 null.
    const owner = document.querySelector('ytd-video-owner-renderer, #owner');
    const ownerLink = owner && owner.querySelector('a[href^="/channel/UC"], a[href^="/@"]');
    if (!ownerLink) return null;
    const href = ownerLink.getAttribute('href') || '';
    const channelMatch = href.match(/^\/channel\/(UC[a-zA-Z0-9_-]{22})/);
    if (channelMatch) return `https://www.youtube.com/channel/${channelMatch[1]}`;
    const handleMatch = href.match(/^(\/@[a-zA-Z0-9._-]{3,30})/);
    if (handleMatch) return `https://www.youtube.com${handleMatch[1]}`;
    return null;
  }

  // 카드 썸네일 링크엔 제목이 없는 경우가 많아 카드 컨테이너에서 #video-title을 찾는다.
  function findCardTitle(linkEl) {
    let container = linkEl;
    for (let i = 0; i < 6 && container; i++) {
      const titleEl = container.querySelector && container.querySelector('#video-title');
      if (titleEl) {
        // aria-label은 부가정보가 붙어 있어 마지막 폴백.
        const text = (titleEl.getAttribute('title') || titleEl.textContent || titleEl.getAttribute('aria-label') || '').trim();
        if (text) return text;
      }
      container = container.parentElement;
    }
    return '';
  }

  // 카드면 카드 제목을, 아니면 document.title을 쓴다. 쇼츠의 일반값("YouTube")은 버린다.
  const GENERIC_PAGE_TITLES = new Set(['YouTube', 'YouTube Shorts', 'Shorts - YouTube']);
  function guessTitle(video, linkEl) {
    const cardTitle = linkEl ? findCardTitle(linkEl) : '';
    if (cardTitle) return cardTitle;
    const pageTitle = (document.title || '').trim();
    if (pageTitle && !GENERIC_PAGE_TITLES.has(pageTitle)) return pageTitle;
    const candidates = [
      video && video.title,
      video && video.getAttribute && video.getAttribute('aria-label'),
      linkEl && linkEl.title,
      linkEl && linkEl.getAttribute && linkEl.getAttribute('aria-label'),
      linkEl && linkEl.textContent
    ];
    const found = candidates.find((v) => v && String(v).trim());
    if (found) return String(found).trim();
    return pageTitle;
  }

  // 트레이 썸네일은 프레임 캡처 대신 플랫폼의 정식 썸네일 URL을 쓴다(미리보기는 늘 처음부터라 암전이 찍힘).

  // 카드 안 실제 썸네일 <img>(작은 아바타 제외).
  function findCardThumbnailUrl(linkEl) {
    let container = linkEl;
    for (let i = 0; i < 6 && container; i++) {
      const imgs = container.querySelectorAll ? container.querySelectorAll('img') : [];
      for (const img of imgs) {
        const w = img.naturalWidth || parseInt(img.getAttribute('width') || '0', 10);
        if (w && w < 60) continue;
        const src = img.currentSrc || img.src
          || img.getAttribute('data-src') || img.getAttribute('data-thumb')
          || (img.getAttribute('srcset') || '').split(/[\s,]+/)[0];
        if (src && !src.startsWith('data:') && !src.startsWith('blob:')) return src;
      }
      container = container.parentElement;
    }
    return null;
  }

  // 시청 페이지는 og:image를 쓴다(유튜브는 로고로 남는 경우가 많아 제외).
  function findPageThumbnailUrl() {
    const og = document.querySelector('meta[property="og:image"], meta[name="og:image"]');
    return (og && og.content) || null;
  }

  // 유튜브는 영상 ID로 표준 썸네일 CDN 경로를 만든다(지연 로딩 대비).
  const YT_VIDEO_ID_RE_LIST = [
    /[?&]v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /\/shorts\/([a-zA-Z0-9_-]{11})/,
    /\/live\/([a-zA-Z0-9_-]{11})/
  ];
  function extractYoutubeVideoId(url) {
    if (!url) return null;
    for (const re of YT_VIDEO_ID_RE_LIST) {
      const m = re.exec(url);
      if (m) return m[1];
    }
    return null;
  }
  function findYoutubeThumbnailUrl(linkEl) {
    const id = extractYoutubeVideoId(location.href) || extractYoutubeVideoId(linkEl && linkEl.href);
    // mqdefault는 16:9라 크롭이 필요 없다.
    return id ? `https://i.ytimg.com/vi/${id}/mqdefault.jpg` : null;
  }

  // 가운데 버튼 mousedown에서 오토스크롤을 미리 막는다(auxclick에선 늦음).
  document.addEventListener('mousedown', (e) => {
    if (e.button !== 1) return;
    const video = findVideoUnderPoint(e.clientX, e.clientY);
    const watchLinkFallback = video ? null : findNearestWatchLink(e.clientX, e.clientY);
    if (!video && !watchLinkFallback) return;
    e.preventDefault();
  }, true);

  let mousePos = { x: 0, y: 0 };
  document.addEventListener('mousemove', (e) => {
    mousePos.x = e.clientX;
    mousePos.y = e.clientY;
  }, { passive: true });

  // 트레이 키 — my_profile.shortcutKeys.trayAdd(KeyboardEvent.code). 없으면 왼쪽 Alt, ''면 끔.
  const DEFAULT_TRAY_ADD_CODE = 'AltLeft';
  let trayAddCode = DEFAULT_TRAY_ADD_CODE;
  function applyTrayAddCode(profile) {
    const saved = profile && profile.shortcutKeys && profile.shortcutKeys.trayAdd;
    trayAddCode = typeof saved === 'string' ? saved : DEFAULT_TRAY_ADD_CODE;
  }
  try {
    chrome.storage.local.get(['my_profile'], (r) => applyTrayAddCode(r && r.my_profile));
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.my_profile) applyTrayAddCode(changes.my_profile.newValue);
    });
  } catch (err) {}

  document.addEventListener('keydown', (e) => {
    if (!trayAddCode || e.code !== trayAddCode) return;
    if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName) || document.activeElement.isContentEditable) {
      return;
    }

    const video = findVideoUnderPoint(mousePos.x, mousePos.y);
    const watchLinkFallback = video ? null : findNearestWatchLink(mousePos.x, mousePos.y);
    if (!video && !watchLinkFallback) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    const linkEl = video ? findNearestChannelLink(video) : watchLinkFallback;
    const isYoutube = location.hostname.endsWith('youtube.com');
    const thumbnail = (isYoutube && findYoutubeThumbnailUrl(linkEl))
      || (linkEl && findCardThumbnailUrl(linkEl))
      || (!isYoutube && findPageThumbnailUrl())
      || null;
    let linkUrl = linkEl ? linkEl.href : null;
    const hintTitle = guessTitle(video, linkEl);

    if (video && location.hostname.endsWith('youtube.com') && isOnYoutubeWatchPage() && isLikelyLiveVideo(video)) {
      const channelUrl = findYoutubeChannelUrl();
      if (channelUrl) linkUrl = channelUrl;
    }

    try {
      chrome.runtime.sendMessage({ type: 'ADD_TO_MULTIVIEW', thumbnail, linkUrl, hintTitle });
    } catch (err) {}
  }, true);
})();
