const ALLOWED_HOSTS = [
  'chzzk.naver.com', 'api.chzzk.naver.com', 'comm-api.game.naver.com',
  'sooplive.com', 'sooplive.co.kr', 'afreecatv.com',
  'youtube.com', 'suggestqueries-clients6.youtube.com',
  'translate.googleapis.com'
];
function isAllowedUrl(url) {
  try {
    const { hostname } = new URL(url);
    return ALLOWED_HOSTS.some(h => hostname === h || hostname.endsWith('.' + h));
  } catch {
    return false;
  }
}

chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("src/html/dashboard.html") });
});

// 치지직 frame-ancestors 우회 — 이 확장이 연 치지직 프레임에서만 헤더를 걷어낸다(다른 사이트 삽입은 그대로 막힘).
const CHZZK_FRAME_RULE_ID = 1;
chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [CHZZK_FRAME_RULE_ID],
  addRules: [{
    id: CHZZK_FRAME_RULE_ID,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      responseHeaders: [
        { header: 'content-security-policy', operation: 'remove' },
        { header: 'x-frame-options', operation: 'remove' }
      ]
    },
    condition: {
      requestDomains: ['chzzk.naver.com'],
      initiatorDomains: [chrome.runtime.id],
      resourceTypes: ['sub_frame']
    }
  }]
}).catch((e) => console.warn('[CHEESE EYES] 치지직 프레임 규칙 등록 실패', e));

// ── 유튜브 추천 영상 새 탭 최후 방어선 ── 페이지 JS 가로채기를 빠져나간 새 탭을 tabs.onCreated로 잡는다.
// 대시보드 탭이 opener인 유튜브 URL 새 탭만 대상.
function extractYoutubeVideoIdFromUrl(url) {
  if (typeof url !== 'string' || !url) return null;
  let m = /[?&]v=([a-zA-Z0-9_-]{11})/.exec(url);
  if (m) return m[1];
  m = /youtu\.be\/([a-zA-Z0-9_-]{11})/.exec(url);
  if (m) return m[1];
  m = /\/shorts\/([a-zA-Z0-9_-]{11})/.exec(url);
  return m ? m[1] : null;
}

function isYoutubeWatchHost(url) {
  try {
    const h = new URL(url).hostname;
    return h === 'www.youtube.com' || h === 'youtube.com' || h === 'youtu.be' || h === 'm.youtube.com';
  } catch (e) {
    return false;
  }
}

async function interceptYoutubeSuggestionNewTab(tab) {
  if (!tab || tab.id == null || tab.openerTabId == null) return;

  let openerTab;
  try {
    openerTab = await chrome.tabs.get(tab.openerTabId);
  } catch (e) {
    return;
  }
  const dashboardUrl = chrome.runtime.getURL(DASHBOARD_PAGE_PATH);
  if (!openerTab || !openerTab.url || !openerTab.url.startsWith(dashboardUrl)) return;

  // 'intercepted' | 'exempt'(의도된 탭, 감시 종료) | 'pending'(계속 지켜봄) — exempt를 pending과 구분하지 않으면
  // SPA가 URL을 다시 바꿀 때 정상 탭을 닫았다.
  const tryHandle = async (url) => {
    if (!isYoutubeWatchHost(url)) return 'pending';
    // 대시보드가 의도적으로 연 새 탭은 cheese_direct 마커로 통과시킨다.
    if (/[?&]cheese_direct=1(&|$)/.test(url)) return 'exempt';
    const videoId = extractYoutubeVideoIdFromUrl(url);
    if (!videoId) return 'pending';
    try { await chrome.tabs.remove(tab.id); } catch (e) {}
    chrome.runtime.sendMessage({ type: 'CHEESE_YT_NEWTAB_SUGGESTION', videoId }).catch(() => {});
    console.log('[CHEESE EYES] 유튜브 추천영상 새 탭 가로챔(chrome.tabs.onCreated) ->', videoId);
    return 'intercepted';
  };

  if ((await tryHandle(tab.pendingUrl || tab.url)) !== 'pending') return;

  // 생성 직후엔 URL이 비어 있을 수 있어 최대 3초 onUpdated로 기다린다.
  await new Promise((resolve) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 3000);
    function listener(updatedTabId, changeInfo) {
      if (updatedTabId !== tab.id || settled) return;
      const url = changeInfo.url || changeInfo.pendingUrl;
      if (!url) return;
      tryHandle(url).then((result) => {
        if (result === 'pending') return;
        settled = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      });
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

chrome.tabs.onCreated.addListener((tab) => {
  interceptYoutubeSuggestionNewTab(tab).catch((err) => {
    console.warn('[CHEESE EYES] 유튜브 추천영상 새 탭 가로채기 실패:', err);
  });
});

// ── 사이드바 '멀티뷰에 추가' 트레이 ── 시청 페이지에서 담은 영상 목록(전역, storage.session).
// UI는 multiview_sidebar.js가 페이지 안에 그리는 오버레이(sidePanel은 우클릭·제스처 제약으로 포기).
const DASHBOARD_PAGE_PATH = 'src/html/dashboard.html';
const STAGED_STORAGE_KEY = 'staged_items';

// dashboard.js parseDirectInput의 페이지 URL 전용 단순화 버전.
function parsePageUrlToChannelRef(pageUrl, isLikelyLive) {
  let u;
  try {
    u = new URL(pageUrl);
  } catch (e) {
    return null;
  }
  const host = u.hostname;

  if (host === 'chzzk.naver.com') {
    const liveMatch = u.pathname.match(/^\/live\/([a-f0-9]{32})/i);
    if (liveMatch) return { platform: 'chzzk', id: liveMatch[1] };
    // VOD는 isVod로 구분해 넘긴다.
    const vodMatch = u.pathname.match(/^\/video\/(\d+)/);
    if (vodMatch) return { platform: 'chzzk', id: vodMatch[1], isVod: true };
    return null;
  }

  // 숲 VOD는 제3자 iframe에서 재생이 안 돼 미지원.
  if (host === 'vod.sooplive.com' || host === 'vod.sooplive.co.kr') {
    return null;
  }

  if (host.endsWith('sooplive.com') || host.endsWith('sooplive.co.kr') || host.endsWith('afreecatv.com')) {
    const parts = u.pathname.split('/').filter(Boolean);
    if (!parts[0]) return null;
    const broadNo = /^\d+$/.test(parts[1] || '') ? parts[1] : undefined;
    return { platform: 'soop', id: parts[0], broadNo };
  }

  if (host === 'www.youtube.com' || host === 'youtube.com') {
    // 채널 URL은 채널 추적(videoId 자동 갱신·오프라인 삭제 대상). ?v=보다 먼저 검사.
    const channelMatch = u.pathname.match(/^\/channel\/(UC[a-zA-Z0-9_-]{22})/);
    if (channelMatch) return { platform: 'youtube', id: channelMatch[1] };

    // /@handle 채널 URL은 '@'를 붙인 채 id로 넘긴다.
    const handleMatch = u.pathname.match(/^\/(@[a-zA-Z0-9._-]{3,30})/);
    if (handleMatch) return { platform: 'youtube', id: handleMatch[1] };

    // ?v= URL은 multiview_trigger.js의 isLikelyLive를 믿는다. 없으면 VOD로 태깅하지 않는다(자동 삭제에서 빠지는 것보다 안전).
    const videoId = u.searchParams.get('v');
    if (videoId) return { platform: 'youtube', id: videoId, isVod: isLikelyLive === false };
    const liveMatch = u.pathname.match(/^\/live\/([a-zA-Z0-9_-]{11})/);
    return liveMatch ? { platform: 'youtube', id: liveMatch[1] } : null;
  }

  return null;
}

async function getStagedItems() {
  const data = await chrome.storage.session.get(STAGED_STORAGE_KEY);
  return data[STAGED_STORAGE_KEY] || [];
}

async function setStagedItems(items) {
  await chrome.storage.session.set({ [STAGED_STORAGE_KEY]: items });
}

// 모든 탭의 트레이에 tabs.sendMessage로 알린다(runtime.sendMessage는 콘텐츠 스크립트에 보장되지 않음).
async function notifyStagedUpdated() {
  chrome.runtime.sendMessage({ type: 'STAGED_UPDATED' }).catch(() => {});
  try {
    const tabs = await chrome.tabs.query({});
    tabs.forEach((t) => {
      if (t.id != null) chrome.tabs.sendMessage(t.id, { type: 'STAGED_UPDATED' }).catch(() => {});
    });
  } catch (e) {}
}

// 변경 작업을 큐로 직렬화한다(탭 간 read-modify-write 경쟁).
let stagedWriteQueue = Promise.resolve();
function enqueueStagedWrite(fn) {
  const result = stagedWriteQueue.then(fn, fn);
  stagedWriteQueue = result.then(() => {}, () => {});
  return result;
}

async function addToMultiviewFromTab(tab, options) {
  const { thumbnail, linkUrl, hintTitle } = options || {};
  if (!tab || tab.id == null) return { ok: false, reason: 'no_tab' };
  // 미리보기 카드면 링크 href를 우선, 실패하면 탭 URL.
  const ref = (linkUrl && parsePageUrlToChannelRef(linkUrl))
    || (tab.url && parsePageUrlToChannelRef(tab.url));
  if (!ref) return { ok: false, reason: 'unsupported_page' };

  return enqueueStagedWrite(async () => {
    const items = await getStagedItems();
    const existing = items.find((it) => it.platform === ref.platform && it.id === ref.id);
    if (!existing) {
      items.push({
        platform: ref.platform,
        id: ref.id,
        broadNo: ref.broadNo,
        isVod: !!ref.isVod,
        title: hintTitle || tab.title || ref.id,
        thumbnail: thumbnail || null,
        addedAt: Date.now()
      });
      await setStagedItems(items);
    } else if (thumbnail) {
      existing.thumbnail = thumbnail;
      await setStagedItems(items);
    }
    notifyStagedUpdated();
    return { ok: true, duplicate: !!existing };
  });
}

async function removeStagedItem(index) {
  return enqueueStagedWrite(async () => {
    const items = await getStagedItems();
    if (index >= 0 && index < items.length) {
      items.splice(index, 1);
      await setStagedItems(items);
      notifyStagedUpdated();
    }
    return { ok: true, items };
  });
}

// 항목 키는 platform+id(순서가 바뀌어도 안정적).
function stagedItemKey(it) { return `${it.platform}:${it.id}`; }

// 드래그 순서는 키 배열로 재구성하고, order에 없는 항목은 맨 뒤에 붙인다.
async function reorderStaged(order) {
  return enqueueStagedWrite(async () => {
    if (!Array.isArray(order) || order.length === 0) return { ok: false };
    const items = await getStagedItems();
    const byKey = new Map(items.map((it) => [stagedItemKey(it), it]));
    const reordered = [];
    order.forEach((key) => {
      if (byKey.has(key)) {
        reordered.push(byKey.get(key));
        byKey.delete(key);
      }
    });
    byKey.forEach((it) => reordered.push(it));
    await setStagedItems(reordered);
    notifyStagedUpdated();
    return { ok: true };
  });
}

async function sendStagedToMultiview(selectedKeys, triggerWindowId) {
  return enqueueStagedWrite(async () => {
    const items = await getStagedItems();
    // selectedKeys가 없으면 전부 보낸다.
    const toSend = Array.isArray(selectedKeys)
      ? items.filter((it) => selectedKeys.includes(stagedItemKey(it)))
      : items;
    if (!toSend.length) return { ok: false, reason: 'empty' };

    // 트리거한 크롬 창의 대시보드 창 몫으로 태그한다(§3.3).
    const ownerSlot = triggerWindowId != null ? await findDashboardSlotInWindow(triggerWindowId) : null;
    const taggedToSend = ownerSlot ? toSend.map((it) => ({ ...it, ownerSlotId: ownerSlot.slotId })) : toSend;

    const dashboardUrl = chrome.runtime.getURL(DASHBOARD_PAGE_PATH);
    const existingTabs = await chrome.tabs.query({ url: dashboardUrl + '*' });

    // storage에 먼저 남기고(새 탭 로드용), 열린 탭엔 메시지로 즉시 처리시킨다. 받을 대시보드 창을 앞으로 가져온다.
    await chrome.storage.session.set({ pending_multiview_add: taggedToSend });

    if (existingTabs.length > 0) {
      const dashTab = (ownerSlot && existingTabs.find((t) => t.id === ownerSlot.tabId)) || existingTabs[0];
      await chrome.runtime.sendMessage({ type: 'MULTIVIEW_PENDING_ADD_READY' }).catch(() => {});
      await chrome.tabs.update(dashTab.id, { active: true });
      await chrome.windows.update(dashTab.windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: dashboardUrl });
    }

    const sentKeys = new Set(toSend.map(stagedItemKey));
    const remaining = items.filter((it) => !sentKeys.has(stagedItemKey(it)));
    await setStagedItems(remaining);
    notifyStagedUpdated();
    return { ok: true };
  });
}

// '대기열에 추가' — 유튜브 항목만 보내고 나머지는 트레이에 남긴다.
async function sendStagedToQueue(selectedKeys) {
  return enqueueStagedWrite(async () => {
    const items = await getStagedItems();
    const eligiblePool = items.filter((it) => it.platform === 'youtube');
    const eligible = Array.isArray(selectedKeys)
      ? eligiblePool.filter((it) => selectedKeys.includes(stagedItemKey(it)))
      : eligiblePool;
    if (!eligible.length) return { ok: false, reason: 'no_youtube_items' };

    const dashboardUrl = chrome.runtime.getURL(DASHBOARD_PAGE_PATH);
    const existingTabs = await chrome.tabs.query({ url: dashboardUrl + '*' });

    await chrome.storage.session.set({ pending_queue_add: eligible });

    if (existingTabs.length > 0) {
      const dashTab = existingTabs[0];
      await chrome.runtime.sendMessage({ type: 'QUEUE_PENDING_ADD_READY' }).catch(() => {});
      await chrome.tabs.update(dashTab.id, { active: true });
      await chrome.windows.update(dashTab.windowId, { focused: true });
    } else {
      await chrome.tabs.create({ url: dashboardUrl });
    }

    const sentKeys = new Set(eligible.map(stagedItemKey));
    const remaining = items.filter((it) => !sentKeys.has(stagedItemKey(it)));
    await setStagedItems(remaining);
    notifyStagedUpdated();
    return { ok: true };
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return false;

  if (message.type === 'PROXY_FETCH') {
    const { url, init, requiresAuth } = message;
    if (!isAllowedUrl(url)) {
      sendResponse({ ok: false, status: 0, statusText: '허용되지 않은 도메인', body: '' });
      return false;
    }
    (async () => {
      try {
        const { hostname } = new URL(url);
        if (hostname === 'www.youtube.com' && url.includes('/youtubei/v1/')) {
          let finalInit = init || {};
          if (requiresAuth) {
            try {
              const authHeader = await buildYoutubeSapisidHashHeader();
              if (authHeader) {
                finalInit = { ...finalInit, headers: { ...(finalInit.headers || {}), ...authHeader } };
              }
            } catch (authErr) {
              console.warn('[CHEESE EYES] 유튜브 인증 헤더 생성 실패, 비로그인 상태로 요청 진행:', authErr);
            }
            // 로그인 필요 요청은 익명 offscreen이 아니라 실제 유튜브 탭에서 실행한다(익명 파티션에 로그인 쿠키를 넣으면 프록시 전체가 막혔다).
            const result = await sendToYoutubeTabProxy(url, finalInit);
            sendResponse(result);
            return;
          }
          const result = await sendToOffscreenYoutubeProxy(url, finalInit);
          sendResponse(result);
          return;
        }
        const res = await fetch(url, init || {});
        const body = await res.text();
        sendResponse({ ok: res.ok, status: res.status, statusText: res.statusText, body });
      } catch (err) {
        sendResponse({ ok: false, status: 0, statusText: String((err && err.message) || err), body: '' });
      }
    })();

    return true;
  }

  if (message.type === 'CHECK_LOGIN_COOKIE') {
    const { url, names } = message;
    (async () => {
      try {
        for (const name of names || []) {
          const cookie = await chrome.cookies.get({ url, name });
          if (cookie && cookie.value) {
            sendResponse({ ok: true, loggedIn: true, name });
            return;
          }
        }
        sendResponse({ ok: true, loggedIn: false });
      } catch (err) {
        console.error('[CHEESE EYES] CHECK_LOGIN_COOKIE 실패:', err);
        sendResponse({ ok: false, loggedIn: false, error: String((err && err.message) || err) });
      }
    })();

    return true;
  }

  if (message.type === 'GET_SOOP_SESSION_KEY') {
    (async () => {
      try {
        const cookie = await chrome.cookies.get({ url: 'https://www.sooplive.com/', name: 'sck_session_key' });
        sendResponse({ ok: true, value: cookie ? cookie.value : '' });
      } catch (err) {
        sendResponse({ ok: false, value: '' });
      }
    })();

    return true;
  }

  if (message.type === 'SOOP_LOGOUT') {
    (async () => {
      try {
        for (const name of SOOP_AUTH_COOKIE_NAMES) {
          try {
            const raw = await chrome.cookies.get({ url: 'https://www.sooplive.com/', name });
            if (raw) {
              const url = cookieHostUrl(raw.domain, raw.path);
              await chrome.cookies.remove({ url, name });
            }
          } catch (e) {}
          try {
            const part = await chrome.cookies.get({ url: 'https://www.sooplive.com/', name, partitionKey: soopPartitionKey });
            if (part) {
              const url = cookieHostUrl(part.domain, part.path);
              await chrome.cookies.remove({ url, name, partitionKey: soopPartitionKey });
            }
          } catch (e) {}
        }
        sendResponse({ ok: true });
      } catch (err) {
        sendResponse({ ok: false, error: String((err && err.message) || err) });
      }
    })();
    return true;
  }

  // ADD_TO_MULTIVIEW만 sender.tab이 필요하다.
  if (message.type === 'ADD_TO_MULTIVIEW') {
    const tab = sender && sender.tab;
    if (!tab) { sendResponse({ ok: false, reason: 'no_tab' }); return false; }
    addToMultiviewFromTab(tab, message).then(sendResponse);
    return true;
  }

  if (message.type === 'GET_STAGED') {
    getStagedItems().then((items) => sendResponse({ ok: true, items }));
    return true;
  }

  if (message.type === 'REMOVE_STAGED_ITEM') {
    removeStagedItem(message.index).then(sendResponse);
    return true;
  }

  if (message.type === 'SEND_STAGED_TO_MULTIVIEW') {
    const triggerWindowId = sender && sender.tab ? sender.tab.windowId : null;
    sendStagedToMultiview(message.keys, triggerWindowId).then(sendResponse);
    return true;
  }

  if (message.type === 'SEND_STAGED_TO_QUEUE') {
    sendStagedToQueue(message.keys).then(sendResponse);
    return true;
  }

  if (message.type === 'REORDER_STAGED') {
    reorderStaged(message.order).then(sendResponse);
    return true;
  }

  if (message.type === 'OPEN_LOGIN_POPUP') {
    const { url, width, height } = message;
    const popupWidth = width || 500;
    const popupHeight = height || 650;
    (async () => {
      try {
        let left;
        let top;
        try {
          const parentWindowId = sender && sender.tab ? sender.tab.windowId : (await chrome.windows.getCurrent()).id;
          const parentWin = await chrome.windows.get(parentWindowId);
          left = Math.round(parentWin.left + (parentWin.width - popupWidth) / 2);
          top = Math.round(parentWin.top + (parentWin.height - popupHeight) / 2);
        } catch (posErr) {
          left = undefined;
          top = undefined;
        }

        const win = await chrome.windows.create({
          url,
          type: 'popup',
          width: popupWidth,
          height: popupHeight,
          ...(left != null && top != null ? { left, top } : {}),
          focused: true
        });

        pinnedPopupWindows.set(win.id, {
          left: win.left != null ? win.left : left,
          top: win.top != null ? win.top : top
        });

        sendResponse({ ok: true, windowId: win.id });
      } catch (err) {
        console.error('[CHEESE EYES] OPEN_LOGIN_POPUP 실패:', err);
        sendResponse({ ok: false, error: String((err && err.message) || err) });
      }
    })();

    return true;
  }

  // 창 등록·소유 창 기록은 여기서만 한다(여러 창이 직접 쓰면 덮어씀, §3.1).
  if (message.type === 'DASHBOARD_WINDOW_REGISTER') {
    const tab = sender && sender.tab;
    if (!tab || tab.id == null) { sendResponse({ ok: false, reason: 'no_tab' }); return false; }
    return respondAsync(registerDashboardWindow(typeof message.slotId === 'string' ? message.slotId : null, tab), sendResponse);
  }

  if (message.type === 'CHANNEL_CLAIM_OWNER') {
    if (typeof message.slotId !== 'string' || !Array.isArray(message.hashes)) { sendResponse({ ok: false }); return false; }
    return respondAsync(claimChannelOwners(message.slotId, message.hashes), sendResponse);
  }

  if (message.type === 'SET_REPRESENTATIVE' || message.type === 'FOCUS_DASHBOARD_WINDOW') {
    if (typeof message.slotId !== 'string') { sendResponse({ ok: false }); return false; }
    const run = message.type === 'SET_REPRESENTATIVE' ? setRepresentativeSlot : focusDashboardSlot;
    return respondAsync(run(message.slotId), sendResponse);
  }

  return false;
});

const pinnedPopupWindows = new Map();
chrome.windows.onBoundsChanged.addListener((win) => {
  const pinned = pinnedPopupWindows.get(win.id);
  if (!pinned || pinned.left == null || pinned.top == null) return;
  const driftedX = Math.abs(win.left - pinned.left) > 2;
  const driftedY = Math.abs(win.top - pinned.top) > 2;
  if (!driftedX && !driftedY) return;
  chrome.windows.update(win.id, { left: pinned.left, top: pinned.top }).catch(() => {});
});

// ── 다중 창 등록부(§3.1, §3.4, §3.5) ── 창마다 slotId, channel_owner, representative_slot(전부 storage.session).
// 창 생존은 tabs.onRemoved로만 판단(새로고침엔 안 옴). 소유 기록은 창이 닫혀도 남겨 같은 slotId로 되살린다.
let windowRegistryWriteChain = Promise.resolve();

function respondAsync(promise, sendResponse) {
  promise.then(sendResponse).catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
  return true;
}

function enqueueWindowRegistryWrite(fn) {
  const run = windowRegistryWriteChain.then(fn, fn);
  windowRegistryWriteChain = run.catch(() => {});
  return run;
}

function pickRepresentativeSlot(registry, current) {
  if (current && registry[current]) return current;
  const slots = Object.keys(registry).sort((a, b) => (registry[a].openedAt || 0) - (registry[b].openedAt || 0));
  return slots[0] || null;
}

async function pruneClosedDashboardWindows(registry) {
  for (const [slotId, entry] of Object.entries(registry)) {
    try {
      await chrome.tabs.get(entry.tabId);
    } catch (e) {
      delete registry[slotId];
    }
  }
}

function registerDashboardWindow(requestedSlotId, tab) {
  return enqueueWindowRegistryWrite(async () => {
    const stored = await chrome.storage.session.get(['cheese_windows', 'representative_slot', 'channel_owner']);
    const registry = { ...(stored.cheese_windows || {}) };
    const owners = { ...(stored.channel_owner || {}) };
    let representative = stored.representative_slot || null;
    await pruneClosedDashboardWindows(registry);

    let slotId = requestedSlotId;
    // 탭 복제는 같은 slotId를 들고 오므로 다른 탭이 쓰는 ID면 새로 발급한다.
    if (!slotId || (registry[slotId] && registry[slotId].tabId !== tab.id)) slotId = crypto.randomUUID();
    // 같은 탭이 다른 ID로 재등록하면 예전 항목의 채널과 대표 자리를 넘겨받는다.
    for (const [otherSlot, entry] of Object.entries(registry)) {
      if (otherSlot === slotId || entry.tabId !== tab.id) continue;
      Object.keys(owners).forEach((hash) => { if (owners[hash] === otherSlot) owners[hash] = slotId; });
      if (representative === otherSlot) representative = slotId;
      delete registry[otherSlot];
    }

    registry[slotId] = {
      tabId: tab.id,
      windowId: tab.windowId,
      openedAt: (registry[slotId] && registry[slotId].openedAt) || Date.now()
    };
    representative = pickRepresentativeSlot(registry, representative);
    await chrome.storage.session.set({ cheese_windows: registry, representative_slot: representative, channel_owner: owners });
    return { ok: true, slotId };
  });
}

function claimChannelOwners(slotId, hashes) {
  return enqueueWindowRegistryWrite(async () => {
    const { channel_owner } = await chrome.storage.session.get('channel_owner');
    const owners = { ...(channel_owner || {}) };
    hashes.forEach((hash) => { if (typeof hash === 'string' && hash) owners[hash] = slotId; });
    await chrome.storage.session.set({ channel_owner: owners });
    return { ok: true };
  });
}

function unregisterDashboardTab(tabId) {
  return enqueueWindowRegistryWrite(async () => {
    const stored = await chrome.storage.session.get(['cheese_windows', 'representative_slot']);
    const registry = { ...(stored.cheese_windows || {}) };
    const removedSlots = Object.keys(registry).filter((slotId) => registry[slotId].tabId === tabId);
    if (removedSlots.length === 0) return;
    removedSlots.forEach((slotId) => { delete registry[slotId]; });
    await chrome.storage.session.set({
      cheese_windows: registry,
      representative_slot: pickRepresentativeSlot(registry, stored.representative_slot)
    });
  });
}

// 계정 잠금 서버를 쓰던 버전(~1.3.2)이 남긴 값을 지운다.
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.remove(['profile_lock_session_id', 'profile_locked_keys']).catch(() => {});
  chrome.storage.session.remove('lock_blocked_platforms').catch(() => {});
});

// "보내기"를 누른 크롬 창의 대시보드 창(실제 windowId로 확인).
async function findDashboardSlotInWindow(windowId) {
  const { cheese_windows } = await chrome.storage.session.get('cheese_windows');
  for (const [slotId, entry] of Object.entries(cheese_windows || {})) {
    try {
      const tab = await chrome.tabs.get(entry.tabId);
      if (tab.windowId === windowId) return { slotId, tabId: entry.tabId };
    } catch (e) {
    }
  }
  return null;
}

// 대표만 바꾼다 — 소유 기록 없는 채널은 먼저 지금 대표 창 소유로 못박는다(안 그러면 새 대표로 통째로 넘어감).
function setRepresentativeSlot(slotId) {
  return enqueueWindowRegistryWrite(async () => {
    const stored = await chrome.storage.session.get(['cheese_windows', 'representative_slot', 'channel_owner']);
    const registry = stored.cheese_windows || {};
    if (!registry[slotId]) return { ok: false, reason: 'unknown_slot' };
    const currentRepresentative = stored.representative_slot;
    const owners = { ...(stored.channel_owner || {}) };
    if (currentRepresentative && registry[currentRepresentative] && currentRepresentative !== slotId) {
      const { my_channels } = await chrome.storage.local.get('my_channels');
      (my_channels || []).forEach((channel) => {
        if (!channel || !channel.hash) return;
        const owner = owners[channel.hash];
        if (!owner || !registry[owner]) owners[channel.hash] = currentRepresentative;
      });
    }
    await chrome.storage.session.set({ representative_slot: slotId, channel_owner: owners });
    return { ok: true };
  });
}

async function focusDashboardSlot(slotId) {
  const { cheese_windows } = await chrome.storage.session.get('cheese_windows');
  const entry = cheese_windows && cheese_windows[slotId];
  if (!entry) return { ok: false, reason: 'unknown_slot' };
  const tab = await chrome.tabs.update(entry.tabId, { active: true });
  await chrome.windows.update(tab.windowId, { focused: true });
  return { ok: true };
}

chrome.tabs.onRemoved.addListener((tabId) => {
  unregisterDashboardTab(tabId).catch((err) => console.warn('[CHEESE EYES] 대시보드 창 등록 해제 실패:', err));
});

chrome.windows.onRemoved.addListener((windowId) => {
  pinnedPopupWindows.delete(windowId);
  chrome.runtime.sendMessage({ type: 'LOGIN_POPUP_CLOSED', windowId }).catch(() => {});
});
const SOOP_AUTH_COOKIE_NAMES = ['AuthTicket', 'UserTicket', 'sck_session_key', 'RDB'];
const soopPartitionKey = { topLevelSite: `chrome-extension://${chrome.runtime.id}` };

function cookieHostUrl(domain, path) {
  const host = domain.startsWith('.') ? `www${domain}` : domain;
  return `https://${host}${path}`;
}

async function syncPartitionedCookies(baseUrl, names, partitionKey) {
  for (const name of names) {
    let cookie;
    try {
      cookie = await chrome.cookies.get({ url: baseUrl, name });
    } catch (err) {
      console.error(`[CHEESE EYES] ${name} 쿠키 조회 실패:`, err);
      continue;
    }
    if (!cookie) continue;
    if (cookie.partitionKey != null) continue;
    const url = cookieHostUrl(cookie.domain, cookie.path);
    try {
      await chrome.cookies.set({
        url,
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        secure: true,
        httpOnly: cookie.httpOnly,
        sameSite: 'no_restriction',
        expirationDate: cookie.expirationDate,
        partitionKey
      });
    } catch (err) {
      console.error(`[CHEESE EYES] ${cookie.name} 파티션 쿠키 동기화 실패:`, err);
    }
  }
}

async function syncSoopPartitionedCookies() {
  await syncPartitionedCookies('https://www.sooplive.com/', SOOP_AUTH_COOKIE_NAMES, soopPartitionKey);
}

chrome.cookies.onChanged.addListener((changeInfo) => {
  const c = changeInfo.cookie;
  if (c.partitionKey != null) return;

  const isSoop = c.domain && c.domain.includes('sooplive.com') && SOOP_AUTH_COOKIE_NAMES.includes(c.name);
  if (!isSoop) return;

  if (changeInfo.removed) {
    (async () => {
      try {
        const url = cookieHostUrl(c.domain, c.path);
        await chrome.cookies.remove({ url, name: c.name, partitionKey: soopPartitionKey });
      } catch (err) {
        console.error(`[CHEESE EYES] ${c.name} 파티션 쿠키 삭제 실패:`, err);
      }
    })();
    return;
  }

  syncSoopPartitionedCookies();
});

chrome.runtime.onInstalled.addListener(syncSoopPartitionedCookies);
chrome.runtime.onStartup.addListener(syncSoopPartitionedCookies);
syncSoopPartitionedCookies();

const YOUTUBE_AUTH_COOKIE_NAMES = [
  'SID', 'HSID', 'SSID', 'APISID', 'SAPISID', 'LOGIN_INFO',
  '__Secure-1PAPISID', '__Secure-1PSID', '__Secure-1PSIDCC', '__Secure-1PSIDTS',
  '__Secure-3PAPISID', '__Secure-3PSID', '__Secure-3PSIDCC', '__Secure-3PSIDTS'
];
const youtubePartitionKey = { topLevelSite: `chrome-extension://${chrome.runtime.id}` };

// 이 파티션엔 로그인 쿠키를 남기지 않는다(로그인 쿠키를 실은 숨은 embed가 이상 탐지에 걸려 프록시 전체가 막혔다).
async function clearYoutubePartitionedCookies() {
  for (const name of YOUTUBE_AUTH_COOKIE_NAMES) {
    try {
      const cookie = await chrome.cookies.get({ url: 'https://www.youtube.com/', name, partitionKey: youtubePartitionKey });
      if (cookie) {
        const url = cookieHostUrl(cookie.domain, cookie.path);
        await chrome.cookies.remove({ url, name, partitionKey: youtubePartitionKey });
      }
    } catch (err) {
      console.error(`[CHEESE EYES] ${name} 유튜브 파티션 쿠키 정리 실패:`, err);
    }
  }
}

chrome.runtime.onInstalled.addListener(clearYoutubePartitionedCookies);
chrome.runtime.onStartup.addListener(clearYoutubePartitionedCookies);
clearYoutubePartitionedCookies();

const OFFSCREEN_DOCUMENT_URL = 'src/html/offscreen.html';
let creatingOffscreenDocument = null;

async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_URL)]
  });
  if (existingContexts.length > 0) return;

  if (creatingOffscreenDocument) {
    await creatingOffscreenDocument;
    return;
  }

  creatingOffscreenDocument = chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_URL,
    reasons: ['IFRAME_SCRIPTING'],
    justification: '유튜브 로그인 세션과 동일한 origin(https://www.youtube.com) 컨텍스트에서 InnerTube 요청을 실행하기 위함'
  });
  try {
    await creatingOffscreenDocument;
  } finally {
    creatingOffscreenDocument = null;
  }
}

async function sendToOffscreenYoutubeProxy(url, init) {
  try {
    await ensureOffscreenDocument();
    const result = await chrome.runtime.sendMessage({ type: 'OFFSCREEN_YT_FETCH', url, init });
    if (!result) {
      return { ok: false, status: 0, statusText: 'offscreen 프록시 응답 없음', body: '' };
    }
    return result;
  } catch (err) {
    return { ok: false, status: 0, statusText: String((err && err.message) || err), body: '' };
  }
}

// 로그인 필요 InnerTube 요청을 실제 유튜브 탭에서 실행한다(열린 탭 재사용, 없으면 비활성 탭 하나를 열어 재사용).
let cachedYoutubeTabId = null;

function waitForTabComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('youtube_tab_load_timeout'));
    }, timeoutMs);

    function listener(updatedTabId, changeInfo) {
      if (updatedTabId !== tabId || changeInfo.status !== 'complete') return;
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }
    chrome.tabs.onUpdated.addListener(listener);

    chrome.tabs.get(tabId).then((tab) => {
      if (settled) return;
      if (tab && tab.status === 'complete') {
        settled = true;
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }).catch(() => {});
  });
}

async function getOrCreateYoutubeTab() {
  if (cachedYoutubeTabId != null) {
    try {
      const tab = await chrome.tabs.get(cachedYoutubeTabId);
      if (tab && tab.url && /(^|\.)youtube\.com$/.test(new URL(tab.url).hostname)) {
        return cachedYoutubeTabId;
      }
    } catch (e) {
    }
    cachedYoutubeTabId = null;
  }

  try {
    const tabs = await chrome.tabs.query({ url: ['https://www.youtube.com/*', 'https://youtube.com/*'] });
    const usable = tabs.find(t => t.id != null && t.status === 'complete');
    if (usable) {
      cachedYoutubeTabId = usable.id;
      return cachedYoutubeTabId;
    }
  } catch (err) {
    console.warn('[CHEESE EYES] 기존 유튜브 탭 조회 실패:', err);
  }

  const created = await chrome.tabs.create({ url: 'https://www.youtube.com/', active: false });
  await waitForTabComplete(created.id);
  cachedYoutubeTabId = created.id;
  return cachedYoutubeTabId;
}

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === cachedYoutubeTabId) cachedYoutubeTabId = null;
});

async function sendToYoutubeTabProxy(url, init) {
  try {
    const tabId = await getOrCreateYoutubeTab();
    const injection = await chrome.scripting.executeScript({
      target: { tabId },
      func: async (fetchUrl, fetchInit) => {
        try {
          const res = await fetch(fetchUrl, { ...(fetchInit || {}), credentials: 'include' });
          const body = await res.text();
          return { ok: res.ok, status: res.status, statusText: res.statusText, body };
        } catch (err) {
          return { ok: false, status: 0, statusText: String((err && err.message) || err), body: '' };
        }
      },
      args: [url, init]
    });
    const result = injection && injection[0] && injection[0].result;
    if (!result) {
      return { ok: false, status: 0, statusText: '유튜브 탭 프록시 응답 없음', body: '' };
    }
    return result;
  } catch (err) {
    console.error('[CHEESE EYES] 유튜브 탭 프록시 실패:', err);
    return { ok: false, status: 0, statusText: String((err && err.message) || err), body: '' };
  }
}

async function sha1Hex(text) {
  const encoded = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest('SHA-1', encoded);
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function buildYoutubeSapisidHashHeader() {
  let cookie = await chrome.cookies.get({ url: 'https://www.youtube.com/', name: 'SAPISID' });
  if (!cookie) {
    cookie = await chrome.cookies.get({ url: 'https://www.youtube.com/', name: '__Secure-3PAPISID' });
  }
  if (!cookie || !cookie.value) return null;

  const timestamp = Math.floor(Date.now() / 1000);
  const origin = 'https://www.youtube.com';
  const digest = await sha1Hex(`${timestamp} ${cookie.value} ${origin}`);

  return {
    Authorization: `SAPISIDHASH ${timestamp}_${digest}`,
    'X-Origin': origin
  };
}